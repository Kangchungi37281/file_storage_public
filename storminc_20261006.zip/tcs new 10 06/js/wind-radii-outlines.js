// Shared warning-map and legend outlines; deliberately no area fill.
export const WARNING_WIND_RADII = Object.freeze([
    {kt:34,color:'#ff5a36',width:1.5},
    {kt:50,color:'#991b1b',width:2},
    {kt:64,color:'#d946ef',width:2.5}
]);
export function drawWindRadiiOutlines(ctx, bands) {
    const visible = bands.filter(band => band.path).slice().sort((a,b)=>a.kt-b.kt);
    ctx.save();ctx.setLineDash([]);
    for(const band of visible) {
        ctx.strokeStyle=band.color;ctx.lineWidth=band.width;
        ctx.stroke(band.path);
    }
    ctx.restore();
}
