/**
 * forecast-models.js
 * 负责生成各种数值模型的预报数据。
 * [修正版] 修复陆地检测逻辑，检测"预报点"而非"初始点"
 */
import { normalizeLongitude } from './utils.js';
import { advanceStormOcean, oceanThermodynamicMpi } from './ocean-thermal.js?v=20261006-variability2';
import { calculateSteering, updatePressureSystems, getStormDepthFactor, integrateStormMotion, createGeopotentialHeight500Sampler } from './cyclone-model.js?v=20261006-forecast-layer3-raster1';
import { calculateBackgroundHumidity } from './visualization.js?v=20261006-forecast-layer3-raster1';

// [辅助] 坐标清洗
function wrap180(lon) {
    lon = lon % 360;
    return (lon > 180) ? lon - 360 : (lon < -180 ? lon + 360 : lon);
}

function createSeededForecastRandom(seed) {
    let state = seed >>> 0;
    return () => {
        state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
        return state / 4294967296;
    };
}

function* forecastSteps(cyclone, pressureSystems, checkLandFunc = null,
    globalTemp = 289, globalShearSetting = 100, randomSeed = null, options = {}) {
    if (cyclone.isExtratropical) {
        return [];
    }
    const random = Number.isFinite(randomSeed)
        ? createSeededForecastRandom(randomSeed)
        : Math.random;
    const forecasts = [];
    
    // 模型定义
    const models = [
        { name: "ENAI", bias: { u: 0.5, v: 0.6 } },
    ];

    // 参数配置
    const PATH_STEP_HOURS = 3;
    const INTENSITY_STEP_HOURS = 6;
    const TOTAL_HOURS = 72; // 预测时长
    // Forecast steering has no per-step phase solve, so mirror the analysis
    // completion proxy instead of imposing a fixed wall-clock dwell.
    const FORECAST_ET_PROGRESS_MAX_HOURS = 36;
    const smoothstep01 = value => {
        const t = Math.max(0, Math.min(1, value));
        return t * t * (3 - 2 * t);
    };
    
    const STEPS_PER_INTENSITY_UPDATE = INTENSITY_STEP_HOURS / PATH_STEP_HOURS; 
    const TOTAL_STEPS = TOTAL_HOURS / PATH_STEP_HOURS; 

    // A Worker receives a structured-clone that is already private to that
    // Worker. Cloning it a second time with JSON on every advisory created a
    // large allocation/GC spike at the 6-hour forecast cycle. The synchronous
    // fallback still clones defensively because it shares the live UI state.
    const inputsOwnedByCaller = options?.inputsOwned === true;
    const profile = options?.profile === true;
    const profileStartedAt = profile ? performance.now() : 0;
    const profileTotals = profile ? {
        atmosphere: 0,
        steering: 0,
        motion: 0,
        intensity: 0,
        humidity: 0,
        compute: 0,
        steps: 0,
        intensitySteps: 0
    } : null;
    for (const model of models) {
        let tempCyclone = inputsOwnedByCaller
            ? { ...cyclone }
            : JSON.parse(JSON.stringify(cyclone));
        let tempPressureSystems = inputsOwnedByCaller
            ? pressureSystems
            : JSON.parse(JSON.stringify(pressureSystems));

        const heightSamplers = {
            850: createGeopotentialHeight500Sampler(tempPressureSystems, 850),
            500: createGeopotentialHeight500Sampler(tempPressureSystems, 500),
            200: createGeopotentialHeight500Sampler(tempPressureSystems, 200)
        };
        
        let track = [[tempCyclone.lon, tempCyclone.lat, tempCyclone.intensity, tempCyclone.isTransitioning, tempCyclone.isExtratropical]];

        let lastCalculatedIntensity = tempCyclone.intensity;
        const startAge = tempCyclone.age || 0;
        for(let t = 1; t <= TOTAL_STEPS; t++) { 
            const stepStartedAt = profile ? performance.now() : 0;
            // 1. 路径计算 (3小时/步)
            updatePressureSystems(tempPressureSystems, cyclone.currentMonth);
            if (profile) profileTotals.atmosphere += performance.now() - stepStartedAt;
            // All three steering layers sample the same immutable atmosphere
            // for this 3-hour substep. Build the evaluator contexts once and
            // reuse them for both the endpoint and midpoint diagnoses.
            // A forecast issued during ET must continue that structural
            // clock. Freezing `isTransitioning` for all 72 hours leaves a
            // midlatitude system indefinitely half-coupled to tropical and
            // extratropical steering, which can produce loops in weak flow.
            if (tempCyclone.isTransitioning) {
                tempCyclone.transitionHours = Math.min(
                    FORECAST_ET_PROGRESS_MAX_HOURS,
                    (tempCyclone.transitionHours || 0) + PATH_STEP_HOURS
                );
                tempCyclone.transitionElapsedHours = Math.min(
                    FORECAST_ET_PROGRESS_MAX_HOURS,
                    (Number.isFinite(tempCyclone.transitionElapsedHours)
                        ? tempCyclone.transitionElapsedHours : 0) + PATH_STEP_HOURS
                );
                const transitionProgress = smoothstep01(
                    tempCyclone.transitionHours / FORECAST_ET_PROGRESS_MAX_HOURS
                );
                const upperColdReadiness = Math.min(1,
                    .62 * transitionProgress
                        + .20 * Math.max(0, Math.min(1, tempCyclone.etTrough || 0))
                        + .18 * Math.max(0, Math.min(1, tempCyclone.baroclinicSupport || 0))
                );
                const lowerColdReadiness = smoothstep01(
                    (tempCyclone.transitionHours - 18) / 18
                );
                const baroclinicReadiness = Math.max(
                    Math.max(0, Math.min(1, tempCyclone.baroclinicSupport || 0)),
                    .35 * Math.max(0, Math.min(1, tempCyclone.etFront || 0))
                        * Math.max(0, Math.min(1, tempCyclone.etTrough || 0))
                );
                if (upperColdReadiness >= .55
                    && lowerColdReadiness >= .45
                    && baroclinicReadiness >= .10) {
                    tempCyclone.isTransitioning = false;
                    tempCyclone.isExtratropical = true;
                    tempCyclone.extratropicalAgeHours = 0;
                    tempCyclone.extratropicalStage = 'developing';
                }
            } else if (tempCyclone.isExtratropical) {
                tempCyclone.extratropicalAgeHours =
                    (tempCyclone.extratropicalAgeHours || 0) + PATH_STEP_HOURS;
            }
            const steeringStartedAt = profile ? performance.now() : 0;
            const steering = calculateSteering(tempCyclone.lon, tempCyclone.lat,
                tempPressureSystems, model.bias, getStormDepthFactor(tempCyclone), tempCyclone,
                { heightSamplers });
            if (profile) profileTotals.steering += performance.now() - steeringStartedAt;
            const motionStartedAt = profile ? performance.now() : 0;
            // Keep the second-stage corrector at the 6-hour advisory cadence.
            // The atmosphere is held over each 3-hour substep, so solving a
            // fresh midpoint steering vector on every substep duplicates the
            // same environmental work. Callers can force all midpoint solves
            // (`midpoint: true`) or disable them (`midpoint: false`) for
            // diagnostics.
            const midpointEnabled = options?.midpoint === true
                || (options?.midpoint !== false
                    && t % STEPS_PER_INTENSITY_UPDATE === 0);
            const motion = integrateStormMotion(tempCyclone, tempPressureSystems,
                steering, PATH_STEP_HOURS, {
                    heightSamplers,
                    midpoint: midpointEnabled
                });
            if (profile) profileTotals.motion += performance.now() - motionStartedAt;
            tempCyclone.lon = motion.lon;
            tempCyclone.lat = motion.lat;
            tempCyclone.direction = (Math.atan2(motion.u, motion.v) * 180 / Math.PI + 360) % 360;
            tempCyclone.speed = Math.hypot(motion.u, motion.v) * 1.94384;
            const { shearU, shearV } = steering;

            // Ocean mixing runs at the physical 3-hour cadence, including
            // intervening steps without an intensity advisory. Same column,
            // geographic wake and reservoir setting as the live simulation.
            tempCyclone.age = startAge + t * PATH_STEP_HOURS;
            const isForecastingLand = typeof checkLandFunc === 'function'
                ? checkLandFunc(tempCyclone.lon, tempCyclone.lat) : false;
            const oceanUpdate = advanceStormOcean(tempCyclone, cyclone.currentMonth || 8,
                globalTemp, cyclone.oceanHeatDistribution ?? 50, PATH_STEP_HOURS, isForecastingLand);
            tempCyclone.oceanWake = oceanUpdate.oceanWake;
            tempCyclone.oceanThermal = oceanUpdate.ocean;

            // 2. 强度计算 (12小时/步)
            if (t % STEPS_PER_INTENSITY_UPDATE === 0) {
                const intensityStartedAt = profile ? performance.now() : 0;
                const queryLon = wrap180(tempCyclone.lon);
                
                // [修正核心] 检测"当前预报点"是否在陆地，而不是检测 cyclone.isLand (初始点)
                const sst = oceanUpdate.ocean.sstC;
                let hum = 65.0;
                
                if (!isForecastingLand) {
                    // [关键修改] 安全调用：如果函数存在且运行正常，才覆盖默认值
                    if (typeof calculateBackgroundHumidity === 'function') {
                        const humidityStartedAt = profile ? performance.now() : 0;
                        try {
                            const hVal = calculateBackgroundHumidity(tempCyclone.lon, tempCyclone.lat, tempPressureSystems, cyclone.currentMonth, tempCyclone, globalTemp);
                            // 确保返回值是有效数字
                            if (typeof hVal === 'number' && !isNaN(hVal)) {
                                hum = hVal;
                            }
                        } catch (e) {
                            console.warn("Forecast humidity calc failed, using 65", e);
                            hum = 65.0;
                        }
                        if (profile) profileTotals.humidity += performance.now() - humidityStartedAt;
                    }
                }

                let nextIntensity = lastCalculatedIntensity;

                if (isForecastingLand) {
                    // --- 陆地逻辑 (衰减) ---
                    const frictionDecay = Math.max(5, lastCalculatedIntensity * 0.22); 
                    let naturalDecayResult = lastCalculatedIntensity - frictionDecay;

                    // 强制约束：强度上限 = 上次强度 - 10KT
                    const hardCap = lastCalculatedIntensity - 10;
                    
                    nextIntensity = Math.min(naturalDecayResult, hardCap);
                } else {
                    // --- 海洋逻辑 (增强/维持) ---
                    const thermodynamicMpi = oceanThermodynamicMpi(sst, tempCyclone.isSubtropical);
                    const dryAirPenalty = Math.max(0, 60 - hum) * 0.5;
                    const mpi = Math.max(0, thermodynamicMpi - dryAirPenalty);
                    const safeShearU = Number.isFinite(shearU) ? shearU : 0;
                    const safeShearV = Number.isFinite(shearV) ? shearV : 0;
                    // Steering shear is in m/s; use the same conversion as
                    // updateCycloneState so the forecast and analysis paths
                    // share one physical unit (knots).
                    const physicalShear = Math.hypot(safeShearU, safeShearV) * 1.94384;
                    const totalShear = physicalShear * (globalShearSetting / 100.0);
                    const gap = mpi - lastCalculatedIntensity;
                    const shearLoss = Math.max(0, totalShear - 8) * 0.10;
                    if (gap > 0) {
                        // Relax toward MPI at a positive rate.  Shear is an
                        // additive loss, never a sign flip on the MPI gap.
                        const growthRate = Math.max(
                            0.02,
                            random() * 0.04 + 0.07
                                - 0.9 / Math.max(25, lastCalculatedIntensity)
                        );
                        nextIntensity += gap * growthRate - shearLoss;
                    } else {
                        const decayRate = 0.11 + totalShear * 0.003;
                        nextIntensity += gap * decayRate - shearLoss;
                    }
                    const currentForecastAge = startAge + (t * PATH_STEP_HOURS);
                    
                    if (tempCyclone.shearEventActive && currentForecastAge < tempCyclone.shearEventEndTime) {
                        const shearPenalty = tempCyclone.shearEventMagnitude * (random() + 0.5);
                        nextIntensity -= shearPenalty;
                    }
                }

                nextIntensity = Math.max(15, nextIntensity);
                tempCyclone.intensity = nextIntensity;
                lastCalculatedIntensity = nextIntensity;
                if (profile) profileTotals.intensity += performance.now() - intensityStartedAt;
                if (profile) profileTotals.intensitySteps++;
            } 
            if (profile) profileTotals.steps++;
            
            track.push([
                tempCyclone.lon, 
                tempCyclone.lat, 
                tempCyclone.intensity, 
                tempCyclone.isTransitioning || false, 
                tempCyclone.isExtratropical || false
            ]);
            if (profile) profileTotals.compute += performance.now() - stepStartedAt;
            // Same numerical step; only the asynchronous driver yields the
            // worker event loop here so live atmosphere/radii jobs can run.
            yield;
        }
        forecasts.push({ name: model.name, track: track });
    }
    if (profile) {
        const profileReport = {
            total: Math.round((performance.now() - profileStartedAt) * 10) / 10,
            ...Object.fromEntries(Object.entries(profileTotals)
                .map(([key, value]) => [key, Math.round(value * 10) / 10]))
        };
        // Per-request callback remains isolated when forecasts interleave.
        // total includes cooperative waiting; compute counts active substeps.
        options.onProfile?.(profileReport);
    }
    return forecasts;
}

export function generatePathForecasts(...args) {
    const iterator = forecastSteps(...args);
    let step;
    do { step = iterator.next(); } while (!step.done);
    return step.value;
}

export async function generatePathForecastsAsync(...args) {
    const iterator = forecastSteps(...args);
    let step = iterator.next();
    while (!step.done) {
        // scheduler.yield() resumes with boosted continuation priority and
        // can keep outranking incoming worker messages. A normal task lets
        // live atmosphere/radii messages run between forecast substeps.
        await new Promise(resolve => setTimeout(resolve, 0));
        step = iterator.next();
    }
    return step.value;
}
