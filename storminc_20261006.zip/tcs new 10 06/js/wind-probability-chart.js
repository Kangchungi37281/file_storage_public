import { probabilityIssue, probabilityTimeLabel, buildWindProbability, arrivalSegments,
    PROBABILITY_LEVELS, PROBABILITY_COLORS } from './wind-probability.js';
import { ICWC_MAP_STYLE } from './icwc-map-style.js';
import { prepareICWCGeography } from './icwc-geography.js';
import { cycloneProductName, ICWC_DISCLAIMER } from './icwc-product-labels.js?v=20261003-labels2';

const wrap=x=>((x+180)%360+360)%360-180;
const coordinate=(v,axis)=>`${Math.abs(v).toFixed(1)}°${axis==='lon'?(v<0?'W':'E'):(v<0?'S':'N')}`;
function text(ctx,value,x,y,size=24,weight='normal',maxWidth) {
    ctx.font=`${weight} ${size}px Arial, sans-serif`;
    if(maxWidth && ctx.measureText(value).width>maxWidth) ctx.font=`${weight} ${size*maxWidth/ctx.measureText(value).width}px Arial, sans-serif`;
    ctx.fillText(value,x,y);
}
function symbol(ctx,x,y,intensity,size=16) {
    ctx.save();ctx.translate(x,y);ctx.strokeStyle='#080808';ctx.fillStyle='#080808';ctx.lineWidth=3;
    ctx.beginPath();ctx.arc(0,0,size*.42,0,Math.PI*2);ctx.stroke();if(intensity>=64) ctx.fill();
    if(intensity>=34) {
        ctx.beginPath();ctx.arc(-size*.2,-size*.6,size*.65,Math.PI*.55,Math.PI*1.65);
        ctx.moveTo(size*.2+size*.65*Math.cos(-Math.PI*.45),size*.6+size*.65*Math.sin(-Math.PI*.45));
        ctx.arc(size*.2,size*.6,size*.65,-Math.PI*.45,Math.PI*.65);ctx.stroke();
    }
    ctx.restore();
}
function chains(segments) {
    const key=p=>p.map(v=>v.toFixed(4)).join(','), edges=new Map(),used=new Set(),paths=[];
    segments.forEach((s,i)=>s.forEach(p=>{const k=key(p);if(!edges.has(k)) edges.set(k,[]);edges.get(k).push(i);}));
    function walk(start) {
        const path=[start];let current=start;
        while(true) {
            const i=edges.get(key(current))?.find(i=>!used.has(i));if(i===undefined) break;
            used.add(i);const s=segments[i];current=key(s[0])===key(current)?s[1]:s[0];path.push(current);
        }
        return path;
    }
    for(const s of segments) for(const p of s) if(edges.get(key(p)).length===1) {const path=walk(p);if(path.length>1) paths.push(path);}
    for(let i=0;i<segments.length;i++) if(!used.has(i)) paths.push(walk(segments[i][0]));
    return paths;
}

export async function renderProbabilitiesStyle(cyclone,timeIndex,worldData,threshold=34) {
    const canvas=document.createElement('canvas');canvas.width=1700;canvas.height=1420;
    canvas.setAttribute('aria-label',`ICWC ${threshold}-kt wind probability and most likely arrival time, UTC`);
    const ctx=canvas.getContext('2d'),W=canvas.width,H=canvas.height;
    const map={x:28,y:120,w:1644,h:1062},footer={x:28,y:1190,w:1644,h:202};
    ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);ctx.fillStyle='#080808';ctx.textAlign='center';ctx.textBaseline='middle';
    text(ctx,`ICWC ${threshold}-kt Wind Probability and Most Likely Arrival Time`,W/2,40,38,'bold',W-70);
    const issue=probabilityIssue(cyclone,timeIndex);
    if(!issue) {text(ctx,'NO CYCLONE DATA',W/2,H/2,36,'bold');return canvas;}
    const initialized=issue.date.toISOString().slice(0,16).replace('T',' ');
    text(ctx,`Initialized ${initialized} UTC    Forecast hours 0–${issue.hours}h`,W/2,89,28);
    if(!issue.tracks.length) {text(ctx,'NO FORECAST ARCHIVED FOR THIS ISSUE TIME',W/2,H/2,32,'bold');return canvas;}
    const field=await buildWindProbability(issue,threshold,{nx:240,ny:155});
    const lon=(field.west+field.east)/2,lat=(field.north+field.south)/2;
    const projection=d3.geoEquirectangular().rotate([-lon,0]).center([0,lat])
        .scale(map.w/((field.east-field.west)*Math.PI/180)).translate([map.x+map.w/2,map.y+map.h/2]);
    const geography=await prepareICWCGeography(worldData,projection);
    const path=d3.geoPath().projection(projection).context(ctx);
    const pixel=p=>[map.x+p[0]/field.nx*map.w,map.y+p[1]/field.ny*map.h];
    ctx.save();ctx.beginPath();ctx.rect(map.x,map.y,map.w,map.h);ctx.clip();
    ctx.fillStyle=ICWC_MAP_STYLE.ocean;ctx.fillRect(map.x,map.y,map.w,map.h);
    if(worldData) {
        ctx.fillStyle=ICWC_MAP_STYLE.land;
        if(geography) ctx.fill(geography.land);
        else {ctx.beginPath();path(worldData);ctx.fill();}
    }
    const transform=d3.geoTransform({point(x,y){const p=pixel([x,y]);this.stream.point(...p);}});
    const contourPath=d3.geoPath().projection(transform).context(ctx);
    const contours=d3.contours().size([field.nx,field.ny]).thresholds(PROBABILITY_LEVELS)(field.probability);
    contours.forEach((g,i)=>{ctx.beginPath();contourPath(g);ctx.fillStyle=PROBABILITY_COLORS[i];ctx.fill();});
    ctx.strokeStyle=ICWC_MAP_STYLE.grid;ctx.lineWidth=1;
    ctx.beginPath();path(d3.geoGraticule().step([ICWC_MAP_STYLE.gridStep,ICWC_MAP_STYLE.gridStep])());ctx.stroke();
    // Coastlines remain legible WITHOUT repainting land over the wind hazard.
    if(worldData) {
        ctx.strokeStyle=ICWC_MAP_STYLE.coast;ctx.lineWidth=1.1;
        if(geography) ctx.stroke(geography.land);
        else {ctx.beginPath();path(worldData);ctx.stroke();}
    }
    if(contours[0]) {ctx.beginPath();contourPath(contours[0]);ctx.strokeStyle='#0a1114';ctx.lineWidth=3;ctx.stroke();}
    const labelBoxes=[];
    for(let h=6;h<=issue.hours;h+=6) {
        const segments=arrivalSegments(field,h);if(!segments.length) continue;
        ctx.beginPath();ctx.strokeStyle='#111';ctx.lineWidth=h%12===0?2.8:1.8;ctx.setLineDash(h%12===0?[]:[9,6]);
        segments.forEach(s=>{ctx.moveTo(...pixel(s[0]));ctx.lineTo(...pixel(s[1]));});ctx.stroke();ctx.setLineDash([]);
        if(h%12!==0) continue;
        const candidates=chains(segments).sort((a,b)=>b.length-a.length);
        const label=probabilityTimeLabel(issue.date,h);ctx.font='bold 25px Arial';const width=ctx.measureText(label).width;
        let placed=false;
        for(const line of candidates) {
            if(line.length<10) continue;
            for(const fraction of [.5,.3,.7]) {
                const i=Math.floor((line.length-1)*fraction),p=pixel(line[i]);
                const a=pixel(line[Math.max(0,i-4)]),b=pixel(line[Math.min(line.length-1,i+4)]);
                let angle=Math.atan2(b[1]-a[1],b[0]-a[0]);if(angle>Math.PI/2) angle-=Math.PI;if(angle< -Math.PI/2) angle+=Math.PI;
                const bw=Math.abs(Math.cos(angle))*width+Math.abs(Math.sin(angle))*34;
                const bh=Math.abs(Math.sin(angle))*width+Math.abs(Math.cos(angle))*34;
                const box={x:p[0]-bw/2-12,y:p[1]-bh/2-12,w:bw+24,h:bh+24};
                if(box.x<map.x+15||box.x+box.w>map.x+map.w-15||box.y<map.y+75||box.y+box.h>map.y+map.h-25) continue;
                if(labelBoxes.some(q=>box.x<q.x+q.w&&box.x+box.w>q.x&&box.y<q.y+q.h&&box.y+box.h>q.y)) continue;
                ctx.save();ctx.translate(...p);ctx.rotate(angle);ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold 25px Arial';
                ctx.strokeStyle='#101010';ctx.lineWidth=5;ctx.lineJoin='round';ctx.strokeText(label,0,0);ctx.fillStyle='white';ctx.fillText(label,0,0);ctx.restore();
                labelBoxes.push(box);placed=true;break;
            }
            if(placed) break;
        }
    }
    const origin=projection([issue.point[0],issue.point[1]]);symbol(ctx,...origin,issue.point[2],23);
    ctx.fillStyle='#080808';ctx.textAlign='right';text(ctx,'ALL TIMES UTC',map.x+map.w-20,map.y+35,30,'bold');
    ctx.textAlign='left';
    for(let latitude=Math.ceil(field.south/5)*5;latitude<field.north;latitude+=5) {
        const p=projection([lon,latitude]);if(p[1]<map.y+18||p[1]>map.y+map.h-40) continue;
        text(ctx,`${Math.abs(latitude)}°${latitude<0?'S':'N'}`,map.x+9,p[1]+4,22);
    }
    ctx.textAlign='center';
    for(let longitude=Math.ceil(field.west/5)*5;longitude<field.east;longitude+=5) {
        const p=projection([longitude,lat]);if(p[0]<map.x+65||p[0]>map.x+map.w-60) continue;
        const l=wrap(longitude);text(ctx,`${Math.abs(l)}°${l<0?'W':'E'}`,p[0],map.y+map.h-18,22);
    }
    if(!field.probability.some(p=>p>=5)) {
        ctx.fillStyle='rgba(255,255,255,.9)';ctx.fillRect(map.x+map.w/2-350,map.y+map.h/2-35,700,70);
        ctx.fillStyle='#111';text(ctx,`NO ${threshold}-KT PROBABILITY AREA ≥5%`,map.x+map.w/2,map.y+map.h/2,27,'bold');
    }
    ctx.restore();ctx.strokeStyle='#080808';ctx.lineWidth=3;ctx.strokeRect(map.x,map.y,map.w,map.h);
    ctx.fillStyle='#e8e8e8';ctx.fillRect(footer.x,footer.y,footer.w,footer.h);ctx.strokeRect(footer.x,footer.y,footer.w,footer.h);
    ctx.beginPath();ctx.moveTo(450,footer.y);ctx.lineTo(450,footer.y+footer.h);ctx.stroke();
    ctx.fillStyle='#080808';ctx.textAlign='left';
    text(ctx,cycloneProductName(cyclone,issue.point),50,footer.y+35,26,'bold',375);
    text(ctx,`Lon: ${coordinate(wrap(issue.point[0]),'lon')}`,50,footer.y+82,24,'bold');
    text(ctx,`Lat: ${coordinate(issue.point[1],'lat')}`,50,footer.y+117,24,'bold');
    text(ctx,`Sustained Wind: ${Math.round(issue.point[2])} kt`,50,footer.y+165,24,'bold');
    ctx.textAlign='center';text(ctx,'Location & wind speed',640,footer.y+30,22,'bold');
    [20,50,80].forEach((v,i)=>{symbol(ctx,520+i*120,footer.y+77,v,19);text(ctx,['<34 kt','34–63 kt','64+ kt'][i],520+i*120,footer.y+119,20,'bold');});
    const legendX=880,legendW=748,barY=footer.y+68,barH=28,step=legendW/10;
    text(ctx,`${issue.hours===72?'3-day':`${issue.hours}-hour`} chance of sustained ${threshold}+ kt (${Math.ceil(threshold*.514444)}+ m/s) winds`,legendX+legendW/2,footer.y+30,22,'bold',legendW+30);
    PROBABILITY_COLORS.forEach((color,i)=>{ctx.fillStyle=color;ctx.fillRect(legendX+i*step,barY,step,barH);});
    ctx.strokeRect(legendX,barY,legendW,barH);ctx.fillStyle='#111';
    [...PROBABILITY_LEVELS,100].forEach((p,i)=>{const x=legendX+i*step;ctx.beginPath();ctx.moveTo(x,barY+barH);ctx.lineTo(x,barY+barH+7);ctx.stroke();text(ctx,`${p}${i===10?'%':''}`,x,barY+barH+27,19);});
    text(ctx,`Lines: median first arrival among scenarios reaching ${threshold} kt (UTC); dashed: 6h, solid: 12h.`,1060,footer.y+157,18,'bold',1160);
    text(ctx,ICWC_DISCLAIMER,1060,footer.y+185,16,'normal',1160);
    return canvas;
}
