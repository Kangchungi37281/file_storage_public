export const ICWC_DISCLAIMER = 'SIMULATION ONLY LOL · STORM_INC / ICWC';

export function cycloneProductName(cyclone, point) {
    let prefix;
    if (point[4]) prefix = 'Extratropical Cyclone';
    else if (getCategory(point[2]).shortName === 'LPA') prefix = 'Low Pressure';
    else if (point[2] < 34) prefix = 'Tropical Depression';
    else if (point[2] < 64) prefix = 'Tropical Storm';
    else if (cyclone.basin === 'WPAC') prefix = 'Typhoon';
    else if (['NATL', 'EPAC', 'CPAC'].includes(cyclone.basin)) prefix = 'Hurricane';
    else prefix = 'Cyclone';
    return `${prefix} ${cyclone.name || 'UNNAMED'}`;
}

export function drawICWCDisclaimer(ctx, width, top, height = 36) {
    ctx.save();
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, top, width, height);
    ctx.fillStyle = '#333';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 18px Arial, sans-serif';
    ctx.fillText(ICWC_DISCLAIMER, width / 2, top + height / 2, width - 40);
    ctx.restore();
}
import { getCategory } from './utils.js';
