const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const conditions = { Fair: '晴好', Cloudy: '多云', Rain: '有雨', 'Heavy rain': '大雨', Thunderstorms: '雷雨' };
const icons = { Fair: 'sun', Cloudy: 'cloud', Rain: 'cloud-rain', 'Heavy rain': 'cloud-showers-heavy', Thunderstorms: 'cloud-bolt' };

function renderPostAlert(result, cn) {
    const levels = {
        watch: { rank: 1, title: '热带气旋注意', english: 'TROPICAL CYCLONE WATCH', range: 400 },
        warning: { rank: 2, title: '热带气旋警报', english: 'TROPICAL CYCLONE WARNING', range: 200 },
        special: { rank: 3, title: '热带气旋特别警报', english: 'SPECIAL TROPICAL CYCLONE WARNING', range: 100 }
    };
    const level = levels[result.alert];
    if (!level) return '';
    return `<section class="post-alert post-alert-${result.alert}" role="alert">
        <div class="post-alert-topline"><span class="post-alert-level">${cn ? '警报等级' : 'ALERT LEVEL'} <b>0${level.rank}</b><span class="post-alert-segments" aria-hidden="true">${[1,2,3].map(rank=>`<i${rank<=level.rank ? ' class="is-active"' : ''}></i>`).join('')}</span></span><span class="post-alert-simulation">${cn ? '模拟预警' : 'SIMULATION'}</span></div>
        <div class="post-alert-body">
            <svg class="post-alert-symbol" viewBox="0 0 48 48" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="7" stroke="currentColor" stroke-width="2"/><path d="M17 25C9 23 7 16 13 10c5-5 14-6 22-2M31 23c8 2 10 9 4 15-5 5-14 6-22 2M13 10c-1 8 3 11 9 10M35 38c1-8-3-11-9-10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="24" cy="24" r="2" fill="currentColor"/></svg>
            <div class="post-alert-heading"><h3>${cn ? level.title : level.english}</h3><p>${cn ? level.english : 'OBSERVATION POST · TROPICAL CYCLONE'}</p></div>
            <div class="post-alert-distance"><span>${cn ? '当前中心距离' : 'CURRENT DISTANCE'}</span><strong>${Math.round(result.currentDistance)}<small>km</small></strong></div>
        </div>
        <div class="post-alert-details"><span>${cn ? '未来72小时预测进入' : 'FORECAST WITHIN 72H'} <b>≤ ${level.range} km</b></span><span>${result.alert === 'special' ? (cn ? '接近时预测强度' : 'INTENSITY AT APPROACH') : (cn ? '评估范围' : 'OUTLOOK FOR')} <b>${result.alert === 'special' ? '&gt; 64 kt' : (cn ? '本站' : 'THIS POST')}</b></span></div>
    </section>`;
}

export function renderPostForecast(result, input, cn = false) {
    const date = new Date(Date.UTC(new Date().getFullYear(), input.month - 1, 1, result.age));
    const stamp = date.toISOString().slice(0,16).replace('T',' ') + ' UTC';
    const alert = renderPostAlert(result, cn);
    return `<p class="post-location">${escape(input.site.name || 'OBSERVATION POST')} · ${Math.abs(input.site.lat).toFixed(2)}°${input.site.lat < 0 ? 'S' : 'N'} ${Math.abs(input.site.lon).toFixed(2)}°${input.site.lon < 0 ? 'W' : 'E'}</p>
        <p class="post-issued">${cn ? '发布时刻' : 'Issued'} ${stamp} · T+${result.age}h</p>${alert}
        <div class="post-days">${result.days.map((day, i) => `<article class="post-day">
            <header><span>DAY ${i + 1}</span><span>+${day.from}–${day.to}h</span></header>
            <i class="post-weather-icon fa-solid fa-${icons[day.condition]}" aria-hidden="true"></i>
            <dl><dt>Weather Condition</dt><dd>${cn ? conditions[day.condition] : day.condition}</dd>
            <dt>Temperature</dt><dd>${day.min}–${day.max}<small> °C</small></dd>
            <dt>Wind Gust</dt><dd>${day.gustKph}<small> kph ${cn ? '最高' : 'max'}</small></dd></dl>
        </article>`).join('')}</div>
        <p class="post-note">${cn ? '未来三个24小时窗口的天气概况、温度范围和最大阵风。温度以游戏内海温为热力背景，根据陆海热惯性和海岸距离估算季节、昼夜响应，再考虑海拔、锋面、持续冷空气输送及回暖与云雨影响。寒潮降温取决于气团及环境风，不由本站气压直接换算。未接入真实温度数据；阵风为地面风诊断估算。非实况或正式预警。刷新可获取当前模拟时刻的新预报。' : 'Three successive 24-hour outlooks: weather, temperature range and peak gust. Temperature uses in-game SST, land/sea thermal inertia, coastal moderation and elevation, with frontal, sustained cold-air transport, recovery and cloud effects. Cold-surge cooling follows air masses and environmental winds, not a direct conversion from station pressure. No real-world temperature dataset is used. Gusts use surface-wind diagnostics. Simulation only, not observations or official warnings. Refresh to update the issue time.'}</p>
        ${!result.hasTrack ? `<p class="post-note">${cn ? '无完整热带气旋预测：未覆盖时段仅显示环境天气估算，不能据此排除气旋影响。' : 'No complete tropical forecast: uncovered periods use environmental weather only; this does not rule out cyclone impacts.'}</p>` : ''}`;
}

export function mountObservationPost({ modal, openButton, closeButton, readInput, generate, configure }) {
    const content = document.getElementById('postForecastContent');
    const refresh = document.getElementById('refreshPostForecast');
    let revision = 0, busy = false, previousFocus = null, previousOverflow = '';
    const cn = () => window.getUserLanguage?.() === 'CN';
    async function load() {
        if (busy) return;
        const input = readInput();
        if (!input.site || !Number.isFinite(input.site.lat) || Math.abs(input.site.lat) > 90 || !Number.isFinite(input.site.lon)) {
            content.innerHTML = `<p class="post-empty">${cn() ? '请先在设置中填写 Observation Post 的经纬度。' : 'Set an Observation Post latitude and longitude first.'}</p><button class="post-action" id="configurePost">${cn() ? '设置观测站' : 'Configure post'}</button>`;
            document.getElementById('configurePost').onclick = () => { close(); configure(); };
            return;
        }
        if (!input.cyclone || input.cyclone.status !== 'active') {
            content.innerHTML = `<p class="post-empty">${cn() ? '请启动模拟后查看三天天气预报。模拟结束后不继续发布旧场预报。' : 'Start a simulation to view the three-day outlook. Ended simulations do not issue new forecasts.'}</p>`;
            return;
        }
        const request = ++revision;
        busy = true; refresh.disabled = true; content.setAttribute('aria-busy', 'true');
        content.innerHTML = `<p class="post-empty" role="status">${cn() ? '正在推算观测站未来三天天气…' : 'Preparing the three-day station outlook…'}</p>`;
        try {
            const result = await generate(input);
            if (request === revision) content.innerHTML = renderPostForecast(result, input, cn());
        } catch (error) {
            if (request === revision) content.innerHTML = `<p class="post-empty" role="status">${cn() ? '预报暂不可用，请重试。' : 'Forecast unavailable. Please retry.'}</p>`;
            console.error('[observation-post]', error);
        } finally {
            busy = false; refresh.disabled = false; content.removeAttribute('aria-busy');
            if (request !== revision && !modal.classList.contains('hidden')) load();
        }
    }
    function close() {
        revision++; modal.classList.add('hidden'); document.body.style.overflow = previousOverflow;
        previousFocus?.focus();
    }
    openButton.addEventListener('click', () => {
        previousFocus = document.activeElement; previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden'; modal.classList.remove('hidden'); closeButton.focus();
        load();
    });
    closeButton.addEventListener('click', close);
    refresh.addEventListener('click', load);
    modal.addEventListener('click', event => { if (event.target === modal) close(); });
    // Do not let modal keystrokes trigger simulation, radar or map shortcuts.
    modal.addEventListener('keydown', event => {
        event.stopPropagation();
        if (event.key === 'Escape') { event.preventDefault(); close(); }
        if (event.key === 'Tab') {
            const buttons = [...modal.querySelectorAll('button:not(:disabled)')];
            const first = buttons[0], last = buttons.at(-1);
            if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
            else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
        }
    });
}
