// Issue-time ownership for forecasts that finish after the live model has
// advanced. Every scheduled advisory is archived; only a newer result
// may replace the visible cone. Weak keys do not retain completed storms.
export function createForecastAdvisoryQueue(generate, publish, reportError) {
    const storms = new WeakMap();
    const stateFor = cyclone => {
        if (!storms.has(cyclone)) storms.set(cyclone, {
            pending: new Set(), revision: 0, publishedRevision: 0, current: cyclone
        });
        return storms.get(cyclone);
    };
    return {
        // The physics integrator returns a new shallow storm object each
        // step. Preserve job ownership across those replacements, not resets.
        adopt(previous, current) {
            const state = stateFor(previous);
            // A result may have arrived while the new step was awaiting its
            // wind radii, after its shallow copy was already constructed.
            if (previous.forecastLogs) current.forecastLogs = previous.forecastLogs;
            if (previous.pathForecasts) current.pathForecasts = previous.pathForecasts;
            state.current = current;
            storms.set(current, state);
        },
        issue(cyclone, systems, temperature, shear, seed = null, archive = true) {
            const state = stateFor(cyclone);
            const revision = ++state.revision;
            const age = cyclone.age;
            const task = generate(cyclone, systems, temperature, shear, seed)
                .then(forecasts => {
                    if (archive) {
                        state.current.forecastLogs ??= {};
                        state.current.forecastLogs[age] = forecasts.map(forecast => ({
                            name: forecast.name,
                            track: forecast.track.map(point => point.slice())
                        }));
                    }
                    // A newer request still computing must not starve the
                    // display. Show the newest completed result, never regress
                    // when responses arrive out of order.
                    if (revision > state.publishedRevision) {
                        state.publishedRevision = revision;
                        publish(state.current, forecasts);
                    }
                    return forecasts;
                }).catch(error => {
                    state.error = error;
                    reportError(error);
                    throw error;
                }).finally(() => state.pending.delete(task));
            state.pending.add(task);
            // Live callers deliberately do not await. Keep failures handled
            // while allowing startup callers to observe the original failure.
            task.catch(() => {});
            return task;
        },
        async waitForCapacity(cyclone) {
            const state = stateFor(cyclone);
            // One computing and one queued advisory. On an overloaded device
            // apply backpressure rather than discard history or grow a backlog.
            while (state.pending.size >= 2) {
                await Promise.race([...state.pending].map(task => task.catch(() => {})));
            }
            if (state.error) throw state.error;
        },
        async drain(cyclone) {
            const state = stateFor(cyclone);
            while (state.pending.size) await Promise.allSettled([...state.pending]);
            if (state.error) throw state.error;
        }
    };
}
