// Fixed Greenwich cut + periodic copies: camera movement must never change
// the expensive geographic geometry. Reference-scale SVG paths retain D3's
// requested screen-space precision; zooming is an affine transform.
export function buildStaticAtlasGeometry(d3, world, highland, scale, precision) {
    const projection = d3.geoEquirectangular().scale(scale).precision(precision)
        .rotate([0, 0, 0]).center([0, 0]).translate([0, 0]);
    const path = d3.geoPath(projection);
    const paths = [
        { className: 'graticule', d: path(d3.geoGraticule().step([10, 10])()) },
        { className: 'land', stroke: 'none', d: path(world) }
    ];
    if (highland) {
        const rings = highland.type === 'MultiPolygon'
            ? highland.coordinates.flat() : highland.coordinates;
        paths.push({ className: 'highland', stroke: 'none', d: path(highland) },
            { className: 'highland', fill: 'none',
                d: path({ type: 'MultiLineString', coordinates: rings }) });
    }
    return { scale, paths };
}

export function staticAtlasCamera(rotation, center, translation, scale, width) {
    const dx = translation[0] + scale * Math.PI / 180
        * (((rotation + 540) % 360) - 180 - center[0]);
    const dy = translation[1] + scale * Math.PI / 180 * center[1];
    const period = 2 * Math.PI * scale;
    const copies = [];
    for (let i = Math.ceil((-dx - period / 2) / period);
        i <= Math.floor((width - dx + period / 2) / period); i++) copies.push(i);
    return { dx, dy, period, copies };
}
