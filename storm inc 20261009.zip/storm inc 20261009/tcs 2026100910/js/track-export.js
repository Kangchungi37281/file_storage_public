/** Fixed-size Wiki Path Painter export. No DOM capture or live map mutations. */
import { EXPORT_LAYOUT, exportLegendBox, cityWindArrow, layoutExportCityLabels } from './track-export-layout.js?v=20261008-forecast-categories1';
export const EXPORT_SIZE = Object.freeze({ width: 2244, height: 1182, header: EXPORT_LAYOUT.header });
const COLORS = { ocean: '#07111f', panel: '#0a1020', land: '#263a36', border: '#263a30', muted: '#718099' };
const TRIANGLES = new Set(['EX', 'LO', 'WV', 'DB', 'MD']);
const NON_ACE = new Set(['SS', 'SD', 'EX', 'DB', 'LO', 'WV', 'MD']);
const COLORED = new Set(['TD', 'TS', 'TY', 'HU', 'ST', 'TC', 'EX', 'SS', 'SD', 'MD']);
const RAD = Math.PI / 180;
let assetsPromise;

// Keep the export annotations aligned with the cities shown on ICWC warning
// graphics. The export is self-contained, so it can also be generated from a
// saved ATCF track after the live simulation has ended.
export const ICWC_MAJOR_CITIES = Object.freeze([
    { name: 'SAIPAN', lon: 145.7, lat: 15.2 },
    { name: 'MANILA', lon: 120.98, lat: 14.6 },
    { name: 'TAIPEI', lon: 121.5, lat: 25.05 },
    { name: 'HONG KONG', lon: 114.17, lat: 22.3 },
    // Rounded station/locality positions (not live observation feeds):
    // Miyako: https://www.data.jma.go.jp/naha-airport/tokusei/romy/romy.html
    // Wake: https://tidesandcurrents.noaa.gov/benchmarks/1890000.html
    // Shantou: https://faculty.ucr.edu/~rjallen/Publications_files/AllenShJClim07.pdf
    // Basco: https://digital.library.unt.edu/explore/locations/p18775/
    { name: 'MIYAKOJIMA', lon: 125.30, lat: 24.78 },
    { name: 'WAKE ISLAND', lon: 166.62, lat: 19.29 },
    { name: 'SHANTOU', lon: 116.68, lat: 23.35 },
    { name: 'BASCO', lon: 121.97, lat: 20.45 },
    { name: 'YAP', lon: 138.12, lat: 9.51 },
    { name: 'SHANGHAI', lon: 121.47, lat: 31.23 },
    { name: 'SEOUL', lon: 126.98, lat: 37.56 },
    { name: 'TOKYO', lon: 139.69, lat: 35.69 },
    { name: 'HO CHI MINH', lon: 106.63, lat: 10.82 },
    { name: 'NAHA', lon: 127.68, lat: 26.21 },
    { name: 'GUAM', lon: 144.7, lat: 13.4 },
    { name: 'IWO TO', lon: 141.3, lat: 24.8 },
    { name: 'DHAKA', lon: 90.39, lat: 23.73 },
    { name: 'HONOLULU', lon: -157.86, lat: 21.31 },
    { name: 'LOS ANGELES', lon: -118.24, lat: 34.05 },
    { name: 'HAVANA', lon: -82.35, lat: 23.13 },
    { name: 'NEW YORK', lon: -74.0, lat: 40.71 },
    { name: 'HOUSTON', lon: -95.37, lat: 29.76 },
    { name: 'SAN FRANCISCO', lon: -122.42, lat: 37.77 },
    { name: 'BRISBANE', lon: 153.02, lat: -27.47 },
    { name: 'DARWIN', lon: 130.84, lat: -12.46 },
    { name: 'CAIRNS', lon: 145.77, lat: -16.92 }
]);

export function intensityColor(type, wind, enableExtremeTier = false) {
    if (!COLORED.has(type)) return '#9ca3af';
    if (enableExtremeTier && wind >= 170) return '#ff7adb';
    return wind >= 137 ? '#8d75e6' : wind >= 113 ? '#ff738a' : wind >= 96 ? '#ff9e59'
        : wind >= 83 ? '#ffd98c' : wind >= 64 ? '#ffffd9' : wind >= 34 ? '#4dffff' : '#6ec1ea';
}

export function normalizeTrackExportOptions(options = {}) {
    return {
        markPeakIntensity: options.markPeakIntensity === true,
        ignoreExPeak: options.ignoreExPeak === true,
        enableExtremeTier: options.enableExtremeTier === true,
        showLegend: options.showLegend !== false,
        showIntensityHistory: options.showIntensityHistory === true,
        showCityObservations: options.showCityObservations === true
    };
}

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

export function sampleSixHourlyIntensity(points) {
    if (!Array.isArray(points) || points.length === 0) return [];
    const ordered = [...points].sort((a, b) => a.timestamp - b.timestamp);
    const origin = ordered[0].timestamp;
    let lastSlot = -1;
    return ordered.flatMap(point => {
        if (!Number.isFinite(point.timestamp) || !Number.isFinite(point.wind)) return [];
        const elapsed = point.timestamp - origin;
        const slot = Math.round(elapsed / SIX_HOURS_MS);
        if (Math.abs(elapsed - slot * SIX_HOURS_MS) > 60_000 || slot === lastSlot) return [];
        lastSlot = slot;
        return [{ ...point, wind: Math.round(point.wind / 5) * 5 }];
    });
}

export function findSignificantIntensityPeaks(samples, minimumRiseKt = 10) {
    if (!Array.isArray(samples) || samples.length < 2) return [];
    const groups = [];
    samples.forEach((sample, index) => {
        const wind = sample.wind;
        const last = groups.at(-1);
        if (last && last.wind === wind) {
            last.end = index;
            last.indices.push(index);
        } else {
            groups.push({ wind, start: index, end: index, indices: [index] });
        }
    });

    const lows = [];
    const highs = [];
    groups.forEach((group, index) => {
        const previous = groups[index - 1]?.wind;
        const next = groups[index + 1]?.wind;
        if ((previous === undefined || group.wind < previous)
            && (next === undefined || group.wind < next)
            && (previous !== undefined || next !== undefined)) lows.push(group);
        if ((previous === undefined || group.wind > previous)
            && (next === undefined || group.wind > next)
            && (previous !== undefined || next !== undefined)) highs.push(group);
    });

    let lowCursor = 0;
    return highs.flatMap(high => {
        while (lowCursor < lows.length && lows[lowCursor].end < high.start) lowCursor++;
        const leftLow = lowCursor > 0 ? lows[lowCursor - 1] : null;
        let rightCursor = lowCursor;
        while (rightCursor < lows.length && lows[rightCursor].start <= high.end) rightCursor++;
        const rightLow = lows[rightCursor] || null;
        const phaseLow = leftLow || rightLow;
        if (!phaseLow || high.wind - phaseLow.wind <= minimumRiseKt) return [];
        const peakIndex = Math.floor((high.start + high.end) / 2);
        return [{ index: peakIndex, wind: high.wind, point: samples[peakIndex] }];
    });
}

function findPeakPoint(points, ignoreExPeak) {
    let peak = null;
    for (const point of points) {
        if (ignoreExPeak && point.type === 'EX') continue;
        if (!peak || point.wind > peak.wind) peak = point;
    }
    return peak;
}

// Snapshot the saved ATCF, including its basin, number and UTC dates. Do not read selectors.
export function parseExportTrack(raw) {
    const records = new Map();
    let identity;
    for (const line of raw.trim().split(/\r?\n/)) {
        if (!line.trim()) continue;
        const f = line.split(',').map(s => s.trim());
        const lat = /^(-?\d+)([NS])$/.exec(f[6] || '');
        const lon = /^(\d+)([EW])$/.exec(f[7] || '');
        if (f.length < 11 || !/^\d{10}$/.test(f[2]) || !lat || !lon) throw new Error('轨迹记录格式不完整，无法导出。');
        const id = `${f[0]} ${f[1]}`;
        if (identity && identity !== id) throw new Error('请一次导出一条气旋轨迹。');
        identity = id;
        const timestamp = Date.UTC(+f[2].slice(0, 4), +f[2].slice(4, 6) - 1, +f[2].slice(6, 8), +f[2].slice(8, 10));
        const p = { lon: +lon[1] / 10 * (lon[2] === 'W' ? -1 : 1),
            lat: +lat[1] / 10 * (lat[2] === 'S' ? -1 : 1), wind: Number(f[8]), pressure: Number(f[9]), type: f[10].toUpperCase(), timestamp };
        if (!Number.isFinite(p.wind) || !f[8] || p.wind < 0 || Math.abs(p.lat) > 90 || p.lon < -180 || p.lon > 360
            || !Number.isFinite(timestamp) || new Date(timestamp).toISOString().replace(/[-:T]/g, '').slice(0, 10) !== f[2]) {
            throw new Error('轨迹包含无效的时间、坐标或风速。');
        }
        // Multiple wind-radius records at one time must not multiply the ACE or markers.
        if (!records.has(timestamp)) records.set(timestamp, p);
        if (records.size > 20000) throw new Error('轨迹过长，请分段导出（最多 20,000 个点）。');
    }
    const points = [...records.values()].sort((a, b) => a.timestamp - b.timestamp);
    if (!points.length) throw new Error('没有可导出的轨迹。');
    let peak = points[0], minPressure = Infinity, ace = 0;
    for (const p of points) {
        if (p.wind > peak.wind) peak = p;
        if (Number.isFinite(p.pressure) && p.pressure > 0) minPressure = Math.min(minPressure, p.pressure);
        if (p.wind >= 34 && !NON_ACE.has(p.type) && new Date(p.timestamp).getUTCHours() % 6 === 0) ace += p.wind ** 2 / 10000;
    }
    return { identity, points, peakWind: peak.wind, peakType: peak.type, minPressure, ace, accent: intensityColor(peak.type, peak.wind) };
}

function mercatorY(lat) {
    return -Math.log(Math.tan(Math.PI / 4 + Math.max(-85.05112878, Math.min(85.05112878, lat)) * RAD / 2)) / RAD;
}

export function fitExportTrack(points) {
    let previous;
    const coordinates = points.map(p => {
        let lon = ((p.lon + 180) % 360 + 360) % 360 - 180;
        if (previous !== undefined) lon += 360 * Math.round((previous - lon) / 360);
        previous = lon;
        return [lon, mercatorY(p.lat)];
    });
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const [x, y] of coordinates) {
        minX = Math.min(minX, x); maxX = Math.max(maxX, x);
        minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
    if (maxX - minX > 720) throw new Error('轨迹跨越过多经度，请分段导出。');
    const { width, height, header } = EXPORT_SIZE;
    const padding = 72;
    const scale = Math.min((width - padding * 2) / Math.max(8, maxX - minX),
        (height - header - padding * 2) / Math.max(8, maxY - minY));
    const centerX = (minX + maxX) / 2, centerY = (minY + maxY) / 2;
    const project = (x, y) => [width / 2 + (x - centerX) * scale, (height + header) / 2 + (y - centerY) * scale];
    return { pixels: coordinates.map(([x, y]) => project(x, y)), project, centerX, scale };
}

function cityDistanceKm(lon1, lat1, lon2, lat2) {
    const dLat = (lat2 - lat1) * RAD;
    const dLon = ((((lon2 - lon1) + 540) % 360) - 180) * RAD;
    const a = Math.sin(dLat / 2) ** 2
        + Math.cos(lat1 * RAD) * Math.cos(lat2 * RAD) * Math.sin(dLon / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
}

function compassDirectionFromVector(uEast, vNorth) {
    if (!Number.isFinite(uEast) || !Number.isFinite(vNorth)
        || Math.hypot(uEast, vNorth) < 0.01) return '--';
    const fromBearing = (Math.atan2(-uEast, -vNorth) / RAD + 360) % 360;
    const index = Math.floor(fromBearing / 22.5 + 0.5) % 16;
    return ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
        'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'][index];
}

function observationPostDirection(record) {
    if (record?.direction) return record.direction;
    if (!Number.isFinite(record?.u) || !Number.isFinite(record?.v)) return '--';
    // Match the live Observation Post label (which uses the flow vector's
    // meteorological-from direction plus its display calibration).
    const flowAngleMath = Math.atan2(-record.v, record.u) * 180 / Math.PI;
    const fromBearing = (flowAngleMath + 250) * RAD;
    return compassDirectionFromVector(
        -Math.sin(fromBearing),
        -Math.cos(fromBearing)
    );
}

function directObservationForCity(city, observations) {
    if (!Array.isArray(observations)) return null;
    const matches = observations.filter(record =>
        Number.isFinite(record?.lat) && Number.isFinite(record?.lon)
        && cityDistanceKm(record.lon, record.lat, city.lon, city.lat) <= 25
        && Number.isFinite(Number(record.wind))
    );
    if (!matches.length) return null;
    const peak = matches.reduce((best, record) =>
        !best || Number(record.wind) > Number(best.wind) ? record : best, null);
    const pressures = matches.map(record => Number(record.pressure))
        .filter(pressure => Number.isFinite(pressure) && pressure > 0);
    return {
        ...city,
        wind: Math.round(Number(peak.wind)),
        direction: observationPostDirection(peak),
        pressure: Math.round(pressures.length ? Math.min(...pressures) : 1013),
        distance: 0,
        timestamp: Number.isFinite(peak.hour) ? peak.hour : undefined,
        fromObservationPost: true
    };
}

function motionVectorAt(points, index) {
    const from = points[Math.max(0, index - 1)];
    const to = points[Math.min(points.length - 1, index + 1)];
    if (!from || !to || from === to) return { u: 0, v: 0 };
    const elapsedHours = Math.max(3 / 2, (to.timestamp - from.timestamp) / 3600000);
    const meanLat = ((from.lat + to.lat) / 2) * RAD;
    const eastKm = ((((to.lon - from.lon) + 540) % 360) - 180) * 111.32 * Math.cos(meanLat);
    const northKm = (to.lat - from.lat) * 111.32;
    // kt = km/h / 1.852. A modest translation contribution is applied below;
    // it provides the same forward-side directional cue as the surface model.
    return { u: eastKm / elapsedHours / 1.852, v: northKm / elapsedHours / 1.852 };
}

function directionalRadiusKm(point, bearingDeg) {
    const radii = Array.isArray(point?.r34) ? point.r34
        : Array.isArray(point?.radii34) ? point.radii34
            : Array.isArray(point?.windRadii34) ? point.windRadii34 : null;
    if (!radii || radii.length < 4) return null;
    // Track records use NE, SE, SW, NW. Convert a mathematical bearing
    // (clockwise from north) to that operational quadrant order.
    const normalized = (bearingDeg + 360) % 360;
    const quadrant = normalized >= 0 && normalized < 90 ? 0
        : normalized < 180 ? 1 : normalized < 270 ? 2 : 3;
    const radiusDeg = Number(radii[quadrant]);
    return Number.isFinite(radiusDeg) && radiusDeg > 0 ? radiusDeg * 111.32 : null;
}

function estimateCityObservation(city, points, index, citySurfaceFriction = null) {
    const point = points[index];
    const distance = cityDistanceKm(point.lon, point.lat, city.lon, city.lat);
    const intensity = Math.max(0, Number(point.wind) || 0);
    if (!(intensity > 0)) return null;

    const dx = ((((city.lon - point.lon) + 540) % 360) - 180) * 111.32
        * Math.cos(point.lat * RAD);
    const dy = (city.lat - point.lat) * 111.32;
    const bearing = (Math.atan2(dx, dy) / RAD + 360) % 360;
    const rmw = Math.max(6, Math.min(190,
        5 + Math.max(0, Number(point.circulationSize) || 300) * 0.105));
    const r34 = directionalRadiusKm(point, bearing);
    const outer = Math.max(rmw + 5, r34 || rmw * 3.0);
    const exponent = intensity > 34 && outer > rmw
        ? Math.max(0.45, Math.min(1.8, Math.log(intensity / 34) / Math.log(outer / rmw)))
        : 0.85;
    const localWind = intensity * Math.pow(rmw / Math.max(rmw, distance), exponent);

    const hemisphere = point.lat >= 0 ? 1 : -1;
    const angle = Math.atan2(dy, dx);
    const inflow = 15 * RAD;
    const tangent = angle + (hemisphere > 0 ? Math.PI / 2 + inflow : -Math.PI / 2 - inflow);
    const motion = motionVectorAt(points, index);
    // City estimates represent 10-m winds over the city surface. Apply the
    // same land / near-coast reduction used by the live Observation Post
    // readout. The factor is supplied by main.js from the shared terrain
    // raster so this export module remains usable with saved tracks alone.
    const suppliedFriction = Number(citySurfaceFriction?.[city.name]);
    const friction = Number.isFinite(suppliedFriction)
        ? Math.max(0.4, Math.min(1, suppliedFriction)) : 1;
    const windU = (localWind * Math.cos(tangent) + motion.u * 0.45) * friction;
    const windV = (localWind * Math.sin(tangent) + motion.v * 0.45) * friction;
    const wind = Math.max(0, Math.hypot(windU, windV));
    const centerPressure = Number.isFinite(point.pressure) && point.pressure > 0
        ? point.pressure : 1013 - intensity * 0.55;
    // Match the ICWC product's surface-pressure closure: the cyclone anomaly
    // decays with exp(-RMW / distance), relative to the local background
    // pressure at the city. The previous 1-exp(-distance / scale) form made
    // distant cities drift toward an overly high fixed 1013–1014 hPa value.
    const backgroundPressure = Number(point.cityBackgroundPressures?.[city.name]);
    const cityBackground = Number.isFinite(backgroundPressure) && backgroundPressure > 0
        ? backgroundPressure : 1013;
    const pressureScale = Math.max(1,
        10 + (Number(point.circulationSize) || 300) * 0.25);
    const pressure = centerPressure
        + (cityBackground - centerPressure) * Math.exp(-pressureScale / Math.max(1, distance));
    return {
        ...city,
        wind,
        direction: compassDirectionFromVector(windU, windV),
        pressure,
        distance,
        timestamp: point.timestamp
    };
}

/**
 * Derive the maximum city observations from the saved track and, when
 * available, its immutable pressure snapshots. This is intentionally
 * evaluated at export time: it keeps the six-hour simulation loop free of
 * cities × N diagnostic calls while preserving deterministic products.
 */
export function deriveCityObservations(model, cities = ICWC_MAJOR_CITIES) {
    const points = (model?.cityPoints || model?.points || []).filter(point =>
        Number.isFinite(point?.lon) && Number.isFinite(point?.lat)
        && Number.isFinite(point?.timestamp));
    if (!points.length) return [];
    return cities.map(city => {
        const direct = directObservationForCity(city, model?.siteObservations);
        if (direct) return direct;
        let best = null;
        let minPressure = Infinity;
        points.forEach((point, index) => {
            const observation = estimateCityObservation(
                city,
                points,
                index,
                model?.citySurfaceFriction
            );
            if (!observation) return;
            if (!best || observation.wind > best.wind) best = observation;
            if (observation.pressure < minPressure) minPressure = observation.pressure;
        });
        return best ? {
            ...best,
            // City observations are reported as whole knots; the 5-kt
            // rounding rule belongs to the historical intensity chart only.
            wind: Math.round(best.wind),
            pressure: Math.round(minPressure)
        } : { ...city, wind: 0, direction: '--', pressure: 1013, distance: Infinity };
    });
}

async function loadAssets() {
    if (!assetsPromise) {
        assetsPromise = (async () => {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 15000);
            try {
                // Fetch font bytes with the same timeout as the map. A failed font never silently falls back.
                const files = ['../../ne_50m_admin_0_countries.geojson',
                    '../../assets/export-fonts/BarlowCondensed-ExtraBold.ttf', '../../assets/export-fonts/BarlowCondensed-Bold.ttf',
                    '../../assets/export-fonts/JetBrainsMono-SemiBold.ttf'];
                const data = await Promise.all(files.map(async (file, i) => {
                    const response = await fetch(new URL(file, import.meta.url), { signal: controller.signal });
                    if (!response.ok) throw new Error(`导出资源加载失败 (${response.status})。`);
                    return i === 0 ? response.json() : response.arrayBuffer();
                }));
                const faces = [new FontFace('TCS Export Display', data[1], { weight: '800' }),
                    new FontFace('TCS Export Display', data[2], { weight: '700' }),
                    new FontFace('TCS Export Mono', data[3], { weight: '600' })];
                await Promise.all(faces.map(face => face.load()));
                faces.forEach(face => document.fonts.add(face));
                return data[0];
            } finally { clearTimeout(timer); }
        })().catch(error => { assetsPromise = null; throw error; });
    }
    return assetsPromise;
}

// Planar Mercator rings match the reference's Leaflet coastlines. Repeat polygons across
// the dateline, using the same unwrapped coordinates as the track; preserve interior holes.
async function drawLand(ctx, world, fit) {
    const { width, height, header } = EXPORT_SIZE;
    ctx.fillStyle = COLORS.land;
    ctx.strokeStyle = COLORS.border;
    ctx.lineWidth = 1;
    let lastYield = performance.now();
    for (const feature of world.features) {
        const geometry = feature.geometry;
        const polygons = geometry?.type === 'Polygon' ? [geometry.coordinates]
            : geometry?.type === 'MultiPolygon' ? geometry.coordinates : [];
        for (const polygon of polygons) {
            const rings = polygon.map(ring => {
                let previous;
                return ring.map(([lon, lat]) => {
                    if (previous !== undefined) lon += 360 * Math.round((previous - lon) / 360);
                    previous = lon;
                    return [lon, mercatorY(lat)];
                });
            });
            if (!rings[0]?.length) continue;
            const base = 360 * Math.round((fit.centerX - rings[0][0][0]) / 360);
            const copies = Math.ceil(width / (360 * fit.scale) / 2) + 1;
            for (let copy = -copies; copy <= copies; copy++) {
                const offset = base + copy * 360;
                const projected = rings.map(ring => ring.map(([x, y]) => fit.project(x + offset, y)));
                let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
                for (const [x, y] of projected[0]) {
                    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
                    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
                }
                if (maxX < 0 || minX > width || maxY < header || minY > height) continue;
                ctx.beginPath();
                for (const ring of projected) {
                    ring.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
                    ctx.closePath();
                }
                ctx.fill('evenodd'); ctx.stroke();
            }
        }
        if (performance.now() - lastYield > 12) {
            await new Promise(resolve => setTimeout(resolve, 0));
            lastYield = performance.now();
        }
    }
}

// Position by ink bounds rather than browser-dependent line boxes.
function text(ctx, value, x, top, size, family, color, maxWidth, spacing = 0, weight = 800) {
    value = String(value);
    ctx.font = `${weight} ${size}px "${family}"`;
    const advance = ctx.measureText(value).width + spacing * Math.max(0, value.length - 1);
    const factor = Math.min(1, maxWidth / Math.max(1, advance));
    const baseline = top + ctx.measureText(value).actualBoundingBoxAscent;
    ctx.save(); ctx.translate(x, baseline); ctx.scale(factor, 1); ctx.fillStyle = color;
    let cursor = 0;
    for (const char of value) {
        ctx.fillText(char, cursor, 0);
        cursor += ctx.measureText(char).width + spacing;
    }
    ctx.restore();
    return advance * factor;
}

function drawHeader(ctx, model, options) {
    const { width, header } = EXPORT_SIZE;
    const first = 920, second = 1610;
    ctx.fillStyle = COLORS.panel; ctx.fillRect(0, 0, width, header);
    ctx.strokeStyle = 'rgba(255,255,255,.10)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(first, 0); ctx.lineTo(first, header);
    ctx.moveTo(second, 0); ctx.lineTo(second, header); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.18)';
    ctx.beginPath(); ctx.moveTo(0, header - 1); ctx.lineTo(width, header - 1); ctx.stroke();
    const mono = (v, x, y, size, color, max, spacing = 0) => text(ctx, v, x, y, size, 'TCS Export Mono', color, max, spacing, 600);
    mono('CYCLONE IDENTIFICATION', 40, 24, 16, COLORS.muted, first - 80, 1.6);
    mono('PEAK SUSTAINED WIND / MINIMUM PRESSURE', first + 40, 24, 16, COLORS.muted, second - first - 80, 1.6);
    mono('ACCUMULATED CYCLONE ENERGY', second + 40, 24, 16, COLORS.muted, width - second - 80, 1.6);
    text(ctx, model.identity, 40, 62, 54, 'TCS Export Display', '#f5f8fb', first - 80, 2);
    const date = time => new Date(time).toISOString().slice(0, 10).replaceAll('-', '/');
    mono(`${date(model.points[0].timestamp)} - ${date(model.points.at(-1).timestamp)}`, 40, 140, 20, '#c8d3df', first - 80);
    const peak = findPeakPoint(model.points, options.ignoreExPeak);
    const peakColor = peak ? intensityColor(peak.type, peak.wind, options.enableExtremeTier) : COLORS.muted;
    const windWidth = text(ctx, peak ? Math.round(peak.wind) : '--', first + 40, 60, EXPORT_LAYOUT.headlineSize, 'TCS Export Display', peakColor, 320);
    const unitX = first + 40 + windWidth + 18;
    text(ctx, 'KT', unitX, 112, 24, 'TCS Export Display', '#c1ccda', 40, 1.5, 700);
    mono(`${Number.isFinite(model.minPressure) ? Math.round(model.minPressure) : '--'} HPA`, first + 40, 146, 18, '#a9b8ca', second - first - 80);
    text(ctx, model.ace.toFixed(4), second + 40, 60, EXPORT_LAYOUT.headlineSize, 'TCS Export Display', peakColor, width - second - 80);
    mono('10⁴ KT² · SYNOPTIC HOURS', second + 40, 146, 16, '#a9b8ca', width - second - 80, 1);
}

function drawPeakIntensityMarker(ctx, model, fit, options) {
    if (!options.markPeakIntensity || !model.points.length) return;
    let peakIndex = -1;
    for (let i = 0; i < model.points.length; i++) {
        if (options.ignoreExPeak && model.points[i].type === 'EX') continue;
        if (peakIndex < 0 || model.points[i].wind > model.points[peakIndex].wind) peakIndex = i;
    }
    if (peakIndex < 0) return;

    const peak = model.points[peakIndex];
    const [x, y] = fit.pixels[peakIndex];
    const color = intensityColor(peak.type, peak.wind, options.enableExtremeTier);
    const label = `MAX ${Math.round(peak.wind)} KT`;
    ctx.save();
    ctx.font = '600 18px "TCS Export Mono"';
    const boxWidth = Math.ceil(ctx.measureText(label).width) + 24;
    const boxHeight = 32;
    const candidates = [
        [x + 24, y - boxHeight - 16],
        [x - boxWidth - 24, y - boxHeight - 16],
        [x + 24, y + 16],
        [x - boxWidth - 24, y + 16]
    ];
    const position = candidates.find(([left, top]) => left >= 12 && left + boxWidth <= EXPORT_SIZE.width - 12
        && top >= EXPORT_SIZE.header + 12 && top + boxHeight <= EXPORT_SIZE.height - 12)
        || candidates[0];
    const boxX = Math.max(12, Math.min(EXPORT_SIZE.width - boxWidth - 12, position[0]));
    const boxY = Math.max(EXPORT_SIZE.header + 12, Math.min(EXPORT_SIZE.height - boxHeight - 12, position[1]));
    const anchorX = x < boxX ? boxX : x > boxX + boxWidth ? boxX + boxWidth : Math.max(boxX + 6, Math.min(boxX + boxWidth - 6, x));
    const anchorY = y < boxY ? boxY : y > boxY + boxHeight ? boxY + boxHeight : Math.max(boxY + 6, Math.min(boxY + boxHeight - 6, y));

    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(anchorX, anchorY); ctx.stroke();
    ctx.fillStyle = 'rgba(10,16,32,.96)';
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.rect(boxX, boxY, boxWidth, boxHeight);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#f5f8fb';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, boxX + 12, boxY + boxHeight / 2);

    // A filled diamond pins the maximum to its exact track position.
    const radius = 13;
    ctx.shadowColor = 'rgba(0,0,0,.8)'; ctx.shadowBlur = 5;
    ctx.beginPath();
    ctx.moveTo(x, y - radius); ctx.lineTo(x + radius, y);
    ctx.lineTo(x, y + radius); ctx.lineTo(x - radius, y); ctx.closePath();
    ctx.fillStyle = color; ctx.strokeStyle = '#f5f8fb'; ctx.lineWidth = 2.5;
    ctx.fill(); ctx.stroke();
    ctx.restore();
    return { left: boxX, top: boxY, width: boxWidth, height: boxHeight };
}

function drawIntensityHistoryChart(ctx, model, options) {
    if (!options.showIntensityHistory) return;
    const samples = sampleSixHourlyIntensity(model.points);
    if (!samples.length) return;

    const peaks = findSignificantIntensityPeaks(samples);
    const { width, height } = EXPORT_SIZE;
    const panelWidth = 640;
    const panelHeight = 258;
    const x = 42;
    const y = height - panelHeight - 42;
    const plot = {
        left: x + 58,
        right: x + panelWidth - 18,
        top: y + 52,
        bottom: y + panelHeight - 43
    };
    const winds = samples.map(sample => sample.wind);
    let minWind = Math.max(0, Math.floor((Math.min(...winds) - 10) / 20) * 20);
    let maxWind = Math.ceil((Math.max(...winds) + 10) / 20) * 20;
    if (maxWind - minWind < 40) maxWind = minWind + 40;
    const range = maxWind - minWind;
    const tickStep = range <= 100 ? 20 : range <= 200 ? 40 : 50;
    const timeSpan = Math.max(1, samples.at(-1).timestamp - samples[0].timestamp);
    const px = timestamp => plot.left
        + (timestamp - samples[0].timestamp) / timeSpan * (plot.right - plot.left);
    const py = wind => plot.bottom
        - (wind - minWind) / range * (plot.bottom - plot.top);

    ctx.save();
    ctx.fillStyle = 'rgba(5, 11, 20, .68)';
    ctx.fillRect(x, y, panelWidth, panelHeight);
    ctx.strokeStyle = 'rgba(113, 224, 238, .68)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, panelWidth - 2, panelHeight - 2);
    ctx.fillStyle = '#4dffff';
    ctx.fillRect(x, y, 7, 42);
    ctx.fillStyle = 'rgba(255,255,255,.14)';
    ctx.fillRect(x + 20, y + 42, panelWidth - 40, 1);

    ctx.font = '600 15px "TCS Export Mono"';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#dce8f2';
    ctx.fillText('INTENSITY HISTORY', x + 22, y + 22);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#718099';
    ctx.fillText('6H REPORTS · 5 KT', x + panelWidth - 20, y + 22);

    ctx.font = '600 12px "TCS Export Mono"';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let tick = Math.ceil(minWind / tickStep) * tickStep; tick <= maxWind; tick += tickStep) {
        const tickY = py(tick);
        ctx.strokeStyle = 'rgba(255,255,255,.12)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(plot.left, tickY); ctx.lineTo(plot.right, tickY); ctx.stroke();
        ctx.fillStyle = '#8290a4';
        ctx.fillText(String(tick), plot.left - 10, tickY);
    }
    ctx.strokeStyle = 'rgba(255,255,255,.26)';
    ctx.beginPath();
    ctx.moveTo(plot.left, plot.top); ctx.lineTo(plot.left, plot.bottom);
    ctx.lineTo(plot.right, plot.bottom); ctx.stroke();

    const xTickCount = Math.min(5, samples.length);
    const xTickIndices = new Set();
    for (let i = 0; i < xTickCount; i++) {
        xTickIndices.add(Math.round(i * (samples.length - 1) / Math.max(1, xTickCount - 1)));
    }
    ctx.font = '600 11px "TCS Export Mono"';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    for (const index of xTickIndices) {
        const sample = samples[index];
        const date = new Date(sample.timestamp);
        const label = `${String(date.getUTCMonth() + 1).padStart(2, '0')}/${String(date.getUTCDate()).padStart(2, '0')} ${String(date.getUTCHours()).padStart(2, '0')}Z`;
        const tickX = px(sample.timestamp);
        ctx.strokeStyle = 'rgba(255,255,255,.22)';
        ctx.beginPath(); ctx.moveTo(tickX, plot.bottom); ctx.lineTo(tickX, plot.bottom + 4); ctx.stroke();
        ctx.fillStyle = '#8290a4';
        ctx.textAlign = index === 0 ? 'left' : index === samples.length - 1 ? 'right' : 'center';
        ctx.fillText(label, tickX, plot.bottom + 8);
    }

    ctx.save();
    ctx.beginPath(); ctx.rect(plot.left, plot.top, plot.right - plot.left, plot.bottom - plot.top); ctx.clip();
    for (let i = 1; i < samples.length; i++) {
        const previous = samples[i - 1];
        const current = samples[i];
        ctx.strokeStyle = intensityColor(current.type, current.wind, options.enableExtremeTier);
        ctx.lineWidth = 2.6;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px(previous.timestamp), py(previous.wind));
        ctx.lineTo(px(current.timestamp), py(current.wind));
        ctx.stroke();
    }
    samples.forEach(sample => {
        const pointX = px(sample.timestamp), pointY = py(sample.wind);
        ctx.beginPath(); ctx.arc(pointX, pointY, 3.1, 0, Math.PI * 2);
        ctx.fillStyle = intensityColor(sample.type, sample.wind, options.enableExtremeTier);
        ctx.fill();
        ctx.strokeStyle = 'rgba(5,11,20,.95)'; ctx.lineWidth = 1.2; ctx.stroke();
    });
    ctx.restore();

    const placedLabels = [];
    peaks.forEach((peak, index) => {
        const pointX = px(peak.point.timestamp), pointY = py(peak.wind);
        const label = `PEAK ${index + 1}`;
        ctx.font = '600 11px "TCS Export Mono"';
        const labelWidth = Math.ceil(ctx.measureText(label).width) + 14;
        const labelHeight = 22;
        const candidates = [
            [pointX + 9, pointY - labelHeight - 10],
            [pointX - labelWidth - 9, pointY - labelHeight - 10],
            [pointX + 9, pointY + 10],
            [pointX - labelWidth - 9, pointY + 10]
        ];
        const inside = ([left, top]) => left >= plot.left + 2
            && left + labelWidth <= plot.right - 2
            && top >= plot.top + 2 && top + labelHeight <= plot.bottom - 2;
        const clear = ([left, top]) => placedLabels.every(box =>
            left + labelWidth + 4 <= box.left || left >= box.left + box.width + 4
            || top + labelHeight + 4 <= box.top || top >= box.top + box.height + 4
        );
        const position = candidates.find(candidate => inside(candidate) && clear(candidate))
            || candidates.find(inside)
            || [Math.max(plot.left + 2, Math.min(plot.right - labelWidth - 2, pointX + 8)),
                Math.max(plot.top + 2, Math.min(plot.bottom - labelHeight - 2, pointY - labelHeight - 8))];
        const [labelX, labelY] = position;
        placedLabels.push({ left: labelX, top: labelY, width: labelWidth, height: labelHeight });
        const color = intensityColor(peak.point.type, peak.wind, options.enableExtremeTier);
        const anchorX = pointX < labelX ? labelX : pointX > labelX + labelWidth ? labelX + labelWidth : pointX;
        const anchorY = pointY < labelY ? labelY : pointY > labelY + labelHeight ? labelY + labelHeight : pointY;
        ctx.strokeStyle = color; ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.moveTo(pointX, pointY); ctx.lineTo(anchorX, anchorY); ctx.stroke();
        ctx.fillStyle = 'rgba(5,11,20,.98)'; ctx.fillRect(labelX, labelY, labelWidth, labelHeight);
        ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.strokeRect(labelX + .5, labelY + .5, labelWidth - 1, labelHeight - 1);
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f5f8fb';
        ctx.fillText(label, labelX + 7, labelY + labelHeight / 2);
        ctx.save(); ctx.translate(pointX, pointY); ctx.rotate(Math.PI / 4);
        ctx.fillStyle = color; ctx.strokeStyle = '#f5f8fb'; ctx.lineWidth = 1.4;
        ctx.fillRect(-4, -4, 8, 8); ctx.strokeRect(-4, -4, 8, 8);
        ctx.restore();
    });
    ctx.restore();
}

function exportOverlayBoxes(options, peakBox) {
    const { width, height } = EXPORT_SIZE;
    const boxes = [{ left: width / 2 - 210, top: height - 36, width: 420, height: 36 }];
    if (peakBox) boxes.push(peakBox);
    if (options.showIntensityHistory) {
        boxes.push({ left: 42, top: height - 258 - 42, width: 640, height: 258 });
    }
    if (options.showLegend) {
        boxes.push(exportLegendBox(EXPORT_SIZE, options));
    }
    return boxes;
}

function drawCityWindArrow(ctx, direction, x, y, color) {
    const vector = cityWindArrow(direction);
    ctx.save(); ctx.translate(x, y);
    ctx.strokeStyle = color; ctx.lineWidth = 1.7; ctx.lineCap = 'round';
    ctx.beginPath();
    if (vector) {
        ctx.rotate(Math.atan2(vector.y, vector.x));
        ctx.moveTo(-7, 0); ctx.lineTo(7, 0);
        ctx.moveTo(2, -4); ctx.lineTo(7, 0); ctx.lineTo(2, 4);
    } else { ctx.moveTo(-4, 0); ctx.lineTo(4, 0); }
    ctx.stroke(); ctx.restore();
}

export function prepareExportCityLabels(ctx, model, fit, options, peakBox) {
    if (!options.showCityObservations) return;
    const observations = deriveCityObservations(model)
        .filter(observation => observation.wind >= 15)
        .sort((a, b) => b.wind - a.wind);
    if (!observations.length) return [];

    const { width, height, header } = EXPORT_SIZE;
    const visible = observation => {
        let lon = ((observation.lon + 180) % 360 + 360) % 360 - 180;
        lon += 360 * Math.round((fit.centerX - lon) / 360);
        const [x, y] = fit.project(lon, mercatorY(observation.lat));
        return Number.isFinite(x) && Number.isFinite(y)
            && x > 8 && x < width - 8 && y > header + 8 && y < height - 8
            ? [x, y] : null;
    };

    const labels = observations.flatMap(observation => {
        const position = visible(observation);
        if (!position) return [];
        const [x, y] = position;
        ctx.font = '600 13px "TCS Export Mono"';
        const nameWidth = ctx.measureText(observation.name).width;
        ctx.font = '600 11px "TCS Export Mono"';
        const windText = `MAX ${observation.wind} KT`;
        const pressureText = `MIN ${observation.pressure} HPA`;
        const windWidth = ctx.measureText(windText).width;
        const detailsWidth = windWidth + 32 + ctx.measureText(pressureText).width;
        return [{ x, y, width: Math.ceil(Math.max(nameWidth, detailsWidth)) + 20, height: 42,
            observation, windText, pressureText, windWidth }];
    });
    return layoutExportCityLabels(labels, fit.pixels,
        { left: 12, top: header + 12, width: width - 24, height: height - header - 54 },
        exportOverlayBoxes(options, peakBox));
}

function drawCityObservationAnnotations(ctx, model, fit, options, peakBox) {
    if (!options.showCityObservations) return;
    ctx.save();
    const labels = prepareExportCityLabels(ctx, model, fit, options, peakBox);
    ctx.textBaseline = 'middle';
    // Paint leaders first; neither a later leader nor a panel covers an earlier label.
    ctx.strokeStyle = 'rgba(200,219,232,.55)'; ctx.lineWidth = 1;
    for (const { leader } of labels) {
        ctx.beginPath(); ctx.moveTo(...leader[0]); ctx.lineTo(...leader[1]); ctx.stroke();
    }
    for (const { x, y, box, observation, windText, pressureText, windWidth } of labels) {
        const { left, top, width: panelWidth, height: panelHeight } = box;
        const color = intensityColor('TS', observation.wind, options.enableExtremeTier);
        ctx.fillStyle = color;
        ctx.fillRect(x - 3, y - 3, 6, 6);
        ctx.strokeStyle = '#07111f'; ctx.lineWidth = 1.2; ctx.strokeRect(x - 3, y - 3, 6, 6);
        ctx.fillStyle = 'rgba(5,11,20,.78)';
        ctx.fillRect(left, top, panelWidth, panelHeight);
        ctx.textAlign = 'left';
        ctx.font = '600 13px "TCS Export Mono"';
        ctx.fillStyle = '#dce8f2'; ctx.fillText(observation.name, left + 10, top + 12);
        ctx.font = '600 11px "TCS Export Mono"';
        ctx.fillStyle = color; ctx.fillText(windText, left + 10, top + 30);
        drawCityWindArrow(ctx, observation.direction, left + 10 + windWidth + 14, top + 30, color);
        ctx.fillStyle = '#b6c4d4'; ctx.fillText(pressureText, left + 10 + windWidth + 32, top + 30);
    }
    ctx.restore();
}

function drawExportLegend(ctx, options) {
    if (!options.showLegend) return;

    const rows = options.enableExtremeTier
        ? [
            ['<34 KT', '#6ec1ea'], ['34–63 KT', '#4dffff'], ['64–82 KT', '#ffffd9'],
            ['83–95 KT', '#ffd98c'], ['96–112 KT', '#ff9e59'], ['113–136 KT', '#ff738a'],
            ['137–169 KT', '#8d75e6'], ['≥170 KT', '#ff7adb']
        ]
        : [
            ['<34 KT', '#6ec1ea'], ['34–63 KT', '#4dffff'], ['64–82 KT', '#ffffd9'],
            ['83–95 KT', '#ffd98c'], ['96–112 KT', '#ff9e59'], ['113–136 KT', '#ff738a'],
            ['≥137 KT', '#8d75e6']
        ];
    const { left: x, top: y, width: panelWidth, height: panelHeight } = exportLegendBox(EXPORT_SIZE, options);

    ctx.save();
    // Hard corners, square swatches and a single neon rule give the key a compact
    // instrument-panel look that reads clearly over either ocean or land.
    ctx.fillStyle = 'rgba(5, 11, 20, .68)';
    ctx.fillRect(x, y, panelWidth, panelHeight);
    ctx.strokeStyle = 'rgba(113, 224, 238, .68)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 1, y + 1, panelWidth - 2, panelHeight - 2);
    ctx.fillStyle = '#4dffff';
    ctx.fillRect(x, y, 5, 34);
    ctx.fillStyle = 'rgba(255,255,255,.14)';
    ctx.fillRect(x + 18, y + 39, panelWidth - 36, 1);
    text(ctx, 'WIND INTENSITY', x + 20, y + 12, 15, 'TCS Export Mono', '#dce8f2', panelWidth - 40, .6, 600);

    rows.forEach(([label, color], index) => {
        const rowY = y + 48 + index * EXPORT_LAYOUT.legendRowHeight;
        ctx.fillStyle = color;
        ctx.fillRect(x + 20, rowY + 2, 15, 15);
        ctx.strokeStyle = 'rgba(255,255,255,.7)';
        ctx.lineWidth = 1;
        ctx.strokeRect(x + 20.5, rowY + 2.5, 14, 14);
        text(ctx, label, x + 48, rowY + 1, 16, 'TCS Export Mono', color,
            panelWidth - 68, 0.2, 600);
    });
    if (options.markPeakIntensity) {
        const markerY = y + 48 + rows.length * EXPORT_LAYOUT.legendRowHeight;
        ctx.fillStyle = 'rgba(255,255,255,.14)';
        ctx.fillRect(x + 18, markerY - 3, panelWidth - 36, 1);
        ctx.save();
        ctx.translate(x + 28, markerY + 14);
        ctx.rotate(Math.PI / 4);
        ctx.fillStyle = '#f5f8fb';
        ctx.fillRect(-6, -6, 12, 12);
        ctx.restore();
        text(ctx, 'MARKED MAXIMUM', x + 48, markerY + 5, 14, 'TCS Export Mono', '#dce8f2', panelWidth - 68, 0.2, 600);
    }
    if (options.showCityObservations) {
        const keyY = y + panelHeight - 20;
        drawCityWindArrow(ctx, 'W', x + 28, keyY, '#b6c4d4');
        text(ctx, 'CITY WIND FLOW', x + 48, keyY - 7, 13, 'TCS Export Mono', '#b6c4d4', panelWidth - 68, .2, 600);
    }
    ctx.restore();
}

export async function renderTrackExport(model, suppliedOptions = {}) {
    const options = normalizeTrackExportOptions(suppliedOptions);
    const fit = fitExportTrack(model.points);
    const world = await loadAssets();
    const canvas = document.createElement('canvas');
    const { width, height, header } = EXPORT_SIZE;
    canvas.width = width; canvas.height = height;
    try {
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('浏览器无法创建导出画布，请关闭部分标签页后重试。');
        ctx.fillStyle = COLORS.ocean; ctx.fillRect(0, 0, width, height);
        ctx.save(); ctx.beginPath(); ctx.rect(0, header, width, height - header); ctx.clip();
        await drawLand(ctx, world, fit);
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 3; ctx.lineJoin = 'round';
        ctx.beginPath();
        fit.pixels.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
        ctx.stroke();
        for (let i = 0; i < model.points.length; i++) {
            const p = model.points[i], [x, y] = fit.pixels[i];
            // Mark only 00/06/12/18 UTC; retain the full track in the connecting line.
            if (new Date(p.timestamp).getUTCHours() % 6 !== 0) continue;
            ctx.fillStyle = intensityColor(p.type, p.wind, options.enableExtremeTier); ctx.strokeStyle = '#000'; ctx.lineWidth = 1.6;
            ctx.beginPath();
            if (TRIANGLES.has(p.type)) {
                ctx.moveTo(x, y - 9); ctx.lineTo(x + 10, y + 9); ctx.lineTo(x - 10, y + 9); ctx.closePath();
            } else if (p.type === 'SS' || p.type === 'SD') ctx.rect(x - 8, y - 8, 16, 16);
            else ctx.arc(x, y, 8, 0, Math.PI * 2);
            ctx.fill(); ctx.stroke();
            if (i > 0 && i % 500 === 0) await new Promise(resolve => setTimeout(resolve, 0));
        }
        const peakBox = drawPeakIntensityMarker(ctx, model, fit, options);
        ctx.restore();
        drawHeader(ctx, model, options);
        drawExportLegend(ctx, options);
        drawIntensityHistoryChart(ctx, model, options);
        drawCityObservationAnnotations(ctx, model, fit, options, peakBox);
        ctx.font = '600 20px "TCS Export Mono"'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(156,163,175,.30)';
        ctx.fillText('GENERATED BY STORM_INC GAME', width / 2, height - 18);
        return await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('PNG 编码失败，请重试。')), 'image/png'));
    } finally {
        // Release the ~10 MB backing store, including on drawing/encoding failure.
        canvas.width = 1; canvas.height = 1;
    }
}
