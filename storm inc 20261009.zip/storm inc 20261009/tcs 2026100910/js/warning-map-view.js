// One view description for the canvas renderer and its geography worker.
// Cone calculations share complete-day cutoffs with the live layer.
import { forecastDisplayLimit, FORECAST_HORIZONS } from './forecast-horizon.js';
import { getWarningWindBands } from './wind-radii-outlines.js?v=20261008-forecast-categories1';
export const WARNING_MAP_SIZE = Object.freeze({ width: 1600, height: 1200 });
// Leave room for the right-hand legend and the forecast-label leaders.
export const WARNING_MAP_FIT_EXTENT = Object.freeze([[140, 90], [1280, 1100]]);

export function prepareWarningMapView(cyclone, timeIndex, { fitCone = false } = {}) {
    const { width, height } = WARNING_MAP_SIZE;
    const [centerLon, centerLat] = cyclone.track[timeIndex];
    const unwrapLon = lon => {
        let diff = lon - centerLon;
        while (diff > 180) diff -= 360;
        while (diff < -180) diff += 360;
        return centerLon + diff;
    };
    const pastTrack = cyclone.track.slice(0, timeIndex + 1).map(p => {
        const newP = [...p]; newP[0] = unwrapLon(p[0]); return newP;
    });
    const currentPoint = pastTrack[timeIndex];
    const windBands = getWarningWindBands(cyclone, currentPoint);
    const currentAge = timeIndex * 3;
    const snapAge = Math.floor(currentAge / 6) * 6;
    let forecastModelsRaw = [];
    if (cyclone.forecastLogs && cyclone.forecastLogs[snapAge]) {
        forecastModelsRaw = cyclone.forecastLogs[snapAge];
    } else if (cyclone.status === 'active' && cyclone.pathForecasts) {
        forecastModelsRaw = cyclone.pathForecasts;
    }
    const forecastModels = forecastModelsRaw.map(model => ({
        ...model,
        track: model.track.map(p => {
            const newP = [...p]; newP[0] = unwrapLon(p[0]); return newP;
        })
    }));
    const rawSteps = [], meanTrack = [];
    let maxSteps = 0, quantizedLimit = 0;
    if (forecastModels.length > 0 && forecastModels[0].track.length > 1) {
        maxSteps = d3.max(forecastModels, m => m.track.length);
        quantizedLimit = forecastDisplayLimit(forecastModels, FORECAST_HORIZONS);
        let maxRadiusSoFar = 0.0;
        for (let i = 0; quantizedLimit && i <= quantizedLimit; i++) {
            const pointsAtStep = [];
            forecastModels.forEach(m => { if (m.track[i]) pointsAtStep.push(m.track[i]); });
            if (pointsAtStep.length === 0) continue;
            const avgLon = d3.mean(pointsAtStep, p => p[0]);
            const avgLat = d3.mean(pointsAtStep, p => p[1]);
            meanTrack.push([avgLon, avgLat]);
            const stdDev = d3.deviation(pointsAtStep, p => {
                const dx = (p[0] - avgLon) * Math.cos(avgLat * Math.PI / 180);
                const dy = p[1] - avgLat;
                return Math.sqrt(dx * dx + dy * dy);
            }) || 0;
            const jitter = Math.sin(i * 132.19 + snapAge) * 0.0;
            const breathing = Math.cos(i * 0.5) * 0.03;
            let radiusDeg = i === 0 ? 0
                : Math.max(0.02, (i * 0.14) + (stdDev * 1.5)
                    + (jitter + breathing) * (1 + i * 0.05));
            if (radiusDeg < maxRadiusSoFar * 0.98) radiusDeg = maxRadiusSoFar * 0.98;
            else maxRadiusSoFar = radiusDeg;
            rawSteps.push({ lon: avgLon, lat: avgLat, r: radiusDeg,
                cosL: Math.cos(avgLat * Math.PI / 180) });
        }
    }
    const projection = d3.geoEquirectangular().rotate([-centerLon, 0])
        .center([0, centerLat]).scale(3500).translate([width / 2, height / 2]);
    let fitted = false;
    if (fitCone && (rawSteps.length > 1 || windBands.some(band => band.radii.some(r => r > 0)))) {
        // The rendered uncertainty primitives are screen-space circles. Fit
        // those same disks, not just the centerline or a latitude/longitude box.
        // Their common tangent bridges cannot extend beyond this envelope.
        let west = Infinity, east = -Infinity, north = Infinity, south = -Infinity;
        for (const step of rawSteps) {
            const [x, y] = projection([step.lon, step.lat]);
            const radiusPoint = projection([step.lon, step.lat + step.r]);
            const r = Math.hypot(radiusPoint[0] - x, radiusPoint[1] - y);
            west = Math.min(west, x - r); east = Math.max(east, x + r);
            north = Math.min(north, y - r); south = Math.max(south, y + r);
        }
        // Warning wind circles are four projected ellipse quadrants, not
        // screen-space disks. Match the renderer's latitude correction and
        // include their radial connectors in the same envelope as the cone.
        const [cx, cy] = projection(currentPoint);
        const pixelsPerDegree = projection.scale() * Math.PI / 180;
        const cosLat = Math.max(0.1, Math.cos(centerLat * Math.PI / 180));
        for (const {radii} of windBands) {
            const [ne, se, sw, nw] = radii;
            west = Math.min(west, cx - Math.max(sw, nw) * pixelsPerDegree / cosLat);
            east = Math.max(east, cx + Math.max(ne, se) * pixelsPerDegree / cosLat);
            north = Math.min(north, cy - Math.max(ne, nw) * pixelsPerDegree);
            south = Math.max(south, cy + Math.max(se, sw) * pixelsPerDegree);
        }
        const [[left, top], [right, bottom]] = WARNING_MAP_FIT_EXTENT;
        // Stroke widths are fixed canvas pixels, independent of map scale.
        const outlinePadding = Math.max(0, ...windBands.map(band => band.width / 2 + 1));
        const factor = Math.min((right - left - 2 * outlinePadding) / (east - west),
            (bottom - top - 2 * outlinePadding) / (south - north));
        if (Number.isFinite(factor) && factor > 0) {
            projection.scale(3500 * factor).translate([
                (left + right) / 2 - factor * ((west + east) / 2 - width / 2),
                (top + bottom) / 2 - factor * ((north + south) / 2 - height / 2)
            ]);
            fitted = true;
        }
    }
    const mapCenter = fitted ? projection.invert([width / 2, height / 2]) : [centerLon, centerLat];
    return { projection, centerLon, centerLat, currentPoint, pastTrack,
        currentAge, snapAge, forecastModels, rawSteps, meanTrack, maxSteps, quantizedLimit, windBands,
        mapCenterLon: unwrapLon(mapCenter[0]), mapCenterLat: mapCenter[1], fitted };
}
