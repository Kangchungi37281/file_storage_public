// 发布开关：改为 false 后，隐藏该图层的入口、图例及手册说明。
// 修改后刷新页面；这里只控制展示，不关闭模拟中的海温/风切变物理。
export const DISPLAY_FEATURES = Object.freeze({
    sst: false,
    shear: true
});

export function applyDisplayFeatures(root = document, features = DISPLAY_FEATURES) {
    root.querySelectorAll('[data-display-feature]').forEach(element => {
        const enabled = features[element.dataset.displayFeature] === true;
        element.hidden = !enabled;
        element.style.display = enabled ? '' : 'none';
    });
}
