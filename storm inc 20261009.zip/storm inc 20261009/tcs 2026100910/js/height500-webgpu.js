import { MONTHLY_HEIGHT_GRID } from "./monthly-height-data.js";
import { packedWeatherSequenceRecord } from "./daily-weather.js?v=20260914-weather-gpu1";

const clampUnit = value => Math.max(0, Math.min(1, value));
const smoothstepJs = value => {
    const t = clampUnit(value);
    return t * t * (3 - 2 * t);
};
const wrapLongitudeJs = value => ((value + 180) % 360 + 360) % 360 - 180;

const NH_MONTHLY = [
    null,
    { summer: .05, ridgeLatitude: 16.0, jetLatitude: 32.5 },
    { summer: .10, ridgeLatitude: 15.5, jetLatitude: 32.5 },
    { summer: .20, ridgeLatitude: 16.0, jetLatitude: 32.5 },
    { summer: .35, ridgeLatitude: 17.0, jetLatitude: 32.5 },
    { summer: .50, ridgeLatitude: 19.5, jetLatitude: 37.5 },
    { summer: .70, ridgeLatitude: 23.0, jetLatitude: 37.5 },
    { summer: .90, ridgeLatitude: 27.5, jetLatitude: 40.0 },
    { summer: 1.00, ridgeLatitude: 30.0, jetLatitude: 45.0 },
    { summer: .85, ridgeLatitude: 28.0, jetLatitude: 42.5 },
    { summer: .60, ridgeLatitude: 24.0, jetLatitude: 40.0 },
    { summer: .30, ridgeLatitude: 21.0, jetLatitude: 35.0 },
    { summer: .10, ridgeLatitude: 18.0, jetLatitude: 35.0 }
];
function circulationForMonth(month, hemisphere) {
    const numericMonth = ((Math.round(month) - 1) % 12 + 12) % 12 + 1;
    const northernMonth = hemisphere < 0 ? (numericMonth + 5) % 12 + 1 : numericMonth;
    const table = NH_MONTHLY[northernMonth];
    if (hemisphere < 0) {
        return {
            summer: table.summer,
            ridgeLatitude: 24.5 + 2.8 * table.summer + 2,
            jetLatitude: Math.max(33, table.jetLatitude - (2 + 4 * table.summer))
                + 2 - 4
        };
    }
    return {
        summer: table.summer,
        ridgeLatitude: table.ridgeLatitude + 2,
        jetLatitude: table.jetLatitude + 2
    };
}

export function packBackgroundWaveFieldTerms(systems, month) {
    const background = systems.upper.find(cell => cell.role === 'height-background');
    if (!background) throw new Error('No height-background cell was initialized');
    const calendarMonth = background.calendarMonth || month || 8;
    const grid = MONTHLY_HEIGHT_GRID[500][Math.max(0, Math.min(11, Math.round(calendarMonth || 8) - 1))];
    const baseGrid = Float32Array.from(grid.flat());
    let flatGrid = baseGrid;
    let weatherData = new Uint32Array(0);
    let weatherDay = 0;
    let weatherMeanBlend = 0;
    if (background.weatherSequence) {
        const sequence = background.weatherSequence;
        weatherData = packedWeatherSequenceRecord(sequence.record);
        weatherDay = sequence.startDay + (background.elapsedHours || 0) / 24;
        const dates = [-14, 16, 47, 77, 108, 139, 169, 200, 230];
        let dateIndex = 0;
        while (dateIndex < dates.length - 2 && weatherDay > dates[dateIndex + 1]) dateIndex++;
        weatherMeanBlend = Math.max(0, Math.min(1,
            (weatherDay - dates[dateIndex]) / (dates[dateIndex + 1] - dates[dateIndex])
        ));
        const monthA = MONTHLY_HEIGHT_GRID[500][dateIndex + 3];
        const monthB = MONTHLY_HEIGHT_GRID[500][dateIndex + 4];
        const meanGridA = Float32Array.from(monthA.flat());
        const meanGridB = Float32Array.from(monthB.flat());
        flatGrid = new Float32Array(baseGrid.length + meanGridA.length + meanGridB.length);
        flatGrid.set(baseGrid, 0);
        flatGrid.set(meanGridA, baseGrid.length);
        flatGrid.set(meanGridB, baseGrid.length + meanGridA.length);
    }
    const waveBank = hemisphere => Float32Array.from((background.waves || [])
        .filter(wave => wave.hemisphere === hemisphere
            && (!background.climatologyVersion || wave.isManual || wave.isTransientAnomaly))
        .flatMap(wave => [wave.k, wave.latitude, wave.width, wave.phase,
            wave.amplitude, wave.axisScaleDeg || 0]));
    const north = circulationForMonth(calendarMonth, 1);
    const south = {
        ...circulationForMonth(calendarMonth, -1),
        // The procedural SH column diagnoses its own monthly ridge/jet.
        // Consume the serialized CPU axes rather than fitting another table;
        // unversioned snapshots and the full WNP field retain their old axes.
        ...(background.southernBasicStateVersion >= 2 && !background.climatologyVersion
            ? background.southernBasicStateAxes : {})
    };
    const elapsed = background.elapsedHours || 0;
    const features = new Float32Array(36);
    const monsoon = background.monsoonCirculation;
    if (monsoon) {
        let strength = 0;
        let progress = 0;
        const regime = background.wnpRecurvatureRegime;
        if (regime) {
            if (Number.isFinite(regime.periodHours)) {
                const wave = .5 + .5 * Math.sin(
                    regime.phase + 2 * Math.PI * elapsed / regime.periodHours
                );
                progress = smoothstepJs(wave);
                strength = clampUnit((regime.baseStrength || 0)
                    + (regime.cycleAmplitude || 0) * progress);
            } else if (regime.strength) {
                progress = smoothstepJs(regime.initialProgress
                    + elapsed / regime.developmentHours);
                strength = regime.strength;
            }
        }
        const independentWobbleScale = 1 - .72 * strength;
        features.set([
            1,
            wrapLongitudeJs(monsoon.lon + 10 * strength * progress
                + independentWobbleScale * 5 * Math.sin(
                    2 * Math.PI * elapsed / monsoon.longitudePeriodHours
                        + monsoon.longitudePhase
                )),
            monsoon.lat + 10 * strength * progress
                + independentWobbleScale * 1.6 * Math.sin(
                    2 * Math.PI * elapsed / monsoon.latitudePeriodHours
                        + monsoon.latitudePhase
                ),
            monsoon.amplitude * (.88 + .12 * Math.sin(
                2 * Math.PI * elapsed / monsoon.amplitudePeriodHours
                    + monsoon.amplitudePhase
            )) * (1 + .22 * strength * progress) * .58,
            monsoon.sigmaLon,
            monsoon.sigmaLat,
            monsoon.tilt
        ], 0);
    }

    const recurvature = background.wnpRecurvatureRegime;
    if (recurvature) {
        let strength = 0;
        let progress = 0;
        if (Number.isFinite(recurvature.periodHours)) {
            const wave = .5 + .5 * Math.sin(
                recurvature.phase + 2 * Math.PI * elapsed / recurvature.periodHours
            );
            progress = smoothstepJs(wave);
            strength = clampUnit((recurvature.baseStrength || 0)
                + (recurvature.cycleAmplitude || 0) * progress);
        } else if (recurvature.strength) {
            progress = smoothstepJs(recurvature.initialProgress
                + elapsed / recurvature.developmentHours);
            strength = recurvature.strength;
        }
        if (background.climatologyVersion && strength > .01) {
            features.set([
                1,
                wrapLongitudeJs(recurvature.troughLon
                    + recurvature.driftDegPerHour * elapsed),
                recurvature.troughLat + .8 * Math.sin(
                    2 * Math.PI * elapsed / recurvature.latitudePeriodHours
                        + recurvature.latitudePhase
                ),
                recurvature.sigmaLon,
                recurvature.sigmaLat,
                recurvature.tilt,
                105 * strength * (.62 + .38 * progress)
                    * (.92 + .08 * Math.sin(
                        2 * Math.PI * elapsed / recurvature.amplitudePeriodHours
                            + recurvature.amplitudePhase
                    ))
            ], 7);
        }
    }

    const ridgeWeather = background.ridgeWeather;
    if (background.climatologyVersion && ridgeWeather?.corridorEnvelope > 0) {
        features.set([
            1,
            Number.isFinite(ridgeWeather.currentLon) ? ridgeWeather.currentLon : ridgeWeather.lon,
            clampUnit(ridgeWeather.corridorEnvelope)
        ], 14);
    }

    const regional = background.regionalCirculationRegime;
    const regionalConfigs = {
        EPAC: { hemisphere: 1, tropicalLon: 232, tropicalLat: 12, tropicalAmplitude: 30, troughLon: 218, troughLat: 36, troughAmplitude: 135 },
        NATL: { hemisphere: 1, tropicalLon: 305, tropicalLat: 14, tropicalAmplitude: 28, troughLon: 286, troughLat: 38, troughAmplitude: 82 },
        NIO: { hemisphere: 1, tropicalLon: 82, tropicalLat: 15, tropicalAmplitude: 34, troughLon: 66, troughLat: 34, troughAmplitude: 70 },
        SHEM: { hemisphere: -1, tropicalLon: 168, tropicalLat: -13, tropicalAmplitude: 30, troughLon: 150, troughLat: -38, troughAmplitude: 76 },
        SIO: { hemisphere: -1, tropicalLon: 78, tropicalLat: -13, tropicalAmplitude: 31, troughLon: 58, troughLat: -38, troughAmplitude: 78 },
        SATL: { hemisphere: -1, tropicalLon: 335, tropicalLat: -15, tropicalAmplitude: 25, troughLon: 315, troughLat: -39, troughAmplitude: 72 }
    };
    const regionalConfig = regionalConfigs[background.activeBasin];
    if (regionalConfig && regional?.basin === background.activeBasin) {
        const wave = .5 + .5 * Math.sin(regional.phase
            + 2 * Math.PI * elapsed / Math.max(168, regional.periodHours));
        const pulse = smoothstepJs(wave);
        const cycleAmplitude = Number.isFinite(regional.cycleAmplitude)
            ? regional.cycleAmplitude : .62 * (1 - regional.strength);
        const strength = clampUnit(regional.strength + cycleAmplitude * pulse);
        if (strength > .01) {
            features.set([
                1,
                regionalConfig.hemisphere,
                wrapLongitudeJs(regionalConfig.tropicalLon + regional.tropicalLonOffset
                    + 4 * Math.sin(regional.phase * .73
                        + 2 * Math.PI * elapsed / (regional.periodHours * 1.25))),
                regionalConfig.tropicalLat + regional.tropicalLatOffset
                    + regionalConfig.hemisphere * 3 * pulse,
                regional.tilt,
                regionalConfig.tropicalAmplitude * strength * .58,
                wrapLongitudeJs(regionalConfig.troughLon + regional.troughLonOffset
                    + regional.driftDegPerHour * elapsed),
                regionalConfig.troughLat + regional.troughLatOffset
                    + regionalConfig.hemisphere * 1.5 * Math.sin(
                        regional.phase + 2 * Math.PI * elapsed
                            / (regional.periodHours * .82)
                    ),
                regional.tilt * .55,
                regionalConfig.troughAmplitude * strength
            ], 17);
        }
    }

    const summerGradientByMonth = { 6: .85, 7: 1, 8: 1, 9: .90 };
    features[27] = background.climatologyVersion
        ? summerGradientByMonth[calendarMonth] || 0 : 0;
    const nioWinterWeights = [.98, .95, .78, .52, .20, 0, 0, 0, .03, .38, .72, .95];
    if (background.activeBasin === 'NIO') {
        const position = ((calendarMonth - 1) % 12 + 12) % 12;
        const lower = Math.floor(position);
        const upper = (lower + 1) % 12;
        const fraction = position - lower;
        features[28] = nioWinterWeights[lower]
            + (nioWinterWeights[upper] - nioWinterWeights[lower]) * fraction;
    }
    const nioProfile = new Float32Array(341);
    if (features[28] > .01) {
        const stepDegrees = .25;
        const stepRadians = stepDegrees * Math.PI / 180;
        const radians = Math.PI / 180;
        for (let index = 1; index <= 340; index++) {
            const latitude0 = (index - 1) * stepDegrees;
            const latitude1 = index * stepDegrees;
            const windAdjustment = latitude => features[28] * (
                4 * Math.exp(-.5 * ((latitude - 23) / 10) ** 2)
                - 3 * Math.exp(-.5 * ((latitude - 33) / 5.5) ** 2)
            );
            const f0 = 2 * 7.292115e-5 * Math.sin(latitude0 * radians);
            const f1 = 2 * 7.292115e-5 * Math.sin(latitude1 * radians);
            const dz = -6371000 * stepRadians
                * (f0 * windAdjustment(latitude0) + f1 * windAdjustment(latitude1))
                / (2 * 9.80665);
            nioProfile[index] = nioProfile[index - 1] + dz;
        }
    }
    const northProfile = background.zonalProfiles?.[500]?.[1]
        || background.zonalProfiles?.[500]?.['1'] || new Array(341).fill(5845);
    const southProfile = background.zonalProfiles?.[500]?.[-1]
        || background.zonalProfiles?.[500]?.['-1'] || new Array(341).fill(5845);
    const profileData = new Float32Array(341 * 3);
    profileData.set(northProfile.slice(0, 341), 0);
    profileData.set(southProfile.slice(0, 341), 341);
    profileData.set(nioProfile, 682);
    features[30] = background.climatologyVersion ? 1 : 0;
    features[34] = background.axisMappingVersion || 1;
    if (background.weatherSequence && weatherData.length) {
        features[31] = 1;
        features[32] = weatherDay;
        features[33] = weatherMeanBlend;
    }
    return {
        background,
        month: Math.max(1, Math.min(12, Math.round(month || 8))),
        grid: flatGrid,
        weatherData,
        northWaves: waveBank(1),
        southWaves: waveBank(-1),
        waves: Float32Array.from([
            ...waveBank(1),
            ...waveBank(-1)
        ]),
        northTropicalWaves: Float32Array.from((background.tropicalWaves || [])
            .filter(wave => wave.hemisphere === 1)
            .flatMap(wave => [wave.k, wave.latitude, wave.width, wave.phase, wave.amplitude])),
        southTropicalWaves: Float32Array.from((background.tropicalWaves || [])
            .filter(wave => wave.hemisphere === -1)
            .flatMap(wave => [wave.k, wave.latitude, wave.width, wave.phase, wave.amplitude])),
        tropicalWaves: Float32Array.from([
            ...(background.tropicalWaves || []).filter(wave => wave.hemisphere === 1)
                .flatMap(wave => [wave.k, wave.latitude, wave.width, wave.phase, wave.amplitude]),
            ...(background.tropicalWaves || []).filter(wave => wave.hemisphere === -1)
                .flatMap(wave => [wave.k, wave.latitude, wave.width, wave.phase, wave.amplitude])
        ]),
        equatorialWaves: Float32Array.from((background.equatorialWaves || [])
            .flatMap(wave => [wave.k, wave.phase, wave.latitude, wave.width, wave.amplitude])),
        northCirculation: north,
        southCirculation: south,
        features,
        profileData
    };
}


export const BACKGROUND_WAVE_SHADER = `
struct Wave { k: f32, latitude: f32, width: f32, phase: f32, amplitude: f32, axisScale: f32 };
struct TropicalWave { k: f32, latitude: f32, width: f32, phase: f32, amplitude: f32 };
struct EquatorialWave { k: f32, phase: f32, latitude: f32, width: f32, amplitude: f32 };
struct Params {
    pointCount: u32, northCount: u32, southCount: u32, equatorialCount: u32,
    northTropicalCount: u32, southTropicalCount: u32, _pad0: u32, _pad1: u32,
    northRidge: f32, northJet: f32, southRidge: f32, southJet: f32
};
@group(0) @binding(0) var<storage, read> pointData: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read> heightGrid: array<f32>;
@group(0) @binding(2) var<storage, read> waveData: array<Wave>;
@group(0) @binding(3) var<storage, read> equatorialData: array<EquatorialWave>;
@group(0) @binding(4) var<storage, read> featureData: array<f32>;
@group(0) @binding(5) var<storage, read> profileData: array<f32>;
@group(0) @binding(6) var<storage, read> tropicalData: array<TropicalWave>;
@group(0) @binding(7) var<storage, read_write> resultData: array<vec2<f32>>;
@group(0) @binding(8) var<uniform> params: Params;
@group(0) @binding(9) var<storage, read> weatherRecord: array<u32>;
const RAD: f32 = 0.017453292519943295;
fn wrapLon(x: f32) -> f32 { return x - 360.0 * floor((x + 180.0) / 360.0); }
fn smooth01(x: f32) -> f32 {
    let t = clamp(x, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}
fn cubic(a: f32, b: f32, c: f32, d: f32, t: f32) -> f32 {
    return b + 0.5 * t * (c - a + t * (2.0 * a - 5.0 * b + 4.0 * c - d
        + t * (3.0 * (b - c) + d - a)));
}
fn wrapCol(col: i32) -> i32 { return ((col % 72) + 72) % 72; }
fn sampleRow(row: i32, ix: i32, tx: f32, gridOffset: u32) -> f32 {
    let j = clamp(row, 0, 72);
    return cubic(
        heightGrid[gridOffset + u32(j * 72 + wrapCol(ix - 1))],
        heightGrid[gridOffset + u32(j * 72 + wrapCol(ix))],
        heightGrid[gridOffset + u32(j * 72 + wrapCol(ix + 1))],
        heightGrid[gridOffset + u32(j * 72 + wrapCol(ix + 2))], tx
    );
}
fn monthlyHeightFromGrid(lon: f32, lat: f32, gridOffset: u32) -> f32 {
    var wrappedLon = lon % 360.0;
    if (wrappedLon < 0.0) { wrappedLon += 360.0; }
    let x = wrappedLon / 5.0;
    let y = (clamp(lat, -90.0, 90.0) + 90.0) / 2.5;
    let ix = i32(floor(x));
    let iy = i32(floor(y));
    let tx = x - f32(ix);
    let ty = y - f32(iy);
    return cubic(sampleRow(iy - 1, ix, tx, gridOffset), sampleRow(iy, ix, tx, gridOffset),
        sampleRow(iy + 1, ix, tx, gridOffset), sampleRow(iy + 2, ix, tx, gridOffset), ty);
}
fn monthlyHeight(lon: f32, lat: f32) -> f32 {
    return monthlyHeightFromGrid(lon, lat, 0u);
}
fn weatherValue(day: u32, row: i32, col: i32) -> f32 {
    let d = min(215u, day);
    let y = u32(clamp(row, 0, 26));
    let x = u32(clamp(col, 0, 46));
    let index = ((d * 3u + 1u) * 27u + y) * 47u + x;
    let word = weatherRecord[index >> 1u];
    let valueBits = select(word & 65535u, word >> 16u, (index & 1u) == 1u);
    return f32(bitcast<i32>(valueBits << 16u) >> 16u);
}
fn weatherRow(day: u32, row: i32, ix: i32, tx: f32) -> f32 {
    return cubic(weatherValue(day, row, ix - 1), weatherValue(day, row, ix),
        weatherValue(day, row, ix + 1), weatherValue(day, row, ix + 2), tx);
}
fn weatherSpatial(day: u32, ix: i32, iy: i32, tx: f32, ty: f32) -> f32 {
    return cubic(weatherRow(day, iy - 1, ix, tx), weatherRow(day, iy, ix, tx),
        weatherRow(day, iy + 1, ix, tx), weatherRow(day, iy + 2, ix, tx), ty);
}
fn weatherSequenceAnomaly(lon: f32, lat: f32) -> f32 {
    if (featureData[31] < 0.5) { return 0.0; }
    let longitude = lon - 360.0 * floor(lon / 360.0);
    let day = featureData[32];
    let weight = smooth01((longitude - 85.0) / 10.0)
        * smooth01((200.0 - longitude) / 10.0)
        * smooth01(lat / 5.0)
        * smooth01((65.0 - lat) / 10.0)
        * smooth01((215.0 - day) / 5.0);
    if (weight == 0.0) { return 0.0; }
    let x = clamp((longitude - 85.0) / 2.5, 0.0, 46.0);
    let y = clamp(lat / 2.5, 0.0, 26.0);
    let ix = i32(floor(x));
    let iy = i32(floor(y));
    let z = x - f32(ix);
    let w = y - f32(iy);
    let lowerDay = u32(floor(clamp(day, 0.0, 215.0)));
    let timeFraction = clamp(day - f32(lowerDay), 0.0, 1.0);
    let sample0 = weatherSpatial(lowerDay, ix, iy, z, w);
    let sample1 = weatherSpatial(min(215u, lowerDay + 1u), ix, iy, z, w);
    let observed = mix(sample0, sample1, timeFraction);
    let gridStride = 5256u;
    let meanA = monthlyHeightFromGrid(longitude, lat, gridStride);
    let meanB = monthlyHeightFromGrid(longitude, lat, gridStride * 2u);
    let sourceMean = mix(meanA, meanB, featureData[33]);
    return weight * (observed - sourceMean);
}
fn profileHeight(offset: u32, latitude: f32) -> f32 {
    let position = clamp(latitude / 0.25, 0.0, 340.0);
    let lower = u32(floor(position));
    let upper = min(340u, lower + 1u);
    let fraction = position - f32(lower);
    return profileData[offset + lower]
        + (profileData[offset + upper] - profileData[offset + lower]) * fraction;
}
fn waveAnomaly(lon: f32, latitude: f32, ridgeLatitude: f32, displacement: f32,
    start: u32, waveCount: u32) -> f32 {
    var disturbance = 0.0;
    let westerlyEdge = ridgeLatitude + 1.0;
    for (var i = 0u; i < waveCount; i++) {
        let wave = waveData[start + i];
        let envelopeScale = max(7.0, wave.width);
        let normalizedLat = (latitude - (wave.latitude + 0.28 * displacement)) / envelopeScale;
        let envelope = exp(-0.5 * normalizedLat * normalizedLat);
        let longTaper = smooth01((latitude - westerlyEdge) / 16.0);
        let shortTaper = smooth01((latitude - (westerlyEdge + 1.0)) / 12.0);
        let polewardTaper = 1.0 - smooth01((latitude - 78.0) / 9.0);
        let latitudeTaper = select(shortTaper, longTaper, wave.k <= 3.0) * polewardTaper;
        let amplitudeScale = select(1.65, 0.84, wave.k <= 3.0);
        disturbance += wave.amplitude * amplitudeScale
            * cos(wave.k * lon * RAD + wave.phase) * envelope * latitudeTaper;
    }
    return 70.0 * tanh(disturbance / 70.0);
}
fn equatorialHeight(lon: f32, lat: f32) -> f32 {
    var anomaly = 0.0;
    for (var i = 0u; i < params.equatorialCount; i++) {
        let mode = equatorialData[i];
        let phase = mode.k * lon * RAD + mode.phase;
        let trough = max(0.0, cos(phase));
        let dy = (lat - mode.latitude) / max(7.0, mode.width);
        anomaly -= mode.amplitude * trough * trough * exp(-0.5 * dy * dy);
    }
    return 0.65 * clamp(anomaly, -30.0, 0.0);
}
fn regionalHeight(lon: f32, lat: f32) -> f32 {
    var height = 0.0;
    if (featureData[17] > 0.5 && lat * featureData[18] > 0.0) {
        let tropicalDx = wrapLon(lon - featureData[19]);
        let tropicalDy = lat - (featureData[20] + featureData[21] * tropicalDx);
        let tx = tropicalDx / 31.0;
        let ty = tropicalDy / 7.5;
        let tropical = exp(-0.5 * (tx * tx + ty * ty));
        let troughDx = wrapLon(lon - featureData[23]);
        let troughDy = lat - (featureData[24] + featureData[25] * troughDx);
        let rx = troughDx / 25.0;
        let ry = troughDy / 18.0;
        let trough = exp(-0.5 * (rx * rx + ry * ry));
        let poleward = 0.28 + 0.72 * smooth01((abs(lat) - 12.0) / 14.0);
        height -= featureData[22] * tropical + featureData[26] * poleward * trough;
    }
    return height;
}
fn coreHeight(lon: f32, lat: f32, hemisphere: f32, north: bool) -> vec2<f32> {
    let northRidge = params.northRidge;
    let northJet = params.northJet;
    let ridgeLatitude = select(params.southRidge, northRidge, north);
    let jetLatitude = select(params.southJet, northJet, north);
    let latitude = abs(lat);
    let waveStart = select(params.northCount, 0u, north);
    let waveCount = select(params.southCount, params.northCount, north);

    var jetDisplacement = 0.0;
    var ridgeDisplacement = 0.0;
    for (var i = 0u; i < waveCount; i++) {
        let wave = waveData[waveStart + i];
        if (wave.k <= 3.0) {
            let axisScale = wave.axisScale * 0.80 * select(0.60, 1.0, north);
            let normalizedJetOffset = (jetLatitude - wave.latitude) / max(8.0, wave.width);
            let envelope = exp(-0.5 * normalizedJetOffset * normalizedJetOffset);
            let phaseDisplacement = axisScale * cos(wave.k * lon * RAD + wave.phase);
            jetDisplacement += phaseDisplacement * envelope;
            ridgeDisplacement += 0.45 * phaseDisplacement;
        }
    }
    let totalDisplacement = clamp(jetDisplacement, -15.0, 15.0)
        + clamp(ridgeDisplacement, -7.0, 7.0);
    // 1.5 is the maximum derivative of the cubic smoothstep, not a wind fit.
    // Match the CPU's strictly monotone latitude map; unversioned saves retain
    // their old map rather than silently changing a historical atmosphere.
    let transitionWidth = 12.0 + select(0.0, 1.5 * abs(totalDisplacement),
        featureData[34] >= 2.0);
    let effectiveDisplacement = select(totalDisplacement * smooth01((latitude - 28.0) / transitionWidth),
        0.0, featureData[30] > 0.5);
    let profileLatitude = clamp(latitude - effectiveDisplacement, 0.0, 85.0);
    var height = 5845.0;
    if (featureData[30] > 0.5) {
        let climatologyAxisShift = select(-2.0, 2.0, north);
        let climatologyLatitude = max(0.0, profileLatitude
            - climatologyAxisShift
                * (1.0 - smooth01((profileLatitude - (jetLatitude + 4.0)) / 12.0)));
        height = monthlyHeight(lon, hemisphere * climatologyLatitude);
    } else {
        height = profileHeight(select(341u, 0u, north), profileLatitude);
    }
    height += waveAnomaly(lon, latitude, ridgeLatitude, effectiveDisplacement,
        waveStart, waveCount);

    if (featureData[30] < 0.5) {
        let tropicalStart = select(params.northTropicalCount, 0u, north);
        let tropicalCount = select(params.southTropicalCount, params.northTropicalCount, north);
        var tropicalDisturbance = 0.0;
        let upperProjection = 0.55 + 0.45 * smooth01((latitude - 8.0) / 14.0);
        for (var i = 0u; i < tropicalCount; i++) {
            let mode = tropicalData[tropicalStart + i];
            let dy = (latitude - mode.latitude) / max(4.5, mode.width);
            tropicalDisturbance += mode.amplitude * upperProjection
                * cos(mode.k * lon * RAD + mode.phase) * exp(-0.5 * dy * dy);
        }
        height += 24.0 * tanh(tropicalDisturbance / 24.0);
    }

    if (featureData[0] > 0.5 && lat >= 0.0) {
        let dx = wrapLon(lon - featureData[1]);
        let dy = lat - (featureData[2] + featureData[6] * dx);
        let x = dx / featureData[4];
        let y = dy / featureData[5];
        height -= featureData[3] * exp(-0.5 * (x * x + y * y));
    }
    if (featureData[7] > 0.5 && lat > 0.0) {
        let dx = wrapLon(lon - featureData[8]);
        let dy = lat - (featureData[9] + featureData[12] * dx);
        let y = dy / featureData[11];
        let x = dx / featureData[10];
        let gaussian = exp(-0.5 * (x * x + y * y));
        let coupling = 0.28 + 0.72 * exp(-0.5 * y * y);
        height -= featureData[13] * coupling * gaussian;
    }
    if (featureData[14] > 0.5 && lat > 0.0) {
        let dx = wrapLon(lon - featureData[15] - 18.0) / 22.0;
        height += 34.0 * featureData[16] * exp(-0.5 * dx * dx)
            * (1.0 - smooth01((lat - 28.0) / 14.0));
    }
    if (lat > 0.0 && featureData[27] > 0.0) {
        let dx = wrapLon(lon - 125.0) / 20.0;
        let lonEnvelope = exp(-0.5 * dx * dx * dx * dx);
        let latEnvelope = (1.0 - smooth01((lat - 22.0) / 12.0)) * smooth01(lat / 8.0);
        height += featureData[27] * lonEnvelope * latEnvelope * 28.0
            * tanh((lat - 10.0) / 10.0);
    }
    height += regionalHeight(lon, lat);

    if (featureData[28] > 0.01 && lat > 0.0) {
        let longitude = wrapLon(lon);
        let longitudeWeight = smooth01((longitude - 42.0) / 10.0)
            * (1.0 - smooth01((longitude - 100.0) / 9.0));
        height += longitudeWeight * profileHeight(682u, min(85.0, lat));
    }
    return vec2<f32>(height, totalDisplacement);
}
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    if (id.x >= params.pointCount) { return; }
    let lon = pointData[id.x].x;
    let lat = pointData[id.x].y;
    let north = lat >= 0.0;
    let hemisphere = select(-1.0, 1.0, north);
    var sample = vec2<f32>(0.0, 0.0);
    if (featureData[30] < 0.5 && abs(lat) < 8.0) {
        let southSample = coreHeight(lon, -8.0, -1.0, false);
        let northSample = coreHeight(lon, 8.0, 1.0, true);
        let northWeight = smooth01((lat + 8.0) / 16.0);
        sample = southSample + (northSample - southSample) * northWeight;
    } else {
        sample = coreHeight(lon, lat, hemisphere, north);
    }
    sample.x += equatorialHeight(lon, lat);
    sample.x += weatherSequenceAnomaly(lon, lat);
    resultData[id.x] = sample;
}`;


export async function runGpuBackgroundWaveFieldKernel(points, packed, device, pipeline) {
    const pointData = new Float32Array(points.length * 2);
    for (let i = 0; i < points.length; i++) pointData.set(points[i], i * 2);
    const buffers = [];
    const safeBuffer = (data, usage) => {
        const buffer = device.createBuffer({
            size: Math.max(4, data.byteLength), usage, mappedAtCreation: true
        });
        buffers.push(buffer);
        new data.constructor(buffer.getMappedRange()).set(data);
        buffer.unmap();
        return buffer;
    };
    const pointBuffer = safeBuffer(pointData, GPUBufferUsage.STORAGE);
    const gridBuffer = safeBuffer(packed.grid, GPUBufferUsage.STORAGE);
    const waveBuffer = safeBuffer(packed.waves.length
        ? packed.waves : new Float32Array(6), GPUBufferUsage.STORAGE);
    const equatorialBuffer = safeBuffer(packed.equatorialWaves.length
        ? packed.equatorialWaves : new Float32Array(5), GPUBufferUsage.STORAGE);
    const featureBuffer = safeBuffer(packed.features, GPUBufferUsage.STORAGE);
    const profileBuffer = safeBuffer(packed.profileData, GPUBufferUsage.STORAGE);
    const tropicalBuffer = safeBuffer(packed.tropicalWaves.length
        ? packed.tropicalWaves : new Float32Array(5), GPUBufferUsage.STORAGE);
    const weatherBuffer = safeBuffer(packed.weatherData?.length
        ? packed.weatherData : new Uint32Array(1), GPUBufferUsage.STORAGE);
    const resultBuffer = device.createBuffer({
        size: points.length * Float32Array.BYTES_PER_ELEMENT * 2,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    });
    buffers.push(resultBuffer);
    const readBuffer = device.createBuffer({
        size: points.length * Float32Array.BYTES_PER_ELEMENT * 2,
        usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST
    });
    buffers.push(readBuffer);
    const paramsData = new ArrayBuffer(48);
    const paramsU32 = new Uint32Array(paramsData);
    paramsU32.set([
        points.length,
        packed.northWaves.length / 6,
        packed.southWaves.length / 6,
        packed.equatorialWaves.length / 5,
        packed.northTropicalWaves.length / 5,
        packed.southTropicalWaves.length / 5,
        0,
        0
    ]);
    new Float32Array(paramsData, 32).set([
        packed.northCirculation.ridgeLatitude,
        packed.northCirculation.jetLatitude,
        packed.southCirculation.ridgeLatitude,
        packed.southCirculation.jetLatitude
    ]);
    const paramsBuffer = safeBuffer(new Uint8Array(paramsData), GPUBufferUsage.UNIFORM);
    try {
        const bindGroup = device.createBindGroup({
            layout: pipeline.getBindGroupLayout(0),
            entries: [pointBuffer, gridBuffer, waveBuffer, equatorialBuffer,
                featureBuffer, profileBuffer, tropicalBuffer, resultBuffer, paramsBuffer, weatherBuffer]
                .map((buffer, binding) => ({ binding, resource: { buffer } }))
        });
        const encoder = device.createCommandEncoder();
        const pass = encoder.beginComputePass();
        pass.setPipeline(pipeline);
        pass.setBindGroup(0, bindGroup);
        pass.dispatchWorkgroups(Math.ceil(points.length / 64));
        pass.end();
        encoder.copyBufferToBuffer(resultBuffer, 0, readBuffer, 0,
            points.length * Float32Array.BYTES_PER_ELEMENT * 2);
        device.queue.submit([encoder.finish()]);
        await readBuffer.mapAsync(GPUMapMode.READ);
        const values = new Float32Array(readBuffer.getMappedRange().slice(0));
        readBuffer.unmap();
        return values;
    } finally {
        for (const buffer of buffers) buffer.destroy();
    }
}


export class Height500BackgroundGpu {
    static async create() {
        const gpu = globalThis.navigator?.gpu;
        if (!gpu) return null;
        const adapter = await gpu.requestAdapter({ powerPreference: "high-performance" });
        if (!adapter) return null;
        // requestDevice() otherwise grants only the baseline limit (8), even
        // when the adapter supports the weather-record shader's ninth buffer.
        const storageBuffers = (BACKGROUND_WAVE_SHADER.match(/var<storage\s*,/g) || []).length;
        if (adapter.limits.maxStorageBuffersPerShaderStage < storageBuffers) return null;
        const device = await adapter.requestDevice({
            requiredLimits: { maxStorageBuffersPerShaderStage: storageBuffers }
        });
        try {
            const module = device.createShaderModule({ code: BACKGROUND_WAVE_SHADER });
            const info = await module.getCompilationInfo();
            const errors = info.messages.filter(message => message.type === "error");
            if (errors.length) throw new Error(errors.map(message => `${message.lineNum}:${message.linePos} ${message.message}`).join("\n"));
            const pipeline = await device.createComputePipelineAsync({ layout: "auto", compute: { module, entryPoint: "main" } });
            return new Height500BackgroundGpu(device, pipeline);
        } catch (error) {
            device.destroy();
            throw error;
        }
    }

    constructor(device, pipeline) {
        this.device = device;
        this.pipeline = pipeline;
        this.lost = false;
        device.lost.then(() => { this.lost = true; this.device = null; this.pipeline = null; }).catch(() => { this.lost = true; });
    }

    async compute(points, systems, month) {
        if (this.lost || !this.device || !this.pipeline) return null;
        const packed = packBackgroundWaveFieldTerms(systems, month);
        const samples = await runGpuBackgroundWaveFieldKernel(points, packed, this.device, this.pipeline);
        return { samples, packed };
    }

    destroy() {
        this.lost = true;
        this.device?.destroy();
        this.device = null;
        this.pipeline = null;
    }
}
