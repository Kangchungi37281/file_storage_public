import { finishTimelineWebM } from './timeline-webm.js';

let exporting = false;
const aborted = () => new DOMException('Timeline export cancelled', 'AbortError');
const checkAbort = signal => { if (signal?.aborted) throw aborted(); };

function encoderWorker(signal) {
    const worker = new Worker(new URL('./timeline-video-worker.js', import.meta.url), { type: 'module' });
    let sequence = 0;
    const pending = new Map();
    const rejectAll = error => { for (const entry of pending.values()) entry.reject(error); pending.clear(); };
    const abort = () => { worker.terminate(); rejectAll(aborted()); };
    signal?.addEventListener('abort', abort, { once: true });
    worker.onmessage = ({ data }) => {
        const entry = pending.get(data.id); if (!entry) return;
        pending.delete(data.id);
        if (data.error) entry.reject(new Error(data.error)); else entry.resolve(data);
    };
    worker.onerror = event => rejectAll(new Error(event.message || 'Video worker failed'));
    worker.onmessageerror = () => rejectAll(new Error('Video worker message failed'));
    return {
        request(type, fields = {}, transfer = []) {
            checkAbort(signal);
            return new Promise((resolve, reject) => {
                const id = ++sequence; pending.set(id, { resolve, reject });
                try { worker.postMessage({ id, type, ...fields }, transfer); }
                catch (error) { pending.delete(id); reject(error); }
            });
        },
        close() { worker.terminate(); signal?.removeEventListener('abort', abort); rejectAll(aborted()); }
    };
}

// Same white background and aspect-ratio-preserving composition as the old exporter.
export function composeTimelineFrame(canvas, frame) {
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    const scale = Math.min(canvas.width / frame.width, canvas.height / frame.height);
    const w = frame.width * scale, h = frame.height * scale;
    ctx.drawImage(frame, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
}

export async function exportTimelineVideo({ indices, renderFrame, onProgress, signal, onFrame, forceRecorder = false }) {
    if (exporting) throw new Error('A timeline export is already running');
    if (!indices.length) throw new Error('No timeline frames');
    checkAbort(signal); exporting = true;
    const canvas = document.createElement('canvas'); canvas.width = 1600; canvas.height = 1200;
    let worker, recorder, stream, recorderDone;
    const chunks = [], stats = { backend: '', charts: 0, samples: 0, maxEncodeQueue: 0, renderMs: [], encodeMs: [] };
    const compose = async index => {
        checkAbort(signal);
        const start = performance.now(), frame = await renderFrame(index);
        stats.renderMs.push(performance.now() - start);
        if (!frame) throw new Error(`Missing timeline chart at T+${index * 3}H`);
        try { checkAbort(signal); composeTimelineFrame(canvas, frame); await onFrame?.(canvas, index); }
        finally { frame.width = frame.height = 0; } // renderFrame must return an export-owned canvas.
        checkAbort(signal);
    };
    let rejectRecorder;
    const abortRecorder = () => rejectRecorder?.(aborted());
    try {
        if (!forceRecorder && typeof Worker !== 'undefined' && typeof createImageBitmap === 'function') {
            worker = encoderWorker(signal);
            const ready = await worker.request('init', { width: canvas.width, height: canvas.height });
            if (!ready.supported) { worker.close(); worker = null; }
        }
        if (worker) {
            stats.backend = 'webcodecs-worker';
            for (const index of indices) {
                await compose(index);
                const bitmap = await createImageBitmap(canvas);
                let encoded;
                try { encoded = await worker.request('frame', { bitmap }, [bitmap]); }
                finally { bitmap.close(); }
                chunks.push(encoded.cluster);
                stats.encodeMs.push(encoded.encodeMs); stats.samples = encoded.samples; stats.maxEncodeQueue = encoded.maxQueue;
                stats.charts++; onProgress?.(stats.charts, indices.length, stats.backend);
            }
            await worker.request('finish');
            return { blob: finishTimelineWebM(chunks, canvas.width, canvas.height), stats };
        }
        // Compatibility route: pause capture during computation and always release it.
        // No resolution, bitrate, codec or timeline frame is sacrificed.
        stats.backend = 'mediarecorder';
        await compose(indices[0]);
        stream = canvas.captureStream(10);
        recorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9', videoBitsPerSecond: 48000000 });
        recorderDone = new Promise((resolve, reject) => {
            rejectRecorder = reject;
            recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
            recorder.onstop = resolve;
            recorder.onerror = event => reject(event.error || new Error('Video recording failed'));
        });
        // Attach immediately: an encoder error during chart rendering must not become an unhandled rejection.
        recorderDone.catch(() => {});
        signal?.addEventListener('abort', abortRecorder, { once: true });
        recorder.start(1000);
        for (let i = 0; i < indices.length; i++) {
            if (i) { recorder.pause(); await compose(indices[i]); recorder.resume(); stream.getVideoTracks()[0]?.requestFrame?.(); }
            await Promise.race([new Promise(resolve => setTimeout(resolve, 400)), recorderDone.then(() => { throw new Error('Recording stopped before the final chart'); })]);
            checkAbort(signal); stats.charts++; onProgress?.(stats.charts, indices.length, stats.backend);
        }
        recorder.stop(); await recorderDone;
        return { blob: new Blob(chunks, { type: 'video/webm' }), stats };
    } finally {
        worker?.close();
        signal?.removeEventListener('abort', abortRecorder);
        if (recorder && recorder.state !== 'inactive') recorder.stop();
        stream?.getTracks().forEach(track => track.stop());
        canvas.width = canvas.height = 0;
        chunks.length = 0; exporting = false;
    }
}
