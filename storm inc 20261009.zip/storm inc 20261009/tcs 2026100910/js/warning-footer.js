import { cycloneProductName } from './icwc-product-labels.js?v=20261008-forecast-categories1';
import { simulationDate } from './simulation-time.js?v=20261008-forecast-categories1';

// Use the selected historical fix, not the cyclone's latest position/intensity.
export function warningFooterInfo(cyclone, timeIndex) {
    const point = cyclone.track[timeIndex];
    const date = simulationDate(cyclone, timeIndex * 3);
    const lon = ((point[0] + 180) % 360 + 360) % 360 - 180;
    const coordinate = (value, positive, negative) =>
        `${Math.abs(value).toFixed(1)}°${value < 0 ? negative : positive}`;
    return {
        name: cycloneProductName(cyclone, point, timeIndex),
        date: `${date.toISOString().slice(0, 10)} ${date.toISOString().slice(11, 16)} UTC`,
        location: `${coordinate(point[1], 'N', 'S')}  ${coordinate(lon, 'E', 'W')}`,
        wind: `${Math.round(point[2] / 5) * 5} kt`
    };
}

export function drawWarningFooter(ctx, info, width, top, height) {
    ctx.save();
    ctx.setLineDash([]);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, top, width, height);
    ctx.strokeStyle = '#111';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, top + 1, width - 2, height - 2);
    ctx.fillStyle = '#111';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    const columns = [24, width * 0.36, width * 0.65];
    ctx.font = 'bold 28px Arial, sans-serif';
    ctx.fillText(info.name, columns[0], top + 12, columns[1] - columns[0] - 28);
    ctx.font = '20px Arial, sans-serif';
    ctx.fillText(info.date, columns[0], top + 47, columns[1] - columns[0] - 28);
    ctx.font = 'bold 22px Arial, sans-serif';
    ctx.fillText('Center Location', columns[1], top + 12);
    ctx.fillText('Maximum Sustained Wind', columns[2], top + 12, width - columns[2] - 24);
    ctx.font = '24px Arial, sans-serif';
    ctx.fillText(info.location, columns[1], top + 44, columns[2] - columns[1] - 28);
    ctx.fillText(info.wind, columns[2], top + 44);
    ctx.restore();
}
