/** Geometry only: keep export labels clear of the complete track, not just fixes. */
export const EXPORT_LAYOUT = Object.freeze({ header: 180, headlineSize: 92, legendWidth: 192,
    legendRowHeight: 24, cityLeaderMaxLength: 90 });

export function exportLegendBox(size, options) {
    const rows = options.enableExtremeTier ? 8 : 7;
    const height = 50 + rows * EXPORT_LAYOUT.legendRowHeight + 14
        + (options.markPeakIntensity ? 34 : 0) + (options.showCityObservations ? 28 : 0);
    return { left: size.width - EXPORT_LAYOUT.legendWidth - 42,
        top: size.height - height - 42, width: EXPORT_LAYOUT.legendWidth, height };
}

export function boxesOverlap(a, b, padding = 0) {
    return a.left < b.left + b.width + padding && a.left + a.width + padding > b.left
        && a.top < b.top + b.height + padding && a.top + a.height + padding > b.top;
}

export function segmentIntersectsBox(a, b, box, padding = 0) {
    const limits = [[box.left - padding, box.left + box.width + padding],
        [box.top - padding, box.top + box.height + padding]];
    let enter = 0, leave = 1;
    for (let axis = 0; axis < 2; axis++) {
        const delta = b[axis] - a[axis];
        if (Math.abs(delta) < 1e-9) {
            if (a[axis] < limits[axis][0] || a[axis] > limits[axis][1]) return false;
        } else {
            const t1 = (limits[axis][0] - a[axis]) / delta;
            const t2 = (limits[axis][1] - a[axis]) / delta;
            enter = Math.max(enter, Math.min(t1, t2));
            leave = Math.min(leave, Math.max(t1, t2));
            if (enter > leave) return false;
        }
    }
    return true;
}

function segmentsCross(a, b, c, d) {
    const cross = (p, q, r) => (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]);
    return cross(a, b, c) * cross(a, b, d) < 0 && cross(c, d, a) * cross(c, d, b) < 0;
}

function trackIndex(points, bounds) {
    // Spatial buckets keep candidate search local even for long saved tracks.
    const cell = 64, buckets = new Map();
    const keys = box => {
        const result = [];
        for (let x = Math.floor(Math.max(bounds.left, box.left) / cell);
            x <= Math.floor(Math.min(bounds.left + bounds.width, box.left + box.width) / cell); x++) {
            for (let y = Math.floor(Math.max(bounds.top, box.top) / cell);
                y <= Math.floor(Math.min(bounds.top + bounds.height, box.top + box.height) / cell); y++) result.push(`${x}:${y}`);
        }
        return result;
    };
    const segments = points.map((point, i) => [points[Math.max(0, i - 1)], point]);
    segments.forEach(([a, b], index) => {
        const box = { left: Math.min(a[0], b[0]) - 14, top: Math.min(a[1], b[1]) - 14,
            width: Math.abs(b[0] - a[0]) + 28, height: Math.abs(b[1] - a[1]) + 28 };
        for (const key of keys(box)) {
            if (!buckets.has(key)) buckets.set(key, []);
            buckets.get(key).push(index);
        }
    });
    return box => [...new Set(keys(box).flatMap(key => buckets.get(key) || []))].map(i => segments[i]);
}

/** Arrow points along the wind flow; a north wind therefore points south. */
export function cityWindArrow(direction) {
    const compass = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
        'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    const index = compass.indexOf(String(direction).toUpperCase());
    if (index < 0) return null;
    const angle = index * Math.PI / 8;
    return { x: -Math.sin(angle), y: Math.cos(angle) };
}

export function layoutExportCityLabels(labels, points, bounds, reserved = []) {
    const nearbyTrack = trackIndex(points, bounds);
    const occupied = [...reserved, ...labels.map(label => ({ left: label.x - 6, top: label.y - 6, width: 12, height: 12 }))];
    const leaders = [];
    return labels.flatMap(label => {
        const origin = [label.x, label.y];
        let best = null, bestScore = Infinity;
        const consider = (left, top) => {
            const box = { left, top, width: label.width, height: label.height };
            if (left < bounds.left || top < bounds.top
                || left + box.width > bounds.left + bounds.width
                || top + box.height > bounds.top + bounds.height
                || occupied.some(other => boxesOverlap(box, other, 8))
                || nearbyTrack(box).some(([a, b]) => segmentIntersectsBox(a, b, box, 14))
                || leaders.some(([a, b]) => segmentIntersectsBox(a, b, box, 3))) return;
            const anchor = [Math.max(left, Math.min(left + box.width, label.x)),
                Math.max(top, Math.min(top + box.height, label.y))];
            if (occupied.some(other => segmentIntersectsBox(origin, anchor, other, 2)
                // The origin's own station marker is not an obstacle.
                && !(label.x >= other.left && label.x <= other.left + other.width
                    && label.y >= other.top && label.y <= other.top + other.height))) return;
            const distance = Math.hypot(anchor[0] - label.x, anchor[1] - label.y);
            if (distance > EXPORT_LAYOUT.cityLeaderMaxLength) return;
            // A city can sit on the track. Ignore just the first 18 px of its
            // leader, then prefer routes that do not cross the track again.
            const start = distance > 18 ? [label.x + (anchor[0] - label.x) * 18 / distance,
                label.y + (anchor[1] - label.y) * 18 / distance] : anchor;
            const leaderBounds = { left: Math.min(start[0], anchor[0]), top: Math.min(start[1], anchor[1]),
                width: Math.abs(start[0] - anchor[0]), height: Math.abs(start[1] - anchor[1]) };
            const crosses = nearbyTrack(leaderBounds).filter(([a, b]) => segmentsCross(start, anchor, a, b)).length
                + leaders.filter(([a, b]) => segmentsCross(origin, anchor, a, b)).length;
            const score = distance + crosses * 180;
            if (score < bestScore) { bestScore = score; best = { ...label, box, leader: [origin, anchor] }; }
        };
        for (const gap of [18, 36, 60, 84]) {
            for (let sector = 0; sector < 8; sector++) {
                const angle = sector * Math.PI / 4;
                consider(label.x + (label.width / 2 + gap) * Math.cos(angle) - label.width / 2,
                    label.y + (label.height / 2 + gap) * Math.sin(angle) - label.height / 2);
            }
            if (bestScore < gap) break;
        }
        // Do not chase distant space or fail the entire PNG for an annotation.
        // Crowded cities are intentionally hidden rather than covering the track.
        if (!best) return [];
        occupied.push(best.box);
        leaders.push(best.leader);
        return [best];
    });
}
