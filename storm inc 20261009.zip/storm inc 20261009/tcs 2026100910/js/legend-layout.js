const legends = new Map();
const bottomIds = ['wind-radii-legend', 'radar-legend', 'doppler-legend', 'sst-legend'];
const sideIds = ['shear-legend', 'wind-field-legend'];

export function initializeLegendLayout() {
    if (legends.size) return;
    const bottom = document.createElement('div');
    bottom.className = 'legend-dock legend-dock-bottom';
    const side = document.createElement('div');
    side.className = 'legend-dock legend-dock-side';
    document.body.append(bottom, side);
    for (const id of [...bottomIds, ...sideIds]) {
        const element = document.getElementById(id);
        if (!element) continue;
        element.classList.remove('opacity-0', 'opacity-100', 'translate-y-3',
            'translate-y-4', 'translate-y-0', '-translate-x-1/2', 'transform',
            'transition-all', 'duration-300', 'ease-out',
            'data-[show=true]:translate-y-0', 'data-[show=true]:opacity-100');
        element.classList.add('hidden', 'stacked-legend');
        element.setAttribute('aria-hidden', 'true');
        legends.set(id, { element, visible: false, animation: null });
    }
    for (const id of bottomIds) if (legends.has(id)) bottom.append(legends.get(id).element);
    for (const id of sideIds) if (legends.has(id)) side.append(legends.get(id).element);
    // Mobile keeps these two legends on their own edge rail, not in the
    // centered map stack. Reserve its actual height for other active legends.
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => {
        bottom.style.setProperty('--side-legend-height', `${Math.ceil(side.getBoundingClientRect().height)}px`);
    }).observe(side);
}

export function setLegendVisible(id, show) {
    const state = legends.get(id);
    if (!state) return;
    const { element } = state;
    const visible = Boolean(show && !element.hidden && element.style.display !== 'none');
    if (state.visible === visible) return; // Redraws never restart a fade.
    state.visible = visible;
    const opacity = element.classList.contains('hidden') ? 0 : Number(getComputedStyle(element).opacity);
    state.animation?.cancel();
    element.classList.remove('hidden');
    element.setAttribute('aria-hidden', String(!visible));
    element.style.opacity = String(visible ? 1 : 0);
    const finish = () => element.classList.toggle('hidden', !state.visible);
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || !element.animate) {
        finish();
        return;
    }
    const animation = element.animate([{ opacity }, { opacity: visible ? 1 : 0 }], {
        duration: 200, easing: 'ease-out'
    });
    state.animation = animation;
    animation.finished.then(() => {
        if (state.animation !== animation) return;
        state.animation = null;
        finish(); // Retain stack space until fade-out completes.
    }).catch(() => {}); // Quick reversal cancels the obsolete completion.
}
