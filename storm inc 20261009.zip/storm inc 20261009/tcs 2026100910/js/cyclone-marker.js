import { getCategory } from './utils.js';

let markerSequence = 0;

function arcPath(radius, start, end) {
    const point = angle => [Math.cos(angle) * radius, Math.sin(angle) * radius];
    return `M${point(start)} A${radius},${radius} 0 ${end - start > Math.PI ? 1 : 0},1 ${point(end)}`;
}

function spiralRibbonPath() {
    const edge = (t, side) => {
        const radius = 15.5 + 16.5 * t;
        const width = 6 * Math.pow(1 - t, .65) * Math.sin(.7 * Math.PI * (1 - t));
        const angle = .2 + t * 2.5;
        return [Math.cos(angle) * (radius + side * width), Math.sin(angle) * (radius + side * width)];
    };
    const points = [];
    for (let i = 0; i <= 24; i++) points.push(edge(i / 24, 1));
    for (let i = 24; i >= 0; i--) points.push(edge(i / 24, -1));
    return `M${points.join(' L')} Z`;
}

function createMarker(group) {
    // Both silhouettes stay mounted: class changes crossfade without restarting rotation.
    const id = `tcs-cyclone-${++markerSequence}`;
    const ribbon = spiralRibbonPath();
    group.html(`
        <defs>
            <radialGradient id="${id}-glow">
                <stop offset="0" stop-color="currentColor" stop-opacity=".50"/>
                <stop offset=".48" stop-color="currentColor" stop-opacity=".20"/>
                <stop offset="1" stop-color="currentColor" stop-opacity="0"/>
            </radialGradient>
            <radialGradient id="${id}-cloud" gradientUnits="userSpaceOnUse" r="32">
                <stop offset=".39" stop-color="#f5f9ff"/>
                <stop offset=".56" stop-color="currentColor"/>
                <stop offset="1" stop-color="currentColor" stop-opacity=".7"/>
            </radialGradient>
            <radialGradient id="${id}-eye">
                <stop offset="0" stop-color="#fff"/>
                <stop offset=".8" stop-color="#f2f7fc"/>
                <stop offset="1" stop-color="currentColor"/>
            </radialGradient>
        </defs>
        <line class="cyclone-motion-trail"/>
        <g class="cyclone-symbol cyclone-symbol-weak">
            <circle r="28" fill="url(#${id}-glow)"/>
            <g class="cyclone-hemisphere">
                <g class="cyclone-symbol-spin">
                    <path class="cyclone-weak-arms" d="${arcPath(13, 0, 2.2)} ${arcPath(13, Math.PI, Math.PI + 2.2)}"/>
                </g>
            </g>
            <circle r="7.5" fill="url(#${id}-eye)" class="cyclone-eye"/>
        </g>
        <g class="cyclone-symbol cyclone-symbol-strong">
            <g class="cyclone-strength-scale">
                <circle r="53" fill="url(#${id}-glow)"/>
                <g class="cyclone-hemisphere">
                    <g class="cyclone-symbol-spin">
                        <path d="${ribbon}" fill="url(#${id}-cloud)"/>
                        <path d="${ribbon}" transform="rotate(180)" fill="url(#${id}-cloud)"/>
                        <g class="cyclone-outer-bands">
                            <path class="cyclone-cloud-band" d="${arcPath(26.88, 2.85, 3.75)} ${arcPath(26.88, Math.PI + 2.85, Math.PI + 3.75)}"/>
                            <path class="cyclone-cloud-edge" d="${arcPath(32, .8, 1.8)} ${arcPath(32, Math.PI + .8, Math.PI + 1.8)}"/>
                        </g>
                        <circle r="14.5" class="cyclone-eyewall-color"/>
                        <circle r="16.2" class="cyclone-eyewall-light"/>
                        <path class="cyclone-eyewall-detail" d="${arcPath(18.3, .25, 1.12)} ${arcPath(18.3, Math.PI + .25, Math.PI + 1.12)}"/>
                    </g>
                </g>
                <circle r="12.5" fill="url(#${id}-eye)" class="cyclone-eye"/>
                <g class="cyclone-erc-rings">
                    <circle r="35" class="cyclone-erc-ring cyclone-erc-ring-inner"/>
                    <circle r="40" class="cyclone-erc-ring cyclone-erc-ring-outer"/>
                </g>
            </g>
        </g>`);
}

export function drawCycloneMarker(cycloneLayer, mapProjection, cyclone) {
    if (!cyclone || cyclone.status !== 'active') {
        cycloneLayer.selectAll('.cyclone-marker').remove();
        return;
    }
    const position = mapProjection([cyclone.lon, cyclone.lat]);
    if (!position || !position.every(Number.isFinite)) return;
    const category = getCategory(cyclone.intensity, cyclone.isTransitioning,
        cyclone.isExtratropical, cyclone.isSubtropical);
    const isTyphoon = cyclone.intensity >= 64 && !cyclone.isExtratropical && !cyclone.isSubtropical;
    const strength = Math.max(0, Math.min(1, (cyclone.intensity - 64) / 76));
    const marker = cycloneLayer.selectAll('g.cyclone-marker').data([cyclone]).join(enter => {
        const group = enter.append('g').attr('class', 'cyclone-marker')
            .attr('aria-hidden', 'true');
        createMarker(group);
        return group;
    });

    marker.attr('transform', `translate(${position[0]},${position[1]})`)
        .style('color', category.color)
        .classed('is-typhoon', isTyphoon)
        .classed('is-erc', Boolean(cyclone.isERCActive));
    marker.selectAll('.cyclone-hemisphere').attr('transform', `scale(1,${cyclone.lat < 0 ? -1 : 1})`);
    marker.select('.cyclone-strength-scale').style('transform', `scale(${.74 + .26 * strength})`);
    marker.select('.cyclone-outer-bands').style('opacity', .45 + .5 * strength);

    const movementRadians = (cyclone.direction || 0) * Math.PI / 180;
    const trailLength = Math.min(22, 8 + Math.max(0, cyclone.speed || 0) * .55);
    marker.select('.cyclone-motion-trail')
        .attr('x1', -Math.sin(movementRadians) * 3)
        .attr('y1', Math.cos(movementRadians) * 3)
        .attr('x2', -Math.sin(movementRadians) * trailLength)
        .attr('y2', Math.cos(movementRadians) * trailLength);
}
