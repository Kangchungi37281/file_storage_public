// One calendar origin per simulation; relative model/forecast hours stay unchanged.
export const SIMULATION_START_WINDOW = Object.freeze({firstDay:1, lastDay:10});

export function createSimulationCalendar(month, random = Math.random, year = new Date().getUTCFullYear()) {
    const {firstDay, lastDay} = SIMULATION_START_WINDOW;
    const draw = Math.max(0, Math.min(1, random()));
    const startDay = Math.min(lastDay, firstDay + Math.floor(draw * (lastDay - firstDay + 1)));
    return {startYear:year, startMonth:month, startDay};
}

export function simulationDate(cyclone = {}, elapsedHours = 0) {
    const year = cyclone.startYear || cyclone.year || new Date().getUTCFullYear();
    const month = cyclone.startMonth || cyclone.currentMonth || cyclone.month || 8;
    // Historical records without a calendar origin retain their original day 1.
    const day = Number.isInteger(cyclone.startDay) && cyclone.startDay >= 1 && cyclone.startDay <= 31
        ? cyclone.startDay : 1;
    return new Date(Date.UTC(year, month - 1, day) + elapsedHours * 3600000);
}
