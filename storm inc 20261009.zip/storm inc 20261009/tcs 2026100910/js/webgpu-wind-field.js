import { getOuterCoreRemap, getCycloneFieldGeometryAt } from './cyclone-model.js?v=20261008-forecast-categories1';

const MAX_SYSTEMS = 32;
const HEADER_FLOATS = 32;
const SYSTEM_STRIDE_FLOATS = 16;

const shaderSource = `
@group(0) @binding(0) var<storage, read> inputData: array<f32>;
@group(0) @binding(1) var<storage, read_write> outputData: array<u32>;

const PI: f32 = 3.14159265359;
const DEG_TO_RAD: f32 = PI / 180.0;
const EARTH_RADIUS_KM: f32 = 6371.0;
const HEADER_FLOATS: u32 = 32u;
const SYSTEM_STRIDE: u32 = 16u;

fn value(index: u32) -> f32 {
    return inputData[index];
}

fn smooth01(v: f32) -> f32 {
    let t = clamp(v, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

fn wrappedLongitudeDelta(a: f32, b: f32) -> f32 {
    var d = a - b;
    if (d > 180.0) { d -= 360.0; }
    if (d < -180.0) { d += 360.0; }
    return d;
}

fn pressureAt(pos: vec2<f32>) -> f32 {
    var pressure = 1010.0;
    let count = min(u32(max(0.0, value(22u))), ${MAX_SYSTEMS}u);
    for (var i = 0u; i < count; i += 1u) {
        let base = HEADER_FLOATS + i * SYSTEM_STRIDE;
        let dx = wrappedLongitudeDelta(pos.x, value(base));
        let dy = pos.y - value(base + 1u);
        let sigmaX = max(0.01, abs(value(base + 2u)));
        let sigmaY = max(0.01, abs(value(base + 3u)));
        let exponent = -0.5 * (
            dx * dx / (sigmaX * sigmaX)
            + dy * dy / (sigmaY * sigmaY)
        );
        pressure += exp(exponent) * value(base + 4u);

        let noiseCount = min(u32(max(0.0, value(base + 5u))), 2u);
        for (var n = 0u; n < noiseCount; n += 1u) {
            let noiseBase = base + 6u + n * 5u;
            let freqX = max(0.001, abs(value(noiseBase + 2u)));
            let freqY = max(0.001, abs(value(noiseBase + 3u)));
            pressure += sin((pos.x + value(noiseBase)) / freqX)
                * cos((pos.y + value(noiseBase + 1u)) / freqY)
                * value(noiseBase + 4u);
        }
    }
    return pressure;
}

fn environmentalWind(pos: vec2<f32>) -> vec2<f32> {
    // Legacy radar pressure proxy, with the same open-water bulk drag
    // balance as the CPU surface diagnostic (not an upper-level jet).
    let d = 0.25;
    let dy = 2.0 * d * 6371000.0 * DEG_TO_RAD;
    let dx = dy * max(0.087, cos(pos.y * DEG_TO_RAD));
    let force = -vec2<f32>(
        (pressureAt(pos + vec2<f32>(d, 0.0)) - pressureAt(pos - vec2<f32>(d, 0.0))) / dx,
        (pressureAt(pos + vec2<f32>(0.0, d)) - pressureAt(pos - vec2<f32>(0.0, d))) / dy
    ) * (100.0 / 1.15);
    let forceSq = dot(force, force);
    if (forceSq <= 0.0) { return vec2<f32>(0.0); }
    let f = 2.0 * 7.292115e-5 * sin(pos.y * DEG_TO_RAD);
    let a = 0.0015 / 500.0;
    let speedSq = 2.0 * forceSq / (f * f + sqrt(f * f * f * f + 4.0 * a * a * forceSq));
    let damping = a * sqrt(speedSq);
    return 0.8 * 1.94384 * vec2<f32>(
        damping * force.x + f * force.y,
        damping * force.y - f * force.x
    ) / (f * f + damping * damping);
}

fn distanceKm(a: vec2<f32>, b: vec2<f32>) -> f32 {
    let dLat = (a.y - b.y) * DEG_TO_RAD;
    let dLon = wrappedLongitudeDelta(a.x, b.x) * DEG_TO_RAD;
    let latA = a.y * DEG_TO_RAD;
    let latB = b.y * DEG_TO_RAD;
    let hav = sin(dLat * 0.5) * sin(dLat * 0.5)
        + cos(latA) * cos(latB) * sin(dLon * 0.5) * sin(dLon * 0.5);
    return 2.0 * EARTH_RADIUS_KM
        * atan2(sqrt(clamp(hav, 0.0, 1.0)), sqrt(max(0.0, 1.0 - hav)));
}

fn cycloneFieldGeometry(pos: vec2<f32>, center: vec2<f32>) -> vec4<f32> {
    let meanLat = (pos.y + center.y) * 0.5 * DEG_TO_RAD;
    let eastKm = wrappedLongitudeDelta(pos.x, center.x) * 111.32
        * max(0.12, cos(meanLat));
    let northKm = (pos.y - center.y) * 111.32;
    let tilt = value(29u);
    let c = cos(tilt);
    let s = sin(tilt);
    let along = eastKm * c + northKm * s;
    let cross = -eastKm * s + northKm * c;
    let aspect = max(1.0, value(28u));
    let major = sqrt(aspect);
    let minor = 1.0 / major;
    let radius = length(vec2<f32>(along / major, cross / minor));
    var gradient = vec2<f32>(along / (major * major), cross / (minor * minor));
    if (length(gradient) < 1.0e-6) {
        gradient = vec2<f32>(1.0, 0.0);
    } else {
        gradient = normalize(gradient);
    }
    let normal = vec2<f32>(
        gradient.x * c - gradient.y * s,
        gradient.x * s + gradient.y * c
    );
    return vec4<f32>(radius, normal.x, normal.y, value(30u));
}

fn hollandB(peak: f32) -> f32 {
    let environmentalPressure = select(1010.0, value(23u), value(23u) > 850.0);
    let estimatedCentral = environmentalPressure - clamp(0.50 * peak, 8.0, 95.0);
    let centralPressure = select(estimatedCentral, value(24u), value(24u) > 800.0);
    let deficit = clamp(environmentalPressure - centralPressure, 5.0, 120.0);
    let tendency = clamp(value(25u), -5.0, 5.0);
    let latitude = abs(value(6u));
    let translation = max(0.0, value(10u)) * 0.514444;
    let delta = 0.6 * (1.0 - deficit / 215.0);
    return clamp(1.0 - 4.4e-5 * deficit * deficit + 0.01 * deficit
        + 0.03 * tendency - 0.014 * latitude + 0.15 * pow(translation, delta), 0.8, 2.5);
}

fn hollandWindAtFitRadius(
    radius: f32,
    rmw: f32,
    peak: f32,
    fitRadius: f32,
    b: f32,
    peripheralWind: f32
) -> f32 {
    if (radius <= 0.0 || rmw <= 0.0 || peak <= 0.0) { return 0.0; }
    let radialPower = pow(rmw / radius, b);
    let normalized = radialPower * exp(1.0 - radialPower);
    let fitPower = pow(rmw / fitRadius, b);
    let fitLog = log(fitPower) + 1.0 - fitPower;
    let peripheralX = max(0.5, log(peripheralWind / peak) / fitLog);
    let outerFraction = pow(max(0.0, (radius - rmw) / (fitRadius - rmw)), 0.10);
    let x = mix(0.5, peripheralX, outerFraction);
    return peak * pow(max(0.0, normalized), x);
}

fn hollandWind(radius: f32, rmw: f32, peak: f32, size: f32, broadness: f32) -> f32 {
    if (radius <= 0.0 || rmw <= 0.0 || peak <= 0.0) { return 0.0; }
    let b = hollandB(peak);
    let boundedBroadness = clamp(broadness, 0.0, 1.0);
    let peripheralWind = min(17.0 / 0.514444, 0.5 * peak);
    let coreFitRadius = max(280.0, rmw + 120.0);
    let coreWind = hollandWindAtFitRadius(
        radius, rmw, peak, coreFitRadius, b, peripheralWind
    );
    if (radius <= coreFitRadius) { return coreWind; }
    let sizeFraction = clamp((clamp(size, 100.0, 800.0) - 200.0) / 600.0, 0.0, 1.0);
    let tailShift = 72.0 * sizeFraction * (0.70 + 0.30 * boundedBroadness);
    if (tailShift <= 0.0) { return coreWind; }
    let tailBlend = smooth01((radius - coreFitRadius) / 120.0);
    let sourceRadius = max(coreFitRadius, radius - tailShift * tailBlend);
    return hollandWindAtFitRadius(
        sourceRadius, rmw, peak, coreFitRadius, b, peripheralWind
    );
}

fn estimateCoreR64(rmw: f32, peak: f32, size: f32) -> f32 {
    if (peak <= 64.0 || rmw <= 0.0) { return rmw; }
    let searchLimit = max(220.0, min(900.0, size * 2.5));
    var previousRadius = rmw;
    var previousWind = peak;
    for (var radius = rmw + 2.0; radius <= searchLimit; radius += 2.0) {
        let wind = hollandWind(radius, rmw, peak, size, value(12u));
        if (wind <= 64.0) {
            let fraction = (previousWind - 64.0) / max(1.0e-6, previousWind - wind);
            return previousRadius + 2.0 * clamp(fraction, 0.0, 1.0);
        }
        previousRadius = radius;
        previousWind = wind;
    }
    return searchLimit;
}

fn primaryWind(
    radius: f32,
    rmw: f32,
    peak: f32,
    size: f32,
    envelopePeak: f32,
    envelopeRmw: f32,
    dispersion: f32,
    broadness: f32
) -> f32 {
    return hollandWind(radius, rmw, peak, size, broadness);
}

fn envelopeTransition() -> f32 {
    if (value(13u) < 0.5) { return 0.0; }
    return clamp(
        0.45 * value(20u)
        + 0.35 * min(1.0, value(19u) * 1.5)
        + 0.55 * (1.0 - value(21u)),
        0.0,
        1.0
    );
}

fn energyDispersion() -> f32 {
    if (value(13u) < 0.5) { return 0.0; }
    let share = clamp(value(19u), 0.0, 1.0);
    let balance = 4.0 * share * (1.0 - share);
    let organization = smooth01((value(20u) - 0.08) / 0.82);
    return organization * smooth01(balance);
}

fn baselineWind(radius: f32) -> f32 {
    let erc = value(13u) >= 0.5;
    let rmw = select(value(9u), value(14u), erc);
    let innerWind = select(value(8u), value(15u), erc);
    let transition = envelopeTransition();
    let envelopeRmw = select(rmw, mix(rmw, value(16u), transition), erc);
    return primaryWind(
        radius,
        rmw,
        innerWind,
        value(7u),
        max(innerWind, value(8u)),
        envelopeRmw,
        energyDispersion(),
        value(12u)
    );
}

fn outerDominance() -> f32 {
    if (value(13u) < 0.5) { return 0.0; }
    let organization = smooth01((value(20u) - 0.28) / 0.62);
    let share = smooth01((value(19u) - 0.20) / 0.52);
    let innerDecay = smooth01((0.76 - value(21u)) / 0.64);
    let retirement = smooth01((0.45 - value(21u)) / 0.31);
    return organization * max(share * innerDecay, retirement);
}

fn outerEyewallWind(radius: f32) -> f32 {
    if (value(13u) < 0.5 || value(18u) <= 0.0) { return 0.0; }
    let innerRmw = value(14u);
    let outerRmw = value(16u);
    let gap = max(8.0, outerRmw - innerRmw);
    let innerCutoff = smooth01((radius - (innerRmw + 0.12 * gap)) / (0.30 * gap));
    let organization = clamp(value(20u), 0.0, 1.0);
    let ringWidth = clamp(value(17u), 8.0, 60.0);
    let innerSigma = min(
        gap * (0.38 + 0.10 * (1.0 - organization)),
        ringWidth * (0.90 + 0.25 * (1.0 - organization))
    );
    let outerSigma = ringWidth * (1.10 + 0.35 * (1.0 - organization));
    let offset = radius - outerRmw;
    let sigma = max(6.0, select(outerSigma, innerSigma, offset < 0.0));
    let coreShape = exp(-0.5 * pow(offset / sigma, 2.0));
    let background = baselineWind(radius);
    let outerBackground = baselineWind(outerRmw);
    let ringPeak = outerBackground + value(18u);
    let localized = background + max(0.0, ringPeak * coreShape - background) * innerCutoff;
    let dominance = outerDominance();
    let replacement = primaryWind(
        radius, outerRmw, ringPeak, value(7u), ringPeak, outerRmw, 0.0, value(12u)
    );
    let remnantGone = smooth01((0.45 - value(21u)) / 0.31);
    let separated = smooth01(max(0.0, outerRmw - innerRmw) / max(8.0, ringWidth));
    let mask = 1.0 - (1.0 - innerCutoff) * separated * (1.0 - remnantGone);
    let resolved = mix(localized, replacement, dominance * mask);
    return resolved - background;
}

fn resolvedVortexWind(radius: f32) -> f32 {
    let start = value(26u);
    let end = value(27u);
    var sourceRadius = radius;
    if (radius > start && radius < end) {
        let y = (radius - start) / (end - start);
        var t = y;
        for (var i = 0u; i < 5u; i += 1u) {
            let s = sin(PI * t);
            t -= (t - 0.1 * s * s - y) / (1.0 - 0.1 * PI * sin(2.0 * PI * t));
        }
        sourceRadius = start + t * (end - start);
    }
    return baselineWind(sourceRadius) + outerEyewallWind(sourceRadius);
}

fn cycloneWind(pos: vec2<f32>) -> vec2<f32> {
    if (value(4u) < 0.5) { return vec2<f32>(0.0); }
    let center = vec2<f32>(value(5u), value(6u));
    let fieldGeometry = cycloneFieldGeometry(pos, center);
    let radius = fieldGeometry.x;
    let erc = value(13u) >= 0.5;
    let innerRmw = select(value(9u), value(14u), erc);
    let innerPeak = select(value(8u), value(15u), erc);
    let outerPeak = select(-1.0e9, baselineWind(value(16u)) + value(18u), erc);
    let takeover = outerDominance();
    let dominantRmw = mix(innerRmw, value(16u), takeover);
    let dominantPeak = select(innerPeak, mix(innerPeak, outerPeak, takeover), erc);
    var coreR64 = estimateCoreR64(dominantRmw, dominantPeak, value(7u));
    if (erc && outerPeak > 54.0) {
        let outerSigma = clamp(value(17u), 8.0, 60.0)
            * (1.10 + 0.35 * (1.0 - clamp(value(20u), 0.0, 1.0)));
        coreR64 = max(coreR64, dominantRmw + (value(16u) + 2.40 * outerSigma - dominantRmw)
            * takeover * smooth01((outerPeak - 54.0) / 20.0));
    }
    let fadeStart = max(value(7u) * 1.4, coreR64 * 2.65);
    let outerRadius = max(value(7u) * 4.0, fadeStart + max(180.0, coreR64));
    if (radius >= outerRadius) { return vec2<f32>(0.0); }

    var speed = resolvedVortexWind(radius);
    if (radius > fadeStart) {
        let t = (radius - fadeStart) / max(1.0, outerRadius - fadeStart);
        let fade = (exp(-2.0 * t) - exp(-2.0)) / (1.0 - exp(-2.0));
        speed *= clamp(fade, 0.0, 1.0);
    }

    let inflow = 15.0 * DEG_TO_RAD;
    var wind = vec2<f32>(0.0);
    if (fieldGeometry.w > 0.01) {
        let hemisphere = select(-1.0, 1.0, center.y >= 0.0);
        let normal = fieldGeometry.yz;
        let tangent = vec2<f32>(-hemisphere * normal.y, hemisphere * normal.x);
        wind = (tangent * cos(inflow) - normal * sin(inflow)) * speed;
    } else {
        let dx = wrappedLongitudeDelta(pos.x, center.x);
        let dy = pos.y - center.y;
        let centerAngle = atan2(dy, dx);
        let rotation = select(-PI * 0.5 - inflow, PI * 0.5 + inflow, center.y >= 0.0);
        let windAngle = centerAngle + rotation;
        wind = vec2<f32>(cos(windAngle), sin(windAngle)) * speed;
    }

    let moveAngle = (450.0 - value(11u)) * DEG_TO_RAD;
    let asymmetry = clamp(0.45 + 0.018 * value(10u), 0.45, 0.75);
    var translation = vec2<f32>(cos(moveAngle), sin(moveAngle)) * value(10u) * asymmetry;
    if (radius > 1.1 * dominantRmw) {
        let decayScale = max(90.0, max(1.75 * dominantRmw, 0.35 * value(7u)));
        translation *= exp(-(radius - 1.1 * dominantRmw) / decayScale);
    }
    return wind + translation;
}

fn encodeChannel(speedMs: f32) -> u32 {
    let normalized = clamp(speedMs, -128.0, 128.0) / 256.0 + 0.5;
    return u32(round(normalized * 255.0));
}

@compute @workgroup_size(8, 8)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let resolution = u32(value(0u));
    if (id.x >= resolution || id.y >= resolution) { return; }
    let radiusKm = value(1u);
    let centerLon = value(2u);
    let centerLat = value(3u);
    let dxKm = ((f32(id.x) + 0.5) / f32(resolution) * 2.0 - 1.0) * radiusKm;
    let dyKm = ((f32(id.y) + 0.5) / f32(resolution) * 2.0 - 1.0) * radiusKm;
    let lonKmPerDegree = 111.0 * max(0.1, cos(centerLat * DEG_TO_RAD));
    let pos = vec2<f32>(centerLon + dxKm / lonKmPerDegree, centerLat + dyKm / 111.0);
    let wind = (environmentalWind(pos) + cycloneWind(pos)) * 0.514444;
    let r = encodeChannel(wind.x);
    let g = encodeChannel(wind.y);
    outputData[id.y * resolution + id.x] = r | (g << 8u) | (255u << 24u);
}
`;

function finite(value, fallback = 0) {
    return Number.isFinite(value) ? value : fallback;
}

function buildInput(state, resolution, radiusKm) {
    const input = new Float32Array(HEADER_FLOATS + MAX_SYSTEMS * SYSTEM_STRIDE_FLOATS);
    const cyclone = state.cyclone || {};
    const systems = Array.isArray(state.pressureSystems)
        ? state.pressureSystems
        : (state.pressureSystems?.lower || []);
    const hasCyclone = cyclone.status === 'active';
    const rmw = finite(cyclone.rmw, 5 + finite(cyclone.circulationSize, 300) * 0.125);
    const hasErc = hasCyclone
        && cyclone.isERCActive
        && Number.isFinite(cyclone.ercInnerRmw)
        && Number.isFinite(cyclone.ercInnerWind)
        && Number.isFinite(cyclone.ercOuterRmw);
    const cycloneFieldGeometry = hasCyclone
        ? getCycloneFieldGeometryAt(cyclone.lon, cyclone.lat, cyclone)
        : { aspectRatio: 1, tilt: 0, baroclinicWeight: 0 };

    input.set([
        resolution,
        radiusKm,
        finite(state.siteLon),
        finite(state.siteLat),
        hasCyclone ? 1 : 0,
        finite(cyclone.lon),
        finite(cyclone.lat),
        finite(cyclone.circulationSize, 300),
        finite(cyclone.intensity),
        rmw,
        finite(cyclone.speed),
        finite(cyclone.direction),
        finite(cyclone.outerWindBroadness, 0.6),
        hasErc ? 1 : 0,
        hasErc ? cyclone.ercInnerRmw : rmw,
        hasErc ? cyclone.ercInnerWind : finite(cyclone.intensity),
        hasErc ? cyclone.ercOuterRmw : rmw,
        hasErc ? finite(cyclone.ercOuterWidth, 18) : 18,
        hasErc ? Math.max(0, finite(cyclone.ercOuterWindAnomaly)) : 0,
        hasErc ? Math.max(0, finite(cyclone.ercOuterShare)) : 0,
        hasErc ? Math.max(0, finite(cyclone.ercOuterOrganization)) : 0,
        hasErc ? Math.max(0, Math.min(1, finite(cyclone.ercInnerIntegrity, 1))) : 1,
        Math.min(systems.length, MAX_SYSTEMS),
        finite(cyclone.environmentalPressure, 1010),
        finite(cyclone.centralPressure, 0),
        finite(cyclone.pressureTendency, 0)
    ], 0);
    input[28] = finite(cycloneFieldGeometry.aspectRatio, 1);
    input[29] = finite(cycloneFieldGeometry.tilt, 0);
    input[30] = finite(cycloneFieldGeometry.baroclinicWeight, 0);

    if (hasCyclone) {
        const remap = getOuterCoreRemap(cyclone);
        input[26] = remap.start;
        input[27] = remap.end;
    }

    systems.slice(0, MAX_SYSTEMS).forEach((system, index) => {
        const base = HEADER_FLOATS + index * SYSTEM_STRIDE_FLOATS;
        const noiseLayers = Array.isArray(system.noiseLayers) ? system.noiseLayers.slice(0, 2) : [];
        input[base] = finite(system.x);
        input[base + 1] = finite(system.y);
        input[base + 2] = Math.max(0.01, Math.abs(finite(system.sigmaX, 1)));
        input[base + 3] = Math.max(0.01, Math.abs(finite(system.sigmaY, 1)));
        input[base + 4] = finite(system.strength);
        input[base + 5] = noiseLayers.length;
        noiseLayers.forEach((layer, noiseIndex) => {
            const noiseBase = base + 6 + noiseIndex * 5;
            input[noiseBase] = finite(layer.offsetX);
            input[noiseBase + 1] = finite(layer.offsetY);
            input[noiseBase + 2] = Math.max(0.001, Math.abs(finite(layer.freqX, 1)));
            input[noiseBase + 3] = Math.max(0.001, Math.abs(finite(layer.freqY, 1)));
            input[noiseBase + 4] = finite(layer.amplitude);
        });
    });
    return input;
}

export class WebGpuWindFieldBackend {
    constructor() {
        this.disabled = false;
        this.initPromise = null;
        this.device = null;
        this.pipeline = null;
        this.inputBuffer = null;
        this.outputBuffer = null;
        this.readbackBuffer = null;
        this.bufferResolution = 0;
    }

    shouldAttempt() {
        return !this.disabled && Boolean(globalThis.navigator?.gpu);
    }

    disable() {
        this.disabled = true;
        for (const buffer of [this.inputBuffer, this.outputBuffer, this.readbackBuffer]) {
            try { buffer?.destroy(); } catch (_) { /* best-effort cleanup */ }
        }
        this.inputBuffer = null;
        this.outputBuffer = null;
        this.readbackBuffer = null;
        this.device = null;
        this.pipeline = null;
        this.bufferResolution = 0;
    }

    async ensureReady() {
        if (!this.shouldAttempt()) return false;
        if (this.device && this.pipeline) return true;
        if (this.initPromise) return this.initPromise;

        this.initPromise = (async () => {
            try {
                const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
                if (!adapter) throw new Error('No WebGPU adapter');
                const device = await adapter.requestDevice();
                const module = device.createShaderModule({ code: shaderSource });
                const pipeline = device.createComputePipelineAsync
                    ? await device.createComputePipelineAsync({
                        layout: 'auto',
                        compute: { module, entryPoint: 'main' }
                    })
                    : device.createComputePipeline({
                        layout: 'auto',
                        compute: { module, entryPoint: 'main' }
                    });
                this.device = device;
                this.pipeline = pipeline;
                device.lost.then(() => this.disable()).catch(() => this.disable());
                return true;
            } catch (_) {
                this.disable();
                return false;
            } finally {
                this.initPromise = null;
            }
        })();
        return this.initPromise;
    }

    ensureBuffers(resolution, inputByteLength) {
        if (this.bufferResolution === resolution && this.inputBuffer) return;
        for (const buffer of [this.inputBuffer, this.outputBuffer, this.readbackBuffer]) {
            try { buffer?.destroy(); } catch (_) { /* best-effort cleanup */ }
        }
        const outputBytes = resolution * resolution * 4;
        this.inputBuffer = this.device.createBuffer({
            size: inputByteLength,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        });
        this.outputBuffer = this.device.createBuffer({
            size: outputBytes,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
        });
        this.readbackBuffer = this.device.createBuffer({
            size: outputBytes,
            usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
        });
        this.bufferResolution = resolution;
    }

    async compute(state, resolution = 160, radiusKm = 460) {
        // Snapshot mutable simulation state before awaiting adapter/device setup.
        const input = buildInput(state, resolution, radiusKm);
        if (!await this.ensureReady()) return null;
        try {
            this.ensureBuffers(resolution, input.byteLength);
            this.device.queue.writeBuffer(this.inputBuffer, 0, input);
            const bindGroup = this.device.createBindGroup({
                layout: this.pipeline.getBindGroupLayout(0),
                entries: [
                    { binding: 0, resource: { buffer: this.inputBuffer } },
                    { binding: 1, resource: { buffer: this.outputBuffer } }
                ]
            });
            const encoder = this.device.createCommandEncoder();
            const pass = encoder.beginComputePass();
            pass.setPipeline(this.pipeline);
            pass.setBindGroup(0, bindGroup);
            pass.dispatchWorkgroups(Math.ceil(resolution / 8), Math.ceil(resolution / 8));
            pass.end();
            encoder.copyBufferToBuffer(
                this.outputBuffer,
                0,
                this.readbackBuffer,
                0,
                resolution * resolution * 4
            );
            this.device.queue.submit([encoder.finish()]);
            await this.readbackBuffer.mapAsync(GPUMapMode.READ);
            const result = new Uint8Array(this.readbackBuffer.getMappedRange()).slice();
            this.readbackBuffer.unmap();
            return result;
        } catch (_) {
            this.disable();
            return null;
        }
    }
}
