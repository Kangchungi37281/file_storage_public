// Same ordered 8-neighbour breadth-first transform on window and Worker.
export function buildCoastDistanceField(landMaskData, mapWidth, mapHeight) {
    const size = mapWidth * mapHeight;
    const distance = new Uint16Array(size);
    distance.fill(0xffff);
    const queue = new Int32Array(size);
    let head = 0, tail = 0;
    const isLand = index => landMaskData[index] > 128;
    for (let y = 0; y < mapHeight; y++) {
        for (let x = 0; x < mapWidth; x++) {
            const index = y * mapWidth + x;
            const land = isLand(index);
            let boundary = false;
            for (let dy = -1; dy <= 1 && !boundary; dy++) {
                const ny = y + dy;
                if (ny < 0 || ny >= mapHeight) continue;
                for (let dx = -1; dx <= 1; dx++) {
                    if (dx === 0 && dy === 0) continue;
                    let nx = x + dx;
                    if (nx < 0) nx += mapWidth;
                    if (nx >= mapWidth) nx -= mapWidth;
                    if (isLand(ny * mapWidth + nx) !== land) { boundary = true; break; }
                }
            }
            if (boundary) { distance[index] = 0; queue[tail++] = index; }
        }
    }
    while (head < tail) {
        const index = queue[head++];
        const y = Math.floor(index / mapWidth), x = index - y * mapWidth;
        const nextDistance = distance[index] + 1;
        for (let dy = -1; dy <= 1; dy++) {
            const ny = y + dy;
            if (ny < 0 || ny >= mapHeight) continue;
            for (let dx = -1; dx <= 1; dx++) {
                if (dx === 0 && dy === 0) continue;
                let nx = x + dx;
                if (nx < 0) nx += mapWidth;
                if (nx >= mapWidth) nx -= mapWidth;
                const neighbour = ny * mapWidth + nx;
                if (nextDistance < distance[neighbour]) {
                    distance[neighbour] = nextDistance;
                    queue[tail++] = neighbour;
                }
            }
        }
    }
    return distance;
}
