// Exact projection reuse, independent of cyclone physics and field sampling.
const sources = new WeakMap();
const pending = new Map();
let worker, unavailable = false, sequence = 0;
const MAX_CAMERAS = 4;

function stopWorker(error) {
    unavailable = true;
    worker?.terminate();
    worker = null;
    for (const request of pending.values()) request.reject(error);
    pending.clear();
}

export async function prepareICWCGeography(world, projection, coast = false) {
    if (!world || unavailable || typeof Worker === 'undefined' || typeof Path2D === 'undefined') return null;
    const spec = {
        rotate: projection.rotate(), center: projection.center(),
        scale: projection.scale(), translate: projection.translate(),
        precision: projection.precision(), clipExtent: projection.clipExtent()
    };
    let source = sources.get(world);
    if (!source) {
        source = { id: ++sequence, sent: false, cameras: new Map() };
        sources.set(world, source);
    }
    const key = JSON.stringify([spec, coast]);
    let result = source.cameras.get(key);
    if (result) {
        source.cameras.delete(key); source.cameras.set(key, result);
        return result;
    }
    result = new Promise((resolve, reject) => {
        try {
            if (!worker) {
                worker = new Worker(new URL('./icwc-geography-worker.js', import.meta.url), { type: 'module' });
                worker.onmessage = ({ data }) => {
                    const request = pending.get(data.id);
                    if (!request) return;
                    pending.delete(data.id);
                    if (data.error) request.reject(new Error(data.error));
                    else {
                        // D3 returns null when a clipped coastline has no
                        // visible segments. Preserve the empty canvas path.
                        try { request.resolve({ land: new Path2D(data.land || ''), coast: new Path2D(data.coast || '') }); }
                        catch (error) { request.reject(error); }
                    }
                };
                worker.onerror = error => stopWorker(error);
                worker.onmessageerror = error => stopWorker(error);
            }
            const id = ++sequence;
            pending.set(id, { resolve, reject });
            try {
                worker.postMessage({ id, worldId: source.id, world: source.sent ? null : world, projection: spec, coast });
                source.sent = true;
            } catch (error) { pending.delete(id); reject(error); }
        } catch (error) { stopWorker(error); reject(error); }
    }).catch(error => {
        source.cameras.delete(key);
        console.warn('[ICWC geography] Original canvas projection fallback:', error);
        return null;
    });
    source.cameras.set(key, result);
    while (source.cameras.size > MAX_CAMERAS) source.cameras.delete(source.cameras.keys().next().value);
    return result;
}
