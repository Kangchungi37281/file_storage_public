/** Procedural ocean, NOT an observational analysis.
 * SST and subsurface stratification have separate geographic parameters.
 * OHC here is TCHP: rho*cp*integral(max(T-26,0), dz), in kJ/cm².
 * https://www.aoml.noaa.gov/phod/cyclone/method.php
 */
export const OCEAN_MODEL = Object.freeze({
    densityKgM3:1025, heatCapacityJKgK:3990, airDensityKgM3:1.2,
    gravityMs2:9.81, thermalExpansionK:2e-4, freezingC:-1.8,
    heatReferenceC:26,
    // Synthetic wind-work closure coefficient, NOT a fraction/efficiency.
    // Calibration: fixed 100 kt, stationary at 15N/145E in August, default
    // heat reservoir, three-hour response, 72h -> 7.5 C cooling.
    // Inverting the entrainment heat and potential-energy equations gives
    // coefficient 5.36719. No direct SST subtraction or independent OHC
    // penalty; other winds/motion/reservoirs remain variable.
    windWorkCoefficient:5.36719, footprintWindFraction:0.8,
    wakeRadiusRmwFactor:3,
    // Local entrainment responds gradually to wind work, not instantly.
    // Three hours is a response time, not a TC-age gate or a hard on/off delay.
    wakeResponseHours:3,
    wakeRecoveryHours:120, wakeRetentionFraction:0.001,
    // Reservoir control 0/50/100 means half/default/1.5x depth, NOT SST.
    minimumDepthScale:0.5, maximumDepthScale:1.5
});
// Synthetic variability, not measured anomalies or a resolved eddy model.
// O(100 km) coherent ocean features and slowly changing subsurface structure:
// doi:10.1016/j.pocean.2011.01.002; NOAA/AOML TCHP methodology above.
// Amplitudes/scales are explicit tuning parameters, not fitted observations.
// Positive reservoir anomalies deepen the equivalent warm column; OHC is
// always recomputed from that column, never painted or multiplied separately.
export const OCEAN_VARIABILITY = Object.freeze({
    waterMassScaleKm:1000, eddyScaleKm:220,
    mixedLayerScaleKm:350, subsurfaceScaleKm:700,
    // Keep broad water-mass contrasts, but let small-scale structure remain
    // subordinate to the existing currents/fronts rather than dominate them.
    waterMassSurfaceC:0.55, eddySurfaceC:0.35,
    eddyReservoirM:12, subsurfaceReservoirM:12,
    mixedLayerM:5, stratificationLogAmplitude:0.08,
    waterMassEvolutionHours:180*24, eddyEvolutionHours:90*24,
    mixedLayerEvolutionHours:90*24, subsurfaceEvolutionHours:180*24
});
const RAD = Math.PI/180, EARTH_KM = 6371, KNOT_MS = 1852/3600;
const clamp = (x,a,b) => Math.max(a,Math.min(b,x));
const smooth = x => {const t=clamp(x,0,1); return t*t*(3-2*t);};
const wrap = lon => ((lon+180)%360+360)%360-180;
const monthIndex = month => (((Number.isFinite(month)?month:8)-1)%12+12)%12;
const HEAT_UNITS = OCEAN_MODEL.densityKgM3*OCEAN_MODEL.heatCapacityJKgK/1e7;
// Synthetic zonal reference/seasonal amplitude (°C), not imported observations.
// No tropical plateau or 10°C polar floor. Summer lags the solstice.
// Annual-mean meridional decay, in C per degree latitude. Previously implicit
// in the 20/30/40-degree anchors: 0.33 and 0.70. Relax the underlying gradient
// instead of adding a latitude-band anomaly. This reference is shared by both
// hemispheres; seasonal amplitudes, currents and polar anchors stay separate.
const LATITUDE_SST_DECAY = Object.freeze({
    subtropicalCPerDeg:0.30, midlatitudeCPerDeg:0.67
});
const reference30C=25.6-(30-20)*LATITUDE_SST_DECAY.subtropicalCPerDeg;
const reference40C=reference30C-(40-30)*LATITUDE_SST_DECAY.midlatitudeCPerDeg;
const LATITUDE_REFERENCE = [
    [0,27.5,0.3],[10,27.3,0.8],[20,25.6,2.3],[30,reference30C,3.5],
    [40,reference40C,4.5],[50,8.2,3.8],[60,2.5,2.4],[75,-1.3,0.6],[90,-1.8,0]
];
const SEASONAL_RESPONSE = [-0.78,-1,-0.89,-0.53,-0.08,0.41,0.79,1,0.93,0.59,0.14,-0.38];
// Surface calibration for a synthetic warm-season state, NOT a 30-year
// monthly climatology fit. Keep the equatorial background near 29–30°C,
// with a seasonally migrating, locally hotter core approaching 32°C.
// Seasonal migration: doi:10.1029/2011JD016557; observed extremes:
// doi:10.1002/joc.8350. The amplitudes below are model tuning parameters,
// not coefficients inferred from those papers. Subsurface depth is separate.
const WEST_PACIFIC_WARM_POOL = Object.freeze({
    centerLat:2, centerLon:142, latWidth:27, lonWidth:65,
    latitudeMigrationDeg:6,
    perennialSurfaceAnomalyC:2.2, warmSeasonSurfaceAnomalyC:1.4,
    // A modest eastward shoulder, sharing the warm pool's latitude migration.
    // 170°W is the warm-pool/cold-tongue transition, not a second hot core:
    // https://www.pmel.noaa.gov/public/pmel/publications-search/search_abstract.php?fmContributionNum=2433
    eastwardTransition:{centerLon:-173,lonWidth:37,surfaceAnomalyC:1}
});
// Atlantic summer warmth extends well beyond the small Caribbean core and
// peaks later than the generic zonal August maximum. Surface-only synthetic
// anomalies (°C, Jan–Dec), not observed monthly SST or an intensity boost.
// Structure: doi:10.1029/2006GL028579 and NOAA/AOML Atlantic warm-pool products.
// Keep the equatorial cold tongue and coastal Canary cooling independent.
const TROPICAL_NORTH_ATLANTIC_WARM_POOL = Object.freeze({
    centerLon:-48,westLonWidth:37,eastLonWidth:44,
    southEdgeLat:0,southCoreLat:8,northCoreLat:20,northEdgeLat:32,
    monthlySurfaceAnomalyC:[0.25,0.15,0.15,0.35,0.7,1,1.25,1.5,1.8,1.5,0.85,0.45]
});
// Broad summer surface pool west of the Florida Current. Its asymmetric
// footprint follows the Gulf's extent rather than shifting the Gulf Stream
// across Florida. Keep the Loop Current's subsurface reservoir independent.
// Seasonal/geographic structure: https://www.aoml.noaa.gov/phod/gom/
// Geometry/amplitude are synthetic tuning, not an observational fit.
const GULF_SUMMER_WARM_POOL = Object.freeze({
    centerLat:24.5, centerLon:-90, northLatWidth:11, southLatWidth:6,
    lonWidth:18, warmSeasonSurfaceAnomalyC:3.4
});
const GULF_STREAM_PATH = [[-80,26],[-80,31],[-75,36],[-66,40],[-49,43],[-31,47],[-13,52]];
// The warm side of the Gulf Stream is a water mass, not just a narrow warm
// line on a cold zonal ocean. Give the western subtropical gyre its own
// seasonal surface reference and independently parameterized reservoir.
// Structure/stratification: doi:10.5194/os-18-1221-2022. Temperatures and
// widths below are synthetic calibration, NOT imported observations or a
// climatology fit. The cold northern side is bounded by the existing axis.
const WESTERN_NORTH_ATLANTIC = Object.freeze({
    // Overlap the western boundary current and tropical warm water before
    // tapering, instead of gating them into separate rectangular water masses.
    // The northern fade begins on the warm side and spans the front smoothly.
    surface:{southEdgeLat:12,southCoreLat:20,westEdgeLon:-91,westCoreLon:-80,
        eastCoreLon:-50,eastEdgeLon:-30,northFrontStartOffsetDeg:-3,northFrontEndOffsetDeg:6,
        references:[
            {lat:30,monthlyC:[21.7,21.2,21.6,22.5,24.4,26.2,28.3,29,29.1,27.6,25.4,23.1]},
            {lat:38,monthlyC:[18.6,18,18.2,19.4,21.5,24.2,26.6,27.4,26.9,24.7,22.1,20]},
            {lat:44,monthlyC:[13.2,12.6,12.7,14,16.2,18.9,21.3,22.5,22.6,20.6,17.8,15.2]}
        ]},
    // Distinct extent/strength, not a fixed multiplier of SST or OHC.
    reservoir:{southEdgeLat:16,southCoreLat:20,westEdgeLon:-91,westCoreLon:-80,
        eastCoreLon:-55,eastEdgeLon:-35,northFrontStartOffsetDeg:-3,northFrontEndOffsetDeg:5.5,depthM:22}
});
// The northern Indian Ocean does not follow the zonal August maximum:
// spring preheating, SW-monsoon cooling and an autumn rebound coexist.
// Arabian Sea: doi:10.5194/os-19-1437-2023; both basins:
// doi:10.1016/j.rsma.2015.05.004. These °C anchors are synthetic reference
// temperatures, NOT downloaded climatology. Blend references rather than
// stacking two warm-pool anomalies. Coastal upwelling is applied separately.
// These surface-only references do not alter MLD or thermocline parameters.
const NORTH_INDIAN_SURFACE = Object.freeze({
    southEdgeLat:2, southCoreLat:8, northCoreLat:23, northEdgeLat:30,
    lowerReferenceLat:10, upperReferenceLat:20,
    sectors:[
        {name:'Arabian Sea',centerLon:64,lonWidth:23,
            lowerMonthlyC:[27,27.4,28.5,29.8,30.2,29.1,28.3,28.2,28.7,29.1,28.3,27.6],
            upperMonthlyC:[25.2,25,26.8,28.9,30.1,29.8,28.7,28.7,29.2,29.4,28,26]},
        {name:'Bay of Bengal',centerLon:88,lonWidth:18,
            lowerMonthlyC:[27.8,28,29,30.3,30.3,29.4,28.8,28.8,29.1,29.3,28.9,28.1],
            upperMonthlyC:[25.5,25.6,27.3,29.4,30.4,29.9,29.2,29.2,29.5,29.5,28,26.1]}
    ]
});
// Warm South Equatorial Current / tropical-gyre water south of the
// Seychelles-Chagos thermocline ridge. The old equatorial Indian footprint
// lost nearly all of its surface/depth contribution by 20-25S.
// Structure and independent surface/subsurface seasonality:
// doi:10.1002/2016JC012028; doi:10.1093/icesjms/fsp074.
// These are synthetic seasonal anchors, NOT observed monthly values or a TC
// intensity bonus. Latitude distances are degrees south. Do not extend this
// positive reservoir correction over the thermocline-ridge region. The base
// column itself has NOT been calibrated against local vertical profiles.
const SOUTH_INDIAN_WARM_WATER = Object.freeze({
    surface:{northEdgeDeg:12,northCoreDeg:15,southCoreDeg:23,southEdgeDeg:32,
        westEdgeLon:45,westCoreLon:60,eastCoreLon:95,eastEdgeLon:112,
        // Jan-Dec, °C above the zonal reference. Retain late-summer warmth
        // rather than mechanically imposing the generic February maximum.
        monthlyAnomalyC:[1,0.9,1.1,0.65,0.15,0,0,0,0,0.05,0.35,0.75]},
    // The prior low-latitude Indian anomaly left the summer surface near
    // 28C. Its subsurface parameters have not been calibrated to ridge profiles.
    // Synthetic warm-season surface calibration, not an imported monthly
    // climatology or a simultaneous deepening of the thermocline. Near-30C
    // warm water can coexist with strong sensitivity to subsequent mixing.
    lowLatitudeSurface:{northEdgeDeg:0,northCoreDeg:5,southCoreDeg:12,southEdgeDeg:20,
        westEdgeLon:45,westCoreLon:60,eastCoreLon:90,eastEdgeLon:108,
        monthlyAnomalyC:[2.2,2.35,2.45,1.85,0.7,0,0,0,0,0.1,0.6,1.6]},
    reservoir:{northEdgeDeg:12,northCoreDeg:18,southCoreDeg:22,southEdgeDeg:30,
        westEdgeLon:50,westCoreLon:65,eastCoreLon:90,eastEdgeLon:108,
        // Independent equivalent warm-layer depth (m); converted through
        // the existing MLD/thermocline closure, never multiplied into OHC.
        monthlyDepthM:[26,28,26,18,8,0,0,0,0,2,10,20]}
});
// Surface cold-water reach, not a permanent southward current. The Somali
// summer cold wedges follow the boreal SW monsoon even near the equator;
// anchoring activation to local hemispheric season reverses it south of 0°.
// Coast/season structure: doi:10.1038/s41598-019-44099-1. Geometry is synthetic.
// Retain the original independent subsurface footprint below.
const SOMALI_MONSOON_UPWELLING = Object.freeze({
    centerLat:9,centerLon:53,northLatWidth:12,southLatWidth:16,lonWidth:11,
    southAxisLonPerLat:2/3,surfaceCoolingC:3.7
});
function cubic(a,b,c,d,t) {
    return b+0.5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*(b-c)+d-a)));
}
function monthlyValue(values,month,shift=0) {
    const p=(monthIndex(month)+shift)%12, i=Math.floor(p), t=p-i;
    const v=n=>values[(n+12)%12];
    return cubic(v(i-1),v(i),v(i+1),v(i+2),t);
}
function latitudeValue(lat,column) {
    const x=Math.abs(lat); let i=0;
    while(i<LATITUDE_REFERENCE.length-2 && x>LATITUDE_REFERENCE[i+1][0]) i++;
    const a=LATITUDE_REFERENCE[i], b=LATITUDE_REFERENCE[i+1];
    const previous=LATITUDE_REFERENCE[Math.max(0,i-1)];
    const next=LATITUDE_REFERENCE[Math.min(LATITUDE_REFERENCE.length-1,i+2)];
    const t=clamp((x-a[0])/(b[0]-a[0]),0,1), span=b[0]-a[0];
    const m0=i?(b[column]-previous[column])/(b[0]-previous[0]):0;
    const m1=(next[column]-a[column])/(next[0]-a[0]);
    return (2*t**3-3*t*t+1)*a[column]+(t**3-2*t*t+t)*span*m0
        +(-2*t**3+3*t*t)*b[column]+(t**3-t*t)*span*m1;
}
function seasonAt(lat,month) {
    // No finite jump across the equator.
    const north=smooth((lat+8)/16);
    return north*monthlyValue(SEASONAL_RESPONSE,month)
        +(1-north)*monthlyValue(SEASONAL_RESPONSE,month,6);
}
function regionalSurfaceReference(lat,lon,month,zonalC) {
    const p=NORTH_INDIAN_SURFACE;
    const latitudeWeight=smooth((lat-p.southEdgeLat)/(p.southCoreLat-p.southEdgeLat))
        *(1-smooth((lat-p.northCoreLat)/(p.northEdgeLat-p.northCoreLat)));
    if(latitudeWeight===0) return zonalC;
    const latitudeBlend=smooth((lat-p.lowerReferenceLat)/(p.upperReferenceLat-p.lowerReferenceLat));
    let correctionC=0,weightSum=0;
    for(const sector of p.sectors) {
        const q=(wrap(lon-sector.centerLon)/sector.lonWidth)**2;
        if(q>=1) continue;
        const weight=latitudeWeight*(1-q)**2;
        const lower=monthlyValue(sector.lowerMonthlyC,month),upper=monthlyValue(sector.upperMonthlyC,month);
        correctionC+=weight*((1-latitudeBlend)*lower+latitudeBlend*upper-zonalC);
        weightSum+=weight;
    }
    return zonalC+correctionC/Math.max(1,weightSum);
}
function regional(lat,lon,centerLat,centerLon,latWidth,lonWidth) {
    const q=((lat-centerLat)/latWidth)**2+(wrap(lon-centerLon)/lonWidth)**2;
    return q<1?(1-q)**3:0;
}
function southIndianWarmWater(lat,lon,month) {
    const latitude=-lat,longitude=wrap(lon);
    const footprint=p=> {
        if(latitude<=p.northEdgeDeg || latitude>=p.southEdgeDeg
            || longitude<=p.westEdgeLon || longitude>=p.eastEdgeLon) return 0;
        return smooth((latitude-p.northEdgeDeg)/(p.northCoreDeg-p.northEdgeDeg))
            *(1-smooth((latitude-p.southCoreDeg)/(p.southEdgeDeg-p.southCoreDeg)))
            *smooth((longitude-p.westEdgeLon)/(p.westCoreLon-p.westEdgeLon))
            *(1-smooth((longitude-p.eastCoreLon)/(p.eastEdgeLon-p.eastCoreLon)));
    };
    const p=SOUTH_INDIAN_WARM_WATER;
    const surfaceWeight=footprint(p.surface),lowLatitudeWeight=footprint(p.lowLatitudeSurface),
        reservoirWeight=footprint(p.reservoir);
    return {
        surfaceC:Math.max(surfaceWeight>0
            ?surfaceWeight*Math.max(0,monthlyValue(p.surface.monthlyAnomalyC,month)):0,
            lowLatitudeWeight>0
                ?lowLatitudeWeight*Math.max(0,monthlyValue(p.lowLatitudeSurface.monthlyAnomalyC,month)):0),
        depthM:reservoirWeight>0
            ?reservoirWeight*Math.max(0,monthlyValue(p.reservoir.monthlyDepthM,month)):0
    };
}
// Connected current/front axes [lon,lat]; width is a cross-axis Gaussian
// thermal-footprint scale in degrees latitude, not the coastal jet's width.
// Warm boundary currents stay narrow; Peru/Benguela include offshore cold
// water, with the same along-axis amplitudes as before the widening.
const CURRENTS = [
    {name:'Gulf Stream',surfaceGroup:'North Atlantic',width:2.5,surfaceC:3.4,depthM:15,
        // Keep the Florida Straits origin offshore; shift the remaining axis
        // 1° west without broadening or amplifying its thermal footprint.
        path:GULF_STREAM_PATH},
    // Broad NE Atlantic warm-water footprint, not a wider Florida jet.
    // Its contrast with the cold zonal reference increases poleward even
    // though absolute SST still falls northwards. Geometry follows the NAC
    // / Norwegian extension (NOAA currents glossary); contrast is synthetic.
    // Share the surface group with the Gulf Stream to avoid double heating.
    {name:'North Atlantic Drift',surfaceGroup:'North Atlantic',width:5,surfaceC:3,
        polewardSurfaceC:7,contrastStartLat:45,contrastEndLat:60,depthM:0,
        // Broaden only the middle-latitude eastward surface shoulder. Keep
        // the western flank, northern extension and along-axis contrast.
        surfaceEastwardStretch:1.6,
        surfaceStretchLat:{southEdge:35,southCore:42,northCore:48,northEdge:55},
        path:[[-35,45],[-27,48],[-17,52],[-10,57],[-2,62],[5,67]]},
    // Modest ~14% reduction in both surface and subsurface corrections.
    {name:'Kuroshio',width:2.4,surfaceC:2.4,depthM:12,
        path:[[123,22],[127,28],[135,33],[145,36],[160,39],[176,41]]},
    {name:'Brazil',width:2.5,surfaceC:1.8,depthM:12,
        path:[[-35,-10],[-40,-20],[-46,-28],[-50,-36]]},
    {name:'Agulhas',width:2.3,surfaceC:2.3,depthM:16,
        path:[[40,-14],[36,-24],[30,-33],[20,-38],[40,-40]]},
    {name:'East Australia',width:2.3,surfaceC:1.9,depthM:12,
        path:[[149,-17],[154,-26],[153,-33],[157,-39]]},
    {name:'California',width:4,surfaceC:-2.8,depthM:-9,
        path:[[-128,42],[-124,35],[-118,27],[-113,23]]},
    // Offshore cold water spreads west, without lengthening the northern
    // endpoint or widening the subsurface correction / coastal jet itself.
    {name:'Canary',width:4,surfaceC:-2.5,depthM:-10,surfaceWestwardStretch:1.4,
        path:[[-11,35],[-16,26],[-19,18],[-23,11]]},
    {name:'Peru',width:7,surfaceC:-3.8,depthM:-12,
        path:[[-74,-34],[-77,-23],[-80,-12],[-85,-3]]},
    {name:'Benguela',width:6,surfaceC:-3.4,depthM:-12,
        path:[[16,-33],[12,-24],[9,-16],[7,-7]]},
    {name:'West Australia',width:4,surfaceC:-1.5,depthM:-7,
        path:[[110,-36],[112,-28],[111,-21]]}
];
for(const c of CURRENTS) c.segments=c.path.slice(1).map((b,i)=>{
    const a=c.path[i], cos=Math.cos((a[1]+b[1])*0.5*RAD);
    const dx=wrap(b[0]-a[0])*cos, dy=b[1]-a[1];
    return {a,dx,dy,cos,length2:dx*dx+dy*dy};
});
function currentWeight(current,lat,lon,eastwardStretch=1,westwardStretch=1) {
    let distance2=Infinity;
    for(const s of current.segments) {
        if(lat<Math.min(s.a[1],s.a[1]+s.dy)-3*current.width
            ||lat>Math.max(s.a[1],s.a[1]+s.dy)+3*current.width) continue;
        const x=wrap(lon-s.a[0])*s.cos, y=lat-s.a[1];
        const t=clamp((x*s.dx+y*s.dy)/s.length2,0,1);
        // Deform the surface footprint around the unchanged nearest axis,
        // not the axis itself. Defaults preserve the old depth calculation.
        const rx=x-t*s.dx,ry=y-t*s.dy;
        const stretch=rx<0?westwardStretch:eastwardStretch;
        distance2=Math.min(distance2,(rx/stretch)**2+ry**2);
    }
    return Math.exp(-distance2/(2*current.width**2))
        *(1-smooth((Math.sqrt(distance2)/current.width-2)));
}
function hash(x,y,z,seed) {
    let h=Math.imul(x,374761393)^Math.imul(y,668265263)^Math.imul(z,2147483647)^seed;
    h=Math.imul(h^(h>>>13),1274126177);
    return ((h^(h>>>16))>>>0)/4294967295;
}
function sphericalPoint(lat,lon) {
    const cos=Math.abs(lat)===90?0:Math.cos(lat*RAD);
    return [cos*Math.cos(lon*RAD),cos*Math.sin(lon*RAD),Math.sin(lat*RAD)];
}
const textureDrifts=new Map();
function sphericalTexture(point,scaleKm,seed,elapsedHours,evolutionHours) {
    // Cartesian noise on a sphere: date-line/polar continuity, no random
    // render draws and no repeating sinusoidal ocean texture. A slowly moving
    // slice through the lattice changes coherent features without frame noise
    // or monthly resets. It is decorrelation, NOT a prognostic ocean current.
    let drift=textureDrifts.get(seed);
    if(!drift) {
        const direction=[2*hash(0,0,0,seed)-1,2*hash(1,0,0,seed)-1,2*hash(0,1,0,seed)-1];
        const length=Math.hypot(...direction)||1;
        drift=direction.map(v=>v/length);textureDrifts.set(seed,drift);
    }
    const f=EARTH_KM/scaleKm,phase=elapsedHours/evolutionHours;
    const p=point.map((v,i)=>f*v+phase*drift[i]);
    const cell=p.map(Math.floor), t=p.map((v,i)=>smooth(v-cell[i])); let value=0;
    for(let z=0;z<2;z++) for(let y=0;y<2;y++) for(let x=0;x<2;x++) {
        value+=hash(cell[0]+x,cell[1]+y,cell[2]+z,seed)
            *(x?t[0]:1-t[0])*(y?t[1]:1-t[1])*(z?t[2]:1-t[2]);
    }
    return 2*value-1;
}
export function sampleOceanVariability(lat,lon,elapsedHours=0) {
    lat=clamp(Number.isFinite(lat)?lat:0,-90,90);lon=wrap(Number.isFinite(lon)?lon:0);
    const age=Number.isFinite(elapsedHours)?Math.max(0,elapsedHours):0;
    const point=sphericalPoint(lat,lon),p=OCEAN_VARIABILITY;
    // Share an eddy component, but leave water-mass, mixed-layer and deeper
    // anomalies independent: warm SST is not synonymous with a deep reservoir.
    const waterMass=sphericalTexture(point,p.waterMassScaleKm,8421,age,p.waterMassEvolutionHours);
    const eddy=sphericalTexture(point,p.eddyScaleKm,1937,age,p.eddyEvolutionHours);
    const mixedLayer=sphericalTexture(point,p.mixedLayerScaleKm,5219,age,p.mixedLayerEvolutionHours);
    const subsurface=sphericalTexture(point,p.subsurfaceScaleKm,7147,age,p.subsurfaceEvolutionHours);
    return {
        surfaceC:p.waterMassSurfaceC*waterMass+p.eddySurfaceC*eddy,
        reservoirM:p.eddyReservoirM*eddy+p.subsurfaceReservoirM*subsurface,
        mixedLayerM:p.mixedLayerM*mixedLayer,
        stratificationLog:p.stratificationLogAmplitude*subsurface
    };
}
function warmPoolSurfaceAnomaly(lat,lon,month,localSeason) {
    const p=WEST_PACIFIC_WARM_POOL;
    const centerLat=p.centerLat+p.latitudeMigrationDeg*seasonAt(20,month);
    const q=((lat-centerLat)/p.latWidth)**2+(wrap(lon-p.centerLon)/p.lonWidth)**2;
    // A broader quadratic core replaces the overly pinched cubic footprint;
    // both value and first derivative still vanish at the boundary.
    const footprint=q<1?(1-q)**2:0;
    const warmSeason=smooth(Math.max(0,localSeason));
    const coreC=footprint*(p.perennialSurfaceAnomalyC+p.warmSeasonSurfaceAnomalyC*warmSeason);
    const shoulder=p.eastwardTransition;
    const transitionQ=((lat-centerLat)/p.latWidth)**2
        +(wrap(lon-shoulder.centerLon)/shoulder.lonWidth)**2;
    const transitionC=transitionQ<1?shoulder.surfaceAnomalyC*(1-transitionQ)**2:0;
    // Two descriptions of connected warm water, not additive heat sources.
    // The shoulder ends west of the eastern cold-tongue core and leaves the
    // existing hot western core and independent subsurface footprint alone.
    return Math.max(coreC,transitionC);
}
function tropicalAtlanticSurfaceAnomaly(lat,lon,month) {
    const p=TROPICAL_NORTH_ATLANTIC_WARM_POOL;
    const latitudeWeight=smooth((lat-p.southEdgeLat)/(p.southCoreLat-p.southEdgeLat))
        *(1-smooth((lat-p.northCoreLat)/(p.northEdgeLat-p.northCoreLat)));
    if(latitudeWeight===0) return 0;
    const dx=wrap(lon-p.centerLon),width=dx<0?p.westLonWidth:p.eastLonWidth;
    const q=(dx/width)**2;
    return q<1?latitudeWeight*(1-q)**2*monthlyValue(p.monthlySurfaceAnomalyC,month):0;
}
function gulfSummerSurfaceAnomaly(lat,lon,localSeason) {
    const p=GULF_SUMMER_WARM_POOL, dy=lat-p.centerLat;
    const latWidth=dy<0?p.southLatWidth:p.northLatWidth;
    const q=(dy/latWidth)**2+(wrap(lon-p.centerLon)/p.lonWidth)**2;
    if(q>=1 || localSeason<=0) return 0;
    return p.warmSeasonSurfaceAnomalyC*(1-q)**2*smooth(localSeason);
}
function gulfStreamFrontLatitude(lon) {
    // At the vertical Florida segment, the northern endpoint is the warm
    // water's poleward boundary. Returning its southern endpoint west of
    // 80°W used to create a 5° boundary jump and a visible meridional seam.
    if(lon<GULF_STREAM_PATH[0][0]) return GULF_STREAM_PATH[1][1];
    for(let i=1;i<GULF_STREAM_PATH.length;i++) {
        const a=GULF_STREAM_PATH[i-1],b=GULF_STREAM_PATH[i];
        if(b[0]>a[0] && lon>=a[0] && lon<=b[0]) {
            return a[1]+(b[1]-a[1])*(lon-a[0])/(b[0]-a[0]);
        }
    }
    return GULF_STREAM_PATH.at(-1)[1];
}
function westernAtlanticWeight(lat,lon,p) {
    lon=wrap(lon);
    if(lat<=p.southEdgeLat || lon<=p.westEdgeLon || lon>=p.eastEdgeLon) return 0;
    const frontLat=gulfStreamFrontLatitude(lon);
    const northWeight=1-smooth((lat-frontLat-p.northFrontStartOffsetDeg)
        /(p.northFrontEndOffsetDeg-p.northFrontStartOffsetDeg));
    if(northWeight===0) return 0;
    return northWeight*smooth((lat-p.southEdgeLat)/(p.southCoreLat-p.southEdgeLat))
        *smooth((lon-p.westEdgeLon)/(p.westCoreLon-p.westEdgeLon))
        *(1-smooth((lon-p.eastCoreLon)/(p.eastEdgeLon-p.eastCoreLon)));
}
function westernAtlanticSurfaceReference(lat,month) {
    const refs=WESTERN_NORTH_ATLANTIC.surface.references;
    let i=0;
    while(i<refs.length-2 && lat>refs[i+1].lat) i++;
    const a=refs[i],b=refs[i+1],blend=smooth((lat-a.lat)/(b.lat-a.lat));
    return (1-blend)*monthlyValue(a.monthlyC,month)+blend*monthlyValue(b.monthlyC,month);
}
function somaliSurfaceCooling(lat,lon,month) {
    const p=SOMALI_MONSOON_UPWELLING,dy=lat-p.centerLat;
    const latitudeWidth=dy<0?p.southLatWidth:p.northLatWidth;
    const axisLon=p.centerLon+Math.min(0,dy)*p.southAxisLonPerLat;
    const q=(dy/latitudeWidth)**2+(wrap(lon-axisLon)/p.lonWidth)**2;
    if(q>=1) return 0;
    const borealMonsoon=smooth((seasonAt(p.centerLat,month)+0.4)/1.1);
    return p.surfaceCoolingC*(1-q)**3*borealMonsoon;
}
function geography(lat,lon,season,month,zonalC) {
    // Preserve the independently calibrated subsurface reservoir footprint.
    const indoPacific=regional(lat,lon,2,142,27,65);
    const indian=regional(lat,lon,-3,75,24,36);
    const southIndian=southIndianWarmWater(lat,lon,month);
    const caribbean=regional(lat,lon,15,-73,17,30);
    const eastPacificPool=regional(lat,lon,12,-103,13,28);
    const loop=regional(lat,lon,24,-87,8,13);
    const pacificTongue=regional(lat,lon,-1,-114,8,48);
    const atlanticTongue=regional(lat,lon,-2,-3,7,29);
    const somaliReservoir=regional(lat,lon,9,53,12,11)*smooth((season+0.4)/1.1);
    const southChina=regional(lat,lon,20,115,14,13);
    const atlanticWarmSurfaceC=Math.max(0.7*caribbean,tropicalAtlanticSurfaceAnomaly(lat,lon,month));
    // Connected descriptions of Indian warm water share an envelope; do
    // not stack two heat sources in their overlap. Surface and reservoir
    // have distinct footprints and monthly cycles.
    const indianSurfaceC=Math.max(0.8*indian,southIndian.surfaceC);
    const indianReservoirM=Math.max(10*indian,southIndian.depthM);
    let surfaceC=warmPoolSurfaceAnomaly(lat,lon,month,season)+indianSurfaceC+atlanticWarmSurfaceC+1.4*eastPacificPool+0.3*loop
        -3.5*pacificTongue-2.3*atlanticTongue-somaliSurfaceCooling(lat,lon,month)
        +southChina*(0.3-2.5*smooth(-season));
    let depthM=20*indoPacific+indianReservoirM+14*caribbean+30*loop
        -14*pacificTongue-10*atlanticTongue-14*somaliReservoir;
    let northAtlanticSurfaceC=0,northAtlanticReservoirM=0;
    for(const current of CURRENTS) {
        const band=current.surfaceStretchLat;
        const stretchWeight=band?smooth((lat-band.southEdge)/(band.southCore-band.southEdge))
            *(1-smooth((lat-band.northCore)/(band.northEdge-band.northCore))):1;
        const eastwardStretch=1+((current.surfaceEastwardStretch||1)-1)*stretchWeight;
        const westwardStretch=1+((current.surfaceWestwardStretch||1)-1)*stretchWeight;
        const w=currentWeight(current,lat,lon,eastwardStretch,westwardStretch);
        const contrast=current.polewardSurfaceC===undefined?current.surfaceC
            :current.surfaceC+(current.polewardSurfaceC-current.surfaceC)
                *smooth((lat-current.contrastStartLat)/(current.contrastEndLat-current.contrastStartLat));
        if(current.surfaceGroup==='North Atlantic') northAtlanticSurfaceC=Math.max(northAtlanticSurfaceC,contrast*w);
        else surfaceC+=contrast*w;
        if(current.depthM!==0) {
            const reservoirWeight=eastwardStretch===1 && westwardStretch===1?w:currentWeight(current,lat,lon);
            depthM+=current.depthM*reservoirWeight;
            if(current.surfaceGroup==='North Atlantic') northAtlanticReservoirM+=current.depthM*reservoirWeight;
        }
    }
    // These are overlapping descriptions of warm surface water, not two
    // independent heat injections. Extend the warm area without double-counting
    // the Florida Current peak. The surface reference describes this same
    // water, so replace a weaker contribution rather than adding a second one.
    const existingCurrentC=Math.max(northAtlanticSurfaceC,gulfSummerSurfaceAnomaly(lat,lon,season));
    const surfaceWeight=westernAtlanticWeight(lat,lon,WESTERN_NORTH_ATLANTIC.surface);
    const gyreSurfaceC=surfaceWeight>0?surfaceWeight*Math.max(0,westernAtlanticSurfaceReference(lat,month)-zonalC):0;
    surfaceC+=existingCurrentC+Math.max(0,gyreSurfaceC-atlanticWarmSurfaceC-existingCurrentC);
    // These connected Atlantic reservoir descriptions overlap; take their
    // envelope instead of stacking the gyre on the current / Caribbean / Loop
    // reservoir. Its independent parameters still cannot rescale SST.
    const gyreReservoirM=westernAtlanticWeight(lat,lon,WESTERN_NORTH_ATLANTIC.reservoir)
        *WESTERN_NORTH_ATLANTIC.reservoir.depthM;
    const existingAtlanticReservoirM=northAtlanticReservoirM+14*caribbean+30*loop;
    depthM+=Math.max(0,gyreReservoirM-existingAtlanticReservoirM);
    return {surfaceC,depthM};
}
function surfaceBackground(lat,lon,month,globalTempK,elapsedHours=0) {
    lat=clamp(Number.isFinite(lat)?lat:0,-90,90); lon=wrap(Number.isFinite(lon)?lon:0);
    const season=seasonAt(lat,month);
    const zonalC=latitudeValue(lat,1)+latitudeValue(lat,2)*season;
    const region=geography(lat,lon,season,month,zonalC);
    const variability=sampleOceanVariability(lat,lon,elapsedHours);
    const anomaly=(Number.isFinite(globalTempK)?globalTempK:289)-289;
    const sstC=Math.max(OCEAN_MODEL.freezingC,regionalSurfaceReference(lat,lon,month,zonalC)
        +region.surfaceC+variability.surfaceC+0.6*anomaly);
    return {lat,lon,sstC,season,depthM:region.depthM,variability};
}
export function getSST(lat,lon,month,globalTempK=289,elapsedHours=0) {
    return surfaceBackground(lat,lon,month,globalTempK,elapsedHours).sstC;
}
export function oceanHeatContent(sstC,mixedLayerDepthM,gradientCPerM) {
    const excess=Math.max(0,sstC-OCEAN_MODEL.heatReferenceC);
    return HEAT_UNITS*(excess*mixedLayerDepthM+excess**2/(2*gradientCPerM));
}
export function sampleOceanBackground(lat,lon,month,globalTempK=289,heatDistribution=50,elapsedHours=0) {
    const surface=surfaceBackground(lat,lon,month,globalTempK,elapsedHours);
    const control=clamp(Number.isFinite(heatDistribution)?heatDistribution:50,0,100)/100;
    const depthScale=OCEAN_MODEL.minimumDepthScale
        +(OCEAN_MODEL.maximumDepthScale-OCEAN_MODEL.minimumDepthScale)*control;
    const reservoirM=surface.depthM+surface.variability.reservoirM;
    // Winter mixing deepens MLD even where SST is too cold for any TCHP.
    // Eddy/current depth is independent of their modest surface anomaly.
    const winterMixingM=38*smooth((Math.abs(surface.lat)-12)/45)*smooth(-surface.season);
    const mixedLayerDepthM=clamp(28+0.4*reservoirM+winterMixingM+surface.variability.mixedLayerM,14,110)*depthScale;
    const stratification=0.065*Math.exp(-reservoirM/65
        +surface.variability.stratificationLog)/depthScale;
    const gradient=clamp(stratification,0.018/depthScale,0.14/depthScale);
    const d26M=surface.sstC>26?mixedLayerDepthM+(surface.sstC-26)/gradient:0;
    return {sstC:surface.sstC,backgroundSstC:surface.sstC,mixedLayerDepthM,
        backgroundMixedLayerDepthM:mixedLayerDepthM,thermoclineGradientCPerM:gradient,
        d26M,ohcKJcm2:oceanHeatContent(surface.sstC,mixedLayerDepthM,gradient),coolingC:0};
}
// Energy per area divided by water density (m³/s²). Exact potential-energy
// cost for mixing an isothermal MLD over a linear thermocline.
export function mixingEnergyForDepth(profile,depthM) {
    const h=profile.backgroundMixedLayerDepthM, x=Math.max(0,depthM-h);
    return OCEAN_MODEL.gravityMs2*OCEAN_MODEL.thermalExpansionK
        *profile.thermoclineGradientCPerM*x*x*(3*h+x)/12;
}
export function mixOceanColumn(profile,energy=0,surfaceCoolingC=0) {
    const h=profile.backgroundMixedLayerDepthM, gradient=profile.thermoclineGradientCPerM;
    // Idealized thermocline ends at 2°C, never fictional sub-zero deep water.
    let low=h, high=h+Math.max(0,profile.backgroundSstC-2)/gradient;
    const work=Math.max(0,Number.isFinite(energy)?energy:0);
    if(work>0) for(let i=0;i<12;i++) {
        const mid=(low+high)/2;
        if(mixingEnergyForDepth(profile,mid)>work) high=mid; else low=mid;
    }
    const depth=work>0?(low+high)/2:h;
    // Conservative entrainment: all heat in the mixed column is retained.
    const surface=profile.backgroundSstC-gradient*(depth-h)**2/(2*depth)-Math.max(0,surfaceCoolingC);
    const excess=Math.max(0,surface-26);
    const remainingBelow=Math.max(0,profile.backgroundSstC-26-gradient*(depth-h));
    return {...profile,sstC:surface,mixedLayerDepthM:depth,
        d26M:surface>26?Math.max(depth,profile.d26M):0,
        ohcKJcm2:HEAT_UNITS*(excess*depth+remainingBelow**2/(2*gradient)),
        coolingC:profile.backgroundSstC-surface};
}
const WAKE_BUCKET_DEG=4;
const WAKE_WORK_VERSION=2; // Independent wind-work increments, not accumulated peaks.
const wakeIndexes=new WeakMap();
const wakeTimeWeights=new WeakMap();
function validWakePatch(patch) {
    return patch && [patch.lat,patch.lon,patch.radiusKm,patch.energy,patch.age].every(Number.isFinite)
        && patch.radiusKm>0 && patch.energy>=0;
}
function wakeIndex(patches) {
    let index=wakeIndexes.get(patches); if(index) return index;
    index=new Map();
    for(const p of patches) {
        if(!validWakePatch(p)) continue;
        const dy=p.radiusKm/EARTH_KM/RAD;
        const dx=Math.min(180,dy/Math.max(0.03,Math.cos((Math.abs(p.lat)+dy)*RAD)));
        for(let y=Math.floor((p.lat-dy+90)/WAKE_BUCKET_DEG);y<=Math.floor((p.lat+dy+90)/WAKE_BUCKET_DEG);y++) {
            for(let x=Math.floor((p.lon-dx+180)/WAKE_BUCKET_DEG);x<=Math.floor((p.lon+dx+180)/WAKE_BUCKET_DEG);x++) {
                const key=`${((x%90)+90)%90}:${y}`;
                if(!index.has(key)) index.set(key,[]);
                index.get(key).push(p);
            }
        }
    }
    wakeIndexes.set(patches,index); return index;
}
function wakeEnergiesAtAge(patches,age) {
    const cached=wakeTimeWeights.get(patches);
    if(cached?.age===age) return cached.energies;
    const energies=new Map();
    for(const p of patches) {
        if(!validWakePatch(p)||age<p.age) continue;
        const elapsed=age-p.age;
        const recovery=Math.exp(-elapsed/OCEAN_MODEL.wakeRecoveryHours);
        let response=1;
        if(p.workVersion===WAKE_WORK_VERSION && Number.isFinite(p.responseHours)
            && p.responseHours>0 && Number.isFinite(p.forcingHours) && p.forcingHours>0) {
            // Integrate the first-order response 1-exp(-t/tau) across the
            // whole forcing step, weighted by the same slow recovery as the
            // deposited work. This also avoids a timestep-sized dead period.
            const recoveryRate=1/OCEAN_MODEL.wakeRecoveryHours;
            const combinedRate=recoveryRate+1/p.responseHours;
            const ratio=(-Math.expm1(-p.forcingHours*combinedRate)/combinedRate)
                /(-Math.expm1(-p.forcingHours*recoveryRate)/recoveryRate);
            response=clamp(1-ratio*Math.exp(-elapsed/p.responseHours),0,1);
        }
        energies.set(p,p.energy*recovery*response);
    }
    // Time weights are computed once per field/time, not for every map
    // pixel. Old samplers retain their own immutable weight map.
    wakeTimeWeights.set(patches,{age,energies});
    return energies;
}
function wakeEnergyAt(lat,lon,index,energies) {
    const key=`${Math.floor((wrap(lon)+180)/WAKE_BUCKET_DEG)}:${Math.floor((lat+90)/WAKE_BUCKET_DEG)}`;
    let legacyEnvelope=0, incrementalWork=0;
    for(const p of index.get(key)||[]) {
        const north=(lat-p.lat)*RAD*EARTH_KM;
        const east=wrap(lon-p.lon)*RAD*EARTH_KM*Math.cos((lat+p.lat)*0.5*RAD);
        const q=(north*north+east*east)/(p.radiusKm*p.radiusKm);
        if(q>=1) continue;
        const energy=(energies.get(p)||0)*(1-q)**2;
        // Each new patch contains ONLY work deposited during its own step.
        // Sum that work at fixed geographic coordinates; never transport an
        // inherited center value into the next footprint. Pre-version-2
        // saves contain accumulated peaks: preserve their frozen envelope
        // once, rather than summing it repeatedly with itself.
        if(p.workVersion===WAKE_WORK_VERSION) incrementalWork+=energy;
        else legacyEnvelope=Math.max(legacyEnvelope,energy);
    }
    return legacyEnvelope+incrementalWork;
}
export function createOceanFieldSampler(month,globalTempK=289,heatDistribution=50,storm=null) {
    const patches=Array.isArray(storm?.oceanWake)?storm.oceanWake:[];
    const index=wakeIndex(patches), age=Number.isFinite(storm?.age)?storm.age:0;
    const energies=wakeEnergiesAtAge(patches,age);
    return (lat,lon)=>{
        const background=sampleOceanBackground(lat,lon,month,globalTempK,heatDistribution,age);
        const energy=wakeEnergyAt(lat,lon,index,energies); let surgeCooling=0;
        if(storm?.coldSurgeCoolingEffect>0) {
            const dy=(lat-storm.lat)*RAD*EARTH_KM;
            const dx=wrap(lon-storm.lon)*RAD*EARTH_KM*Math.cos(lat*RAD);
            const radius=Math.max(60,storm.rmw||30)*2;
            surgeCooling=storm.coldSurgeCoolingEffect*Math.exp(-(dx*dx+dy*dy)/(2*radius**2));
        }
        return mixOceanColumn(background,energy,surgeCooling);
    };
}
/** Geographic, additive, copy-on-write wind-work field. Rendering
 * never advances it; forecast/history objects may safely share old patches.
 * Winds and motion are kt; RMW and wake radius are km.
 * sourcePosition is the previous step's center; SST is sampled at storm's
 * current center. Direct column callers may omit it for stationary forcing.
 * Call once per physical timestep.
 */
export function advanceStormOcean(storm,month,globalTempK=289,heatDistribution=50,hours=3,isLand=false,sourcePosition=null) {
    const age=Number.isFinite(storm.age)?storm.age:0;
    const retentionHours=-OCEAN_MODEL.wakeRecoveryHours*Math.log(OCEAN_MODEL.wakeRetentionFraction);
    // Drop invalid patches left by the former degree-array/scalar mismatch;
    // never mutate historical snapshots or fabricate their missing cooling.
    const patches=(Array.isArray(storm.oceanWake)?storm.oceanWake:[])
        .filter(p=>validWakePatch(p)&&age-p.age<=retentionHours);
    let nextWake=patches;
    // Limit each new disturbance to three times its source RMW, with no R34 or
    // minimum-radius override. With no valid RMW, preserve
    // and recover the existing field but do not invent a new footprint.
    const radiusKm=Number.isFinite(storm.rmw)&&storm.rmw>0?OCEAN_MODEL.wakeRadiusRmwFactor*storm.rmw:0;
    const source=sourcePosition||storm;
    if(!isLand && hours>0 && storm.intensity>0 && radiusKm>0
        && Number.isFinite(source.lon) && Number.isFinite(source.lat)) {
        const speedMs=Math.max(0,storm.speed||0)*KNOT_MS;
        const seconds=Math.min(hours*3600,speedMs>0?2*radiusKm*1000/speedMs:Infinity);
        const windMs=storm.intensity*KNOT_MS*OCEAN_MODEL.footprintWindFraction;
        const drag=0.001*clamp(1.1+0.035*windMs,1.1,2.4);
        const friction=Math.sqrt(OCEAN_MODEL.airDensityKgM3/OCEAN_MODEL.densityKgM3*drag)*windMs;
        const decayStep=hours/OCEAN_MODEL.wakeRecoveryHours;
        const work=OCEAN_MODEL.windWorkCoefficient*friction**3*seconds
            *(-Math.expm1(-decayStep)/decayStep);
        nextWake=[...patches,{lon:wrap(source.lon),lat:source.lat,radiusKm,age,
            energy:work,workVersion:WAKE_WORK_VERSION,
            forcingHours:hours,responseHours:OCEAN_MODEL.wakeResponseHours}];
    }
    const ocean=createOceanFieldSampler(month,globalTempK,heatDistribution,{...storm,oceanWake:nextWake})(storm.lat,storm.lon);
    return {oceanWake:nextWake,ocean};
}
export function oceanThermodynamicMpi(sstC,isSubtropical=false) {
    // Existing empirical curve at its former neutral heat setting (50).
    // Reservoir size now acts ONLY through effective SST, never a MPI boost.
    // Still a game proxy, not an Emanuel potential-intensity solver.
    const effective=sstC+(isSubtropical?2:0);
    const mpi=effective>25?264.28*(1-Math.exp(-0.182*(effective-25))):0;
    return isSubtropical?Math.min(90,mpi):mpi;
}
