// Coordinates come from the existing ICWC map-city catalogue, not a second list.
const chineseNames = {
    SAIPAN:'塞班岛', MANILA:'马尼拉', TAIPEI:'台北', 'HONG KONG':'香港', YAP:'雅浦岛',
    MIYAKOJIMA:'宫古岛', 'WAKE ISLAND':'威克岛', SHANTOU:'汕头', BASCO:'巴士古',
    SHANGHAI:'上海', SEOUL:'首尔', TOKYO:'东京', 'HO CHI MINH':'胡志明市', NAHA:'那霸',
    GUAM:'关岛', 'IWO TO':'硫磺岛', DHAKA:'达卡', HONOLULU:'檀香山',
    'LOS ANGELES':'洛杉矶', HAVANA:'哈瓦那', 'NEW YORK':'纽约', HOUSTON:'休斯敦',
    'SAN FRANCISCO':'旧金山', BRISBANE:'布里斯班', DARWIN:'达尔文', CAIRNS:'凯恩斯'
};
const words = {
    EN:{choose:'Select a city / region', list:'City / region list', custom:'Custom',
        location:'City / region', name:'Site callsign', lon:'Longitude', lat:'Latitude',
        mode:'Observation Post location'},
    CN:{choose:'选择城市 / 地区', list:'列表选择', custom:'自定义',
        location:'城市 / 地区', name:'站点呼号', lon:'经度', lat:'纬度', mode:'观测站位置选择'}
};
const numeric = value => value.trim()==='' ? null : Number.isFinite(Number(value)) ? Number(value) : null;

export function mountObservationSiteSelector({root,cities,storage=localStorage,onChange,language=()=> 'EN'}) {
    const radios = [...root.querySelectorAll('input[name="siteSelectionMode"]')];
    const select = root.querySelector('#siteCitySelect');
    const listPanel = root.querySelector('#siteCityFields');
    const customPanel = root.querySelector('#siteCustomFields');
    const coordinates = root.querySelector('#siteCityCoordinates');
    const inputs = {
        name:root.querySelector('#siteNameInput'), lon:root.querySelector('#siteLonInput'),
        lat:root.querySelector('#siteLatInput')
    };
    const read = () => Object.fromEntries(Object.entries(inputs).map(([key,input])=>[key,input.value]));
    const get = key => {try{return storage.getItem(key);}catch{return null;}};
    const put = (key,value) => {try{storage.setItem(key,value);}catch{/* Selection still works without storage. */}};
    const lang = () => language()==='CN' ? 'CN' : 'EN';
    const names = city => ({EN:city.name,CN:chineseNames[city.name]||city.name});
    let mode = get('tcs_site_mode')==='custom' ? 'custom'
        : get('tcs_site_mode')==='list' ? 'list'
        : Object.values(read()).some(Boolean) ? 'custom' : 'list';
    let cityId = get('tcs_site_city') || '';
    if(!cities.some(city=>city.name===cityId)) cityId='';
    let draft = read(), locked = false;
    try {
        const saved = JSON.parse(get('tcs_site_custom_v1'));
        if(saved && ['name','lon','lat'].every(key=>typeof saved[key]==='string')) draft=saved;
    } catch {/* Legacy coordinates are the initial custom draft. */}
    const city = () => mode==='list' ? cities.find(value=>value.name===cityId) : null;
    function apply(values) {
        for(const [key,input] of Object.entries(inputs)) input.value=values[key];
        put('tcs_site_name',values.name);put('tcs_site_lon',values.lon);put('tcs_site_lat',values.lat);
        onChange({name:values.name,lon:numeric(values.lon),lat:numeric(values.lat)});
    }
    function commit() {
        const chosen=city();
        apply(mode==='custom' ? draft : chosen
            ? {name:names(chosen)[lang()],lon:String(chosen.lon),lat:String(chosen.lat)}
            : {name:'',lon:'',lat:''});
        put('tcs_site_mode',mode);put('tcs_site_city',cityId);
    }
    function render() {
        const text=words[lang()];
        for(const node of root.querySelectorAll('[data-site-copy]')) {
            node.textContent=text[node.dataset.siteCopy];
        }
        for(const [key,input] of Object.entries(inputs)) input.placeholder=text[key];
        select.replaceChildren();
        const placeholder=document.createElement('option');
        placeholder.value='';placeholder.textContent=text.choose;select.append(placeholder);
        for(const entry of [...cities].sort((a,b)=>names(a)[lang()].localeCompare(names(b)[lang()],lang()==='CN'?'zh-CN':'en'))) {
            const option=document.createElement('option');
            option.value=entry.name;option.textContent=names(entry)[lang()];select.append(option);
        }
        select.value=cityId;
        listPanel.hidden=mode!=='list';customPanel.hidden=mode!=='custom';
        for(const radio of radios) {
            radio.checked=radio.value===mode;radio.disabled=locked;
            radio.closest('label').classList.toggle('is-active',radio.checked);
        }
        select.disabled=locked;
        for(const input of Object.values(inputs)) input.disabled=locked;
        const chosen=city();
        coordinates.textContent=chosen ? `${Math.abs(chosen.lat).toFixed(2)}°${chosen.lat<0?'S':'N'} · ${Math.abs(chosen.lon).toFixed(2)}°${chosen.lon<0?'W':'E'}` : '';
    }
    for(const radio of radios) radio.addEventListener('change',()=>{
        if(locked || !radio.checked) return;
        if(mode==='custom') {draft=read();put('tcs_site_custom_v1',JSON.stringify(draft));}
        mode=radio.value;commit();render();
    });
    select.addEventListener('change',()=>{
        if(locked) return;
        cityId=select.value;commit();render();
    });
    for(const input of Object.values(inputs)) input.addEventListener('input',()=>{
        if(locked || mode!=='custom') return;
        draft=read();put('tcs_site_custom_v1',JSON.stringify(draft));commit();
    });
    const relocalize=()=>{render();if(city())commit();};
    window.addEventListener('uiLanguageChanged',relocalize);
    // Keep legacy/custom settings intact; a fresh list starts unselected.
    commit();render();
    return {
        setLocked(value){locked=Boolean(value);render();},
        focus(){(mode==='list'?select:inputs.lon).focus();},
        getCityNames(){const chosen=city();return chosen ? names(chosen) : undefined;},
        destroy(){window.removeEventListener('uiLanguageChanged',relocalize);}
    };
}
