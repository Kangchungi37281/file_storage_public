/**
 * terrain-data.js
 * 负责管理地形高程数据和陆地遮罩
 */
import { prepareTerrainRaster } from './terrain-raster-service.js';
import { buildCoastDistanceField as buildCoastDistanceRaster } from './coast-distance.js';

let elevationData = null; // 存储高程图像素数据 (RGBA)
let landMaskData = null;  // 存储陆地遮罩像素数据 (Alpha channel only is enough, but we use RGBA)
let coastDistanceData = null; // 到最近海岸像素的栅格距离
let mapWidth = 0;
let mapHeight = 0;

const MAX_ELEVATION_METERS = 680; // 保持现有地形标定
const elevationGeometryCache = new Map();

// 初始化地形系统
export function initTerrainSystem(imageUrl, worldData) {
    return new Promise((resolve, reject) => {
        // 1. 加载高程图
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.src = imageUrl;
        
        img.onload = async () => {
            try {
                const width = img.width, height = img.height;
            
                // --- A. 处理高程数据 ---
                const elevCanvas = document.createElement('canvas');
                elevCanvas.width = width;
                elevCanvas.height = height;
                const elevCtx = elevCanvas.getContext('2d');
                elevCtx.drawImage(img, 0, 0);
                const rawData = elevCtx.getImageData(0, 0, width, height).data;
                const nextElevation = new Uint8Array(width * height);
                for (let i = 0, j = 0; i < rawData.length; i += 4, j++) {
                    nextElevation[j] = rawData[i]; // 只取 Red 通道
                }
                let nextLandMask = null, nextCoastDistance = null;
                // --- B. 生成陆地遮罩 (Land Mask) ---
                // 使用 D3 将矢量地图绘制到内存 Canvas 上
                if (worldData) {
                    const raster = await prepareTerrainRaster(worldData, width, height);
                    if (raster) {
                        nextLandMask = raster.landMaskData;
                        nextCoastDistance = raster.coastDistanceData;
                    } else {
                        const maskCanvas = document.createElement('canvas');
                        maskCanvas.width = width;
                        maskCanvas.height = height;
                        const maskCtx = maskCanvas.getContext('2d');

                        // 设置投影以匹配图片 (Equirectangular)
                        const projection = d3.geoEquirectangular()
                            .scale(width / (2 * Math.PI))
                            .translate([width / 2, height / 2]);

                        const pathGenerator = d3.geoPath()
                            .projection(projection)
                            .context(maskCtx);

                        // 绘制背景（海洋 = 黑色）
                        maskCtx.fillStyle = '#000000';
                        maskCtx.fillRect(0, 0, width, height);

                        // 绘制陆地（陆地 = 白色）
                        maskCtx.fillStyle = '#FFFFFF';
                        maskCtx.beginPath();
                        pathGenerator(worldData);
                        maskCtx.fill();

                        // 获取遮罩数据
                        const raw = maskCtx.getImageData(0, 0, width, height).data;
                        nextLandMask = new Uint8Array(width * height);

                        for (let i = 0, j = 0; i < raw.length; i += 4, j++) {
                            nextLandMask[j] = raw[i];
                        }
                        nextCoastDistance = buildCoastDistanceRaster(nextLandMask, width, height);
                    }
                }

                // Publish one complete terrain snapshot after background work;
                // model and renderer must never observe a half-initialized raster.
                mapWidth = width; mapHeight = height;
                elevationData = nextElevation;
                landMaskData = nextLandMask;
                coastDistanceData = nextCoastDistance;
                elevationGeometryCache.clear();

                console.log(`Terrain System Initialized. Size: ${mapWidth}x${mapHeight}`);
                resolve();
            } catch (error) { reject(error); }
        };
        
        img.onerror = (e) => reject(e);
    });
}

// Wind-radius diagnostics can run in a module Worker, but the Worker does not
// share this module's raster state with the window.  Export one compact copy
// after initialization and transfer it once; subsequent diagnostic jobs only
// need cyclone and atmosphere snapshots.
export function createTerrainWorkerSnapshot() {
    if (!elevationData || !landMaskData || !mapWidth || !mapHeight) return null;
    return {
        width: mapWidth,
        height: mapHeight,
        elevationData: elevationData.slice(),
        landMaskData: landMaskData.slice(),
        coastDistanceData: coastDistanceData?.slice() || null
    };
}

export function restoreTerrainWorkerSnapshot(snapshot) {
    if (!snapshot || !Number.isFinite(snapshot.width) || !Number.isFinite(snapshot.height)) {
        return false;
    }
    mapWidth = snapshot.width;
    mapHeight = snapshot.height;
    elevationData = snapshot.elevationData || null;
    landMaskData = snapshot.landMaskData || null;
    coastDistanceData = snapshot.coastDistanceData || null;
    elevationGeometryCache.clear();
    return Boolean(elevationData && landMaskData && mapWidth && mapHeight);
}

// Build a geographic contour for visual terrain tinting.  The land mask is
// included in the scalar field so ocean pixels can never become "highland"
// merely because of colour noise in the source elevation texture.
export function getElevationThresholdGeometry(thresholdMeters = 200) {
    if (!elevationData || !landMaskData || !mapWidth || !mapHeight || typeof d3 === 'undefined') {
        return null;
    }
    const threshold = Math.max(0, Math.min(MAX_ELEVATION_METERS, thresholdMeters));
    if (elevationGeometryCache.has(threshold)) return elevationGeometryCache.get(threshold);

    const thresholdByte = threshold / MAX_ELEVATION_METERS * 255;
    const scalar = new Float32Array(elevationData.length);
    for (let i = 0; i < scalar.length; i++) {
        scalar[i] = landMaskData[i] > 128 ? elevationData[i] : 0;
    }
    const contour = d3.contours()
        .size([mapWidth, mapHeight])
        .smooth(true)
        .thresholds([thresholdByte])(scalar)[0];
    if (!contour) return null;

    const toGeoPoint = point => [
        point[0] / mapWidth * 360 - 180,
        90 - point[1] / mapHeight * 180
    ];
    const geometry = {
        type: 'MultiPolygon',
        coordinates: contour.coordinates.map(polygon =>
            // The Y-axis inversion changes planar contour winding. Reverse
            // every ring back to D3's spherical GeoJSON convention so the
            // highland itself is filled, not its global complement.
            polygon.map(ring => ring.map(toGeoPoint).reverse())
        )
    };
    elevationGeometryCache.set(threshold, geometry);
    return geometry;
}

// 内部辅助：经纬度转像素坐标
function getPixelCoords(lon, lat) {
    // 经度归一化 [-180, 180] -> [0, 360]
    let normLon = ((lon + 180) % 360 + 360) % 360 - 180;

    // 映射到像素
    // 假设图片是标准等距投影: -180在左边缘, +180在右边缘
    let x = Math.floor(((normLon + 180) / 360) * (mapWidth - 1));
    let y = Math.floor(((90 - lat) / 180) * (mapHeight - 1));

    // 边界钳制
    x = Math.max(0, Math.min(x, mapWidth - 1));
    y = Math.max(0, Math.min(y, mapHeight - 1));

    return { x, y };
}

// 获取海拔 (米)
export function getElevationAt(lon, lat) {
    if (!elevationData) return 0;
    const { x, y } = getPixelCoords(lon, lat);
    const index = y * mapWidth + x;
    const brightness = elevationData[index]; // Read Red channel
    
    // 如果亮度很低，直接返回0
    if (brightness < 5) return 0;
    return (brightness / 255) * MAX_ELEVATION_METERS;
}

// Single raster lookup shared by the hot-path terrain consumers. The
// coast-distance value is intentionally approximate: it is a gate for the
// expensive vector fallback, not a replacement for exact coastline geometry.
export function queryTerrain(lon, lat, nearThresholdDeg = 0.2) {
    if (!landMaskData || !mapWidth || !mapHeight) {
        return {
            isLand: false,
            isNearLand: false,
            elevation: 0,
            coastDistancePixels: null,
            coastDistanceDeg: Infinity,
            rasterAvailable: false
        };
    }

    const { x, y } = getPixelCoords(lon, lat);
    const index = y * mapWidth + x;
    const isLand = landMaskData[index] > 128;
    const pixelsPerDegree = Math.max(mapWidth / 360, mapHeight / 180);
    const radiusPixels = Math.max(1, Math.ceil(nearThresholdDeg * pixelsPerDegree));
    const coastDistancePixels = coastDistanceData
        ? coastDistanceData[index]
        : null;
    const isNearLand = isLand || (coastDistancePixels !== null
        ? coastDistancePixels <= radiusPixels
        : false);
    const brightness = elevationData?.[index] || 0;

    return {
        isLand,
        isNearLand,
        elevation: brightness < 5 ? 0 : (brightness / 255) * MAX_ELEVATION_METERS,
        coastDistancePixels,
        coastDistanceDeg: coastDistancePixels === null
            ? Infinity : coastDistancePixels / pixelsPerDegree,
        rasterAvailable: true
    };
}

// 获取陆地状态 (包含 isLand 和 isNearLand)
// nearThresholdDeg: 近岸判定阈值，单位度。默认 0.2 度
export function getLandStatus(lon, lat, nearThresholdDeg = 0.2) {
    const terrain = queryTerrain(lon, lat, nearThresholdDeg);
    if (!terrain.rasterAvailable || terrain.coastDistancePixels !== null) {
        return { isLand: terrain.isLand, isNearLand: terrain.isNearLand };
    }

    // Compatibility fallback for partially initialized terrain systems that
    // have a mask but no distance field yet.
    const { x: cx, y: cy } = getPixelCoords(lon, lat);
    const pixelsPerDegree = mapWidth / 360;
    const radius = Math.max(1, Math.ceil(nearThresholdDeg * pixelsPerDegree));
    let isNearLand = terrain.isLand;
    if (!terrain.isLand) {
        searchLoop:
        for (let dy = -radius; dy <= radius; dy++) {
            for (let dx = -radius; dx <= radius; dx++) {
                if (dx === 0 && dy === 0) continue;
                let nx = cx + dx;
                let ny = cy + dy;
                if (nx < 0) nx += mapWidth;
                if (nx >= mapWidth) nx -= mapWidth;
                if (ny < 0 || ny >= mapHeight) continue;
                if (landMaskData[ny * mapWidth + nx] > 128) {
                    isNearLand = true;
                    break searchLoop;
                }
            }
        }
    }
    return { isLand: terrain.isLand, isNearLand };
}
