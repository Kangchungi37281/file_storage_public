/** One-member 72h forecast using the live model's physical state step.
 * Private atmosphere, ocean and RNG; no diagnostic wind-radius/phase solve.
 */
import { updateCycloneState, updatePressureSystems, updateFrontalZone,
    createGeopotentialHeight500Sampler } from './cyclone-model.js?v=20261008-forecast-categories1';
import { FORECAST_STEP_HOURS, FORECAST_HORIZONS, FORECAST_MIN_WIND_KT, completedForecastHours } from './forecast-horizon.js';

function createSeededForecastRandom(seed) {
    let state = seed >>> 0;
    return () => {
        state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
        return state / 4294967296;
    };
}

function forecastPoint(storm) {
    // First five fields are the established public tuple. Append structural
    // fields so consumers need not freeze size/subtropical identity at issue.
    const dissipated = storm.status === 'dissipated';
    return [storm.lon, storm.lat, Math.max(FORECAST_MIN_WIND_KT, dissipated ? FORECAST_MIN_WIND_KT : storm.intensity), Boolean(storm.isTransitioning),
        Boolean(storm.isExtratropical), storm.circulationSize, Boolean(storm.isSubtropical), dissipated];
}

function* forecastSteps(cyclone, pressureSystems, checkLandFunc = null,
    globalTemp = 289, globalShearSetting = 100, randomSeed = null, options = {}) {
    if (cyclone.isExtratropical) return [];
    const random = createSeededForecastRandom(Number.isFinite(randomSeed)
        ? randomSeed : Math.round(cyclone.age || 0) + 1);
    const forecasts = [];
    const models = [{ name: 'ENAI', bias: { u: .5, v: .6 } }];
    const PATH_STEP_HOURS = FORECAST_STEP_HOURS;
    const TOTAL_HOURS = 72;
    const TOTAL_STEPS = TOTAL_HOURS / PATH_STEP_HOURS;
    const inputsOwnedByCaller = options?.inputsOwned === true;
    const profile = options?.profile === true;
    const profileStartedAt = profile ? performance.now() : 0;
    // Physics includes steering, ocean, ET, intensity and structural evolution.
    // It is timed once, not misreported as the old cheap intensity-only solve.
    const profileTotals = profile ? { atmosphere: 0, physics: 0, compute: 0,
        steps: 0, intensitySteps: 0 } : null;
    for (const model of models) {
        const { track: history, forecastLogs, pathForecasts, satelliteCache, ...state } = cyclone;
        let tempCyclone = inputsOwnedByCaller ? { ...state } : structuredClone(state);
        const tempPressureSystems = inputsOwnedByCaller
            ? pressureSystems : structuredClone(pressureSystems);
        tempCyclone.age = Number.isFinite(tempCyclone.age) ? tempCyclone.age : 0;
        tempCyclone.ace = Number.isFinite(tempCyclone.ace) ? tempCyclone.ace : 0;
        tempCyclone.status ||= 'active';
        const month = cyclone.currentMonth || 8;
        const track = [forecastPoint(tempCyclone)];
        let termination = null;
        for (let t = 1; t <= TOTAL_STEPS; t++) {
            const stepStartedAt = profile ? performance.now() : 0;
            updatePressureSystems(tempPressureSystems, month);
            const frontalZone = updateFrontalZone(tempPressureSystems, month);
            if (profile) profileTotals.atmosphere += performance.now() - stepStartedAt;
            // These evaluators belong to THIS immutable 3h atmosphere. Keeping
            // them outside this loop froze compiled ridge/wave geometry even
            // while the underlying pressure-system objects advanced.
            const heightSamplers = Object.fromEntries([850, 500, 200].map(level =>
                [level, createGeopotentialHeight500Sampler(tempPressureSystems, level)]));
            const physicsStartedAt = profile ? performance.now() : 0;
            const midpoint = options?.midpoint === true
                || (options?.midpoint !== false && t % 2 === 0);
            tempCyclone = updateCycloneState(tempCyclone, tempPressureSystems,
                frontalZone, null, month, globalTemp, globalShearSetting,
                cyclone.oceanHeatDistribution ?? 50, 0, {
                    forecast: true, random, checkLandFunc, deferWindRadii: true,
                    steeringBias: model.bias, steeringOptions: { heightSamplers, midpoint }
                });
            track.push(forecastPoint(tempCyclone));
            if (profile) {
                profileTotals.physics += performance.now() - physicsStartedAt;
                profileTotals.compute += performance.now() - stepStartedAt;
                profileTotals.steps++;
                profileTotals.intensitySteps++;
            }
            // Preserve the FIRST physical termination, but finish at least
            // one complete 12h interval. After termination the coordinates
            // describe the residual circulation, not a surviving TC; tuples
            // carry the requested 15kt floor plus an explicit dissipated flag.
            if (!termination && tempCyclone.status === 'dissipated') {
                termination = { leadHours: t * PATH_STEP_HOURS,
                    reason: tempCyclone.terminationReason || 'model-dissipation' };
            }
            yield;
            if (termination && t * PATH_STEP_HOURS >= FORECAST_HORIZONS[0]) {
                const hours = completedForecastHours(t * PATH_STEP_HOURS);
                track.length = hours / PATH_STEP_HOURS + 1;
                break;
            }
        }
        forecasts.push({ name: model.name, track, horizonHours: (track.length - 1) * PATH_STEP_HOURS,
            ...(termination ? { termination } : {}) });
    }
    if (profile) {
        options.onProfile?.({ total: Math.round((performance.now() - profileStartedAt) * 10) / 10,
            ...Object.fromEntries(Object.entries(profileTotals)
                .map(([key, value]) => [key, Math.round(value * 10) / 10])) });
    }
    return forecasts;
}

export function generatePathForecasts(...args) {
    const iterator = forecastSteps(...args);
    let step;
    do { step = iterator.next(); } while (!step.done);
    return step.value;
}

export async function generatePathForecastsAsync(...args) {
    const iterator = forecastSteps(...args);
    let step = iterator.next();
    while (!step.done) {
        // Allow live atmosphere/radii messages between physical substeps.
        await new Promise(resolve => setTimeout(resolve, 0));
        step = iterator.next();
    }
    return step.value;
}
