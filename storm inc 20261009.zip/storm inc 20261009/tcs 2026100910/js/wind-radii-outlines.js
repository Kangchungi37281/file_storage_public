// Shared warning-map and legend outlines; deliberately no area fill.
export const WARNING_WIND_RADII = Object.freeze([
    {kt:34,color:'#ff5a36',width:1.5},
    {kt:50,color:'#991b1b',width:2},
    {kt:64,color:'#d946ef',width:2.5}
]);
// Use the same saved/fallback radii for rendering and fitting the camera.
// Track radii are latitude degrees, ordered NE, SE, SW, NW.
export function getWarningWindBands(cyclone, currentPoint) {
    const intensity = currentPoint[2];
    const size = currentPoint[5] || cyclone.circulationSize || 200;
    return WARNING_WIND_RADII.filter(cfg => intensity >= cfg.kt).map((cfg, index) => {
        const saved = currentPoint[7 + index];
        const fallback = (size / 80) * Math.pow(intensity / cfg.kt, 0.6);
        const radii = Array.from({length:4}, (_, q) => {
            const radius = Array.isArray(saved) ? saved[q]
                : typeof saved === 'number' ? saved : fallback;
            return Number.isFinite(radius) ? Math.max(0, radius) : 0;
        });
        return {...cfg, radii};
    });
}
export function drawWindRadiiOutlines(ctx, bands) {
    const visible = bands.filter(band => band.path).slice().sort((a,b)=>a.kt-b.kt);
    ctx.save();ctx.setLineDash([]);
    for(const band of visible) {
        ctx.strokeStyle=band.color;ctx.lineWidth=band.width;
        ctx.stroke(band.path);
    }
    ctx.restore();
}
