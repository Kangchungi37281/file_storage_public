import { DISPLAY_FEATURES } from './display-features.js?v=20260922-shear1';
import { createEnvironmentalShearSampler } from './cyclone-model.js?v=20261008-forecast-categories1';

export const SHEAR_COLORS = ['#334155', '#22c55e', '#eab308', '#f97316', '#ef4444', '#a855f7'];
export const SHEAR_THRESHOLDS = [0, 10, 20, 30, 40, 60];
const requests = new WeakMap();

export function clearShearField(container) {
    const node = container.node();
    if (node) requests.delete(node);
    container.selectAll('*').remove();
}

// Render only a complete, current snapshot. Slice the new optional layer's
// sampling so enabling it does not introduce one large main-thread task.
export async function drawShearField(container, projection, systems, globalShearSetting = 100) {
    if (!DISPLAY_FEATURES.shear) { clearShearField(container); return; }
    const node = container.node();
    const { width, height } = node.closest('svg').getBoundingClientRect();
    if (!(width > 0 && height > 0)) return;
    const request = {};
    requests.set(node, request);
    const current = () => requests.get(node) === request && node.isConnected;
    const nx = 40, ny = Math.max(2, Math.round(nx * height / width));
    // Capture screen/geo geometry before yielding; D3 projections are mutable
    // and do not have copy(). Panning cannot mix two projections in one frame.
    const points = Array.from({ length: nx * ny }, (_, index) => {
        const i = index % nx, j = Math.floor(index / nx);
        const x = i * width / nx, y = j * height / ny;
        const coords = projection.invert([x, y]);
        const valid = coords && coords.every(Number.isFinite) && Math.abs(coords[1]) <= 90;
        let east = null, north = null;
        if (valid && i % 4 === 2 && j % 4 === 2) {
            const scale = Math.max(.087, Math.cos(coords[1] * Math.PI / 180));
            east = projection([coords[0] + .01 / scale, coords[1]]);
            north = projection([coords[0], coords[1] + .01]);
        }
        return { x, y, coords: valid ? coords : null, east, north };
    });
    const sample = createEnvironmentalShearSampler(structuredClone(systems), globalShearSetting);
    const grid = [], arrows = [];
    let sliceStart = performance.now();
    for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
            const { x, y, coords, east, north } = points[j * nx + i];
            const vec = coords ? sample(coords[0], coords[1]) : null;
            grid.push(vec && Number.isFinite(vec.magnitude) ? vec.magnitude : NaN);
            if (vec && vec.magnitude > 0 && Number.isFinite(vec.magnitude)
                && i % 4 === 2 && j % 4 === 2) {
                // Project the vector into the map rather than assuming north
                // is always up. This also handles rotated map projections.
                if (east && north && [...east, ...north].every(Number.isFinite)) {
                    const dx = (east[0] - x) * vec.u + (north[0] - x) * vec.v;
                    const dy = (east[1] - y) * vec.u + (north[1] - y) * vec.v;
                    arrows.push({ id: j * nx + i, x, y, angle: Math.atan2(dy, dx) * 180 / Math.PI });
                }
            }
            if (performance.now() - sliceStart >= 8) {
                await new Promise(resolve => setTimeout(resolve, 0));
                if (!current()) return;
                sliceStart = performance.now();
            }
        }
    }
    if (!current()) return;
    const contours = d3.contours().size([nx, ny]).thresholds(SHEAR_THRESHOLDS)(grid);
    const transform = d3.geoTransform({ point(x, y) {
        this.stream.point(x * width / nx, y * height / ny);
    }});
    const path = d3.geoPath().projection(transform);
    container.attr('pointer-events', 'none');
    container.selectAll('path.shear-band').data(contours, d => d.value).join('path')
        .attr('class', 'shear-band').attr('d', path)
        .attr('fill', (_, i) => SHEAR_COLORS[i]).attr('fill-opacity', .22);
    // Keep arrow nodes alive across field updates so CSS motion does not restart
    // every simulation step. Motion is a direction cue, not parcel advection or
    // a second speed scale; colour remains the quantitative magnitude encoding.
    container.selectAll('g.shear-vector').data(arrows, d => d.id).join(enter => {
        const group = enter.append('g').attr('class', 'shear-vector');
        group.append('path').attr('class', 'shear-arrow')
            .attr('d', 'M-8,0H6M2,-3L6,0L2,3')
            .style('animation-delay', d => `${-((d.id * 0.61803398875) % 1) * 2.4}s`)
            .attr('fill', 'none').attr('stroke', '#f8fafc')
            .attr('stroke-width', 1.2).attr('stroke-linecap', 'round');
        return group;
    })
        .attr('transform', d => `translate(${d.x},${d.y}) rotate(${d.angle})`)
        .raise();
}
