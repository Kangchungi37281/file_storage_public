// Diagnostic, deterministic forecast scenarios; not an operationally
// calibrated probability model. Arrival is the conditional median FIRST
// threshold-wind encounter, never the time of maximum wind/probability.
import { simulationDate } from './simulation-time.js?v=20261008-forecast-categories1';
export const PROBABILITY_LEVELS = [5,10,20,30,40,50,60,70,80,90];
export const PROBABILITY_COLORS = ['#26934c','#27bf49','#73d94c','#c5db4d','#c6c44f',
    '#ab9148','#c38a48','#a74050','#7f3e51','#803e9d'];
const wrap = x => ((x+180)%360+360)%360-180;
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const valid = p => Array.isArray(p) && p.length>=3 && p.slice(0,3).every(Number.isFinite);
const KM_PER_DEGREE = 111.32;
const MODEL = {members:64, positionErrorKmPerHour:5.5, intensityErrorKtPerHour:.25};

export function probabilityIssue(cyclone,timeIndex) {
    if (!cyclone?.track?.length) return null;
    const selected = Number.isInteger(timeIndex) && timeIndex>=0 && timeIndex<cyclone.track.length
        ? timeIndex : cyclone.track.length-1;
    const index = Math.floor(selected/2)*2, age=index*3, point=cyclone.track[index];
    if (!valid(point)) return null;
    // Never silently substitute today's forecast into an archived product.
    const latestAge=Math.floor((cyclone.track.length-1)*3/6)*6;
    const forecasts=cyclone.forecastLogs?.[age]
        || (age===latestAge ? cyclone.pathForecasts : null);
    const tracks=(forecasts || []).map(f=>f.track).filter(t=>t?.length && t.every(valid));
    const hours=Math.min(72,Math.max(0,...tracks.map(t=>(t.length-1)*3)));
    const date=simulationDate(cyclone,age);
    return {point,index,age,tracks,hours,date};
}

export function probabilityTimeLabel(date,hours=0) {
    const d=new Date(date.getTime()+hours*3600000);
    const months=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
    return `${String(d.getUTCDate()).padStart(2,'0')} ${months[d.getUTCMonth()]} ${String(d.getUTCHours()).padStart(2,'0')}Z`;
}

function halton(n,base) { let f=1,v=0; while(n>0) {f/=base;v+=f*(n%base);n=Math.floor(n/base);} return v; }
function normal(n,a,b) {return Math.sqrt(-2*Math.log(Math.max(1e-9,halton(n,a))))*Math.cos(2*Math.PI*halton(n,b));}

// A compact spatial kernel removes finite-ensemble/grid aliasing. Apply it
// to the SAME first-encounter histogram for both probability and arrival,
// rather than smoothing time across missing/no-risk cells independently.
async function smoothEncounters(histogram,nx,ny,bins,yieldWork) {
    const n=nx*ny,result=new Float32Array(histogram.length),horizontal=new Float32Array(n);
    const weights=[1,4,6,4,1],norm=16;
    for(let h=0;h<bins;h++) {
        for(let y=0;y<ny;y++) for(let x=0;x<nx;x++) {
            let sum=0;
            for(let k=-2;k<=2;k++) if(x+k>=0&&x+k<nx) sum+=histogram[(y*nx+x+k)*bins+h]*weights[k+2];
            horizontal[y*nx+x]=sum/norm;
        }
        for(let y=0;y<ny;y++) for(let x=0;x<nx;x++) {
            let sum=0;
            for(let k=-2;k<=2;k++) if(y+k>=0&&y+k<ny) sum+=horizontal[(y+k)*nx+x]*weights[k+2];
            result[(y*nx+x)*bins+h]=sum/norm;
        }
        if(h%8===7) await yieldWork();
    }
    return result;
}

function radiusKm(issue,intensity,threshold,quadrant) {
    if(intensity<threshold) return 0;
    const radii=issue.point[threshold===64?9:7];
    if(Array.isArray(radii) && radii.length===4 && radii.every(v=>Number.isFinite(v)&&v>=0)
        && issue.point[2]>=threshold) {
        return radii[quadrant]*KM_PER_DEGREE*clamp(intensity/Math.max(1,issue.point[2]),.5,1.5);
    }
    // Existing product's approximate radius law, only if archived radii are
    // unavailable or winds strengthen through this threshold after issue.
    return (.5+Math.max(0,intensity-threshold)*.015)*KM_PER_DEGREE;
}

export function probabilityScenarios(issue,threshold) {
    if(![34,64].includes(threshold)) throw new Error('Unsupported wind threshold');
    if(!issue?.tracks?.length) return [];
    return Array.from({length:MODEL.members},(_,m)=>{
        const track=issue.tracks[m%issue.tracks.length], samples=[];
        const east=normal(m+1,2,3),north=normal(m+1,5,7),wind=normal(m+1,11,13);
        for(let h=0;h<=Math.min(issue.hours,(track.length-1)*3);h++) {
            const k=Math.min(Math.floor(h/3),track.length-1),a=track[k],b=track[Math.min(k+1,track.length-1)],t=h/3-k;
            const intensity=h===0?issue.point[2]:a[7]===true?0
                :a[2]+(b[2]-a[2])*t+wind*h*MODEL.intensityErrorKtPerHour;
            const lat=h===0?issue.point[1]:a[1]+(b[1]-a[1])*t;
            const lon=h===0?issue.point[0]:issue.point[0]+wrap(a[0]-issue.point[0])+wrap(b[0]-a[0])*t;
            const error=h*MODEL.positionErrorKmPerHour;
            samples.push({h,lat:clamp(lat+north*error/KM_PER_DEGREE,-85,85),
                lon:lon+east*error/(KM_PER_DEGREE*Math.max(.15,Math.cos(lat*Math.PI/180))),
                radii:Array.from({length:4},(_,q)=>radiusKm(issue,intensity,threshold,q))});
        }
        return samples;
    });
}

export async function buildWindProbability(issue,threshold,{nx=240,ny=154,yieldWork=()=>new Promise(r=>setTimeout(r,0))}={}) {
    const scenarios=probabilityScenarios(issue,threshold);
    if(!scenarios.length) return null;
    let west=issue.point[0]-3,east=issue.point[0]+3,south=issue.point[1]-3,north=issue.point[1]+3;
    for(const samples of scenarios) for(const p of samples) {
        if(!p.radii.some(r=>r>0)) continue;
        const r=Math.max(...p.radii)/KM_PER_DEGREE,dx=r/Math.max(.15,Math.cos(p.lat*Math.PI/180));
        west=Math.min(west,p.lon-dx);east=Math.max(east,p.lon+dx);south=Math.min(south,p.lat-r);north=Math.max(north,p.lat+r);
    }
    const pad=1.2; west-=pad;east+=pad;south-=pad;north+=pad;
    // Fit the chart's plot aspect in geographic coordinates, not a fixed zoom
    // around the initial fix that clips long/turning forecast swaths.
    const aspect=nx/ny;
    if((east-west)/(north-south)<aspect) {const extra=((north-south)*aspect-(east-west))/2;west-=extra;east+=extra;}
    else {const extra=((east-west)/aspect-(north-south))/2;south-=extra;north+=extra;}
    const dx=(east-west)/nx,dy=(north-south)/ny,n=nx*ny,bins=issue.hours+1;
    const histogram=new Uint8Array(n*bins);
    for(let member=0;member<scenarios.length;member++) {
        const seen=new Uint8Array(n);
        for(const p of scenarios[member]) {
            const radius=Math.max(...p.radii); if(radius<=0) continue;
            const cos=Math.max(.15,Math.cos(p.lat*Math.PI/180));
            const rx=radius/KM_PER_DEGREE/cos,ry=radius/KM_PER_DEGREE;
            const x0=clamp(Math.floor((p.lon-rx-west)/dx),0,nx-1),x1=clamp(Math.ceil((p.lon+rx-west)/dx),0,nx-1);
            const y0=clamp(Math.floor((north-p.lat-ry)/dy),0,ny-1),y1=clamp(Math.ceil((north-p.lat+ry)/dy),0,ny-1);
            for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++) {
                const i=y*nx+x; if(seen[i]) continue;
                const e=(west+(x+.5)*dx-p.lon)*KM_PER_DEGREE*cos;
                const n=(north-(y+.5)*dy-p.lat)*KM_PER_DEGREE;
                const q=n>=0?(e>=0?0:3):(e>=0?1:2); // NE, SE, SW, NW
                if(Math.hypot(e,n)>p.radii[q]) continue;
                seen[i]=1;histogram[i*bins+p.h]++;
            }
        }
        if(member%8===7) await yieldWork();
    }
    const encounters=await smoothEncounters(histogram,nx,ny,bins,yieldWork);
    const probability=new Float32Array(n),arrival=new Float32Array(n).fill(NaN);
    for(let i=0;i<n;i++) {
        let count=0;
        for(let h=0;h<bins;h++) count+=encounters[i*bins+h];
        probability[i]=Math.min(100,count/scenarios.length*100);
        if(probability[i]<5) continue;
        let cumulative=0;
        for(let h=0;h<bins;h++) {
            const previous=cumulative,frequency=encounters[i*bins+h];cumulative+=frequency;
            if(cumulative>=count/2) {
                // Resolve hourly quantization continuously; the issue-time
                // mass is already present, not a future arrival interval.
                arrival[i]=h===0?0:h-1+(count/2-previous)/frequency;break;
            }
        }
    }
    return {nx,ny,west,east,south,north,probability,arrival,members:scenarios.length};
}

// Station coverage uses the same smoothed scalar field as the ICWC chart,
// not a centre-distance surrogate or a second uncertainty model. Grid
// samples lie at cell centres; unwrap longitude onto this field's branch.
export function sampleWindProbability(field, lon, lat) {
    if (!field || !Number.isFinite(lon) || !Number.isFinite(lat)) return null;
    const { nx, ny, west, east, south, north, probability } = field;
    lon = (west + east) / 2 + wrap(lon - (west + east) / 2);
    if (lon < west || lon > east || lat < south || lat > north) return 0;
    const x = clamp((lon - west) / (east - west) * nx - .5, 0, nx - 1);
    const y = clamp((north - lat) / (north - south) * ny - .5, 0, ny - 1);
    const x0 = Math.floor(x), y0 = Math.floor(y), x1 = Math.min(x0 + 1, nx - 1), y1 = Math.min(y0 + 1, ny - 1);
    const a = probability[y0 * nx + x0], b = probability[y0 * nx + x1];
    const c = probability[y1 * nx + x0], d = probability[y1 * nx + x1];
    if (![a,b,c,d].every(Number.isFinite)) return null;
    return (a + (b - a) * (x - x0)) * (1 - (y - y0))
        + (c + (d - c) * (x - x0)) * (y - y0);
}

// Open marching-square segments: masked cells are skipped, not closed around
// the probability boundary as polygon contours of a NaN-filled grid would be.
export function arrivalSegments(field,hour) {
    const {nx,ny,arrival:a}=field,segments=[];
    for(let y=0;y<ny-1;y++) for(let x=0;x<nx-1;x++) {
        const v=[a[y*nx+x],a[y*nx+x+1],a[(y+1)*nx+x+1],a[(y+1)*nx+x]];
        if(!v.every(Number.isFinite)) continue;
        const points=[[x+.5,y+.5],[x+1.5,y+.5],[x+1.5,y+1.5],[x+.5,y+1.5]],hits=[];
        for(let e=0;e<4;e++) {
            const j=(e+1)%4;if((v[e]<hour)===(v[j]<hour)) continue;
            const t=(hour-v[e])/(v[j]-v[e]);
            hits.push([points[e][0]+t*(points[j][0]-points[e][0]),points[e][1]+t*(points[j][1]-points[e][1])]);
        }
        if(hits.length===2) segments.push(hits);
        else if(hits.length===4) {
            const center=v.reduce((s,t)=>s+t,0)/4;
            if((v[0]>=hour)===(center>=hour)) segments.push([hits[0],hits[1]],[hits[2],hits[3]]);
            else segments.push([hits[0],hits[3]],[hits[1],hits[2]]);
        }
    }
    return segments;
}
