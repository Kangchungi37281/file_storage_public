// Complete advisories, with distinct live-layer / Warning Graphic horizons.
export const FORECAST_STEP_HOURS = 3;
export const FORECAST_MIN_WIND_KT = 15;
export const FORECAST_HORIZONS = Object.freeze([12, 24, 36, 48, 60, 72]);
export const FORECAST_LAYER_HORIZONS = Object.freeze([12, 24, 48, 72]);

export function completedForecastHours(hours, horizons = FORECAST_HORIZONS) {
    return [...horizons].reverse().find(h => hours >= h) || 0;
}

export function forecastDisplayLimit(forecasts, horizons = FORECAST_LAYER_HORIZONS) {
    const tracks = (forecasts || []).map(f => f?.track).filter(Array.isArray);
    const valid = p => Array.isArray(p) && p.slice(0, 3).length === 3
        && p.slice(0, 3).every(Number.isFinite) && Math.abs(p[1]) <= 90;
    const last = Math.min(72 / FORECAST_STEP_HOURS,
        Math.max(0, ...tracks.map(track => track.length - 1)));
    let available = -1, death = Infinity;
    for (let i = 0; i <= last; i++) {
        const points = tracks.map(track => track[i]).filter(valid);
        if (!points.length) break;
        available = i;
        if (death === Infinity && points.reduce((sum, p) => sum + p[2], 0) / points.length <= FORECAST_MIN_WIND_KT) death = i;
    }
    const complete = completedForecastHours(available * FORECAST_STEP_HOURS, horizons);
    // Never display an archived partial interval or extrapolate missing data.
    if (!complete) return 0;
    const lifetime = death === Infinity ? complete
        : Math.max(horizons[0], completedForecastHours(death * FORECAST_STEP_HOURS, horizons));
    return Math.min(complete, lifetime) / FORECAST_STEP_HOURS;
}
