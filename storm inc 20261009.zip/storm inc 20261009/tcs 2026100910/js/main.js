/**
 * main.js
 * 应用程序的入口点。负责状态管理、事件处理和协调其他模块。
 */

// 从各模块导入函数
import { createForecastAdvisoryQueue } from './forecast-advisories.js?v=20261008-forecast-categories1';
import { mountIntensityDrawer } from './intensity-drawer.js?v=20261003-side1';
import { exportTimelineVideo } from './timeline-video.js?v=20261004-video1';
import { createSimulationCalendar, simulationDate } from './simulation-time.js?v=20261007-start-window1';
import { getCategory, knotsToKph, knotsToMph, windToPressure, directionToCompass, calculateDistance, NAME_LISTS } from './utils.js';
import { createOceanFieldSampler } from './ocean-thermal.js?v=20261008-forecast-categories1';
import { RadarRenderer, calculateRadarDbz, getShaderWindVector } from './radar-system.js?v=20261008-forecast-categories1';
import { DopplerRenderer } from './radar-doppler.js?v=20261008-forecast-categories1';
// [新增] 导入卫星云图模块
import { initSatelliteView, updateSatelliteView, resetSatelliteParams, setSatelliteGrayscale, getSatelliteSnapshot, releaseSatelliteSnapshot } from './satellite-view.js?v=20260914-render2';
import { initTerrainSystem, getElevationAt, getLandStatus, createTerrainWorkerSnapshot } from './terrain-data.js?v=20260911-worker1-raster1';
import { initializeCyclone, initializePressureSystems, updatePressureSystems, updateFrontalZone, updateCycloneState, finalizeCycloneStepDiagnostics, diagnoseCyclonePhaseSpace, getWindVectorAt, getEyewallStructure, getSurfacePressureAt, invalidatePressureSystemCaches, prepareLandFeatureIndex } from './cyclone-model.js?v=20261008-forecast-categories1';
import {
    initializeWindRadiiWorker,
    advanceAtmosphereOffMainThread,
    calculateWindRadiiOffMainThread,
    generateObservationForecastOffMainThread,
    generatePathForecastsOffMainThread
} from './wind-radii-service.js?v=20261008-forecast-categories1';
import { mountObservationPost } from './observation-post-ui.js?v=20261008-site-select1';
import { mountObservationSiteSelector } from './observation-site-selector.js?v=20261008-forecast-categories1';
// [修改] 引入新的历史强度图绘制函数
import { drawMap, drawForecastCone, prepareHeight500MapField, drawCycloneMarker, triggerLandfallEffect, drawFinalPath, drawHistoricalIntensityChart, drawHumidityField, calculateBackgroundHumidity, calculateTotalHumidity, drawAllHistoryTracks, renderJTWCStyleAsync as renderJTWCStyle, renderProbabilitiesStyle, drawStationGraph, renderPhaseSpace, startNewsAnimation, renderStationSynopticChartAsync as renderStationSynopticChart, renderHeight500ChartAsync, renderHeight200ChartAsync as renderHeight200Chart } from './visualization.js?v=20261008-forecast-categories1';
import { playClick, playPanelOpen, playPanelClose, playPageTurn, playToggleOn, playToggleOff, playStart, playError, playAlert, playLandfallSound, playUpgradeSound, toggleSFX } from './audio.js?v=20261006-sfx5';
import { DISPLAY_FEATURES, applyDisplayFeatures } from './display-features.js?v=20260922-shear1';
import { initializeLegendLayout, setLegendVisible } from './legend-layout.js?v=20261006-legends-mobile1';

import { ICWC_MAJOR_CITIES, parseExportTrack, renderTrackExport } from './track-export.js?v=20261008-forecast-categories1';

const ICWC_HEIGHT500_CACHE_LIMIT = 2;
const icwcHeight500CanvasCache = new Map();
const icwcHeight500RenderPromises = new Map();
const icwcHeight500ObjectIds = new WeakMap();
let nextIcwcHeight500ObjectId = 1;

function icwcHeight500ObjectId(value) {
    if (!value || (typeof value !== 'object' && typeof value !== 'function')) return 'none';
    let id = icwcHeight500ObjectIds.get(value);
    if (!id) {
        id = nextIcwcHeight500ObjectId++;
        icwcHeight500ObjectIds.set(value, id);
    }
    return id;
}

function icwcHeight500SystemsSignature(systems) {
    const summarize = list => (list || []).map(cell => [
        cell.role, cell.fieldId, cell.waveKey, cell.x, cell.y,
        cell.strength, cell.sigmaX, cell.sigmaY, cell.phase,
        cell.amplitude, cell.elapsedHours, cell.calendarMonth,
        cell.fieldVersion, cell.flowModel, cell.isManual ? 1 : 0
    ]);
    const background = systems?.upper?.find(cell => cell.role === 'height-background');
    const waveSignature = (background?.waves || []).map(wave => [
        wave.k, wave.hemisphere, wave.phase, wave.latitude,
        wave.amplitude, wave.width, wave.axisScaleDeg
    ]);
    const tropicalSignature = (background?.tropicalWaves || []).map(wave => [
        wave.k, wave.hemisphere, wave.phase, wave.latitude,
        wave.amplitude, wave.width
    ]);
    const equatorialSignature = (background?.equatorialWaves || []).map(wave => [
        wave.k, wave.phase, wave.latitude, wave.width, wave.amplitude
    ]);
    return JSON.stringify([
        summarize(systems?.upper),
        summarize(systems?.lower),
        waveSignature,
        tropicalSignature,
        equatorialSignature,
        background?.elapsedHours,
        background?.calendarMonth,
        background?.flowModel,
        background?.fieldVersion,
        background?.climatologyVersion,
        background?.activeBasin,
        background?.weatherSequence?.version,
        background?.weatherSequence?.record,
        background?.weatherSequence?.startDay,
        background?.monsoonCirculation,
        background?.wnpRecurvatureRegime,
        background?.regionalCirculationRegime,
        background?.ridgeWeather
    ]);
}

function icwcHeight500ProductKey(cyclone, timeIndex, world, systems) {
    const point = cyclone?.track?.[timeIndex];
    return [
        icwcHeight500ObjectId(cyclone),
        icwcHeight500ObjectId(world),
        icwcHeight500ObjectId(systems?.upper),
        icwcHeight500ObjectId(systems?.lower),
        timeIndex,
        cyclone?.currentMonth,
        point?.slice(0, 7).join(','),
        icwcHeight500SystemsSignature(systems)
    ].join('|');
}

function getCachedIcwcHeight500Canvas(key) {
    const canvas = icwcHeight500CanvasCache.get(key);
    if (!canvas) return null;
    icwcHeight500CanvasCache.delete(key);
    icwcHeight500CanvasCache.set(key, canvas);
    return canvas;
}

function renderIcwcHeight500ChartCached(cyclone, timeIndex, world, systems, key) {
    const cached = getCachedIcwcHeight500Canvas(key);
    if (cached) return Promise.resolve(cached);
    const inFlight = icwcHeight500RenderPromises.get(key);
    if (inFlight) return inFlight;

    const renderPromise = Promise.resolve()
        .then(() => renderHeight500ChartAsync(cyclone, timeIndex, world, systems))
        .then(canvas => {
            icwcHeight500CanvasCache.set(key, canvas);
            while (icwcHeight500CanvasCache.size > ICWC_HEIGHT500_CACHE_LIMIT) {
                icwcHeight500CanvasCache.delete(icwcHeight500CanvasCache.keys().next().value);
            }
            return canvas;
        })
        .finally(() => icwcHeight500RenderPromises.delete(key));
    icwcHeight500RenderPromises.set(key, renderPromise);
    return renderPromise;
}

const MAX_SATELLITE_SNAPSHOTS = 48;
const pendingSatelliteSnapshots = new WeakMap();
const deferredSatelliteFinalizations = new WeakSet();

const checkLandWrapper = (lon, lat) => {
    const status = getLandStatus(lon, lat);
    return status.isLand; 
};

document.addEventListener('DOMContentLoaded', () => {
    applyDisplayFeatures();
    initializeLegendLayout();

    // --- DOM 元素与全局状态 ---
    const generateButton = document.getElementById('generateButton');
    const pauseButton = document.getElementById('pauseButton');
    const catButton = document.getElementById('catButton');
    const newsModal = document.getElementById('newsModal');
    const closeNewsModal = document.getElementById('closeNewsModal');
    const helpButton = document.getElementById('helpButton');
    const helpModal = document.getElementById('helpModal');
    const closeHelpModal = document.getElementById('closeHelpModal');
    const sfxButton = document.getElementById('sfxButton');
    const sfxIcon = sfxButton.querySelector('i');
    const irBwCheckbox = document.getElementById('irBwCheckbox');
    const basinSelector = document.getElementById('basinSelector');
    const monthSelector = document.getElementById('monthSelector');
    const leftContent = document.getElementById('left-hud-content');
    let selectedHistoryPointIndex = -1; // 记录当前选中的历史点
    const generateJTWCButton = document.getElementById('generateJTWCButton');
    const jtwcModal = document.getElementById('jtwcModal');
    const jtwcOutput = document.getElementById('jtwcOutput');
    const closeJtwcModal = document.getElementById('closeJtwcModal');
    const saveJtwcImage = document.getElementById('saveJtwcImage');
    const warningMapFitButton = document.getElementById('toggleWarningMapFit');
    let fitWarningMapCone = false;
    let isLeftPanelCollapsed = false;
    let chartMode = 'kt';
    let intensityChartCyclone = null;
    let intensityChartRevision = '';
    const tabKt = document.getElementById('tab-kt');
    const tabHpa = document.getElementById('tab-hpa');
    const togglePressureButton = document.getElementById('togglePressureButton');
    const toggleHumidityButton = document.getElementById('toggleHumidityButton');
    const toggleSSTButton = document.getElementById('toggleSSTButton');
    const toggleWindFieldButton = document.getElementById('toggleWindFieldButton');
    const toggleWindRadiiButton = document.getElementById('toggleWindRadiiButton');
    const windRadiiLegend = document.getElementById('wind-radii-legend');
    const radarLegend = document.getElementById('radar-legend');
    const dopplerLegend = document.getElementById('doppler-legend');
    const sstLegend = document.getElementById('sst-legend');
    const togglePathButton = document.getElementById('togglePathButton');
    const copyTrackButton = document.getElementById('copy-track-button');
    const downloadTrackButton = document.getElementById('download-track-button');
    const historyButton = document.getElementById('toggleHistoryButton'); 
    const historyModal = document.getElementById('historyModal');
    const historyHeader = historyModal.querySelector('.border-b');
    const closeHistoryModal = document.getElementById('closeHistoryModal');
    const historyList = document.getElementById('historyList');
    const bestTrackContainer = document.getElementById('best-track-container');
    const bestTrackData = document.getElementById('best-track-data');
    const historyBestTrackContainer = document.getElementById('history-best-track-container');
    const historyBestTrackData = document.getElementById('history-best-track-data');
    const downloadHistoryTrackButton = document.getElementById('downloadHistoryTrackButton');
    const mapContainer = d3.select("#map-container");
    const chartContainer = d3.select("#intensity-chart-container");
    const forecastContainer = document.getElementById('intensity-chart-section'); // [新增] 获取容器元素
    function refreshIntensityChart(force = false) {
        if (forecastContainer.classList.contains('hidden') || !forecastContainer.classList.contains('mobile-open')) return;
        const cyclone = intensityChartCyclone;
        if (!cyclone?.track?.length) return;
        const revision = `${cyclone.track.length}:${chartMode}`;
        if (!force && revision === intensityChartRevision) return;
        intensityChartRevision = revision;
        drawHistoricalIntensityChart(chartContainer, cyclone.track, tooltip, chartMode, cyclone.basin || basinSelector.value);
    }
    function showIntensityDrawer(cyclone) {
        intensityChartCyclone = cyclone;
        forecastContainer.classList.remove('hidden');
        refreshIntensityChart(true);
    }
    const tooltip = d3.select("body").append("div").attr("class", "tooltip");

    // [新增] 设置菜单 DOM 元素
    const settingsButton = document.getElementById('settingsButton');
    const settingsMenu = document.getElementById('settingsMenu');
    const musicButton = document.getElementById('musicButton');
    const musicMenu = document.getElementById('musicMenu');
    const musicListContainer = document.getElementById('musicListContainer');
    const bgmVolumeSlider = document.getElementById('bgmVolume');
    const bgmAudio = document.getElementById('bgmAudio');
    const globalTempSlider = document.getElementById('globalTempSlider');
    const globalTempValue = document.getElementById('globalTempValue');
    const heatDistributionSlider = document.getElementById('heatDistributionSlider');
    const heatDistributionValue = document.getElementById('heatDistributionValue');
    const globalShearSlider = document.getElementById('globalShearSlider');
    const globalShearValue = document.getElementById('globalShearValue');
    const siteNameInput = document.getElementById('siteNameInput');
    const siteLonInput = document.getElementById('siteLonInput');
    const siteLatInput = document.getElementById('siteLatInput');
    let observationSiteSelector;
    const customLonInput = document.getElementById('customLonInput');
    const customLatInput = document.getElementById('customLatInput');
    const showPathPointsCheckbox = document.getElementById('showPathPointsCheckbox');
    const exportPeakIntensityCheckbox = document.getElementById('exportPeakIntensityCheckbox');
    const exportIgnoreExPeakCheckbox = document.getElementById('exportIgnoreExPeakCheckbox');
    const exportExtremeTierCheckbox = document.getElementById('exportExtremeTierCheckbox');
    const exportLegendCheckbox = document.getElementById('exportLegendCheckbox');
    const exportIntensityHistoryCheckbox = document.getElementById('exportIntensityHistoryCheckbox');
    const exportCityObservationsCheckbox = document.getElementById('exportCityObservationsCheckbox');
    const trackExportSettingsKey = 'tcs_track_export_settings_v1';
    const trackExportSettings = (() => {
        try {
            const saved = JSON.parse(localStorage.getItem(trackExportSettingsKey) || '{}');
            return {
                markPeakIntensity: saved.markPeakIntensity === true,
                ignoreExPeak: saved.ignoreExPeak === true,
                enableExtremeTier: saved.enableExtremeTier === true,
                showIntensityHistory: saved.showIntensityHistory === true,
                showCityObservations: saved.showCityObservations === true,
                // Existing users retain a visible ≥170 kt cue after it moves
                // from the header into the new lower-right legend.
                showLegend: saved.showLegend !== false
            };
        } catch {
            return { markPeakIntensity: false, ignoreExPeak: false, enableExtremeTier: false,
                showIntensityHistory: false, showCityObservations: false, showLegend: true };
        }
    })();
    if (exportPeakIntensityCheckbox) exportPeakIntensityCheckbox.checked = trackExportSettings.markPeakIntensity;
    if (exportIgnoreExPeakCheckbox) exportIgnoreExPeakCheckbox.checked = trackExportSettings.ignoreExPeak;
    if (exportExtremeTierCheckbox) exportExtremeTierCheckbox.checked = trackExportSettings.enableExtremeTier;
    if (exportLegendCheckbox) exportLegendCheckbox.checked = trackExportSettings.showLegend;
    if (exportIntensityHistoryCheckbox) exportIntensityHistoryCheckbox.checked = trackExportSettings.showIntensityHistory;
    if (exportCityObservationsCheckbox) exportCityObservationsCheckbox.checked = trackExportSettings.showCityObservations;
    const persistTrackExportSettings = () => {
        try {
            localStorage.setItem(trackExportSettingsKey, JSON.stringify(trackExportSettings));
        } catch (error) {
            console.warn('Could not save track export settings:', error);
        }
    };
    const savedSiteName = localStorage.getItem('tcs_site_name');
    const savedSiteLon = localStorage.getItem('tcs_site_lon');
    const savedSiteLat = localStorage.getItem('tcs_site_lat');
    const stats = new Stats();
    const musicTracks = [
        "./music/WPAC - Barotropicity.m4a",
        "./music/EPAC - Abyssal Tempest.m4a",
        "./music/NATL - Atlantide.m4a",
        "./music/SATL - Serendipity Land.m4a",
        "./music/NIO - Gyre.m4a",
        "./music/SIO - Westerlies.m4a",
        "./music/SHEM - Void.m4a",
    ];
    let currentTrackIndex = -1;
    let needsFullRedraw = false;
    let needsTrackUpdate = false;
    let needsForecastRedraw = false;
    let pathForecastRevision = 0;
    let simulationStepInFlight = false;
    let simulationStepQueued = false;
    let initializingCyclone = null;
    const advisoryQueue = createForecastAdvisoryQueue(
        generatePathForecastsOffMainThread,
        (cyclone, forecasts) => {
            if (state.cyclone !== cyclone) return;
            state.pathForecasts = cyclone.isExtratropical ? [] : forecasts;
            cyclone.pathForecasts = state.pathForecasts;
            pathForecastRevision++;
            needsForecastRedraw = true;
        },
        error => console.error('[forecast] Advisory failed:', error)
    );
    // Opt-in diagnostics for the real-time simulation loop. Keep this off in
    // normal runs; `?step-profile=1` prints one compact record per 3-hour
    // step, including the extra forecast work on 6-hour advisories.
    const simulationStepProfiling = new URLSearchParams(location.search).has('step-profile');
    const snapshotProfiling = new URLSearchParams(location.search).has('step-profile');
    const longTaskProfiling = new URLSearchParams(location.search).has('longtask-profile');
    if (longTaskProfiling && typeof PerformanceObserver === 'function') {
        try {
            const observer = new PerformanceObserver(list => {
                for (const entry of list.getEntries()) {
                    const attribution = (entry.attribution || [])
                        .map(item => item.containerName || item.name || item.containerType)
                        .filter(Boolean);
                    console.info(`[long-task-profile] ${JSON.stringify({
                        duration: Math.round(entry.duration * 10) / 10,
                        start: Math.round(entry.startTime * 10) / 10,
                        attribution
                    })}`);
                }
            });
            observer.observe({ type: 'longtask', buffered: true });
        } catch (error) {
            console.info('[long-task-profile] unavailable');
        }
    }

    function detachPressureSystemsForManualEdit() {
        const latestSnapshot = state.pressureHistory?.at(-1);
        if (!latestSnapshot) return;
        if (latestSnapshot.lower === state.pressureSystems?.lower
            || latestSnapshot.upper === state.pressureSystems?.upper) {
            state.pressureSystems = typeof structuredClone === 'function'
                ? structuredClone(state.pressureSystems)
                : JSON.parse(JSON.stringify(state.pressureSystems));
        }
    }

    function refreshForecastWhileDragging(pressureSystems) {
        const cyclone = state.cyclone;
        if (!state.showPathForecast || !cyclone || cyclone.status !== 'active') return;

        // The worker must receive the position for this pointer event, not a
        // later mutation of the live systems object while it waits in queue.
        const systemsSnapshot = structuredClone(pressureSystems);
        let randomSeed = 2166136261;
        for (const value of [cyclone.age, cyclone.lon, cyclone.lat,
            cyclone.intensity, cyclone.currentMonth]) {
            const quantized = Number.isFinite(value) ? Math.round(value * 1000) : 0;
            randomSeed = Math.imul(randomSeed ^ quantized, 16777619) >>> 0;
        }

        generatePathForecastsOffMainThread(
            cyclone, systemsSnapshot, state.GlobalTemp, state.GlobalShear, randomSeed
        ).then(forecasts => {
            // A reset or new cyclone can happen while the Worker is solving.
            if (state.cyclone !== cyclone) return;
            state.pathForecasts = forecasts;
            state.cyclone.pathForecasts = forecasts;
            pathForecastRevision++;
            needsForecastRedraw = true;
            const forecastLayer = mapSvg.select('.layer-forecast');
            if (!forecastLayer.empty()) {
                if (state.showPathForecast && forecasts?.length) {
                    drawForecastCone(forecastLayer, mapProjection, forecasts);
                } else {
                    forecastLayer.selectAll('*').remove();
                }
            }
        }).catch(error => {
            console.warn('[forecast] Live pressure-drag update failed:', error);
        });
    }

    stats.showPanel(0); // 0: fps, 1: ms, 2: mb, 3+: custom
    stats.dom.style.position = 'absolute'; // 样式调整以适应你的布局
    stats.dom.style.top = '0px';
    stats.dom.style.right = '0px'; 
    //document.body.appendChild(stats.dom);
    if(bgmAudio) bgmAudio.volume = 0.4;
    let radarRenderer = null;
    let dopplerRenderer = null; // [新增] 多普勒渲染器实例
    let radarOverlayCtx = null; // 用于画圆圈和线的2D Canvas
    let radarOverlayCanvas = null;
    let isRadarLayerVisible = false;
    let lastRadarRenderKey = '';
    const savedIrBw = localStorage.getItem('tcs_ir_bw') === 'true';
    if (irBwCheckbox) {
        irBwCheckbox.checked = savedIrBw;
        setSatelliteGrayscale(savedIrBw);
    }
    if (irBwCheckbox) {
        irBwCheckbox.addEventListener('change', (e) => {
            const isEnabled = e.target.checked;
            setSatelliteGrayscale(isEnabled);
            if (typeof playClick === 'function') playClick();
            localStorage.setItem('tcs_ir_bw', isEnabled);
        });
    }
    if (historyHeader) {
        // 创建按钮容器以保持布局整洁
        const btnContainer = document.createElement('div');
        btnContainer.className = "flex gap-2 ml-auto mr-4"; // 放在右侧，关闭按钮左边

        const showAllBtn = document.createElement('button');
        showAllBtn.innerHTML = '<i class="fa-solid fa-earth-asia"></i> SHOW ALL';
        showAllBtn.className = "text-[10px] font-bold bg-cyan-900/50 hover:bg-cyan-700 text-cyan-300 border border-cyan-500/30 px-3 py-1 rounded transition-colors uppercase tracking-wider";
        
        showAllBtn.addEventListener('click', () => {
            if (state.history.length === 0) {
                    alert("No historical track to display :(");
                    return;
                }
            
                // 1. 关闭模态框
                historyModal.classList.add('hidden');
    
                // 2. 清理界面多余元素
                if (state.simulationInterval) clearInterval(state.simulationInterval);
                state.simulationInterval = null;
                state.isPaused = false;
                state.showAllHistory = true;
                state.selectedHistoryCyclone = null;
                state.selectedHistoryTrackData = '';
                pauseButton.disabled = true;
    
                // --- [修复开始] ---
                // 隐藏卫星云图窗口
                document.getElementById('satellite-window').classList.add('hidden');
                // 隐藏下方的“恢复卫星”按钮（如果存在）
                const restoreBtn = document.getElementById('restore-sat-btn');
                if(restoreBtn) restoreBtn.classList.add('hidden');

                // 隐藏整个信息面板容器 (不仅仅是内部文字)
                document.getElementById('info-panel').classList.add('hidden');
    
                // 隐藏其他组件
                document.getElementById('map-info-box').classList.add('hidden');
                document.getElementById('best-track-container').classList.add('hidden');
                forecastContainer.classList.add('hidden');
    
                // --- [修复结束] ---
    
                // 3. 更新状态栏文字 (为了让用户知道怎么退出，我们可以把状态写在顶部，或者让 Reset 按钮生效)
                // 由于 info-panel 隐藏了，原本的 'status' 元素也看不见了。
    
                // 4. 调用批量绘图
                requestRedraw();
            });

        const closeBtn = document.getElementById('closeHistoryModal');
        historyHeader.insertBefore(showAllBtn, closeBtn);
    }

    // 创建一个独立的渲染循环来更新统计
    async function animate() {
        stats.begin();

        if (state.world && mapSvg) {
            if (state.showAllHistory || state.selectedHistoryCyclone) {
                needsTrackUpdate = false;
                needsForecastRedraw = false;
            }
            if ((state.showAllHistory || state.selectedHistoryCyclone) && needsFullRedraw) {
                requestRedraw();
            }
            if (needsFullRedraw) {
                const frameProfileStartedAt = simulationStepProfiling ? performance.now() : 0;
                const frameProfileMarks = simulationStepProfiling ? {} : null;
                const frameProfileMark = label => {
                    if (frameProfileMarks) frameProfileMarks[label] = performance.now() - frameProfileStartedAt;
                };
                // Render every completed model update. In particular, do not
                // rate-limit full redraws or silently replace intermediate
                // cyclone states with a later visual frame.
                // Keep this exact model snapshot alive across GPU readback.
                // A later model update can request another redraw while this
                // frame is being computed; it must not mutate the frame in flight.
                const frameUsesHeight500 = state.showPressureField;
                const frameForecastRevision = pathForecastRevision;
                if (frameUsesHeight500) {
                    // Pressure-history entries share their arrays with the
                    // live worker result. Detach before binding drag handles,
                    // so pointer edits update live state without rewriting an
                    // already-recorded atmospheric frame.
                    detachPressureSystemsForManualEdit();
                }
                const frameCyclone = frameUsesHeight500
                    ? structuredClone(state.cyclone) : state.cyclone;
                const framePressureSystems = frameUsesHeight500
                    ? structuredClone(state.pressureSystems) : state.pressureSystems;
                const frameOptions = {
                    pathForecasts: frameUsesHeight500
                        ? structuredClone(state.pathForecasts) : state.pathForecasts,
                    pressureSystems: framePressureSystems,
                    interactivePressureSystems: state.pressureSystems,
                    showPressureField: state.showPressureField,
                    showHumidityField: state.showHumidityField,
                    showSSTField: state.showSSTField,
                    showShearField: DISPLAY_FEATURES.shear && state.showShearField,
                    showPathForecast: state.showPathForecast,
                    showWindRadii: state.showWindRadii,
                    siteName: state.siteName,
                    siteLon: state.siteLon,
                    siteLat: state.siteLat,
                    showPathPoints: state.showPathPoints,
                    showWindField: state.showWindField,
                    month: state.currentMonth,
                    globalTemp: state.GlobalTemp,
                    globalShear: state.GlobalShear,
                    siteHistory: state.siteHistory,
                    siteData: state.currentSiteData,
                    onSiteClick: () => { 
                        state.isSiteSelected = !state.isSiteSelected;
                        needsFullRedraw = true; 
                    },
                    onSystemRemove: (systemData) => {
                         if (!systemData.isManual) return;
                         detachPressureSystemsForManualEdit();
                         const removeManual = (list) => {
                             const idx = list.findIndex(s => s.isManual);
                             if (idx !== -1) list.splice(idx, 1);
                         };
                         if (state.pressureSystems.lower) removeManual(state.pressureSystems.lower);
                         if (state.pressureSystems.upper) removeManual(state.pressureSystems.upper);
                         invalidatePressureSystemCaches(state.pressureSystems);
                         playToggleOff();
                         needsFullRedraw = true; 
                    },
                    onSystemChange: () => {
                        // Drag edits live state. Re-enter the normal redraw
                        // pipeline so the next visible field is sampled on
                        // WebGPU and every completed model frame remains visible.
                        invalidatePressureSystemCaches(state.pressureSystems);
                        needsFullRedraw = true;
                    },
                    onSystemDrag: (pressureSystems) => {
                        invalidatePressureSystemCaches(pressureSystems);
                        // Paused maps have no model ticks to request a field
                        // redraw: pointer edits must enter the same GPU path.
                        needsFullRedraw = true;
                        refreshForecastWhileDragging(pressureSystems);
                    }
                };
                frameProfileMark('snapshot');
                needsFullRedraw = false;
                needsTrackUpdate = false;
                if (frameOptions.showPressureField) {
                    frameOptions.precomputedHeight500Grid = await prepareHeight500MapField(
                        mapSvg, mapProjection, framePressureSystems, frameCyclone,
                        frameOptions.month
                    ).catch(error => {
                        console.warn('500-hPa GPU preparation failed; using the CPU field renderer.', error);
                        return null;
                    });
                    frameProfileMark('height500');
                }
                // drawMap updates mapProjection to the same active-cyclone
                // view used by prepareHeight500MapField, then commits this frame.
                if (!state.showAllHistory && !state.selectedHistoryCyclone) {
                    // A close action can arrive during GPU readback. Never
                    // resurrect the height layer from that older snapshot;
                    // the queued redraw still handles a subsequent reopen.
                    frameOptions.showPressureField = frameOptions.showPressureField && state.showPressureField;
                    drawMap(mapSvg, mapProjection, state.world, frameCyclone, frameOptions);
                }
                frameProfileMark('drawMap');
                if (frameProfileMarks) {
                    const report = {
                        ...Object.fromEntries(Object.entries(frameProfileMarks).map(([key, value], index, entries) => {
                            const previous = index === 0 ? 0 : entries[index - 1][1];
                            return [key, Math.round((value - previous) * 10) / 10];
                        })),
                        total: Math.round((performance.now() - frameProfileStartedAt) * 10) / 10
                    };
                    console.info(`[map-frame-profile] ${JSON.stringify(report)}`);
                }
                // A drag forecast can finish while this frame is awaiting GPU
                // readback. Repaint the forecast layer after that older frame
                // commits so the path never snaps back to its stale snapshot.
                if (pathForecastRevision !== frameForecastRevision && !state.showAllHistory && !state.selectedHistoryCyclone) {
                    needsForecastRedraw = true;
                }

            } else if (!needsFullRedraw && needsTrackUpdate) {
                // 增量更新 (此时投影未变，直接移动元素)
                // 确保 fastUpdateMap 已定义在 DOMContentLoaded 内部
                if (typeof fastUpdateMap === 'function') {
                    fastUpdateMap();
                }
                needsTrackUpdate = false;
            } else if (!needsFullRedraw && needsForecastRedraw) {
                needsForecastRedraw = false;
                const forecastLayer = mapSvg.select('.layer-forecast');
                if (!forecastLayer.empty()) {
                    if (state.showPathForecast && state.pathForecasts?.length) {
                        drawForecastCone(forecastLayer, mapProjection, state.pathForecasts);
                    } else {
                        forecastLayer.selectAll('*').remove();
                    }
                }
            }
        }

        // 检查是否有轨迹数据 (用于逻辑判断，非绘图)
        const hasTrackData = (state.cyclone && state.cyclone.track && state.cyclone.track.length > 1);
        
        if (state.radarMode || state.dopplerMode) {
            // 现在调用 drawRadarScope，它会获取最新的投影坐标
            drawRadarScope();
            isRadarLayerVisible = true;
        } else {
            // 清理雷达层
            if (isRadarLayerVisible) {
                if (radarCanvas) radarCanvas.classList.add('hidden');
                if (radarOverlayCanvas) {
                    radarOverlayCanvas.classList.add('hidden');
                    if (radarOverlayCtx) {
                        radarOverlayCtx.setTransform(1, 0, 0, 1, 0, 0);
                        radarOverlayCtx.clearRect(
                            0, 0,
                            radarOverlayCanvas.width,
                            radarOverlayCanvas.height
                        );
                    }
                }
            isRadarLayerVisible = false;
            }
        }

        stats.end();
        requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);

	    let state = {
        simulationInterval: null,
        isPaused: false,
        hasAlerted: false,
        hasTriggeredCat1News: false,
        hasTriggeredCat5News: false,
        highestSoundCategory: 0,
        simulationSpeed: 200,
        cyclone: {},
        selectedHistoryCyclone: null,
        showAllHistory: false,
        pressureSystems: { upper: [], lower: [] },
        pressureHistory: [],
        frontalZone: {},
        pathForecasts: [],
        currentMonth: 7,
        world: null,
        showPressureField: false,
        showHumidityField: false,
        showSSTField: false,
        showShearField: false,
        showPathForecast: false,
        showWindRadii: false,
        GlobalShear: 100,
        GlobalTemp: 289, // [新增] 全局温度状态，默认 289K (16°C)
        heatDistribution: 50,
        siteName: savedSiteName || '',
        siteLon: savedSiteLon ? parseFloat(savedSiteLon) : null,
        siteLat: savedSiteLat ? parseFloat(savedSiteLat) : null,
        radarMode: false,
        dopplerMode: false,
        customLon: null,
        customLat: null,
        showPathPoints: false,
        showWindField: false,
        history: [],
        simulationCount: 1,
        nextNameIndex: 0,
        selectedHistoryTrackData: '',
        lastFinalStats: null,
        currentSiteData: null,
        siteHistory: [],
        isSiteSelected: false,
        idleRotation: Math.random() * 50
	    };

    let mapSvg, mapProjection;
    let radarCanvas, radarCtx;
    let cachedPathGenerator = null; 
    let _cachedSiteLon = null;
    let _cachedSiteLat = null;
    let _cachedSiteIsLand = false;
    let _cachedSiteIsNearShore = false;
    if (savedSiteName) siteNameInput.value = savedSiteName;
    if (savedSiteLon) siteLonInput.value = savedSiteLon;
    if (savedSiteLat) siteLatInput.value = savedSiteLat;
    generateButton.disabled = true;
    // --- 初始化与设置 ---

    function getEnglishCategoryName(knots, isExtra, isSub, basin) {
        if (isExtra) return "EXTRATROPICAL CYCLONE";
        if (isSub) return "SUBTROPICAL STORM";
        if (knots < 34) return "TROPICAL DEPRESSION";
        if (knots < 64) return "TROPICAL STORM";
        let term = "TYPHOON"; // 默认西太 (WPAC)
    
        // 美洲/大西洋 -> 飓风
        if (['EPAC', 'NATL', 'SATL'].includes(basin)) {
            term = "HURRICANE";
        } 
        // 印度洋/南半球 -> 气旋
        else if (['SHEM', 'SIO', 'NIO'].includes(basin)) {
            term = "CYCLONE";
        }

        // 2. 拼接等级
        if (knots < 83) return `${term} (CAT 1)`;
        if (knots < 96) return `${term} (CAT 2)`;
        if (knots < 113) return `${term} (CAT 3)`;
    
        return `SUPER ${term} (CAT ${knots < 137 ? '4' : '5'})`;
    }

    function fastUpdateMap() {
        if (!state.cyclone || state.cyclone.status !== 'active' || !mapSvg) return;
        const center = mapProjection([state.cyclone.lon, state.cyclone.lat]);
        if (!center) return;

        drawCycloneMarker(mapSvg.select('.layer-cyclone'), mapProjection, state.cyclone);

    // --- B. 增量绘制轨迹线 ---
        const track = state.cyclone.track;
        const len = track.length;
        if (len >= 2) {
            const prev = track[len - 2];
            const curr = track[len - 1];

            // 处理日界线跨越 (逻辑简化自 drawMap)
            let p1Lon = prev[0];
            let p2Lon = curr[0];
            if (Math.abs(p2Lon - p1Lon) > 180) {
                p2Lon += (p2Lon < p1Lon) ? 360 : -360;
            }

            // 构建单段 LineString
            const segmentGeoJSON = {
                type: "LineString",
                coordinates: [[p1Lon, prev[1]], [p2Lon, curr[1]]]
            };

            mapSvg.select(".layer-track-lines")
                .append("path")
                .attr("class", "storm-track-segment-fast") // 标记为快速段
                .attr("d", cachedPathGenerator(segmentGeoJSON))
                .style("fill", "none")
                .style("stroke-width", 2) // 保持与 visualization.js 一致的宽度
                .style("stroke-linecap", "round")
                .style("stroke", getCategory(curr[2], curr[3], curr[4], curr[6]).color);
        }

        // --- C. 增量绘制轨迹点 (如果开启) ---
        if (state.showPathPoints && len > 0) {
            const curr = track[len - 1];
            // 假设每步都画，或者你可以加逻辑 (len % 2 === 0)
            if (len % 2 === 0) { 
                mapSvg.select(".layer-track-points")
                    .append("circle")
                    .attr("r", 4.5)
                    .attr("stroke", "#222222")
                    .attr("stroke-width", 1)
                    .attr("cx", center[0])
                    .attr("cy", center[1])
                    .style("fill", getCategory(curr[2], curr[3], curr[4], curr[6]).color);
            }
        }

        // --- D. 更新 UI 数值 ---
        throttledUpdateInfoPanel();
        throttledUpdateMapInfoBox();
    }

    // [新增] 初始化卫星云图 WebGL 上下文
    initSatelliteView('satCanvas');

    function setupCanvases() {
        // A. SVG 重置 (保持不变)
        mapContainer.select("svg").remove();
        mapSvg = mapContainer.insert("svg", ":first-child")
            .attr("width", "100%")
            .attr("height", "100%")
            .style("z-index", "10")
            .style("pointer-events", "none"); 
        
        // B. 投影更新
        const { width, height } = mapContainer.node().getBoundingClientRect();
        let initLon = 120;
        let initLat = 15;
        if (typeof state !== 'undefined' && state.siteLon != null && state.siteLat != null) {
            initLon = state.siteLon;
            initLat = state.siteLat;
        } else if (typeof savedSiteLon !== 'undefined' && savedSiteLon) {
            // 兜底：如果 state 还没初始化，尝试读取顶部的全局变量
            initLon = parseFloat(savedSiteLon);
            initLat = parseFloat(savedSiteLat);
        }
        mapProjection = d3.geoEquirectangular()
            .scale(height / (20 * Math.PI / 180))
            .translate([width / 2, height / 2])
            .rotate([-initLon, 0])
            .center([0, initLat]);
        // The main camera is cylindrical: its static geometry can be
        // projected once and moved using a periodic SVG atlas.
        mapProjection.tcsCylindricalAtlas = true;
        cachedPathGenerator = d3.geoPath().projection(mapProjection);
        if (!document.getElementById('interaction-fix-style')) {
            const style = document.createElement('style');
            style.id = 'interaction-fix-style';
            style.textContent = `
                /* 允许以下特定图层响应鼠标 */
                .track-interaction-layer, 
                .layer-pressure-handles, 
                .layer-ui,
                .layer-ui rect,
                .pressure-handle { 
                    pointer-events: auto !important; 
                    cursor: pointer;
                }
                
                /* 确保遮罩层本身虽然透明但能被点击 */
                .interaction-overlay {
                    pointer-events: auto !important;
                }
            `;
            document.head.appendChild(style);
        }

        // C. WebGL Canvas 初始化 (单例模式)
        // 只有当 radarRenderer 不存在时才创建，防止重复初始化导致 WebGL 上下文丢失
        radarCanvas = document.getElementById('radar-canvas-layer');
        if (radarCanvas) {
            // [修复核心 3]：双重保险，强制雷达 Canvas 穿透
            radarCanvas.style.pointerEvents = 'none'; 
            
            if (!radarRenderer) {
                radarCanvas.width = 256; 
                radarCanvas.height = 256;
                radarCanvas.style.opacity = "0.65";
                radarRenderer = new RadarRenderer(radarCanvas);
            }
            if (!dopplerRenderer) {
                dopplerRenderer = new DopplerRenderer(radarCanvas);
            }
        }

        // D. Overlay Canvas 初始化 (单例模式)
        if (!radarOverlayCanvas) {
            radarOverlayCanvas = document.getElementById('radar-overlay-layer');
            // 如果 HTML 里没写，动态创建
            if (!radarOverlayCanvas) {
                radarOverlayCanvas = document.createElement('canvas');
                radarOverlayCanvas.id = 'radar-overlay-layer';
                radarOverlayCanvas.className = "absolute top-0 left-0 w-full h-full pointer-events-none z-30 hidden";
                document.getElementById('map-container').appendChild(radarOverlayCanvas);
            }
            radarOverlayCtx = radarOverlayCanvas.getContext('2d');
        }
        
        // 确保 Overlay 尺寸匹配屏幕
        if (radarOverlayCanvas) {
            radarOverlayCanvas.style.pointerEvents = 'none';
            radarOverlayCanvas.width = width;
            radarOverlayCanvas.height = height;
        }
    }
        
    // --- 初始化流程 ---
    
    // 1. 先加载地图数据
    d3.json("js/world-f.json").then(data => {
        window.dispatchEvent(new CustomEvent('storm:boot-progress', {
            detail: { value: 24, label: 'LOADING FIELD CORE', detail: 'PARSING WORLD GEOMETRY' }
        }));
        state.world = topojson.feature(data, data.objects.collection);
        
        // 2. 数据加载完，建立图层和投影
        setupCanvases();
        updateSiteGeoCache();
        if (mapProjection && mapProjection.precision) {
            mapProjection.precision(3.1); // 值越大越快，0.1 是平衡点
        }
        // 3. 加载地形数据 (纹理)
        console.log("Loading Terrain Data...");
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.src = './js/elevation_1080x540.png';
        
        img.onload = () => {
            window.dispatchEvent(new CustomEvent('storm:boot-progress', {
                detail: { value: 58, label: 'BUILDING TERRAIN INDEX', detail: 'PREPARING LAND MASK' }
            }));
            // A. JS 逻辑用的地形数据 (异步)
            initTerrainSystem(img.src, state.world).then(() => {
                console.log("Terrain Logic Ready.");
                prepareLandFeatureIndex(state.world);
                initializeWindRadiiWorker(createTerrainWorkerSnapshot());
                generateButton.disabled = false;
                needsFullRedraw = true;
                window.dispatchEvent(new CustomEvent('storm:boot-progress', {
                    detail: { value: 100, ready: true, label: 'FIELD CORE ONLINE', detail: 'HANDING OFF TO SIMULATION' }
                }));
            });
            
            // B. WebGL 渲染用的地形纹理 (同步上传)
            // 此时 setupCanvases 已经执行过，radarRenderer 一定存在
            if (radarRenderer) {
                radarRenderer.loadTerrainTexture(img);
                console.log("WebGL Terrain Texture Loaded.");
            }
            if (dopplerRenderer) {
                dopplerRenderer.loadTerrainTexture(img);
                console.log("Doppler Terrain Texture Loaded.");
            }
        };

        // 4. 绘制初始地图 (不需要等图片加载完，先画出来)
        drawMap(mapSvg, mapProjection, state.world, {status: null, track: []}, {
            pressureSystems: state.pressureSystems,
            showPressureField: state.showPressureField,
            showHumidityField: state.showHumidityField,
            showSSTField: state.showSSTField,
            showShearField: DISPLAY_FEATURES.shear && state.showShearField,
            showPathForecast: state.showPathForecast,
            showWindRadii: state.showWindRadii,
            siteName: state.siteName,
            siteLon: state.siteLon,
            siteLat: state.siteLat,
            showPathPoints: state.showPathPoints,
            showWindField: state.showWindField,
            month: state.currentMonth,
            globalTemp: state.GlobalTemp,
            globalShear: state.GlobalShear,
        });
        window.dispatchEvent(new CustomEvent('storm:boot-progress', {
            detail: { value: 76, label: 'WARMING FIELD CACHE', detail: 'COMPILING PRESSURE CLOSURE' }
        }));
    });
    // 封装折叠/展开函数
    function toggleLeftPanel() {
        if (!leftContent) return;
        
        // 播放音效
        isLeftPanelCollapsed ? playToggleOn() : playToggleOff();
        
        isLeftPanelCollapsed = !isLeftPanelCollapsed;

        if (isLeftPanelCollapsed) {
            // 收缩
            leftContent.style.width = '0px';
            leftContent.style.opacity = '0';
            leftContent.style.paddingRight = '0'; 
            // 可选：添加一个小的提示音或视觉反馈
        } else {
            // 展开
            leftContent.style.width = ''; // 恢复 CSS 默认宽度
            leftContent.style.opacity = '100';
            leftContent.style.paddingRight = ''; 
        }
    }

    function updateTabUI() {
        [tabKt, tabHpa].forEach(btn => {
            btn.classList.remove('bg-cyan-600', 'text-white');
            btn.classList.add('text-slate-400');
        });
        const activeBtn = chartMode === 'kt' ? tabKt : tabHpa;
        activeBtn.classList.remove('text-slate-400');
        activeBtn.classList.add('bg-cyan-600', 'text-white');
    }

    let mapExportInProgress = false;
    function enrichExportModelWithTrackDiagnostics(model, cyclone, pressureHistory = [], siteHistory = []) {
        const sourceTrack = cyclone?.track;
        const hasAlignedTrack = Array.isArray(sourceTrack) && sourceTrack.length === model.points.length;
        const snapshots = Array.isArray(pressureHistory)
            ? pressureHistory.filter(snapshot => snapshot && Number.isFinite(snapshot.age))
                .sort((a, b) => a.age - b.age)
            : [];
        const hasSiteHistory = Array.isArray(siteHistory) && siteHistory.length > 0;
        const citySurfaceFriction = Object.fromEntries(ICWC_MAJOR_CITIES.map(city => {
            try {
                const status = getLandStatus(city.lon, city.lat);
                return [city.name, status?.isLand ? 0.78 : status?.isNearLand ? 0.89 : 1];
            } catch {
                return [city.name, 1];
            }
        }));
        if (!hasAlignedTrack && snapshots.length === 0 && !hasSiteHistory) {
            return { ...model, citySurfaceFriction };
        }
        const origin = model.points[0]?.timestamp;
        const snapshotForPoint = point => {
            if (!snapshots.length || !Number.isFinite(origin)) return null;
            const age = (point.timestamp - origin) / 3600000;
            return snapshots.reduce((closest, snapshot) =>
                Math.abs(snapshot.age - age) < Math.abs(closest.age - age) ? snapshot : closest);
        };
        return {
            ...model,
            // ATCF text intentionally stays operationally standard. These
            // extra fields remain in memory only for the optional export
            // city-impact annotations (R34 and circulation size).
            siteObservations: Array.isArray(siteHistory) ? siteHistory.slice() : [],
            citySurfaceFriction,
            cityPoints: model.points.map((point, index) => {
                const source = hasAlignedTrack ? sourceTrack[index] || [] : [];
                const snapshot = snapshotForPoint(point);
                // Reuse the immutable snapshot object so the atmosphere
                // sampler can retain its per-snapshot point cache.
                const systems = snapshot || null;
                const cityBackgroundPressures = systems
                    ? Object.fromEntries(ICWC_MAJOR_CITIES.map(city => {
                        try {
                            return [city.name, getSurfacePressureAt(city.lon, city.lat, systems)];
                        } catch {
                            return [city.name, 1013];
                        }
                    }))
                    : null;
                return {
                    ...point,
                    circulationSize: Number(source[5]),
                    r34: Array.isArray(source[7]) ? source[7].slice() : null,
                    isSubtropical: source[6] === true,
                    isExtratropical: source[4] === true,
                    cityBackgroundPressures
                };
            })
        };
    }

    async function downloadMapImage() {
        if (mapExportInProgress) return;
        mapExportInProgress = true;
        const wasDisabled = downloadTrackButton.disabled;
        downloadTrackButton.disabled = true;
        downloadTrackButton.setAttribute('aria-busy', 'true');
        const status = document.getElementById('map-export-status');
        status.textContent = '';
        try {
            // The text and parsed model are immutable snapshots across asynchronous resource loading.
            const raw = state.selectedHistoryCyclone && state.selectedHistoryTrackData
                ? state.selectedHistoryTrackData : bestTrackData.value;
            const model = parseExportTrack(raw);
            const sourceCyclone = state.selectedHistoryCyclone || state.cyclone;
            const pressureHistory = sourceCyclone?.pressureHistory || state.pressureHistory || [];
            const siteHistory = sourceCyclone?.siteHistory || state.siteHistory || [];
            const exportModel = enrichExportModelWithTrackDiagnostics(model, sourceCyclone, pressureHistory, siteHistory);
            const blob = await renderTrackExport(exportModel, { ...trackExportSettings });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            try {
                link.href = url;
                link.download = `map_${exportModel.identity.replace(/\s+/g, '')}_${new Date(exportModel.points[0].timestamp).toISOString().slice(0, 7).replace('-', '')}.png`;
                document.body.appendChild(link);
                link.click();
            } finally {
                link.remove();
                // Allow Safari to consume the download before releasing the Blob URL.
                setTimeout(() => URL.revokeObjectURL(url), 30000);
            }
        } catch (error) {
            console.error('Track image export failed:', error);
            status.textContent = error.name === 'AbortError'
                ? '字体或底图加载超时，请重试。'
                : `导出失败：${error.message || '请重试。'}`;
        } finally {
            mapExportInProgress = false;
            downloadTrackButton.disabled = wasDisabled;
            downloadTrackButton.removeAttribute('aria-busy');
        }
    }

    function downloadHistoryTrack() {
        if (state.selectedHistoryTrackData) {
            const blob = new Blob([state.selectedHistoryTrackData], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            // 尝试从第一行解析出名称来命名文件
            const fileNameMatch = state.selectedHistoryTrackData.split('\n')[0].match(/^(\S+), (\S+)/);
            const fileName = fileNameMatch ? `${fileNameMatch[1]}${fileNameMatch[2]}.txt` : 'history_track.txt';
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } else {
            alert("没有可下载的历史轨迹数据。");
        }
    }
    // --- 辅助函数 ---
    function updateToggleButtonVisual(button, isActive) {
        if (isActive) {
            // 高亮状态: 更亮的背景, 亮青色文字, 青色边框
            button.classList.remove('bg-slate-900', 'text-slate-300', 'border-slate-600', 'hover:text-cyan-400');
            button.classList.add('bg-slate-700', 'text-cyan-400', 'border-cyan-500', 'shadow-md', 'shadow-cyan-900/20');
        } else {
            // 默认状态: 深色背景, 灰色文字
            button.classList.add('bg-slate-900', 'text-slate-300', 'border-slate-600', 'hover:text-cyan-400');
            button.classList.remove('bg-slate-700', 'text-cyan-400', 'border-cyan-500', 'shadow-md', 'shadow-cyan-900/20');
        }
    }

    function changeSimulationSpeed(newInterval) {
        state.simulationSpeed = newInterval;
        
        // 更新状态栏显示（可选，给你一个视觉反馈）
        const speedMap = { 30: 'MAX (3x)', 90: 'FAST (2x)', 200: 'NORMAL (1x)' };
        const speedText = speedMap[newInterval] || `${newInterval}ms`;
        
        // 如果当前正在运行（非暂停，且已启动），立即应用新速度
        if (state.simulationInterval && !state.isPaused && state.cyclone.status === 'active') {
            clearInterval(state.simulationInterval);
            state.simulationInterval = setInterval(updateSimulation, state.simulationSpeed);
            // 临时显示速度提示
            const originalStatus = document.getElementById('status').textContent;
            document.getElementById('status').textContent = `SPEED CHANGED: ${speedText}`;
            setTimeout(() => {
                // 如果还在运行，恢复原始状态文本
                if(state.simulationInterval) document.getElementById('status').textContent = "模拟进行中...";
            }, 1000);
        }
    }

    function getAtcfTypeCode(windKts, isExtratropical, isSubtropical) {
        if (isSubtropical) {
            if (windKts < 34) return 'SD';
            return 'SS';
        }
        if (isExtratropical) return 'EX';
        if (windKts >= 130) return 'ST';
        if (windKts >= 64) return 'TY';
        if (windKts >= 34) return 'TS';
        if (windKts >= 24) return 'TD';
        if (windKts > 0) return 'DB';
        return 'LO';
    }

    function formatBestTrack(track, cycloneInfo, simulationCount) {
        const basinMap = { 'WPAC': 'WP', 'EPAC': 'EP', 'NATL': 'AL', 'NIO': 'IO', 'SHEM': 'SH', 'SIO': 'SH', 'SATL': 'SL' };
        const basin = basinMap[cycloneInfo.basin] || 'WP';
        const cycloneNum = String(simulationCount).padStart(2, '0');
        const startDate = simulationDate(cycloneInfo);

        return track.map((point, index) => {
            const currentDate = new Date(startDate);
            currentDate.setUTCHours(currentDate.getUTCHours() + index * 3);

            const dateString = `${currentDate.getUTCFullYear()}${String(currentDate.getUTCMonth() + 1).padStart(2, '0')}${String(currentDate.getUTCDate()).padStart(2, '0')}${String(currentDate.getUTCHours()).padStart(2, '0')}`;
            const lat = `${Math.round(point[1] * 10)}N`;
            const normalizedLon = ((point[0] + 180) % 360 + 360) % 360 - 180;
            const lonValue = Math.abs(normalizedLon);
            const lonHemi = normalizedLon < 0 ? 'W' : 'E';
            const lon = `${Math.round(lonValue * 10)}${lonHemi}`;
            const vmax = Math.round(point[2]);
            const circulationSize = point[5]; 
            let mslp;
            if (point[10] !== undefined) {
                mslp = point[10];
            } else {
                const circulationSize = point[5] || 300;
                const envP = getSurfacePressureAt(point[0], point[1], state.pressureSystems);
                mslp = windToPressure(vmax, circulationSize, cycloneInfo.basin, envP);
            }
            
            const type = getAtcfTypeCode(vmax, point[4], point[6]);

            return [
                basin.padEnd(2, ' '), cycloneNum.padStart(3, ' '), ` ${dateString}`, ' 00', ' BEST', '   0',
                lat.padStart(6, ' '), lon.padStart(7, ' '), String(vmax).padStart(4, ' '),
                String(mslp).padStart(5, ' '), ` ${type}`,
            ].join(',');
        }).join('\n');
    }

    function drawRadarScope() {
        // 1. 基础检查
        if ((!state.radarMode && !state.dopplerMode) || state.siteLon == null || state.siteLat == null) {
            if (radarCanvas) radarCanvas.classList.add('hidden');
            if (radarOverlayCanvas) radarOverlayCanvas.classList.add('hidden');
            lastRadarRenderKey = '';
            return;
        }
        if (!radarRenderer || !dopplerRenderer) return;
        radarCanvas.classList.remove('hidden');
        radarOverlayCanvas.classList.remove('hidden');

        // 2. 确定位置 (UI 层需要全屏分辨率)
        const { width, height } = mapContainer.node().getBoundingClientRect();
        if (radarOverlayCanvas.width !== width) {
            radarOverlayCanvas.width = width;
            radarOverlayCanvas.height = height;
        }

        // Radar shader time is tied to simulation age, not wall-clock time.
        // Re-rendering an identical 256x256 field on every display frame only
        // competes with the satellite and wind GPU passes. Position, mode,
        // atmosphere and viewport changes all invalidate this compact key.
        const projectionCenter = mapProjection.center();
        const projectionRotation = mapProjection.rotate();
        const radarRenderKey = [
            state.radarMode ? 1 : 0,
            state.dopplerMode ? 1 : 0,
            state.dopplerMode ? dopplerRenderer.windFieldRevision : 0,
            state.siteLon,
            state.siteLat,
            state.cyclone?.age,
            state.cyclone?.lon,
            state.cyclone?.lat,
            projectionCenter[0],
            projectionCenter[1],
            projectionRotation[0],
            width,
            height
        ].join('|');
        if (radarRenderKey === lastRadarRenderKey) return;
        lastRadarRenderKey = radarRenderKey;

        const centerProj = mapProjection([state.siteLon, state.siteLat]);
        if (!centerProj) return;
        const [cx, cy] = centerProj;

        // Equidistant-cylindrical map: a physical radar circle projects to an
        // east-west stretched ellipse away from the equator. Use the same
        // km/degree conversion as both radar shaders so the eye overlays the
        // track and wind center exactly.
        const lonKmPerDegree = 111 * Math.max(
            0.1,
            Math.cos(state.siteLat * Math.PI / 180)
        );
        const eastRefPoint = mapProjection([
            state.siteLon + 460 / lonKmPerDegree,
            state.siteLat
        ]);
        const northRefPoint = mapProjection([
            state.siteLon,
            state.siteLat + 460 / 111
        ]);
        const radiusXPx = Math.abs(eastRefPoint[0] - cx);
        const radiusYPx = Math.abs(northRefPoint[1] - cy);

        // ============================
        // A. 调用 WebGL 渲染 (极速)
        // ============================
        // WebGL 不需要擦除，它每一帧都是重画覆盖
        // 我们只需要更新 Canvas 的 CSS 位置，让它正好对准雷达区域
        
        // 技巧：我们不全屏渲染 WebGL，而是把 WebGL Canvas 作为一个小贴纸，定位到雷达区域
        radarCanvas.style.width = `${radiusXPx * 2}px`;
        radarCanvas.style.height = `${radiusYPx * 2}px`;
        radarCanvas.style.left = `${cx - radiusXPx}px`;
        radarCanvas.style.top = `${cy - radiusYPx}px`;
        const activeCyclone = (state.cyclone && state.cyclone.status === 'active') ? state.cyclone : null;
        if (state.dopplerMode) {
            // 多普勒模式：渲染径向速度
            dopplerRenderer.render(state, 256, 256);
            radarCanvas.style.opacity = "0.75"; // 多普勒模式稍微不透明一点，以便看清颜色
        } else if (state.radarMode) {
            // 基本反射率模式
            const rawHum = calculateBackgroundHumidity(
                state.siteLon, 
                state.siteLat, 
                state.pressureSystems, 
                state.currentMonth, 
                activeCyclone, 
                state.GlobalTemp
            );
            const normalizedHum = rawHum / 100.0;
            radarRenderer.render(state, 256, 256, normalizedHum);
            radarCanvas.style.opacity = "0.65";
        }

        // ============================
        // B. 绘制 UI (扫描线) - 使用 2D Canvas
        // ============================
        const ctx = radarOverlayCtx;
        
        // [修复] 强制重置变换矩阵，防止之前的 clip() 或变换导致清除不彻底
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        
        // 清除整个画布
        ctx.clearRect(0, 0, width, height);
        
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 1.5;
        
        // 裁剪区域 (只在圆内显示扫描线)
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(cx, cy, radiusXPx, radiusYPx, 0, 0, Math.PI * 2);
        ctx.clip(); // 限制绘制区域

        // 圆圈
        ctx.beginPath();
        ctx.ellipse(cx, cy, radiusXPx, radiusYPx, 0, 0, Math.PI * 2); 
        ctx.stroke();
        
        ctx.restore();
    }
    // --- UI更新函数 ---
    // [新增] 显示突发新闻 Banner
    function triggerNewsBanner(headlineHTML, subText, currentAge, currentMonth, type = 'ORANGE') {
        const container = document.getElementById('news-feed-container');

        // Category cues are emitted once by the simulation step, not by banners.
        if (type === 'RED') {
            playAlert();
        } else if (type !== 'ORANGE' && type !== 'PURPLE') {
            playClick(); // 默认回退
        }
        if (!container) return;

        // 1. 计算时间字符串
        const currentDate = simulationDate(state.cyclone || {currentMonth}, currentAge);
        
        const m = String(currentDate.getUTCMonth() + 1).padStart(2, '0');
        const d = String(currentDate.getUTCDate()).padStart(2, '0');
        const h = String(currentDate.getUTCHours()).padStart(2, '0');
        const dateStr = `${m}/${d} ${h}Z`;

        // 2. 设定颜色主题
        let themeColor = '#ea580c'; // 默认橙色 (Typhoon Upgrade)
        let borderColor = 'border-[#ea580c]';
        
        if (type === 'RED') { // 红色 (警报/进入范围)
            themeColor = '#dc2626'; 
            borderColor = 'border-[#dc2626]';
        }

        else if (type === 'PURPLE') {
            themeColor = '#a855f7'; // Purple-500 (亮紫色)
            borderColor = 'border-[#a855f7]';
        }

        // 3. 创建 DOM 元素
        const newsItem = document.createElement('div');
        // 初始状态：translate-x-full (在屏幕右侧外)
        newsItem.className = `transform translate-x-full transition-transform duration-500 ease-out flex flex-col items-end font-mono shadow-2xl pointer-events-auto`;
        
        // 构建内部 HTML (保持之前的 Newsletter 风格)
        newsItem.innerHTML = `
            <div class="text-white px-6 py-2 flex items-center gap-3 shadow-lg" style="background-color: ${themeColor}">
                <h2 class="text-xl md:text-2xl font-black uppercase tracking-tighter italic leading-none drop-shadow-md text-right">
                    ${headlineHTML}
                </h2>
                <div class="w-2 h-6 bg-white animate-pulse"></div>
            </div>
            <div class="bg-black/90 text-slate-300 px-6 py-1.5 border-r-4 ${borderColor} flex justify-between items-center gap-4 min-w-[300px] shadow-lg w-full">
                <span class="text-[10px] md:text-xs font-mono text-orange-400">
                    ${dateStr}
                </span>
                <span class="text-[10px] md:text-xs font-bold tracking-widest uppercase text-slate-400 text-right">
                    ${subText}
                </span>
            </div>
        `;

        // 4. 插入容器 (Append 实现向下堆叠)
        container.appendChild(newsItem);

        // 5. 触发进场动画 (需要下一帧执行，否则 transition 不生效)
        requestAnimationFrame(() => {
            newsItem.classList.remove('translate-x-full');
        });

        // 6. 设置自动销毁
        // 停留 6 秒后滑出
        setTimeout(() => {
            newsItem.classList.add('translate-x-full');
            
            // 等待滑出动画结束后(500ms)，从 DOM 中移除
            setTimeout(() => {
                if (newsItem.parentNode) {
                    newsItem.parentNode.removeChild(newsItem);
                }
            }, 500); // 对应 duration-500
        }, 6000);
    }

    // These four numeric elements have no CSS animations. Retain only the
    // animation we create: getAnimations() synchronizes pending DOM styles
    // after every numeric write, even when there is nothing left to cancel.
    const mechanicalAnimations = new WeakMap();
    function setMechanicalValue(element, value) {
        if (!element) return;
        const nextValue = String(value);
        if (element.dataset.mechanicalValue === nextValue) return;
        element.dataset.mechanicalValue = nextValue;
        element.textContent = nextValue;
        element.classList.add('mechanical-number');
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        mechanicalAnimations.get(element)?.cancel();
        mechanicalAnimations.set(element, element.animate([
            { transform: 'perspective(180px) translateY(-0.42em) rotateX(-72deg)', opacity: 0.12, filter: 'brightness(1.8)' },
            { offset: 0.58, transform: 'perspective(180px) translateY(0.08em) rotateX(9deg)', opacity: 1, filter: 'brightness(1.25)' },
            { transform: 'perspective(180px) translateY(0) rotateX(0deg)', opacity: 1, filter: 'brightness(1)' }
        ], { duration: 360, easing: 'cubic-bezier(.2,.8,.2,1)' }));
    }

    function queueSatelliteSnapshot(cyclone) {
        if (!cyclone || cyclone.age % 6 !== 0) return;

        const cache = cyclone.satelliteCache || [];
        if (cache.some(snapshot => snapshot.age === cyclone.age)) return;

        let pending = pendingSatelliteSnapshots.get(cyclone);
        if (!pending) {
            pending = new Map();
            pendingSatelliteSnapshots.set(cyclone, pending);
        }
        if (pending.has(cyclone.age)) return;

        const age = cyclone.age;
        const snapshotStartedAt = snapshotProfiling ? performance.now() : 0;
        const snapshotJob = getSatelliteSnapshot()
            .then(snapshotData => {
                if (!snapshotData) return;

                // A restart may replace state.cyclone while the browser is
                // encoding the previous frame. Never attach an old frame to
                // the new run, and release its Blob URL immediately.
                if (state.cyclone !== cyclone) {
                    releaseSatelliteSnapshot(snapshotData);
                    return;
                }

                const liveCache = cyclone.satelliteCache || (cyclone.satelliteCache = []);
                if (liveCache.some(snapshot => snapshot.age === age)) {
                    releaseSatelliteSnapshot(snapshotData);
                    return;
                }

                liveCache.push({
                    age,
                    img: snapshotData,
                    timestamp: Date.now()
                });

                if (liveCache.length > MAX_SATELLITE_SNAPSHOTS) {
                    const removed = liveCache.splice(
                        0,
                        liveCache.length - MAX_SATELLITE_SNAPSHOTS
                    );
                    removed.forEach(snapshot => releaseSatelliteSnapshot(snapshot.img));
                }
            })
            .catch(error => {
                console.warn('Satellite snapshot capture failed:', error);
            })
            .finally(() => {
                if (snapshotProfiling) {
                    console.info(`[satellite-snapshot-profile] ${JSON.stringify({
                        age,
                        duration: Math.round((performance.now() - snapshotStartedAt) * 10) / 10
                    })}`);
                }
                pending.delete(age);
            });
        pending.set(age, snapshotJob);
    }

    function updateInfoPanel() {
        if (!state.selectedHistoryCyclone) {
            intensityChartCyclone = state.cyclone;
            refreshIntensityChart();
        }
        const cat = getCategory(state.cyclone.intensity, state.cyclone.isTransitioning, state.cyclone.isExtratropical, state.cyclone.isSubtropical);
        document.getElementById('simulationTime').textContent = `SIM T+${state.cyclone.age}H`;
        document.getElementById('latitude').textContent = `${state.cyclone.lat.toFixed(1)}°N`;
        document.getElementById('longitude').textContent = `${state.cyclone.lon.toFixed(1)}°E`;
        const intensityElement = document.getElementById('intensity');
        setMechanicalValue(document.getElementById('intensity-kph'), knotsToKph(state.cyclone.intensity));
        setMechanicalValue(document.getElementById('intensity-mph'), knotsToMph(state.cyclone.intensity));
        intensityElement.style.color = cat.color;
        // The model state is the canonical live value. Only the initial frame
        // needs a fallback before updateCycloneState has written it.
        const centralPressure = Number.isFinite(state.cyclone.centralPressure)
            ? state.cyclone.centralPressure
            : windToPressure(
                state.cyclone.intensity,
                state.cyclone.circulationSize,
                state.cyclone.basin,
                getSurfacePressureAt(state.cyclone.lon, state.cyclone.lat, state.pressureSystems)
            );
        setMechanicalValue(document.getElementById('pressure'), centralPressure.toFixed(0));
        const categoryElement = document.getElementById('category');
        categoryElement.textContent = cat.name;
        categoryElement.style.color = cat.color;
        categoryElement.style.borderColor = `${cat.color}80`;
        categoryElement.style.backgroundColor = `${cat.color}1f`;
        categoryElement.style.boxShadow = `0 0 12px ${cat.color}24`;
        document.getElementById('ace').textContent = state.cyclone.ace.toFixed(2);
        document.getElementById('direction').textContent = `${directionToCompass(state.cyclone.direction)}`;
    setMechanicalValue(document.getElementById('speed'), `${state.cyclone.speed.toFixed(0)} kts`);
        const eyewallStructure = getEyewallStructure(state.cyclone);
        const dominantRmw = Number.isFinite(eyewallStructure?.dominantRmw)
            ? eyewallStructure.dominantRmw
            : state.cyclone.rmw;
        // Keep physical radii separate from peak identity across ERC. One
        // sample per model step makes a reported jump inspectable without
        // smoothing it away or applying a display-only radius transform.
        const rmwDiagnostics = state.cyclone.rmwDiagnostics || [];
        if (rmwDiagnostics.at(-1)?.age !== state.cyclone.age) {
            state.cyclone.rmwDiagnostics = [...rmwDiagnostics.slice(-63), {
                age: state.cyclone.age,
                rmw: state.cyclone.rmw,
                dominantRmw,
                innerRmw: eyewallStructure?.innerRmw,
                outerRmw: eyewallStructure?.outerRmw,
                innerPeak: eyewallStructure?.innerPeak,
                outerPeak: eyewallStructure?.outerPeak,
                ercState: state.cyclone.ercState,
                isERCActive: state.cyclone.isERCActive
            }];
        }
        const rmwStatus = document.getElementById('rmwStatus');
        rmwStatus.classList.toggle('hidden', state.cyclone.isExtratropical);
        rmwStatus.textContent = state.cyclone.isExtratropical
            ? ''
            : Number.isFinite(dominantRmw)
                ? `RMW @ ${Math.round(dominantRmw)} km`
                : 'RMW @ -- km';
        const isLand = state.cyclone.isLand || false;
        const currentSST = createOceanFieldSampler(state.currentMonth, state.GlobalTemp,
            state.cyclone.oceanHeatDistribution ?? state.heatDistribution, state.cyclone)
            (state.cyclone.lat, state.cyclone.lon).sstC;
        const basin = state.cyclone.basin || 'WPAC';
        const cycloneNum = String(state.simulationCount).padStart(2, '0');
        const intensity = state.cyclone.intensity;
        const isExtra = state.cyclone.isExtratropical;
        const isSub = state.cyclone.isSubtropical;
        let effectiveHumidity = 75;
        let peakWindSoFar = 0;
        if (state.cyclone.track) {
            state.cyclone.track.forEach(p => {
                if (p[2] > peakWindSoFar) peakWindSoFar = p[2];
            });
        }
        
        // 直接使用气旋对象里的名字，不再重新查表
        const stormName = state.cyclone.name ? state.cyclone.name.toUpperCase() : "UNKNOWN";
        let statusText = "";

        // 判定逻辑：只要巅峰风速达到过 34kt，或者已经获得命名(named标志位)
        if (peakWindSoFar >= 34 || state.cyclone.named) {
            // 已获得命名
            if (state.cyclone.intensity >= 34) {
                // 当前仍是风暴级以上 -> 显示名字 (或 EX-名字)
                if (state.cyclone.isExtratropical) statusText = `EX-${stormName}`;
                else statusText = stormName;
            } else {
                // 当前已减弱为低压，但保留名字 -> 显示 TD 名字
                if (state.cyclone.isExtratropical) statusText = `EX-${stormName}`; 
                else if (state.cyclone.isSubtropical) statusText = `SD ${stormName}`;
                else statusText = `TD ${stormName}`;
            }
        } else {
            // 尚未获得命名 -> 显示编号 (TD 01)
            if (state.cyclone.isExtratropical) statusText = `EX ${cycloneNum}`;
            else if (state.cyclone.isSubtropical) statusText = `SD ${cycloneNum}`;
            else statusText = `TD ${cycloneNum}`;
        }
        document.getElementById('status').textContent = statusText;

        if (state.cyclone && state.pressureSystems) {
            const samplingRadiusDeg = state.cyclone.circulationSize * 0.005;
            let envHumiditySum = 0;
            let minEnvHumidity = 60;
            const samplePoints = 12;

            for (let i = 0; i < samplePoints; i++) {
                const angleRad = (i / samplePoints) * 2 * Math.PI;
                // 计算采样点
                const sampleLon = state.cyclone.lon + samplingRadiusDeg * Math.cos(angleRad) / Math.cos(state.cyclone.lat * Math.PI / 180);
                const sampleLat = state.cyclone.lat + samplingRadiusDeg * Math.sin(angleRad);
                
                // 计算该点的背景湿度 (传入 globalTemp 计算 SST)
                const val = calculateBackgroundHumidity(
                    sampleLon, 
                    sampleLat, 
                    state.pressureSystems, 
                    state.currentMonth, 
                    state.cyclone,
                    state.GlobalTemp
                );
                
                envHumiditySum += val;
                
                if (val < minEnvHumidity) {
                    minEnvHumidity = val;
                }
            }
            
            const avgEnvHumidity = envHumiditySum / samplePoints;

            // B. 加权计
            effectiveHumidity = (minEnvHumidity * 0.4) + (avgEnvHumidity * 0.6);
        }

        // 3. 调用 updateSatelliteView (传入计算好的 effectiveHumidity)
        updateSatelliteView(
            state.cyclone.intensity, 
            state.cyclone.age, 
            state.cyclone.lat, 
            state.cyclone.isExtratropical, 
            state.cyclone.isSubtropical,
            isLand,
            currentSST,
            effectiveHumidity, // <--- 使用加权后的湿度
            state.cyclone.isERCActive && Number.isFinite(state.cyclone.ercInnerRmw)
                ? state.cyclone.ercInnerRmw
                : state.cyclone.rmw,
            state.cyclone.circulationSize,
            Number.isFinite(state.cyclone.totalShear) ? state.cyclone.totalShear : 0
        );
        
        queueSatelliteSnapshot(state.cyclone);
    }

    function updateMapInfoBox() {
        const cat = getCategory(state.cyclone.intensity, state.cyclone.isTransitioning, state.cyclone.isExtratropical, state.cyclone.isSubtropical);
        document.getElementById('map-info-time').textContent = `T+${state.cyclone.age}h`;
        const mapInfoIntensity = document.getElementById('map-info-intensity');
        mapInfoIntensity.textContent = `${cat.shortName} - ${state.cyclone.intensity.toFixed(0)}KT`;
        mapInfoIntensity.style.color = cat.color;
        const pVal = Number.isFinite(state.cyclone.centralPressure)
            ? state.cyclone.centralPressure
            : windToPressure(
                state.cyclone.intensity,
                state.cyclone.circulationSize,
                state.cyclone.basin,
                getSurfacePressureAt(state.cyclone.lon, state.cyclone.lat, state.pressureSystems)
            );
        
        document.getElementById('map-info-movement').textContent = `${pVal.toFixed(0)}hPa ${directionToCompass(state.cyclone.direction)} ${state.cyclone.speed.toFixed(0)}KT`;
    }

    function throttle(func, delay) {
        let lastCall = 0;
        return function(...args) {
            const now = performance.now();
            if (now - lastCall >= delay) {
                lastCall = now;
                return func.apply(this, args);
            }
        };
    }

    const throttledUpdateInfoPanel = throttle(updateInfoPanel, 40);
    const throttledUpdateMapInfoBox = throttle(updateMapInfoBox, 40);
    
    function updateSiteGeoCache() {
        const lon = state.siteLon;
        const lat = state.siteLat;

        // 坐标未变则直接跳过
        if (lon === _cachedSiteLon && lat === _cachedSiteLat) return;

        _cachedSiteLon = lon;
        _cachedSiteLat = lat;

        if (!state.world || lon == null || lat == null) {
            _cachedSiteIsLand = false;
            _cachedSiteIsNearShore = false;
            return;
        }

        // ✅ 利用已有的 checkLandFast（visualization.js 已有，直接复用）
        // 如果 checkLandFast 可在 main.js 里访问（通过 import），直接用：
        _cachedSiteIsLand = checkLandWrapper(lon, lat);

        if (!_cachedSiteIsLand) {
            const nearThreshold = 0.1;
            _cachedSiteIsNearShore = state.world.features.some(feature => {
                const geometry = feature.geometry;
                const polygons = geometry.type === 'Polygon'
                    ? [geometry.coordinates]
                    : geometry.coordinates;
                return polygons.some(poly =>
                    poly.some(ring =>
                        ring.some(vertex => {
                            let dx = Math.abs(vertex[0] - lon);
                            if (dx > 180) dx = 360 - dx;
                            const dy = Math.abs(vertex[1] - lat);
                            return dx < nearThreshold && dy < nearThreshold;
                        })
                    )
                );
            });
        } else {
            _cachedSiteIsNearShore = false;
        }
    }

    function updateStateSiteData() {
        if (state.siteLon != null && state.siteLat != null) {
            
            // 1. 获取原始风场
            // 注意：即使气旋未生成，这里也能算出背景风场
            let vec = getWindVectorAt(state.siteLon, state.siteLat, state.currentMonth, state.cyclone, state.pressureSystems);
            
            if (state.world) {
                if (_cachedSiteIsLand) {
                    vec.magnitude *= 0.78;
                    vec.u *= 0.78;
                    vec.v *= 0.78;
                } else {
                    // 近岸判定 (复用之前的逻辑)
                    const nearThreshold = 0.1; // 约50km
                    const isNearShore = state.world.features.some(feature => {
                        const geometry = feature.geometry;
                        const polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates;
                        return polygons.some(poly => poly.some(ring => ring.some(vertex => {
                            let dx = Math.abs(vertex[0] - state.siteLon);
                            if (dx > 180) dx = 360 - dx; 
                            const dy = Math.abs(vertex[1] - state.siteLat);
                            return dx < nearThreshold && dy < nearThreshold;
                        })));
                    });

                    if (_cachedSiteIsNearShore) {
                        vec.magnitude *= 0.89; 
                        vec.u *= 0.89;
                        vec.v *= 0.89;
                    }
                }
            }
            
            const speedKt = Math.round(vec.magnitude + Math.random());

            // 3. 计算风向字符串
            const flowAngleMath = Math.atan2(-vec.v, vec.u) * (180 / Math.PI);
            let windDir = (flowAngleMath + 250) % 360;
            if (windDir < 0) windDir += 360;
            const dirText = directionToCompass(windDir);

            // [新增] 计算雷达反射率并判断天气图标
            const dbz = calculateRadarDbz(state.siteLon, state.siteLat, state);
            
            let weatherIcon = '<i class="fa-solid fa-sun text-yellow-500"></i>'; // 默认晴天
            const isNight = false; // 简化的昼夜逻辑，你可以扩展它

            // 简单的天气判定逻辑
            if (dbz >= 50) {
                weatherIcon = '<i class="fa-solid fa-cloud-bolt text-yellow-500"></i>';
            } else if (dbz >= 35) {
                weatherIcon = '<i class="fa-solid fa-cloud-showers-heavy text-blue-500"></i>'; // 大雨
            } else if (dbz >= 15) {
                weatherIcon = '<i class="fa-solid fa-cloud-rain text-blue-400"></i>'; // 中雨
            } else if (dbz >= 5) {
                weatherIcon = '<i class="fa-solid fa-cloud text-slate-400"></i>'; // 阴天/多云
            } else {
                weatherIcon = '<i class="fa-solid fa-sun text-yellow-500"></i>';
            }

            // 构建包含 HTML 的 Label
            // 使用 span 调整间距
            const label = `${weatherIcon} <span style="margin-left:2px;">${dirText}</span> / ${speedKt}KT`;
            let localPressure = 1010; // 默认值
            // 1. 获取当前模拟时间的 UTC 小时数
            // state.cyclone.age 是模拟开始后的累计小时数
            // 假设模拟通常从 00Z 或 06Z 开始并不重要，关键是相对变化
            const currentSimHour = (state.cyclone && state.cyclone.age) ? state.cyclone.age : 0;
            
            // 2. 计算当地平太阳时 (LMT)
            // 经度每 15 度相差 1 小时
            const localHour = (currentSimHour + state.siteLon / 15) % 24;

            // 3. 计算半日潮 (Semi-diurnal Tide)
            // 规律：每天有两个高点 (10:00, 22:00) 和两个低点 (04:00, 16:00)
            // 使用余弦波模拟：Cos((Hour - 10) / 12 * 2π)
            // 当 Hour=10 时，Cos(0)=1 (最高)；当 Hour=16 时，Cos(π)=-1 (最低)
            
            // 振幅纬度修正：赤道最强 (~1.6 hPa)，两极最弱 (~0 hPa)
            const latFactor = Math.max(0, Math.cos(state.siteLat * Math.PI / 180));
            const tideAmplitude = 1.6 * latFactor; 
            
            const diurnalBias = tideAmplitude * Math.cos(((localHour - 10) / 12) * 2 * Math.PI);

            // 4. 叠加微小随机噪声 (模拟测量误差/微湍流)
            const microNoise = (Math.random() - 0.5) * 0.2;
            const Pn = getSurfacePressureAt(state.siteLon, state.siteLat, state.pressureSystems);
            if (state.cyclone && state.cyclone.status === 'active') {
                const distKm = calculateDistance(state.cyclone.lat, state.cyclone.lon, state.siteLat, state.siteLon);
                const Rm = 10 + state.cyclone.circulationSize * 0.25;
                const centerEnvP = getSurfacePressureAt(state.cyclone.lon, state.cyclone.lat, state.pressureSystems);
                const Pc = windToPressure(state.cyclone.intensity, state.cyclone.circulationSize, state.cyclone.basin || 'WPAC', centerEnvP);
    
                // 基础气压 (Holland 模型)
                const baseP = Pc + (Pn - Pc) * Math.exp(-Rm / Math.max(1, distKm));
                
                // 叠加潮汐修正
                localPressure = baseP + diurnalBias + microNoise;
            } else {
                localPressure = Pn + diurnalBias + microNoise;
            }

            // 4. 更新 State
            state.currentSiteData = {
                u: vec.u,
                v: vec.v,
                magnitude: vec.magnitude,
                displaySpeed: speedKt,
                direction: dirText,
                label: label, // 现在这是 HTML 字符串
                dbz: dbz,     // 保存 dBZ 数值备用
                pressure: localPressure,
                isSelected: state.isSiteSelected
            };
        } else {
            state.currentSiteData = null;
        }
    }

    // --- 核心模拟循环 ---

        function updateSimulation() {
            // A frame queued by the previous run may fire during the new
            // run's initial advisory. Do not advance it before startup commits.
            if (state.cyclone === initializingCyclone) return;
            if (simulationStepInFlight) {
                // Coalesce timer pressure into exactly one pending model step.
                // The next step starts after the current Worker result commits,
                // preserving chronological order without overlapping updates.
                simulationStepQueued = true;
                return;
            }
            simulationStepInFlight = true;
            Promise.resolve(runSimulationStep())
                .catch(error => {
                    console.error('Simulation step failed:', error);
                    clearInterval(state.simulationInterval);
                    state.simulationInterval = null;
                    state.isPaused = true;
                    document.getElementById('status').textContent = '模拟计算发生错误';
                })
                .finally(() => {
                    simulationStepInFlight = false;
                    if (simulationStepQueued) {
                        simulationStepQueued = false;
                        if (state.simulationInterval && !state.isPaused) {
                            requestAnimationFrame(updateSimulation);
                        }
                    }
                });
        }

	    async function runSimulationStep() {
        const profileStartedAt = simulationStepProfiling ? performance.now() : 0;
        const profileMarks = simulationStepProfiling ? {} : null;
        const profileMark = label => {
            if (profileMarks) profileMarks[label] = performance.now() - profileStartedAt;
        };
        const steppingCyclone = state.cyclone;
        await advisoryQueue.waitForCapacity(steppingCyclone);
        profileMark('forecastBackpressure');
        if (state.cyclone !== steppingCyclone) return;
        if (state.cyclone.status !== 'active') {
            // Final history/products must include every issued advisory, even
            // when the terminal model step outruns the forecast worker.
            await advisoryQueue.drain(steppingCyclone);
            if (state.cyclone !== steppingCyclone) return;
            clearInterval(state.simulationInterval);
            state.simulationInterval = null;
            state.isPaused = false;

            // Do not clone the final history item while an asynchronous
            // satellite encode is still in flight. The normal simulation
            // loop remains non-blocking; only this one terminal save waits
            // for already-requested frames to finish.
            const pendingSnapshots = pendingSatelliteSnapshots.get(state.cyclone);
            if (pendingSnapshots?.size && !deferredSatelliteFinalizations.has(state.cyclone)) {
                const finalizingCyclone = state.cyclone;
                deferredSatelliteFinalizations.add(finalizingCyclone);
                Promise.all(pendingSnapshots.values()).then(() => {
                    deferredSatelliteFinalizations.delete(finalizingCyclone);
                    if (state.cyclone === finalizingCyclone) updateSimulation();
                });
                return;
            }
            
            // --- 变量统一区域 (彻底解决命名混乱) ---
            const basinId = state.cyclone.basin || basinSelector.value || 'WPAC';
            const cycloneInfo = {
                basin: basinId,
                month: state.currentMonth,
                year: state.cyclone.startYear || new Date().getUTCFullYear(),
                startMonth: state.cyclone.startMonth,
                startDay: state.cyclone.startDay
            };
            
            // 生成最佳路径文本
            const bestTrackText = formatBestTrack(state.cyclone.track, cycloneInfo, state.simulationCount);
            
            // 解析简写代码 (用于显示编号), 例如 "WP"
            const firstLine = bestTrackText.split('\n')[0];
            const basinCode = firstLine.split(',')[0].trim(); 
            const cycloneNumStr = String(state.simulationCount).padStart(2, '0');
            
            // -------------------------------------

            // 1. 遍历轨迹计算极值 (Peak Wind & Min Pressure)
            let peakWind = 0;
            let minPressure = 9999;
            state.cyclone.track.forEach(point => {
                const intensity = point[2];
                let pressure;
                if (point[10] !== undefined && point[10] !== null) {
                    pressure = point[10];
                } else {
                    // 兼容旧存档的回退逻辑 (只有读取旧版存档时才会执行这里)
                    const circulationSize = point[5] || 300;
                    // 注意：事后反算无法获取当时的环境气压，只能用默认值，这是造成不一致的根源
                    // 但对于新模拟，point[10] 一定存在，所以不会进这里
                    pressure = windToPressure(intensity, circulationSize, basinId); 
                }

                if (intensity > peakWind) peakWind = intensity;
                if (pressure < minPressure) minPressure = pressure;
            });

            // 2. 获取名字 (使用 basinId 查表)
            const cycloneNum = String(state.simulationCount).padStart(2, '0');
            const stormName = state.cyclone.name ? state.cyclone.name.toUpperCase() : "UNKNOWN";
            let statusText = "";

            // 逻辑与 updateInfoPanel 完全一致
            if (peakWind >= 34 || state.cyclone.named) {
                if (state.cyclone.intensity >= 34) {
                    if (state.cyclone.isExtratropical) statusText = `EX-${stormName}`;
                    else statusText = stormName;
                } else {
                    if (state.cyclone.isExtratropical) statusText = `EX-${stormName}`;
                    else if (state.cyclone.isSubtropical) statusText = `SD ${stormName}`;
                    else statusText = `TD ${stormName}`;
                }
            } else {
                if (state.cyclone.isExtratropical) statusText = `EX ${cycloneNum}`;
                else if (state.cyclone.isSubtropical) statusText = `SD ${cycloneNum}`;
                else statusText = `TD ${cycloneNum}`;
            }
            // 更新 UI
            document.getElementById('status').textContent = statusText;
            document.getElementById('map-info-box').classList.add('hidden');
            
            // 重置按钮状态
            pauseButton.disabled = true;
            pauseButton.innerHTML = '<i class="fa-solid fa-pause text-xs"></i>';
            monthSelector.disabled = false;
            basinSelector.disabled = false;
            globalTempSlider.disabled = false;
            heatDistributionSlider.disabled = false;
            globalShearSlider.disabled = false;
            observationSiteSelector.setLocked(false);
            customLonInput.disabled = false;
            customLatInput.disabled = false;

            // 4. 创建最终统计对象 (使用 basinCode 组合编号, 如 "WP 01")
            const finalStats = {
                number: `${basinCode} ${cycloneNumStr}`,
                peakWind: Math.round(peakWind),
                minPressure: Math.round(minPressure),
                ace: state.cyclone.ace.toFixed(2)
            };
            state.lastFinalStats = finalStats;

            // 5. 绘图
            // Use the cyclone's actual basin so the product code and rendering
            // stay aligned with a forced spawn outside the selected menu basin.
            drawFinalPath(mapSvg, mapProjection, state.cyclone, state.world, tooltip, state.siteName, state.siteLon, state.siteLat, state.showPathPoints, finalStats, basinId, state.pressureSystems, state.showWindField);
            requestRedraw();
            
            showIntensityDrawer(state.cyclone);

            bestTrackData.value = bestTrackText;
            bestTrackContainer.classList.remove('hidden');
            copyTrackButton.textContent = "复制数据";

            // 6. 保存历史记录
            try {
                const totalHours = state.cyclone.age;
                const peakIntensityKt = Math.round(peakWind);
                
                // 历史列表显示的名称
                const historyName = `${statusText} (${basinCode} ${cycloneNumStr}) - T+${totalHours}h, Peak ${peakIntensityKt}kt`;
                const cycloneClone = { ...state.cyclone };
                const satCacheRef = cycloneClone.satelliteCache;
                delete cycloneClone.satelliteCache;
                const cycloneDataDeep = JSON.parse(JSON.stringify(cycloneClone));
                if (satCacheRef) {
                    cycloneDataDeep.satelliteCache = satCacheRef;
                }
                state.history.push({ 
                    name: historyName, 
                    cycloneData: cycloneDataDeep,
                    atcfData: bestTrackText,
                    // Atmospheric snapshots are immutable Worker results.
                    // Copy only the list container instead of serializing the
                    // entire multi-week field history again at dissipation.
                    pressureHistory: (state.pressureHistory || []).slice(),
                    siteHistory: JSON.parse(JSON.stringify(state.siteHistory || []))
                });
                state.simulationCount++;
            } catch (e) {
                console.error("无法保存历史记录:", e);
            }
            return;
        }        // [修改] 传递 GlobalTemp 到模型
        const wasNamed = state.cyclone.named;
        const previousLandfallAge = state.cyclone.landfallEvent?.age;

        const cycloneAtStepStart = state.cyclone;
        const atmosphereStep = await advanceAtmosphereOffMainThread(
            state.pressureSystems,
            state.cyclone.currentMonth
        );
        profileMark('atmosphere');
        // A restart can replace the active cyclone while the atmosphere job
        // is in flight. Never commit the previous run's weather to the new one.
        if (state.cyclone !== cycloneAtStepStart) return;
        state.pressureSystems = atmosphereStep.pressureSystems;
        state.frontalZone = atmosphereStep.frontalZone;
	  const updatedCyclone = updateCycloneState(
            cycloneAtStepStart,
            state.pressureSystems,
            state.frontalZone,
            state.world,
            state.currentMonth,
            state.GlobalTemp,
            state.GlobalShear,
            state.heatDistribution,
            state.nextNameIndex,
            { deferWindRadii: true }
        );
        profileMark('cycloneModel');
        const rawWindRadii = await calculateWindRadiiOffMainThread(
            updatedCyclone,
            state.pressureSystems,
            state.currentMonth
        );
        profileMark('windRadii');
        // A restart can replace the active cyclone while a Worker job is in
        // flight. Never attach that stale result to the new run.
        if (state.cyclone !== cycloneAtStepStart) return;
        finalizeCycloneStepDiagnostics(updatedCyclone, rawWindRadii, state.pressureSystems);
        advisoryQueue.adopt(cycloneAtStepStart, updatedCyclone);
        state.cyclone = updatedCyclone;
        state.cyclone.currentMonth = state.currentMonth;
        const landfallEvent = state.cyclone.landfallEvent;
        if (landfallEvent
            && landfallEvent.age === state.cyclone.age
            && landfallEvent.age !== previousLandfallAge) {
            triggerLandfallEffect(
                mapSvg,
                mapProjection,
                landfallEvent.lon,
                landfallEvent.lat,
                landfallEvent
            );
            playLandfallSound();
        }
        {
            // 为了节省内存，我们只存 keyframe (比如对应 track 的每一个点)
            // 假设 updateTimer 触发 track 更新时刻：
            
            // The atmosphere Worker returns a fresh structured-clone object on
            // every step. updateCycloneState only reads it, so this reference
            // is already an immutable historical snapshot; cloning it again
            // on the UI thread caused avoidable GC stalls in long simulations.
            const snapshot = {
                age: state.cyclone.age, // 时间戳，用于对齐
                month: state.cyclone.currentMonth, // 记录当时的月份(影响SST等)
                // Preserve both layers for MSLP and 500 hPa products.
                lower: state.pressureSystems.lower || [],
                upper: state.pressureSystems.upper || []
            };
            
            // 存入历史数组
            state.pressureHistory.push(snapshot);
        }
        if (!wasNamed && state.cyclone.named) {
            state.nextNameIndex++;
            console.log("Name assigned. Next name index:", state.nextNameIndex);
        }

        // Audio only: follow the existing category scale and report each new
        // lifetime high once. ERC recovery/threshold chatter must not repeat it.
        const soundCategory = Number(getCategory(
            state.cyclone.intensity, state.cyclone.isTransitioning,
            state.cyclone.isExtratropical, state.cyclone.isSubtropical
        ).shortName.match(/^Cat ([1-5])$/)?.[1] || 0);
        if (soundCategory > state.highestSoundCategory) {
            state.highestSoundCategory = soundCategory;
            playUpgradeSound(soundCategory);
        }

        if (!state.hasTriggeredCat1News && state.cyclone.intensity >= 64 && !state.cyclone.isExtratropical) {
            state.hasTriggeredCat1News = true; // 锁定，防止重复触发
            
            // 获取名字 (如果没有名字显示编号)
            const cycloneNum = String(state.simulationCount).padStart(2, '0');
            const displayName = state.cyclone.name ? state.cyclone.name.toUpperCase() : `SYSTEM ${cycloneNum}`;
            const currentBasinId = state.cyclone.basin || basinSelector.value;

            let stormTerm = "HURRICANE";
            if (currentBasinId === 'WPAC') stormTerm = "TYPHOON";
            else if (['NIO', 'SIO', 'SHEM'].includes(currentBasinId)) { stormTerm = "CAT-1 CYCLONE"; }
            
            // 构建 HTML 标题
            const headlineHTML = `${displayName} <span class="text-black/50 text-base align-middle not-italic ml-2 font-bold">HAS BECOME A ${stormTerm}</span>`;

            // [修改] 调用新函数，类型为 ORANGE
            triggerNewsBanner(headlineHTML, "BREAKING NEWSLETTER", state.cyclone.age, state.currentMonth, 'ORANGE');
        }
        
        if (!state.hasTriggeredCat5News && state.cyclone.intensity >= 137 && !state.cyclone.isExtratropical) {
            state.hasTriggeredCat5News = true;
            
            const cycloneNum = String(state.simulationCount).padStart(2, '0');
            const displayName = state.cyclone.name ? state.cyclone.name.toUpperCase() : `SYSTEM ${cycloneNum}`;
            const currentBasinId = state.cyclone.basin || basinSelector.value;

            // 术语区分：西太叫“超强台风”，其他叫“五级飓风”
            let statusTerm = "CATEGORY 5 HURRICANE";
            if (currentBasinId === 'WPAC') {
                statusTerm = "CAT-5 SUPER TYPHOON";
            }

            // 构建标题 HTML (紫色高亮风格)
            // 注意：这里使用 font-black 加粗，让 Cat 5 看起来更具压迫感
            const headlineHTML = `${displayName} <span class="text-black/60 text-base align-middle not-italic ml-2 font-black">ACHIEVED ${statusTerm} STATUS</span>`;

            // 调用新闻条 (类型为 PURPLE)
            triggerNewsBanner(headlineHTML, "EXTREME INTENSITY ALERT", state.cyclone.age, state.currentMonth, 'PURPLE');
        }

        if (state.siteLon != null && state.siteLat != null) {
            const dist = calculateDistance(state.cyclone.lat, state.cyclone.lon, state.siteLat, state.siteLon);
            
            // 阈值：400km
            if (dist <= 400 && state.cyclone.intensity >= 34) {
                // 只有当之前没有报警过时，才播放
                if (!state.hasAlerted) {
                    state.hasAlerted = true; // 锁定，防止下一帧重复播放
                    
                    // 可选：在控制台或界面给出一个小的视觉提示
                    console.log(`Alert: Cyclone entered 400km radius (${Math.round(dist)}km)`);
const cycloneNum = String(state.simulationCount).padStart(2, '0');
                    const displayName = state.cyclone.name ? state.cyclone.name.toUpperCase() : `SYSTEM ${cycloneNum}`;
                    const siteName = state.siteName ? state.siteName.toUpperCase() : "OBSERVATION POST";

                    // 构建标题 HTML (红色警报风格)
                    const headlineHTML = `ALERT: <span class="text-white text-base align-middle not-italic ml-2 font-bold">${displayName} ENTERED 400KM WARNING RANGE</span>`;
                    
                    // 调用函数，类型为 RED
                    triggerNewsBanner(headlineHTML, `THREAT TO ${siteName}`, state.cyclone.age, state.currentMonth, 'RED');
                }
            } else {
                // 如果气旋离开了 800km 范围，重置标志
                // 这样如果它回头再次进入，会再次报警
                state.hasAlerted = false; 
            }
        }

        updateInfoPanel();
        updateMapInfoBox();
        updateStateSiteData();

        // 存入历史 (保持原有逻辑，因为这里是随时间推进的)
        if (state.currentSiteData) {
            const currentHour = state.cyclone.age;
            const lastEntry = state.siteHistory[state.siteHistory.length - 1];
            if (!lastEntry || lastEntry.hour !== currentHour) {
                 state.siteHistory.push({
                    hour: currentHour,
                    // 核心数据
                    wind: state.currentSiteData.displaySpeed,
                    pressure: state.currentSiteData.pressure,
                    // 矢量分量 (用于反推风向)
                    u: state.currentSiteData.u,
                    v: state.currentSiteData.v,
                    direction: state.currentSiteData.direction,
                    // 天气数据
                    dbz: state.currentSiteData.dbz,
                    // 记录当时的站点位置，以防用户后来改了位置导致数据错位
                    lat: state.siteLat,
                    lon: state.siteLon
                });
            }
        }
   
        // Keep the six-hour advisory cadence even when the live cone is
        // hidden: forecastLogs feed historical products and exports.
        if (state.cyclone.age % 6 === 0 && state.cyclone.age > 0) {
             advisoryQueue.issue(
                 state.cyclone,
                 state.pressureSystems,
                 state.GlobalTemp,
                 state.GlobalShear
             );
             profileMark('forecastDispatch');
             
             // [关键] 只有在生成了新预测路径（每3小时）时，才触发全量重绘
             // 因为预测线改变了，或者需要清理旧的痕迹
             needsFullRedraw = true; 
        } else {
             // 地图投影以气旋为中心；每个位置步必须统一重投影底图、
             // 轨迹和气旋标记，否则增量段会与地图中心逐步脱节。
             needsFullRedraw = true;
             needsTrackUpdate = false;
        }

        if (state.cyclone.track.length > 3) {
            generateJTWCButton.classList.remove('hidden');
        }
        if (profileMarks) {
            profileMarks.total = performance.now() - profileStartedAt;
            const profileReport = {
                age: state.cyclone.age,
                ...Object.fromEntries(Object.entries(profileMarks).map(([key, value], index, entries) => {
                    const previous = index === 0 ? 0 : entries[index - 1][1];
                    return [key, Math.round((value - previous) * 10) / 10];
                })),
                total: Math.round(profileMarks.total * 10) / 10
            };
            // Stringify so DevTools/remote log collectors retain the fields
            // instead of collapsing the object to the word "Object".
            console.info(`[simulation-step-profile] ${JSON.stringify(profileReport)}`);
        }
    }

	    async function startSimulation() {
        playStart();
        selectedHistoryPointIndex = -1;
        if (state.simulationInterval) clearInterval(state.simulationInterval);
        state.simulationInterval = null;
        state.isPaused = false;
        state.hasAlerted = false;
        state.hasTriggeredCat1News = false;
        state.hasTriggeredCat5News = false;
        state.highestSoundCategory = 0;
        state.siteHistory = []; 
        state.pressureHistory = [];
        state.isSiteSelected = false;
        state.selectedHistoryCyclone = null;
        state.showAllHistory = false;
        simulationStepQueued = false;
        if (!state.world) return;
        let generatedCyclone;
        try {
            generatedCyclone = initializeCyclone(state.world, parseInt(monthSelector.value, 10),
                basinSelector.value, state.GlobalTemp, state.GlobalShear, state.customLon, state.customLat);
        } catch (error) {
            document.getElementById('status').textContent = error.message;
            playError();
            return;
        }
        resetSatelliteParams();
        setupCanvases();
        document.getElementById('initial-message').classList.add('hidden');
        document.getElementById('simulation-output').classList.remove('hidden');
        document.getElementById('satellite-window').classList.remove('hidden');
        document.getElementById('info-panel').classList.remove('hidden');
        const restoreBtn = document.getElementById('restore-sat-btn');
        if (restoreBtn) restoreBtn.classList.add('hidden');
        const newsContainer = document.getElementById('news-feed-container');
        if (newsContainer) {
            newsContainer.innerHTML = ''; // 直接清空所有子元素
        }
        document.getElementById('map-info-box').classList.remove('hidden');
        bestTrackContainer.classList.add('hidden');
        
        // [UI修复] 使用 innerHTML 设置带图标的按钮，保持风格一致
        generateButton.innerHTML = '<span class="relative z-10 flex items-center justify-center gap-2"><i class="fa-solid fa-power-off"></i> RESTART</span>';
        pauseButton.disabled = true;
        // [UI修复] 设置为暂停图标
        pauseButton.innerHTML = '<i class="fa-solid fa-pause text-xs"></i>';
        
        const selectedBasin = basinSelector.value;
        const hasCustomCoords = state.customLon !== null && state.customLat !== null;
        if (!hasCustomCoords && (!state.lastBasin || state.lastBasin !== selectedBasin)) {
            const list = NAME_LISTS[selectedBasin] || NAME_LISTS['WPAC'];
            state.nextNameIndex = Math.floor(Math.random() * list.length);
        }
        state.currentMonth = parseInt(monthSelector.value, 10);
        monthSelector.disabled = true;
        basinSelector.disabled = true;
        // [修改] 禁用设置滑块
        globalTempSlider.disabled = true;
        heatDistributionSlider.disabled = true;
        globalShearSlider.disabled = true;
        observationSiteSelector.setLocked(true);
        customLonInput.disabled = true;
        customLatInput.disabled = true;
        settingsMenu.classList.add('hidden'); // [修改] 开始模拟时隐藏菜单

        // [修改] 传递 GlobalTemp 到模型
        state.cyclone = generatedCyclone;
        state.cyclone.oceanHeatDistribution = state.heatDistribution;
        const activeBasin = state.cyclone.basin || selectedBasin || 'WPAC';
        if (hasCustomCoords && (!state.lastBasin || state.lastBasin !== activeBasin)) {
            const list = NAME_LISTS[activeBasin] || NAME_LISTS['WPAC'];
            state.nextNameIndex = Math.floor(Math.random() * list.length);
        }
        state.lastBasin = activeBasin;
        state.cyclone.currentMonth = state.currentMonth;
        Object.assign(state.cyclone, createSimulationCalendar(state.currentMonth));
        state.pressureSystems = initializePressureSystems(state.cyclone, state.currentMonth, state.GlobalTemp, state.GlobalShear);
        const initialPhase = diagnoseCyclonePhaseSpace(state.cyclone, state.pressureSystems);
        state.cyclone.track.push([state.cyclone.lon, state.cyclone.lat, state.cyclone.intensity, false, false, state.cyclone.circulationSize, state.cyclone.isSubtropical, undefined, undefined, undefined, undefined, {
            transitionHours: 0, extratropicalStage: 'none', extratropicalAgeHours: 0,
            ...(initialPhase ? { phase: initialPhase } : {})
        }]);
        state.pressureHistory = [{ age: 0, month: state.currentMonth, ...JSON.parse(JSON.stringify(state.pressureSystems)) }];
        showIntensityDrawer(state.cyclone);
        state.frontalZone = updateFrontalZone(state.pressureSystems, state.currentMonth, state.GlobalTemp, state.GlobalShear);
        
        state.pathForecasts = [];
        needsFullRedraw = true;
        const initialCyclone = state.cyclone;
        initializingCyclone = initialCyclone;
     const initialForecasts = await generatePathForecastsOffMainThread(
            initialCyclone,
            state.pressureSystems,
            state.GlobalTemp,
            state.GlobalShear
        );
        if (state.cyclone !== initialCyclone) return;
        initializingCyclone = null;
        state.pathForecasts = initialForecasts;
        pauseButton.disabled = false;
        updateToggleButtonVisual(togglePressureButton, state.showPressureField);
        updateToggleButtonVisual(toggleWindRadiiButton, state.showWindRadii);
        updateToggleButtonVisual(togglePathButton, state.showPathForecast);
        updateInfoPanel();
        // Establish the complete base map before any incremental track update.
        // Station overlays and ICWC interaction layers are created by drawMap.
        needsFullRedraw = true;
        needsTrackUpdate = false;
     state.simulationInterval = setInterval(updateSimulation, state.simulationSpeed);
    }
    
    function togglePause() {
        if (state.cyclone === initializingCyclone) return;
        if (!state.cyclone.status || state.cyclone.status !== 'active') {
            playError(); // [新增] 如果无法暂停（未激活），播放错误音
            return;
        }
        playClick();
        state.isPaused = !state.isPaused;
     if (state.isPaused) {
            clearInterval(state.simulationInterval);
            state.simulationInterval = null;
            // [UI修复] 暂停状态显示播放图标
            pauseButton.innerHTML = '<i class="fa-solid fa-play text-xs"></i>';
            document.getElementById('status').textContent = "模拟已暂停";
            requestRedraw();
        } else {
            state.simulationInterval = setInterval(updateSimulation, state.simulationSpeed);
            // [UI修复] 运行状态显示暂停图标
            pauseButton.innerHTML = '<i class="fa-solid fa-pause text-xs"></i>';
            updateInfoPanel();
        }
    }

    function requestRedraw() {
        // History is an explicit view: setting changes and resize must not
        // silently replace it with the most recent live simulation.
        if (state.world && mapSvg && (state.showAllHistory || state.selectedHistoryCyclone)) {
            needsFullRedraw = false;
            needsTrackUpdate = false;
            needsForecastRedraw = false;
            if (state.showAllHistory) {
                drawAllHistoryTracks(mapSvg, mapProjection, state.history, state.world,
                    { showPathPoints: state.showPathPoints });
            } else {
                const selected = state.selectedHistoryCyclone;
                drawFinalPath(mapSvg, mapProjection, selected, state.world, tooltip,
                    null, null, null, state.showPathPoints, null, selected.basin || basinSelector.value);
            }
            return;
        }
        // 1. 确保在重绘前更新站点数据
        updateStateSiteData();
        // 2. 【核心】检查气旋状态，控制显示标志
        const isCycloneActive = state.cyclone && state.cyclone.status === 'active';
        const onSiteClickCallback = () => {
            state.isSiteSelected = !state.isSiteSelected;
            requestRedraw();
        };
        if (state.world && mapSvg) {
            if (isCycloneActive || !state.cyclone.track || state.cyclone.track.length < 2) {
        // 如果模拟结束，强制隐藏所有气旋相关的动态元素
                const forecasts = isCycloneActive ? state.pathForecasts : [];
                const showRadii = isCycloneActive && state.showWindRadii;
                const showForecast = isCycloneActive && state.showPathForecast;
                const showWindField = isCycloneActive && state.showWindField;
                const showPressure = isCycloneActive && state.showPressureField;
                const showHumidity = isCycloneActive && state.showHumidityField;
                const siteDataToPass = state.currentSiteData;
    
                needsFullRedraw = true;
            } else {
                const siteDataToPass = state.currentSiteData ? { 
                    ...state.currentSiteData, 
                    label: null 
                } : null;
                drawFinalPath(
                    mapSvg, mapProjection, state.cyclone, state.world, tooltip, 
                    state.siteName, state.siteLon, state.siteLat, 
                    state.showPathPoints, state.lastFinalStats, state.cyclone.basin || basinSelector.value, 
                    state.pressureSystems, state.showWindField,
                    // [新增] 传入站点相关参数
                    state.currentMonth, state.siteHistory, siteDataToPass, onSiteClickCallback,
                    { showSSTField: state.showSSTField }
                );
            }
        }
    }

    function initMusicPlaylist() {
        if (!musicListContainer) return;
        musicListContainer.innerHTML = ''; // 清空现有内容

        musicTracks.forEach((filename, index) => {
            // 1. 只显示文件名，并移除实际音频扩展名
            const displayName = filename
                .split('/').pop()
                .replace(/\.[^.]+$/i, '')
                .replace(/_/g, ' ');

            // 2. 创建列表项
            const li = document.createElement('li');
            li.className = "flex items-center justify-between px-3 py-2 rounded cursor-pointer transition-all border border-transparent hover:bg-white/5 hover:border-white/10 group";
            
            // 3. 内部 HTML 结构
            li.innerHTML = `
                <div class="flex items-center gap-2 overflow-hidden">
                    <i class="fa-solid fa-play text-[10px] text-slate-600 group-hover:text-cyan-400 transition-colors status-icon"></i>
                    <span class="text-xs font-mono text-slate-400 group-hover:text-white truncate transition-colors">${displayName}</span>
                </div>
                <div class="w-1.5 h-1.5 rounded-full bg-cyan-500 opacity-0 active-indicator shadow-[0_0_5px_cyan]"></div>
            `;

            // 4. 点击事件
            li.addEventListener('click', () => {
                playSelectedTrack(filename, index);
            });

            musicListContainer.appendChild(li);
        });
    }

    // [函数] 播放指定音轨
    function playSelectedTrack(filename, index) {
        // 如果点击的是当前正在播放的，且正在播放中，则暂停
        if (currentTrackIndex === index && !bgmAudio.paused) {
            bgmAudio.pause();
            updateMusicUI(index, false);
            return;
        }

        // 切换源并播放
        // 假设音乐文件在根目录或特定目录下，如果在 js 同级需调整路径，例如 `audio/${filename}`
        bgmAudio.src = filename; 
        bgmAudio.volume = bgmVolumeSlider ? bgmVolumeSlider.value : 0.4;
        
        bgmAudio.play().then(() => {
            currentTrackIndex = index;
            updateMusicUI(index, true);
        }).catch(err => {
            console.error("播放失败:", err);
        });
    }

    // [函数] 更新播放列表 UI 状态 (高亮当前项)
    function updateMusicUI(activeIndex, isPlaying) {
        const items = musicListContainer.querySelectorAll('li');
        
        items.forEach((item, idx) => {
            const icon = item.querySelector('.status-icon');
            const text = item.querySelector('span');
            const indicator = item.querySelector('.active-indicator');

            if (idx === activeIndex) {
                // 激活状态样式
                item.classList.add('bg-white/10', 'border-cyan-500/30');
                text.classList.replace('text-slate-400', 'text-cyan-400');
                indicator.classList.remove('opacity-0');
                
                if (isPlaying) {
                    icon.className = "fa-solid fa-pause text-[10px] text-cyan-400 status-icon";
                    // 主按钮高亮
                    musicButton.classList.add('text-cyan-400', 'border-cyan-500');
                } else {
                    icon.className = "fa-solid fa-play text-[10px] text-cyan-400 status-icon";
                    musicButton.classList.remove('text-cyan-400', 'border-cyan-500');
                }
            } else {
                // 重置其他项
                item.classList.remove('bg-white/10', 'border-cyan-500/30');
                text.classList.replace('text-cyan-400', 'text-slate-400');
                indicator.classList.add('opacity-0');
                icon.className = "fa-solid fa-play text-[10px] text-slate-600 group-hover:text-cyan-400 transition-colors status-icon";
            }
        });
    }

    // [初始化]
    initMusicPlaylist();

    // --- 事件监听器 ---
    generateButton.addEventListener('click', startSimulation);
    pauseButton.addEventListener('click', togglePause);

    downloadTrackButton.addEventListener('click', downloadMapImage);

    downloadHistoryTrackButton.addEventListener('click', downloadHistoryTrack);

    // [新增] 设置菜单事件监听器
    settingsButton.addEventListener('click', () => {
        // The inline mobile HUD controller owns this toggle on touch layouts,
        // so the settings sheet also works if module loading is unavailable.
        const mobileTouchLayout = window.matchMedia(
            '(max-width: 767px), (hover: none) and (pointer: coarse)'
        ).matches;
        if (!mobileTouchLayout) settingsMenu.classList.toggle('hidden');
        settingsMenu.classList.contains('hidden') ? playPanelClose() : playPanelOpen();
    });

    exportPeakIntensityCheckbox?.addEventListener('change', event => {
        trackExportSettings.markPeakIntensity = event.target.checked;
        persistTrackExportSettings();
    });

    exportIgnoreExPeakCheckbox?.addEventListener('change', event => {
        trackExportSettings.ignoreExPeak = event.target.checked;
        persistTrackExportSettings();
    });

    exportExtremeTierCheckbox?.addEventListener('change', event => {
        trackExportSettings.enableExtremeTier = event.target.checked;
        persistTrackExportSettings();
    });

    exportLegendCheckbox?.addEventListener('change', event => {
        trackExportSettings.showLegend = event.target.checked;
        persistTrackExportSettings();
    });

    exportIntensityHistoryCheckbox?.addEventListener('change', event => {
        trackExportSettings.showIntensityHistory = event.target.checked;
        persistTrackExportSettings();
    });

    exportCityObservationsCheckbox?.addEventListener('change', event => {
        trackExportSettings.showCityObservations = event.target.checked;
        persistTrackExportSettings();
    });

    globalTempSlider.addEventListener('input', (e) => {
        state.GlobalTemp = parseInt(e.target.value, 10);
        globalTempValue.textContent = `${state.GlobalTemp}K`;
        requestRedraw();
    });

    heatDistributionSlider.addEventListener('input', event => {
        const value = Number(event.target.value);
        state.heatDistribution = value;
        heatDistributionValue.textContent = value;
    });

    globalShearSlider.addEventListener('input', (e) => {
        state.GlobalShear = parseInt(e.target.value, 10);
        globalShearValue.textContent = `${state.GlobalShear}`;
        requestRedraw();
    });

    historyButton.addEventListener('click', () => {
        playPanelOpen();
        historyList.innerHTML = '';
        if (state.history.length === 0) {
            historyList.innerHTML = '<li class="text-gray-400 p-2">尚无历史模拟记录。</li>';
        } else {
            [...state.history].reverse().forEach((item, index) => {
                const li = document.createElement('li');
                li.textContent = item.name; 
                li.className = 'text-white font-medium py-2 px-3 rounded-md cursor-pointer hover:bg-gray-700 transition-colors';
                li.dataset.historyIndex = state.history.length - 1 - index; 
                historyList.appendChild(li);
            });
        }
        historyModal.classList.remove('hidden');
        historyBestTrackContainer.classList.add('hidden'); // [新增] 默认隐藏ATCF显示区域
        state.selectedHistoryTrackData = ''; // [新增] 清空选中数据
    });

    closeHistoryModal.addEventListener('click', () => {
        playPanelClose();
        historyModal.classList.add('hidden');
    });

    // 历史列表项点击事件
    historyList.addEventListener('click', (e) => {
        const historyEntry = e.target?.closest?.('li[data-history-index]');
        if (historyEntry) {
            const index = parseInt(historyEntry.dataset.historyIndex, 10);
            const historyItem = state.history[index];
            if (!historyItem) return;
            selectedHistoryPointIndex = -1;
            const selectedCyclone = historyItem.cycloneData;
            selectedCyclone.pressureHistory = historyItem.pressureHistory || [];
            selectedCyclone.siteHistory = historyItem.siteHistory || [];
            state.selectedHistoryCyclone = selectedCyclone;
            state.showAllHistory = false;

            if (state.simulationInterval) {
                clearInterval(state.simulationInterval);
                state.simulationInterval = null;
            }
            state.isPaused = false;
            pauseButton.disabled = true;

            // historyModal.classList.add('hidden'); // 不关闭模态框，而是更新模态框内容
            document.getElementById('initial-message').classList.add('hidden');
            document.getElementById('simulation-output').classList.remove('hidden');
            bestTrackContainer.classList.add('hidden');
            
            document.getElementById('info-panel').classList.remove('hidden');
            requestRedraw();
            showIntensityDrawer(selectedCyclone);

            let peak = { intensity: 0 };
            selectedCyclone.track.forEach(p => {
                if(p[2] > peak.intensity) {
                    peak = { lon: p[0], lat: p[1], intensity: p[2], isT: p[3], isE: p[4], circulationSize: p[5] || 300, isS: p[6], pressure: p[10] };
                }
            });
            const peakCat = getCategory(peak.intensity, peak.isT, peak.isE, peak.isS);
            
            document.getElementById('status').textContent = `查看历史: ${historyItem.name}`;
            document.getElementById('simulationTime').textContent = `SIM T+${selectedCyclone.age}H`;
            document.getElementById('latitude').textContent = `${peak.lat.toFixed(1)}°N`;
            document.getElementById('longitude').textContent = `${peak.lon.toFixed(1)}°E`;
            document.getElementById('intensity-kph').textContent = knotsToKph(peak.intensity);
            document.getElementById('intensity-mph').textContent = knotsToMph(peak.intensity);
            document.getElementById('intensity').style.color = peakCat.color;
            let displayP = peak.pressure;
            if (displayP === undefined || displayP === null) {
                const basin = selectedCyclone.basin || state.cyclone.basin || 'WPAC';
                displayP = windToPressure(peak.intensity, peak.circulationSize, basin);
            }
            document.getElementById('pressure').textContent = Number.isFinite(Number(displayP))
                ? Number(displayP).toFixed(0)
                : displayP;
            document.getElementById('category').textContent = peakCat.name;
            document.getElementById('ace').textContent = selectedCyclone.ace.toFixed(2);
            document.getElementById('direction').textContent = "N/A";
            document.getElementById('speed').textContent = "N/A";
            const historyRmwStatus = document.getElementById('rmwStatus');
            historyRmwStatus.classList.toggle('hidden', !!peak.isE);
            historyRmwStatus.textContent = peak.isE ? "" : "RMW @ -- km";

            // [新增] 显示历史ATCF数据
            historyBestTrackData.value = historyItem.atcfData;
            historyBestTrackContainer.classList.remove('hidden');
            state.selectedHistoryTrackData = historyItem.atcfData; // [新增] 保存到state中，以便下载
        }
    });

    observationSiteSelector = mountObservationSiteSelector({
        root: document.getElementById('observationSiteSettings'), cities: ICWC_MAJOR_CITIES,
        language: () => window.getUserLanguage?.() || localStorage.getItem('userLanguage') || 'EN',
        onChange: site => {
            state.siteName=site.name;state.siteLon=site.lon;state.siteLat=site.lat;
            updateSiteGeoCache();requestRedraw();
        }
    });

    const savedShowPoints = localStorage.getItem('tcs_show_points');

    if (showPathPointsCheckbox) {
        // A. 初始化状态
        if (savedShowPoints !== null) {
            // 有记录：覆盖 DOM 和 State
            const isChecked = savedShowPoints === 'true';
            showPathPointsCheckbox.checked = isChecked;
            state.showPathPoints = isChecked; 
        } else {
            // 无记录：同步 State
            state.showPathPoints = showPathPointsCheckbox.checked;
        }

        // B. 监听变更 (使用 'change' 事件更稳妥)
        showPathPointsCheckbox.addEventListener('change', (e) => {
            const isChecked = e.target.checked;
            state.showPathPoints = isChecked; 
            localStorage.setItem('tcs_show_points', isChecked);
            
            if (typeof playClick === 'function') playClick();

            if (state.cyclone.status === 'active') {
                 requestRedraw();
            } else {
                requestRedraw();
            } 
        });
    }

    // [新增] 自定义生成点事件监听器
    customLonInput.addEventListener('input', (e) => {
        const lon = parseFloat(e.target.value);
        if (!isNaN(lon)) {
            state.customLon = lon;
        } else {
            state.customLon = null;
        }
    });
    customLatInput.addEventListener('input', (e) => {
        const lat = parseFloat(e.target.value);
        if (!isNaN(lat)) {
            state.customLat = lat;
        } else {
            state.customLat = null;
        }
    });

    copyTrackButton.addEventListener('click', () => {
        bestTrackData.select();
        document.execCommand('copy');
        copyTrackButton.textContent = "已复制!";
    });

    // 在 DOMContentLoaded 内定义通用处理函数
    const toggleState = (key, btnId, callback) => {
        state[key] = !state[key];
        const btn = document.getElementById(btnId);
        updateToggleButtonVisual(btn, state[key]);
        if (state[key]) {
            playToggleOn();
        } else {
            playToggleOff();
        }
        if (callback) callback(state[key]); // 比如处理图例显示
        requestRedraw();
        return state[key];
    };

    // 绑定事件时：
    document.getElementById('togglePressureButton').onclick = () => toggleState('showPressureField', 'togglePressureButton', enabled => {
        if (!enabled && mapSvg) {
            // Closing a layer is a presentation action, not a reason to wait
            // for the in-flight height grid before acknowledging the button.
            mapSvg.select('.layer-pressure').selectAll('*').remove();
            mapSvg.select('.layer-pressure-handles').selectAll('*').remove();
        }
    });
    document.getElementById('toggleHumidityButton').onclick = () => toggleState('showHumidityField', 'toggleHumidityButton');
toggleSSTButton.addEventListener('click', () => {
    if (!DISPLAY_FEATURES.sst) return;
    state.showSSTField = !state.showSSTField;

    updateToggleButtonVisual(
        toggleSSTButton,
        state.showSSTField
    );

setLegendVisible('sst-legend', state.showSSTField);
if (state.showSSTField) {
    playToggleOn();
} else {

    playToggleOff();
}

    requestRedraw();
});
    document.getElementById('toggleWindFieldButton').onclick = () => toggleState('showWindField', 'toggleWindFieldButton');
    document.getElementById('toggleShearButton').onclick = () => {
        if (!DISPLAY_FEATURES.shear) return;
        toggleState('showShearField', 'toggleShearButton', enabled => {
            setLegendVisible('shear-legend', enabled && state.cyclone?.status === 'active');
            document.getElementById('toggleShearButton').setAttribute('aria-pressed', String(enabled));
        });
    };
    document.getElementById('togglePathButton').onclick = () => {
        const enabled = toggleState('showPathForecast', 'togglePathButton');
        if (enabled && state.cyclone?.status === 'active') {
            refreshForecastWhileDragging(state.pressureSystems);
        }
    };

    // 对于带图例的特殊处理 (Wind Radii)
    document.getElementById('toggleWindRadiiButton').onclick = () => toggleState('showWindRadii', 'toggleWindRadiiButton', (isShow) => {
        setLegendVisible('wind-radii-legend', isShow);
    });

    musicButton.onclick = (e) => {
        e.stopPropagation();
        
        // 切换菜单显示
        const isHidden = musicMenu.classList.contains('hidden');
        isHidden ? playPanelOpen() : playPanelClose();
        
        // 关闭其他菜单 (如 Settings) 以防重叠
        if (settingsMenu) settingsMenu.classList.add('hidden');
        
        if (isHidden) {
            musicMenu.classList.remove('hidden');
        } else {
            musicMenu.classList.add('hidden');
        }
    };

    // [事件监听] 点击外部关闭菜单
    document.addEventListener('click', (e) => {
        if (musicMenu && !musicMenu.contains(e.target) && !musicButton.contains(e.target)) {
            musicMenu.classList.add('hidden');
        }
    });

    // [事件监听] 音量滑块
    if (bgmVolumeSlider) {
        bgmVolumeSlider.addEventListener('input', (e) => {
            bgmAudio.volume = e.target.value;
        });
    }
    
    // [新增] 地图双击事件：生成手动高压
    mapContainer.on("dblclick", (event) => {
        // 1. 只有打开气压场时才允许操作
        if (!state.showPressureField) return;
        
        // 2. 获取鼠标位置的经纬度
        const [mouseX, mouseY] = d3.pointer(event);
        const coords = mapProjection.invert([mouseX, mouseY]);
        if (!coords) return;
        const [lon, lat] = coords;

        // 3. 检查是否已经存在手动高压 (限制最多 1 个)
        // 我们检查 lower 层即可
        const existingIndex = state.pressureSystems.lower.findIndex(s => s.isManual);

        if (existingIndex === -1) {
            detachPressureSystemsForManualEdit();
            // --- 生成新系统 ---
            const newSystem = {
                type: 'high',
                x: lon, 
                y: lat,
                sigmaX: 5,        // [要求] x=5 (大小)
                sigmaY: 3,        // [要求] y=3
                baseSigmaX: 5,    // 记录基准大小以便呼吸动画
                strength: 8,      // [要求] strength=8
                baseStrength: 8,
                velocityX: 0,     // 默认静止，可被 updatePressureSystems 推着走
                velocityY: 0,
                isManual: true,   // [标记] 这是手动生成的
                noiseLayers: []
            };

            // 同时推送到 upper 和 lower 层以符合双层架构
            const lowerSys = JSON.parse(JSON.stringify(newSystem));
            const upperSys = JSON.parse(JSON.stringify(newSystem));
            upperSys.strength = 8; // 上层稍微强一点

            state.pressureSystems.lower.push(lowerSys);
            state.pressureSystems.upper.push(upperSys);
            invalidatePressureSystemCaches(state.pressureSystems);

            playClick(); // 播放音效
            needsFullRedraw = true;
        } else {
            // 如果已经存在一个，这里的逻辑是“再双击H按钮删除”，
            // 但如果用户双击地图空白处，是否要移动它？
            // 按照您的要求，这里什么都不做，或者您也可以选择移动它。
            // 暂且留空，严格遵守“双击H按钮删除”。
            console.log("Manual High already exists. Double click the 'H' marker to remove.");
        }
    });

    window.addEventListener('resize', () => {
        if (state.world) {
            setupCanvases();
             if (state.cyclone.status) {
                 updateStateSiteData();
                 needsFullRedraw = true;
             }
             refreshIntensityChart(true);
        }
    });

    window.addEventListener('cycloneTrackClick', (e) => {
        selectedHistoryPointIndex = e.detail.index;

        // 激活 JTWC 按钮
        generateJTWCButton.classList.remove('hidden');

        // 可选：给个按钮高亮动画
        generateJTWCButton.classList.add('ring-2', 'ring-red-500');
        setTimeout(() => generateJTWCButton.classList.remove('ring-2', 'ring-red-500'), 300);
    });

    mapContainer.node().addEventListener('click', (e) => {
        // 如果点击的是 SVG 背景或容器本身（而不是上面的 UI 按钮）
        if (e.target.tagName === 'svg' || e.target.id === 'map-container') {
            const jtwcActionButton = document.getElementById('jtwcActionButton');
            if (jtwcActionButton) jtwcActionButton.classList.add('hidden');
            selectedHistoryPointIndex = -1; // 确保你有这个变量的访问权限
        
            // 还要清除地图上的选中圆圈
            const interactionLayer = mapSvg.select(".track-interaction-layer");
            if (!interactionLayer.empty()) {
                interactionLayer.select(".selected-circle").style("opacity", 0);
            }
            requestRedraw();
        }
    });

    window.addEventListener('cycloneTrackDeselect', () => {
        if (generateJTWCButton) {
            generateJTWCButton.classList.add('hidden');
        }
    });

    // 绑定 JTWC 按钮点击事件
    generateJTWCButton.addEventListener('click', () => {
        console.log("JTWC Button Clicked");
        const targetCyclone = state.selectedHistoryCyclone || state.cyclone;
        
        let renderIndex = selectedHistoryPointIndex;
        if (renderIndex === -1) {
            if (targetCyclone && targetCyclone.track.length > 0) {
                renderIndex = targetCyclone.track.length - 1;
                if (!state.isPaused && state.simulationInterval && !state.selectedHistoryCyclone) {
                    togglePause(); 
                }
            } else {
                return;
            }
        }

        if (renderIndex === -1 || !targetCyclone) return;
        // ICWC products are issued on a 6-hour cycle. Keep the selected
        // 3-hour track point as context, but render the nearest completed
        // product page so every tab shares one time cursor.
        renderIndex = Math.max(0, Math.min(
            targetCyclone.track.length - 1,
            Math.floor(renderIndex / 2) * 2
        ));
        const targetHour = renderIndex * 3;

const isHistoryMode = !!state.selectedHistoryCyclone;

const pressureHistorySource = isHistoryMode
    ? state.selectedHistoryCyclone.pressureHistory || []
    : state.pressureHistory || [];

let renderPressureSystems = null;

// 优先精确匹配
const exactSnapshot = pressureHistorySource.find(
    snapshot => snapshot.age === targetHour
);

if (exactSnapshot) {
    renderPressureSystems = {
        lower: exactSnapshot.lower || [],
        upper: exactSnapshot.upper || []
    };
} else if (pressureHistorySource.length > 0) {
    // 找时间最接近的快照
    const closestSnapshot = pressureHistorySource.reduce(
        (closest, current) => {
            return Math.abs(current.age - targetHour) <
                   Math.abs(closest.age - targetHour)
                ? current
                : closest;
        }
    );

    // 只接受前后相差不超过 6 小时的快照
    if (Math.abs(closestSnapshot.age - targetHour) <= 6) {
        renderPressureSystems = {
            lower: closestSnapshot.lower || [],
            upper: closestSnapshot.upper || []
        };
    }
}

// 最后才退回当前压力场
if (!renderPressureSystems) {
    renderPressureSystems = state.pressureSystems;
}
        playPanelOpen();
        jtwcModal.classList.remove('hidden');
        jtwcModal.setAttribute('tabindex', '-1');
        jtwcModal.focus({ preventScroll: true });

        const getIcwcLanguage = () => window.getUserLanguage?.()
            || (localStorage.getItem('userLanguage') === 'CN' ? 'CN' : 'EN');
        const updateWarningMapFitButton = () => {
            const chinese = getIcwcLanguage() === 'CN';
            warningMapFitButton.setAttribute('aria-pressed', String(fitWarningMapCone));
            warningMapFitButton.querySelector('span').textContent = chinese
                ? (fitWarningMapCone ? '适配预报锥体' : '固定比例')
                : (fitWarningMapCone ? 'FIT FORECAST CONE' : 'FIXED SCALE');
            warningMapFitButton.querySelector('i').className = fitWarningMapCone
                ? 'fa-solid fa-compress' : 'fa-solid fa-expand';
            warningMapFitButton.title = chinese
                ? (fitWarningMapCone ? '切换为固定比例' : '自动适配完整预报锥体')
                : (fitWarningMapCone ? 'Switch to fixed scale' : 'Fit the complete forecast cone');
        };
        const icwcProductLabels = {
            products: { EN: 'PRODUCTS', CN: '产品列表' },
            graphic: { EN: 'WARNING GRAPHIC', CN: '警报图' },
            prob34: { EN: 'WIND PROB 34KT', CN: '34KT 风速概率' },
            prob64: { EN: 'WIND PROB 64KT', CN: '64KT 风速概率' },
            satellite: { EN: 'SAT IMAGERY', CN: '卫星影像' },
            phase: { EN: 'PHASE SPACE', CN: '相空间' },
            station: { EN: 'STATION OBS', CN: '站点观测' },
            synoptic: { EN: 'SYNOPTIC CHART', CN: '天气形势图' },
            height500: { EN: '500 hPa HEIGHT', CN: '500 hPa 高度场' },
            height200: { EN: '200 hPa HEIGHT', CN: '200 hPa 高度场' }
        };
        const updateIcwcProductListLanguage = () => {
            updateWarningMapFitButton();
            const language = getIcwcLanguage();
            jtwcOutput.querySelectorAll('[data-icwc-label]').forEach(element => {
                const key = element.dataset.icwcLabel;
                const label = icwcProductLabels[key];
                if (label) element.textContent = label[language] || label.EN;
            });
        };
        if (window.__icwcLanguageHandler) {
            window.removeEventListener('uiLanguageChanged', window.__icwcLanguageHandler);
        }
        window.__icwcLanguageHandler = updateIcwcProductListLanguage;
        window.addEventListener('uiLanguageChanged', updateIcwcProductListLanguage);
        
        // --- 1. 构建 Tab 界面结构 (增加 64KT 按钮) ---
        jtwcOutput.innerHTML = `
            <div class="flex h-[600px] w-full"> 
                <div class="w-40 flex-shrink-0 bg-gray-100 border-r border-gray-300 p-2 flex flex-col gap-2">
                    <div class="text-xs font-bold text-gray-500 mb-2 px-2" data-icwc-label="products">PRODUCTS</div>
                    
                    <button id="jtwc-tab-graphic" data-icwc-label="graphic" class="text-left px-3 py-2 text-sm font-bold bg-white border border-gray-300 rounded shadow-sm text-cyan-700 transition-all hover:bg-gray-50">
                        WARNING GRAPHIC
                    </button>
                    
                    <button id="jtwc-tab-prob34" data-icwc-label="prob34" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">
                        WIND PROB 34KT
                    </button>

                    <button id="jtwc-tab-prob64" data-icwc-label="prob64" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">
                        WIND PROB 64KT
                    </button>

                    <button id="jtwc-tab-satellite" data-icwc-label="satellite" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">
                    SAT IMAGERY
                    </button>

                    <button id="jtwc-tab-phase" data-icwc-label="phase" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">
                        PHASE SPACE
                    </button>

                    <div class="h-px bg-gray-300 my-1"></div>
                    <button id="jtwc-tab-station" data-icwc-label="station" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors flex items-center gap-2">
                        STATION OBS
                    </button>

                    <button id="jtwc-tab-synoptic" data-icwc-label="synoptic" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors flex items-center gap-2">
                        SYNOPTIC CHART
                    </button>
                    <button id="jtwc-tab-height500" data-icwc-label="height500" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">500 hPa HEIGHT</button>
                    <button id="jtwc-tab-height200" data-icwc-label="height200" class="text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors">200 hPa HEIGHT</button>
                </div>
                
                <div id="jtwc-product-stage" class="group relative flex-1 min-w-0 bg-gray-50 overflow-hidden">
                    <div id="jtwc-content-area" class="absolute inset-0 flex items-center justify-center overflow-auto p-4">
                        <div id="jtwc-loading" class="hidden absolute inset-0 flex items-center justify-center bg-white/80 z-10 text-cyan-600 font-bold pointer-events-none">
                            GENERATING...
                        </div>
                    </div>
                    <div id="jtwc-time-navigation" class="pointer-events-none absolute inset-0 z-20" aria-label="ICWC six-hour product navigation">
                        <button id="jtwc-prev-time" type="button" aria-label="Previous ICWC product, 6 hours earlier" title="Previous product · −6h" class="pointer-events-auto absolute left-0 top-1/2 -translate-y-1/2 w-12 h-24 rounded-r-xl bg-slate-900/55 text-white/80 opacity-0 transition-opacity hover:opacity-100 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 disabled:pointer-events-none disabled:opacity-0">
                            <i class="fa-solid fa-chevron-left"></i>
                        </button>
                        <button id="jtwc-next-time" type="button" aria-label="Next ICWC product, 6 hours later" title="Next product · +6h" class="pointer-events-auto absolute right-0 top-1/2 -translate-y-1/2 w-12 h-24 rounded-l-xl bg-slate-900/55 text-white/80 opacity-0 transition-opacity hover:opacity-100 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 disabled:pointer-events-none disabled:opacity-0">
                            <i class="fa-solid fa-chevron-right"></i>
                        </button>
                        <div id="jtwc-time-hint" class="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/75 px-3 py-1 text-[10px] font-mono font-bold tracking-wider text-white/80 opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100">
                            T+0H · ←/→ ±6H
                        </div>
                    </div>
                </div>
            </div>
        `;

        updateIcwcProductListLanguage();

        const contentArea = document.getElementById('jtwc-content-area');
        const tabGraphic = document.getElementById('jtwc-tab-graphic');
        const tabProb34 = document.getElementById('jtwc-tab-prob34');
        const tabProb64 = document.getElementById('jtwc-tab-prob64');
        const tabSatellite = document.getElementById('jtwc-tab-satellite');
        const tabStation = document.getElementById('jtwc-tab-station');
        const tabSynoptic = document.getElementById('jtwc-tab-synoptic');
        const tabHeight500 = document.getElementById('jtwc-tab-height500');
        const tabHeight200 = document.getElementById('jtwc-tab-height200');
        const loadingNode = document.getElementById('jtwc-loading');
        
        let currentCanvas = null;
        let currentMode = 'GRAPHIC'; // 用于保存文件名
        let renderRevision = 0;
        let activeProductTab = null;

        const previousTimeButton = document.getElementById('jtwc-prev-time');
        const nextTimeButton = document.getElementById('jtwc-next-time');
        const timeHint = document.getElementById('jtwc-time-hint');

        const updateTimeNavigation = () => {
            const currentHour = renderIndex * 3;
            const canGoBack = renderIndex >= 2;
            const canGoForward = renderIndex + 2 < targetCyclone.track.length;
            previousTimeButton.disabled = !canGoBack;
            nextTimeButton.disabled = !canGoForward;
            timeHint.textContent = `T+${currentHour}H · ←/→ ±6H`;
            previousTimeButton.title = canGoBack
                ? `Previous product · T+${currentHour - 6}H`
                : 'Already at the first product';
            nextTimeButton.title = canGoForward
                ? `Next product · T+${currentHour + 6}H`
                : 'Already at the latest product';
        };

        const showLoading = () => {
            contentArea.innerHTML = ''; 
            loadingNode.classList.remove('hidden'); 
            contentArea.appendChild(loadingNode); 
        };

        const updateTabStyles = (activeTab) => {
            if (activeProductTab && activeProductTab !== activeTab) playPageTurn();
            activeProductTab = activeTab;
            warningMapFitButton.hidden = activeTab !== tabGraphic;
            [tabGraphic, tabProb34, tabProb64, tabSatellite, tabPhase, tabStation, tabSynoptic, tabHeight500, tabHeight200].forEach(tab => {
                if (tab === activeTab) {
                    tab.className = "text-left px-3 py-2 text-sm font-bold bg-white border border-gray-300 rounded shadow-sm text-cyan-700 transition-all";
                } else {
                    tab.className = "text-left px-3 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 rounded transition-colors";
                }
            });
        };

        // --- 2. 定义渲染函数 ---
        
        const showGraphic = () => {
            const requestId = ++renderRevision;
            const viewOptions = { fitCone: fitWarningMapCone };
            updateTabStyles(tabGraphic);
            currentMode = 'GRAPHIC';
            currentCanvas = null;
            showLoading(); 

            setTimeout(async () => {
                if (requestId !== renderRevision) return;
                try {
                    const canvas = await renderJTWCStyle(targetCyclone, renderIndex, state.world,
                        getPressureSystemsAtHour(renderIndex * 3), viewOptions);
                    if (requestId !== renderRevision) return;
                    canvas.className = "max-w-full max-h-full shadow-lg border border-gray-200";
                    contentArea.replaceChildren(canvas);
                    currentCanvas = canvas;
                } catch (error) {
                    if (requestId !== renderRevision) return;
                    console.error('Warning graphic failed', error);
                    contentArea.innerText = 'Unable to render warning graphic.';
                }
            }, 10);
        };

        // 通用概率图渲染函数
        const showProb = (threshold) => {
            const requestId = ++renderRevision;
            const activeTab = threshold === 64 ? tabProb64 : tabProb34;
            updateTabStyles(activeTab);
            currentMode = threshold === 64 ? 'PROB64' : 'PROB34';
            currentCanvas = null;
            
            showLoading();

            setTimeout(async () => {
                if (requestId !== renderRevision) return;
                if (typeof renderProbabilitiesStyle === 'function') {
                    try {
                        const canvas = await renderProbabilitiesStyle(targetCyclone, renderIndex, state.world, threshold);
                        if (requestId !== renderRevision) return;
                        canvas.className = "max-w-full max-h-full shadow-lg border border-gray-200";
                        contentArea.innerHTML = '';
                        contentArea.appendChild(canvas);
                        currentCanvas = canvas;
                    } catch (error) {
                        if (requestId !== renderRevision) return;
                        console.error('Wind probability product failed', error);
                        contentArea.innerText = 'Unable to render wind probability product.';
                    }
                } else {
                    contentArea.innerText = "Error: renderProbabilitiesStyle not imported.";
                }
            }, 50); 
        };

        // B. Phase Space 页面
        const showPhaseSpace = () => {
            const requestId = ++renderRevision;
            updateTabStyles(tabPhase);
            currentMode = 'PHASE';
            currentCanvas = null;
            showLoading();

            setTimeout(() => {
                if (requestId !== renderRevision) return;
                if (typeof renderPhaseSpace === 'function') {
                    const canvas = renderPhaseSpace(targetCyclone, state.GlobalTemp, renderIndex);
                    canvas.className = "max-w-full max-h-full shadow-lg border border-gray-800";
                    contentArea.innerHTML = '';
                    contentArea.appendChild(canvas);
                    currentCanvas = canvas;
                } else {
                    contentArea.innerText = "Module not loaded.";
                }
            }, 50);
        };

        const tabPhase = document.getElementById('jtwc-tab-phase');
        tabPhase.onclick = showPhaseSpace;

        const showSatelliteImagery = () => {
            ++renderRevision;
            updateTabStyles(tabSatellite);
            currentMode = 'SATELLITE';
            currentCanvas = null;
            contentArea.innerHTML = ''; // 清空区域

            // 1. 确定目标气旋和时间
            const targetPoint = targetCyclone.track[renderIndex];
            const targetAge = renderIndex * 3; // 假设每步3小时
        
            // 2. 在缓存中查找图片
            // 我们需要找到最接近 targetAge 的快照 (因为快照是每6小时存一张，而时间轴可能是每3小时)
            const cache = targetCyclone.satelliteCache || [];
        
            // 查找精确匹配或最近的匹配 (向后查找最近的过去图像)
            // 例如：如果是 T+9，我们显示 T+6 的图；如果是 T+12，显示 T+12 的图。
            let bestShot = cache.find(s => s.age === targetAge);
        
            if (!bestShot && cache.length > 0) {
                // 如果没有精确匹配，找最近的一个 (Fallback)
                bestShot = cache.reduce((prev, curr) => {
                    return (Math.abs(curr.age - targetAge) < Math.abs(prev.age - targetAge) ? curr : prev);
                });
            }

           // 3. 渲染 UI
            const container = document.createElement('div');
            container.className = "w-full h-full flex flex-col items-center justify-center bg-[#1a1a1a] relative";

            if (bestShot) {
                // A. 显示图片
                const img = document.createElement('img');
                img.src = bestShot.img;
                img.className = "w-full h-full shadow-lg border border-gray-800 object-contain";
                container.appendChild(img);

                // B. 显示信息水印 (HTML覆盖层)
                const infoOverlay = document.createElement('div');
                infoOverlay.className = "absolute top-4 left-4 text-white/80 font-mono text-xs bg-black/50 p-2 rounded pointer-events-none";
            
                // 格式化时间戳
                const d = simulationDate(targetCyclone, bestShot.age);
                const timeStr = `${String(d.getUTCDate()).padStart(2,'0')}/${String(d.getUTCHours()).padStart(2,'0')}Z`;
            
                // 查找那一刻的强度 (用于显示)
                const trackData = targetCyclone.track.find((_, i) => i * 3 === bestShot.age) || targetPoint;
                const intensity = trackData ? trackData[2] : 0;

                let nameDisplay = "UNKNOWN";
                if (targetCyclone.name) {
                    nameDisplay = targetCyclone.name.toUpperCase();
                } else {
                    // 如果没有名字，尝试显示编号
                    // 注意：如果是正在进行的模拟，用 state.simulationCount
                    // 如果是历史记录，这可能不准确，但在没有存储 ID 的情况下这是最佳回退
                    const num = String(state.simulationCount).padStart(2, '0');
                    nameDisplay = `TD ${num}`;
                }

                infoOverlay.innerHTML = `
                    <div class="font-bold text-lg text-cyan-400">SATELLITE SNAPSHOT OF ${nameDisplay}</div>
                    <div>VALID: ${timeStr} (T+${bestShot.age}H)</div>
                    <div>INTENSITY: ${Math.round(intensity/5)*5} KT</div>
                    ${bestShot.age !== targetAge ? `<div class="text-yellow-400 mt-1">Note: Showing nearest img (Req: T+${targetAge}H)</div>` : ''}
                `;
                container.appendChild(infoOverlay);

            } else {
               // C. 没有图片的空状态
                container.innerHTML = `
                    <div class="text-center text-slate-500">
                        <i class="fa-solid fa-satellite-dish text-6xl mb-4 opacity-50"></i>
                        <p class="text-xl font-bold">NO IMAGERY AVAILABLE</p>
                        <p class="text-sm mt-2">Simulation hasn't generated satellite cache for T+${targetAge}H yet.</p>
                        <p class="text-xs text-slate-600 mt-1">Images are captured every 6 hours during simulation run.</p>
                    </div>
                `;
            }

            contentArea.appendChild(container);
        };

        const showSynopticChart = () => {
            const requestId = ++renderRevision;
            updateTabStyles(tabSynoptic);
            currentMode = 'SYNOPTIC';
            currentCanvas = null;
            showLoading();

            // 1. 确定时间点
            const targetHour = renderIndex * 3;
            const isHistoryMode = !!state.selectedHistoryCyclone;
            
            let sourceSiteList = isHistoryMode ? (state.selectedHistoryCyclone.siteHistory || []) : state.siteHistory;
            const record = sourceSiteList.find(h => h.hour === targetHour);
            const sLon = record ? record.lon : state.siteLon;
            const sLat = record ? record.lat : state.siteLat;
            const sName = state.siteName || "STATION";

            let historySystem = null;
            
if (isHistoryMode) {
                // 历史模式：只读存档
                const pressureHistory = state.selectedHistoryCyclone.pressureHistory || [];
                // 精确查找
                const found = pressureHistory.find(h => h.age === targetHour);
                if (found) {
                    // Historical snapshots are immutable. Keep their identity
                    // so reopening this chart can reuse exact point samples.
                    historySystem = found;
                } else if (pressureHistory.length > 0) {
                    // 模糊查找 (fallback)
                    const closest = pressureHistory.reduce((prev, curr) => {
                        return (Math.abs(curr.age - targetHour) < Math.abs(prev.age - targetHour) ? curr : prev);
                    });
                    // 只接受误差在6小时内的
                    if (Math.abs(closest.age - targetHour) <= 6) {
                        historySystem = closest;
                    }
                }
            } else {
                // 实时模式：优先读全局 pressureHistory (模拟进行中)，或者直接读实时 pressureSystems (刚开始)
                if (state.pressureHistory && state.pressureHistory.length > 0) {
                    const found = state.pressureHistory.find(h => h.age === targetHour);
                    if (found) {
                        // The current snapshot can still be manually edited.
                        // Its live owner receives the existing cache invalidation.
                        historySystem = found.age === state.cyclone.age
                            ? state.pressureSystems : found;
                    }
                }
                
                // 兜底：如果还没生成历史 (Time=0)，直接用当前实时系统
                if (!historySystem) {
                    historySystem = state.pressureSystems;
                }
            }

            // 渲染检查
            if (!historySystem) {
                contentArea.innerHTML = '<div class="flex items-center justify-center h-full text-slate-400 font-bold">NO SYNOPTIC DATA FOUND</div>';
                return;
            }

            setTimeout(async () => {
                if (requestId !== renderRevision) return;
                if (typeof renderStationSynopticChart === 'function') {
                    try {
                        const canvas = await renderStationSynopticChart(
                            targetCyclone,
                            renderIndex,
                            state.world,
                            historySystem,
                            sLon, sLat, sName
                        );
                        if (requestId !== renderRevision || currentMode !== 'SYNOPTIC') return;
                        canvas.className = "max-w-full max-h-full shadow-lg border border-gray-800";
                        contentArea.innerHTML = '';
                        contentArea.appendChild(canvas);
                        currentCanvas = canvas;
                    } catch (error) {
                        if (requestId !== renderRevision || currentMode !== 'SYNOPTIC') return;
                        console.error('Unable to render surface synoptic chart', error);
                        contentArea.innerHTML = '<div class="text-red-400 font-bold">SYNOPTIC FIELD RENDER FAILED</div>';
                    }
                } else {
                    contentArea.innerText = "Module renderStationSynopticChart not loaded.";
                }
            }, 50);
        };

        // 绑定事件
        tabSynoptic.onclick = showSynopticChart;
        const exactHeightSystems = hour => {
            const history = state.selectedHistoryCyclone?.pressureHistory || state.pressureHistory || [];
            if (!state.selectedHistoryCyclone && hour === state.cyclone.age) return state.pressureSystems;
            const found = history.find(snapshot => snapshot.age === hour);
            if (found) return found;
            return null;
        };
        const showHeightChart = async (level, tab, mode, renderer) => {
            const requestId = ++renderRevision;
            updateTabStyles(tab);
            currentMode = mode; currentCanvas = null;
            const systems = exactHeightSystems(renderIndex * 3);
            contentArea.innerHTML = '';
            if (!systems?.upper?.some(cell => cell.role === 'height-background')) {
                contentArea.innerHTML = `<div class="text-slate-500 font-bold">NO ${level} hPa DATA AT THIS TIME</div>`;
                return;
            }
            const height500Key = level === 500
                ? icwcHeight500ProductKey(targetCyclone, renderIndex, state.world, systems)
                : null;
            const cachedCanvas = height500Key ? getCachedIcwcHeight500Canvas(height500Key) : null;
            if (cachedCanvas) {
                currentCanvas = cachedCanvas;
                currentCanvas.className = 'max-w-full max-h-full shadow-lg border border-gray-800';
                contentArea.innerHTML = '';
                contentArea.appendChild(currentCanvas);
                return;
            }
            contentArea.innerHTML = '<div class="text-slate-500 font-bold">RENDERING HEIGHT FIELD…</div>';
            try {
                const canvas = level === 500
                    ? await renderIcwcHeight500ChartCached(
                        targetCyclone, renderIndex, state.world, systems, height500Key
                    )
                    : await renderer(targetCyclone, renderIndex, state.world, systems);
                if (requestId !== renderRevision || currentMode !== mode) return;
                currentCanvas = canvas;
                currentCanvas.className = 'max-w-full max-h-full shadow-lg border border-gray-800';
                contentArea.innerHTML = '';
                contentArea.appendChild(currentCanvas);
            } catch (error) {
                if (requestId !== renderRevision || currentMode !== mode) return;
                console.error(`Unable to render ${level} hPa chart`, error);
                contentArea.innerHTML = `<div class="text-red-400 font-bold">${level} hPa FIELD RENDER FAILED</div>`;
            }
        };
        tabHeight500.onclick = () => showHeightChart(500, tabHeight500, 'HEIGHT500', renderHeight500ChartAsync);
        tabHeight200.onclick = () => showHeightChart(200, tabHeight200, 'HEIGHT200', renderHeight200Chart);

        // C. [修复版] 站点数据视图：基于历史记录查表
        const showStationData = () => {
            ++renderRevision;
            updateTabStyles(tabStation);
            currentMode = 'STATION';
            currentCanvas = null;
            contentArea.innerHTML = ''; 

            // 1. 计算目标时间
            // renderIndex 是轨迹点的索引，每步3小时
            const targetHour = renderIndex * 3;
            const isHistoryMode = !!state.selectedHistoryCyclone;
            let sourceList = [];
            if (isHistoryMode) {
                sourceList = state.selectedHistoryCyclone.siteHistory || [];
            } else {
                sourceList = state.siteHistory || [];
            }

            // 在确定的列表里查找记录
            const record = sourceList.find(h => h.hour === targetHour);

            // 3. 错误处理：如果没有记录（例如模拟未开始、未设置站点、或改了站点导致历史失效）
            if (!record) {
                contentArea.innerHTML = `
                    <div class="text-center text-slate-500 mt-20">
                        <i class="fa-solid fa-file-circle-xmark text-4xl mb-4 text-slate-300"></i>
                        <p class="font-bold">NO DATA RECORDED</p>
                        <p class="text-xs mt-2">No station measurements found for T+${targetHour}H.</p>
                        <p class="text-[10px] text-slate-400 mt-1">(Station monitoring might have been disabled)</p>
                    </div>
                `;
                return;
            }

            // 4. 解析记录的数据 (不再进行物理计算)
            const localWindKt = Math.round(record.wind);
            const localPressure = Math.round(record.pressure);
            
            // 恢复风向
            const flowAngleMath = Math.atan2(-record.v, record.u) * (180 / Math.PI);
            let windFromDir = (flowAngleMath + 270) % 360; 
            if (windFromDir < 0) windFromDir += 360;
            const localWindDirStr = record.direction || directionToCompass(windFromDir);

            // 恢复天气状况 (基于 dBZ)
            const dbz = record.dbz || 0;
            let conditionText = "FAIR";
            let conditionClass = "text-slate-500";
            let iconClass = "fa-sun";

            if (dbz >= 50) { conditionText = "VIOLENT STORM"; conditionClass = "text-purple-600"; iconClass = "fa-cloud-bolt"; }
            else if (dbz >= 35) { conditionText = "HEAVY RAIN"; conditionClass = "text-blue-700"; iconClass = "fa-cloud-showers-heavy"; }
            else if (dbz >= 15) { conditionText = "MODERATE RAIN"; conditionClass = "text-blue-500"; iconClass = "fa-cloud-rain"; }
            else if (dbz >= 5) { conditionText = "OVERCAST"; conditionClass = "text-slate-600"; iconClass = "fa-cloud"; }

            // 计算气旋距离 (使用当时气旋的位置 vs 当时站点的位置)
            // 注意：targetCyclone.track[renderIndex] 是气旋当时的位置
            const p = targetCyclone.track[renderIndex];
            // record.lat/lon 是当时站点的位置 (如果按照上面的修改存了的话，否则用当前的 state.siteLat)
            const siteLatFixed = record.lat || state.siteLat;
            const siteLonFixed = record.lon || state.siteLon;
            
            const distKm = calculateDistance(p[1], p[0], siteLatFixed, siteLonFixed);
            const bearing = (Math.atan2(p[0] - siteLonFixed, p[1] - siteLatFixed) * 180 / Math.PI + 360) % 360;
            const dirCompass = directionToCompass(bearing);
            const bearingRad = Math.atan2(p[0] - siteLonFixed, p[1] - siteLatFixed);
            let bearingDeg = (bearingRad * 180 / Math.PI);
            if (bearingDeg < 0) bearingDeg += 360;
            const bearingStr = directionToCompass(bearingDeg);

            // 5. 渲染 HTML (保持原有样式)
            const siteName = state.siteName || "UNNAMED STATION";
            const simDate = simulationDate(targetCyclone, targetHour);
            
            const dd = String(simDate.getUTCDate()).padStart(2, '0');
            const hh = String(simDate.getUTCHours()).padStart(2, '0');
            const validTimeStr = `${dd}/${hh}Z`; // 例如: 05/12Z
            const yyyyStr = simDate.getUTCFullYear();
            const mmStr = String(simDate.getUTCMonth() + 1).padStart(2, '0');
            const ddStr = String(simDate.getUTCDate()).padStart(2, '0');
            const hhStr = String(simDate.getUTCHours()).padStart(2, '0');
            const obsTimeCode = `${yyyyStr}${mmStr}${ddStr}${hhStr}`;

            // 2. 计算降水 (3小时累积估算)
            const precipVal = Math.max(0, (dbz - 12) * 2);
            const precipStr = precipVal.toFixed(1); // 保留1位小数 (8.6MM)

            // 3. 拼接最终字符串
            const rawObsText = `${obsTimeCode} ${localWindKt}KT ${localWindDirStr} ${localPressure}hPa ${precipStr}MM`;

contentArea.innerHTML = `
                <div class="bg-white p-6 shadow-sm border border-gray-200 w-full max-w-2xl font-mono h-full flex flex-col">
                    <div class="flex justify-between items-end mb-4 border-b pb-2">
                        <div>
                            <div class="text-[10px] text-gray-400 font-bold">STATION OBS</div>
                            <div class="text-2xl font-black">${siteName.toUpperCase()}</div>
                            <div class="text-[10px] text-gray-500 mt-1 flex gap-2">
                                <span><i class="fa-solid fa-location-dot"></i> ${siteLatFixed.toFixed(2)}N, ${siteLonFixed.toFixed(2)}E</span>
                                <span><i class="fa-solid fa-clock"></i> T+${targetHour}H</span>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="text-3xl font-black text-cyan-700">${validTimeStr}</div>
                            <div class="text-xs text-gray-400 font-bold">VALID TIME</div>
                            <button id="btn-show-obs-text" class="text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-1 rounded border border-slate-300 transition-colors">
                                <i class="fa-solid fa-file-code"></i> TEXT REPORT
                            </button>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div id="panel-wind" class="bg-slate-50 p-3 border-2 border-transparent hover:border-cyan-400 cursor-pointer transition-all group relative">
                            <div class="text-[10px] text-slate-400 font-bold mb-1 group-hover:text-cyan-600">10-MIN WIND (CLICK FOR CHART)</div>
                            <div class="flex items-baseline gap-2">
                                <div class="text-4xl font-black text-slate-800">${localWindKt}</div>
                                <div class="text-sm font-bold text-slate-500">KT</div>
                            </div>
                            <div class="text-xs font-bold text-slate-600 mt-1 flex items-center gap-1">
                                <i class="fa-solid fa-location-arrow transform rotate-[${windFromDir + 135}deg]"></i> 
                                ${localWindDirStr} <span class="text-[10px] text-slate-400 font-normal">(${Math.round(windFromDir)}°)</span>
                            </div>
                            <i class="fa-solid fa-chart-line absolute top-2 right-2 text-slate-200 group-hover:text-cyan-400"></i>
                        </div>

                        <div id="panel-pressure" class="bg-slate-50 p-3 border-2 border-transparent hover:border-yellow-400 cursor-pointer transition-all group relative">
                            <div class="text-[10px] text-slate-400 font-bold mb-1 group-hover:text-yellow-600">MSLP (CLICK FOR CHART)</div>
                            <div class="flex items-baseline gap-2">
                                <div class="text-4xl font-black text-slate-800">${localPressure}</div>
                                <div class="text-sm font-bold text-slate-500">hPa</div>
                            </div>
                            <div class="text-xs text-slate-400 mt-1">RECORDED</div>
                            <i class="fa-solid fa-chart-line absolute top-2 right-2 text-slate-200 group-hover:text-yellow-400"></i>
                        </div>
                    </div>

                    <div class="grid grid-cols-3 gap-2 text-center mb-4">
                        <div class="border p-2 rounded"><div class="text-[10px] text-gray-400">DIST</div><div class="font-bold">${Math.round(distKm)} KM</div></div>
                        <div class="border p-2 rounded"><div class="text-[10px] text-gray-400">COND</div><div class="font-bold ${conditionClass}"><i class="fa-solid ${iconClass}"></i> ${conditionText}</div></div>
                        <div class="border p-2 rounded">
                            <div class="text-[10px] text-gray-400">STORM BEARING</div>
                            <div class="font-bold text-[10px]">${bearingStr} (${Math.round(bearingDeg)}°)</div>
                        </div>
                    </div>

                    <div class="flex-1 border border-slate-100 bg-slate-50 rounded relative overflow-hidden">
                        <div id="station-chart-title" class="absolute top-2 left-2 text-[10px] font-bold text-slate-400 z-10">SELECT A PARAMETER ABOVE</div>
                        <div id="station-chart-view" class="w-full h-full"></div>
                    </div>
                </div>
            `;

            // 绑定点击事件
            const chartContainer = "#station-chart-view";
            const titleLabel = document.getElementById('station-chart-title');
            const panelWind = document.getElementById('panel-wind');
            const panelPressure = document.getElementById('panel-pressure');
            const historySlice = sourceList.filter(h => h.hour <= targetHour);

            // 默认显示 Wind
            drawStationGraph(chartContainer, historySlice, 'wind');
            titleLabel.textContent = "PAST WIND SPEED HISTORY";
            panelWind.classList.add('border-cyan-400', 'bg-cyan-50');

            panelWind.onclick = () => {
                drawStationGraph(chartContainer, historySlice, 'wind');
                titleLabel.textContent = "WIND SPEED HISTORY";
                // 更新高亮状态
                panelWind.classList.add('border-cyan-400', 'bg-cyan-50');
                panelPressure.classList.remove('border-yellow-400', 'bg-yellow-50');
            };

            panelPressure.onclick = () => {
                drawStationGraph(chartContainer, historySlice, 'pressure');
                titleLabel.textContent = "MSLP HISTORY";
                // 更新高亮状态
                panelPressure.classList.add('border-yellow-400', 'bg-yellow-50');
                panelWind.classList.remove('border-cyan-400', 'bg-cyan-50');
            };
            document.getElementById('btn-show-obs-text').onclick = () => {
                const container = document.querySelector(chartContainer);
                titleLabel.textContent = "FULL OBSERVATION LOG (CHRONOLOGICAL)";
                
                // 2. 遍历历史切片，生成每一行报文
                // historySlice 已经包含了从 T=0 到 当前时刻 的所有记录
                const logLines = historySlice.map(h => {
                    // A. 恢复时间
                    const tDate = simulationDate(targetCyclone, h.hour);

                    const yyyy = tDate.getUTCFullYear();
                    const mm = String(tDate.getUTCMonth() + 1).padStart(2, '0');
                    const dd = String(tDate.getUTCDate()).padStart(2, '0');
                    const hh = String(tDate.getUTCHours()).padStart(2, '0');
                    const timeStr = `${yyyy}${mm}${dd}${hh}`;

                    // B. 恢复数据
                    const w = Math.round(h.wind);
                    const p = Math.round(h.pressure);

                    // 恢复风向字符串
                    const angleMath = Math.atan2(-h.v, h.u) * (180 / Math.PI);
                    let dirDeg = (angleMath + 270) % 360;
                    if (dirDeg < 0) dirDeg += 360;
                    const dirStr = directionToCompass(dirDeg);

                    // 恢复降水
                    const dVal = h.dbz || 0;
                    const prec = Math.max(0, (dVal - 15) * (Math.random() + 1.8)).toFixed(1);

                    // C. 格式化单行 (使用 padEnd/padStart 对齐，让排版更整齐)
                    // 例如: 2026070106  12KT  NE   1008hPa  0.0MM
                    return `${timeStr}  ${String(w).padStart(3)}KT  ${dirStr.padEnd(3)}  ${p}hPa  ${prec.padStart(5)}MM`;
                }).join('\n'); // 用换行符连接

                // 3. 渲染到 Textarea (方便复制和滚动)
                container.innerHTML = `
                    <div class="w-full h-full p-2 bg-slate-50 border border-slate-200 rounded">
                        <textarea class="w-full h-full bg-transparent font-mono text-xs md:text-sm text-slate-700 resize-none focus:outline-none leading-relaxed p-2" readonly spellcheck="false">${logLines}</textarea>
                    </div>
                `;
                
                // 自动滚动到底部 (显示最新的一行)
                setTimeout(() => {
                    const textarea = container.querySelector('textarea');
                    if (textarea) textarea.scrollTop = textarea.scrollHeight;
                }, 10);
            };
        };

        const renderCurrentProduct = () => {
            switch (currentMode) {
                case 'PROB34': showProb(34); break;
                case 'PROB64': showProb(64); break;
                case 'SATELLITE': showSatelliteImagery(); break;
                case 'PHASE': showPhaseSpace(); break;
                case 'STATION': showStationData(); break;
                case 'SYNOPTIC': showSynopticChart(); break;
        case 'HEIGHT500': showHeightChart(500, tabHeight500, 'HEIGHT500', renderHeight500ChartAsync); break;
                case 'HEIGHT200': showHeightChart(200, tabHeight200, 'HEIGHT200', renderHeight200Chart); break;
                default: showGraphic();
            }
        };

        const navigateTime = direction => {
            const nextIndex = renderIndex + direction * 2;
            if (nextIndex < 0 || nextIndex >= targetCyclone.track.length) return;
            playPageTurn();
            renderIndex = nextIndex;
            updateTimeNavigation();
            renderCurrentProduct();
        };

        previousTimeButton.onclick = () => navigateTime(-1);
        nextTimeButton.onclick = () => navigateTime(1);
        jtwcModal.setAttribute('tabindex', '-1');
        jtwcModal.onkeydown = event => {
            const tagName = event.target?.tagName;
            if (tagName === 'INPUT' || tagName === 'TEXTAREA'
                || event.target?.isContentEditable) return;
            if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                navigateTime(event.key === 'ArrowRight' ? 1 : -1);
            }
        };
        updateTimeNavigation();

        // --- 3. 绑定事件 ---
        tabGraphic.onclick = showGraphic;
        warningMapFitButton.onclick = () => {
            fitWarningMapCone = !fitWarningMapCone;
            updateWarningMapFitButton();
            showGraphic();
        };
        tabProb34.onclick = () => showProb(34);
        tabProb64.onclick = () => showProb(64);
        tabSatellite.onclick = showSatelliteImagery;
        tabStation.onclick = showStationData;

        const saveBtn = document.getElementById('saveJtwcImage');
        saveBtn.onclick = () => {

            if (currentMode === 'SATELLITE') {
                const name = targetCyclone.name || 'STORM';
                const timeTag = `T${renderIndex * 3}`;
                const imgElement = contentArea.querySelector('img');
                if (imgElement && imgElement.src) {
                    const link = document.createElement('a');
                    link.download = `SAT_${name}_${timeTag}.png`;
                    link.href = imgElement.src; // 直接获取 Base64 数据
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                } else {
                    alert("No image to save!");
                }
                return; // 结束执行
            }

            if (currentCanvas) {
                const link = document.createElement('a');
                const name = targetCyclone.name || 'STORM';
                // 使用 currentMode 来区分文件名
                link.download = `JTWC_${name}_${currentMode}_T${renderIndex * 3}.png`;
                link.href = currentCanvas.toDataURL();
                link.click();
            } else {
                alert("No image to save!");
            }
        };
function getPressureSystemsAtHour(targetHour) {
    const isHistoryMode = !!state.selectedHistoryCyclone;

    const pressureHistory = isHistoryMode
        ? state.selectedHistoryCyclone.pressureHistory || []
        : state.pressureHistory || [];

    if (pressureHistory.length === 0) {
        return state.pressureSystems;
    }

    // 先精确匹配
    const exact = pressureHistory.find(
        snapshot => snapshot.age === targetHour
    );

    if (exact) {
        return {
            lower: exact.lower || [],
            upper: exact.upper || []
        };
    }

    // 没有精确值时，找最近的快照
    const closest = pressureHistory.reduce(
        (best, current) =>
            Math.abs(current.age - targetHour) <
            Math.abs(best.age - targetHour)
                ? current
                : best
    );

    // 防止误用相距很远的压力场
    if (Math.abs(closest.age - targetHour) <= 6) {
        return {
            lower: closest.lower || [],
            upper: closest.upper || []
        };
    }

    return state.pressureSystems;
}
        const timelineBtn = document.getElementById('saveTimelineVideo');

        timelineBtn.onclick = async () => {
            // Freeze the product and recorded-history owners for this job; tab switches must not mix products.
            const exportMode = currentMode;
            const exportViewOptions = { fitCone: fitWarningMapCone };
            if (!['GRAPHIC', 'SYNOPTIC', 'HEIGHT500', 'HEIGHT200'].includes(exportMode)) {
                alert('Timeline video is only available for WARNING GRAPHIC, SYNOPTIC CHART, 500 hPa HEIGHT and 200 hPa HEIGHT tabs.');
                return;
            }
            const exportCyclone = { ...targetCyclone, track: targetCyclone.track.slice(), forecastLogs: { ...targetCyclone.forecastLogs } };
            const timelineIndices = exportCyclone.track.map((_, i) => i).filter(i => i % 2 === 0);
            if (!timelineIndices.length) return;
            const historyOwner = state.selectedHistoryCyclone || state;
            const isHistoryExport = !!state.selectedHistoryCyclone;
            const pressureHistory = (historyOwner.pressureHistory || []).slice();
            const siteHistory = (historyOwner.siteHistory || []).slice();
            const world = state.world, fallbackSystems = state.pressureSystems;
            const site = { lon: state.siteLon, lat: state.siteLat, name: state.siteName || 'STATION' };
            const systemsAt = hour => {
                const exact = pressureHistory.find(snapshot => snapshot.age === hour);
                if (exact) return exact;
                if (!pressureHistory.length) return fallbackSystems;
                const closest = pressureHistory.reduce((best, next) => Math.abs(next.age - hour) < Math.abs(best.age - hour) ? next : best);
                return Math.abs(closest.age - hour) <= 6 ? closest : fallbackSystems;
            };
            const controller = new AbortController();
            const loadingBadge = document.createElement('div');
            loadingBadge.className = 'fixed top-4 right-4 bg-red-600 text-white px-4 py-2 rounded shadow-xl z-[9999] font-bold flex items-center gap-3';
            const progress = document.createElement('span'); progress.textContent = 'PREPARING TIMELINE…';
            const cancel = document.createElement('button'); cancel.textContent = 'CANCEL'; cancel.className = 'border border-white/60 px-2 py-1 rounded';
            cancel.onclick = () => { controller.abort(); progress.textContent = 'CANCELLING…'; cancel.disabled = true; };
            loadingBadge.append(progress, cancel); document.body.appendChild(loadingBadge);
            timelineBtn.disabled = true;
            timelineBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> PROCESSING...';
            try {
                const { blob } = await exportTimelineVideo({
                    indices: timelineIndices, signal: controller.signal,
                    onProgress: (done, total) => { progress.textContent = `EXPORTING FRAME ${done}/${total}`; },
                    renderFrame: async idx => {
                        const hour = idx * 3;
                        if (exportMode === 'GRAPHIC') return renderJTWCStyle(exportCyclone, idx, world, systemsAt(hour), exportViewOptions);
                        if (exportMode === 'HEIGHT500' || exportMode === 'HEIGHT200') {
                            const systems = !isHistoryExport && hour === exportCyclone.age
                                ? fallbackSystems : pressureHistory.find(snapshot => snapshot.age === hour);
                            if (!systems?.upper?.some(cell => cell.role === 'height-background')) throw new Error('Missing height snapshot');
                            // Export owns and releases these canvases; do not evict or resize the modal's cached canvas.
                            return exportMode === 'HEIGHT200'
                                ? renderHeight200Chart(exportCyclone, idx, world, systems)
                                : renderHeight500ChartAsync(exportCyclone, idx, world, systems);
                        }
                        const record = siteHistory.find(item => item.hour === hour);
                        return renderStationSynopticChart(exportCyclone, idx, world, systemsAt(hour),
                            record ? record.lon : site.lon, record ? record.lat : site.lat, site.name);
                    }
                });
                const url = URL.createObjectURL(blob), link = document.createElement('a');
                link.href = url; link.download = `${(exportCyclone.name || 'STORM').toUpperCase()}_${exportMode}_TIMELINE.webm`;
                document.body.appendChild(link); link.click(); link.remove();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
            } catch (error) {
                if (error.name !== 'AbortError') {
                    console.error('Video generation failed:', error);
                    alert('Failed to generate video. Check console for details.');
                }
            } finally {
                loadingBadge.remove(); timelineBtn.disabled = false;
                timelineBtn.innerHTML = '<i class="fa-solid fa-film"></i> SAVE TIMELINE';
            }
        };

        showGraphic();
    });

    closeJtwcModal.addEventListener('click', () => {
        jtwcModal.classList.add('hidden');
        playPanelClose();
    });
    
    if (catButton && newsModal) {
        mountObservationPost({
            modal: newsModal, openButton: catButton, closeButton: closeNewsModal,
            onOpen: playPanelOpen, onClose: playPanelClose,
            generate: generateObservationForecastOffMainThread,
            readInput: () => ({
                site: { name: state.siteName, lon: state.siteLon, lat: state.siteLat,
                    names: observationSiteSelector.getCityNames() },
                cyclone: state.cyclone, pressureSystems: state.pressureSystems,
                month: state.currentMonth, globalTemp: state.GlobalTemp, globalShear: state.GlobalShear,
                // Never relabel an older advisory as a fresh +0h forecast.
                forecasts: state.cyclone?.forecastLogs?.[state.cyclone.age] || []
            }),
            configure: () => {
                settingsMenu.classList.remove('hidden');
                siteLonInput.closest('details').open = true;
                observationSiteSelector.focus();
            }
        });
    }

    document.addEventListener('keydown', (event) => {
        // [关键] 如果焦点在输入框或文本域内，不触发快捷键，防止打字冲突
        if (event.target.closest?.('input, textarea, select, button, a, [contenteditable="true"]')) {
            return;
        }

        // Space: 暂停/继续
        if (event.code === 'Space') {
            event.preventDefault(); // 防止滚动页面
            togglePause();
        }


        // S: 开始 / 重启 (相当于点击 Generate 按钮)
        if (event.code === 'KeyS') {
            // 使用 click() 模拟点击，这样能同时触发音效、UI更新和模拟逻辑
            generateButton.click();
        }

        // [优化] 统一更新 UI 状态 (状态改变后调用一次即可)
        const updateRadarUI = () => {
            setLegendVisible('radar-legend', state.radarMode);
            setLegendVisible('doppler-legend', state.dopplerMode);
            requestRedraw();
            console.log(`[Mode] Radar: ${state.radarMode}, Doppler: ${state.dopplerMode}`);
        };

        // 'R' 键：切换雷达 (如果多普勒开启，则强切回雷达)
        if (event.code === 'KeyR') {
            if (state.dopplerMode) {
                state.dopplerMode = false;
                state.radarMode = true;
            } else {
                state.radarMode = !state.radarMode;
            }
            updateRadarUI();
        }

        // 'D' 键：切换多普勒 (如果雷达开启，则强切回多普勒)
        if (event.code === 'KeyD') {
            if (state.radarMode) {
                state.radarMode = false;
                state.dopplerMode = true;
            } else {
                state.dopplerMode = !state.dopplerMode;
            }
            updateRadarUI();
        }
        // 1, 2, 3: 切换模拟速度 (如果你之前添加了这部分代码，请保留)
        if (event.key === '1') changeSimulationSpeed(50);
        if (event.key === '2') changeSimulationSpeed(200);
        if (event.key === '3') changeSimulationSpeed(600);

        if (event.code === 'KeyV') {
            toggleLeftPanel();
        }
    });

    mountIntensityDrawer(forecastContainer, () => refreshIntensityChart(true));

    tabKt.addEventListener('click', () => {
        chartMode = 'kt';
        updateTabUI();
        refreshIntensityChart(true);
    });

    tabHpa.addEventListener('click', () => {
        chartMode = 'hpa';
        updateTabUI();
        refreshIntensityChart(true);
    });

    // 打开帮助面板
    helpButton.addEventListener('click', () => {
        playPanelOpen();
        helpModal.classList.remove('hidden');
        // 微小的延时以触发 CSS transition
        setTimeout(() => {
            helpModal.classList.remove('opacity-0');
            helpModal.querySelector('div').classList.remove('scale-95');
            helpModal.querySelector('div').classList.add('scale-100');
        }, 10);
    });

    // 关闭帮助面板
    function hideHelp() {
        playPanelClose();
        helpModal.classList.add('opacity-0');
        helpModal.querySelector('div').classList.add('scale-95');
        helpModal.querySelector('div').classList.remove('scale-100');
        setTimeout(() => {
            helpModal.classList.add('hidden');
        }, 300);
    }

    closeHelpModal.addEventListener('click', () => {
        hideHelp();
    });

    sfxButton.addEventListener('click', () => {
        const isMuted = toggleSFX();
    
        // 更新 UI 状态
        if (isMuted) {
            sfxIcon.classList.remove('fa-volume-high');
            sfxIcon.classList.add('fa-volume-xmark');
            sfxButton.classList.replace('text-cyan-400', 'text-slate-500');
        } else {
            sfxIcon.classList.remove('fa-volume-xmark');
            sfxIcon.classList.add('fa-volume-high');
            sfxButton.classList.replace('text-slate-500', 'text-cyan-400');
        }
    
        // 触发一个简短的点击音效（如果此时已开启）以反馈
        if (typeof playClick === 'function') playClick();
    });

    // 点击背景关闭
    helpModal.addEventListener('click', (e) => {
        if (e.target === helpModal) {
            hideHelp();
        }
    });
});
