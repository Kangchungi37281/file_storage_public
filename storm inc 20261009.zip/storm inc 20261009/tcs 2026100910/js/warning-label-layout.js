// Warning Graphic has at most six forecast labels. Each leader can point
// along either normal to the forecast track, separated by exactly 180 degrees.
export function warningLeadersIntersect(a, b) {
    const [ax, ay] = a.pos, [bx, by] = b.pos;
    const rx = a.labelX - ax, ry = a.labelY - ay;
    const sx = b.labelX - bx, sy = b.labelY - by;
    const qx = bx - ax, qy = by - ay;
    const cross = (x, y, u, v) => x * v - y * u;
    const denominator = cross(rx, ry, sx, sy);
    const epsilon = 1e-9;
    if (Math.abs(denominator) <= epsilon) {
        if (Math.abs(cross(qx, qy, rx, ry)) > epsilon) return false;
        const lengthSquared = rx * rx + ry * ry;
        if (lengthSquared <= epsilon) return false;
        const start = (qx * rx + qy * ry) / lengthSquared;
        const end = start + (sx * rx + sy * ry) / lengthSquared;
        return Math.min(1, Math.max(start, end)) - Math.max(0, Math.min(start, end)) > epsilon;
    }
    const t = cross(qx, qy, sx, sy) / denominator;
    const u = cross(qx, qy, rx, ry) / denominator;
    // A shared endpoint is not a crossing; touching forecast fixes may be
    // unavoidable on a stationary track. Detect interior intersections.
    return t > epsilon && t < 1 - epsilon && u > epsilon && u < 1 - epsilon;
}

export function layoutWarningLeaders(labels, offsetDist = 145, minimumLabelGap = 30) {
    const place = (label, angle) => ({...label, normalAngle:angle,
        labelX:label.pos[0] + Math.cos(angle) * offsetDist,
        labelY:label.pos[1] + Math.sin(angle) * offsetDist});
    // Keep the established vertical-spacing choices when they do not cross.
    const preferred = [];
    for (const label of labels) {
        let placed = place(label, label.normalAngle);
        if (preferred.length && Math.abs(placed.labelY - preferred.at(-1).labelY) < minimumLabelGap) {
            placed = place(label, label.normalAngle + Math.PI);
        }
        preferred.push(placed);
    }
    const score = layout => {
        let crossings = 0, crowded = 0;
        for (let i = 0; i < layout.length; i++) for (let j = 0; j < i; j++) {
            crossings += Number(warningLeadersIntersect(layout[i], layout[j]));
            crowded += Number(Math.abs(layout[i].labelY - layout[j].labelY) < minimumLabelGap);
        }
        return [crossings, crowded];
    };
    let best = preferred, bestScore = [...score(preferred), 0];
    if (!bestScore[0]) return best;
    // Check all 64 or fewer assignments together. Flipping only the newest
    // line can create another crossing, or miss an older nonadjacent label.
    for (let mask = 1; mask < 2 ** preferred.length; mask++) {
        let flips = 0;
        const candidate = preferred.map((label, index) => {
            const flip = Boolean(mask & (1 << index));
            flips += Number(flip);
            return flip ? place(label, label.normalAngle + Math.PI) : label;
        });
        const candidateScore = [...score(candidate), flips];
        const difference = candidateScore.findIndex((value, index) => value !== bestScore[index]);
        if (difference >= 0 && candidateScore[difference] < bestScore[difference]) {
            best = candidate;
            bestScore = candidateScore;
        }
    }
    return best;
}
