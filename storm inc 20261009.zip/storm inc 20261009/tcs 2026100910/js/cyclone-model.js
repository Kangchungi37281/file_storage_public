/**
 * cyclone-model.js
 * Core logic
 */
import { sampleMonthlyHeight, sampleWnpPropagation, sampleWeatherHeight, initializeWeatherSequence, NAME_LISTS, getSST, getPressureAt, normalizeLongitude, calculateDistance, windToPressure } from './utils.js';
import { advanceStormOcean, oceanThermodynamicMpi } from './ocean-thermal.js?v=20261008-forecast-categories1';
import { MONTHLY_HEIGHT_GRID } from './monthly-height-data.js';
import { getElevationAt, getLandStatus, queryTerrain } from './terrain-data.js?v=20260911-worker1-raster1';
import { calculateBackgroundHumidity } from './visualization.js?v=20261008-forecast-categories1';

const basinConfig = {
    'WPAC': { lon: { min: 100, max: 180 }, lat: { min: 5, max: 25 } },  // 西北太平洋
    'EPAC': { lon: { min: 180, max: 262 }, lat: { min: 5, max: 20 } },  // 东北太平洋 (140W to 80W)
    'NATL': { lon: { min: 262, max: 350 }, lat: { min: 6, max: 32 } },  // 北大西洋 (75W to 10W)
    'NIO':  { lon: { min: 60,  max: 100 }, lat: { min: 5, max: 25 } },   // 北印度洋
    'SHEM':  { lon: { min: 140,  max: 200 }, lat: { min: -15, max: -5 } },   // 南太平洋
    'SIO':  { lon: { min: 30,  max: 140 }, lat: { min: -15, max: -5 } },
    'SATL':  { lon: { min: -50,  max: 15 }, lat: { min: -25, max: -10 } }
};

// Coarse inland separator, [longitude east, latitude north], following the
// Mexico–Central America land bridge and continuing inland through Colombia.
// These are geographic control points, not a fitted circulation parameter or
// an official watershed dataset. Ocean points south/west belong to EPAC;
// Gulf of Mexico / Caribbean points north/east belong to NATL.
// NHC includes the Gulf of Panama and Pacific Colombia in the eastern Pacific:
// https://www.nhc.noaa.gov/pdf/Eastern_Pacific_Offshore_Description.pdf
const AMERICAS_BASIN_DIVIDE = [
    [260, 19.5], [262, 18], [264, 17], [266, 17.2], // Southern Mexico
    [268, 16.4], [270, 15.4], [272, 14.6], [274, 13.2], // Guatemala–Nicaragua
    [275, 10.8], [276, 10], [277, 9.2], [277.5, 8.9], // Costa Rica
    [278, 8.7], [279, 8.6], [280, 8.8], [280.4, 9], // Western Panama
    [280.7, 9.15], [281, 9.2], [281.5, 9.05], [282, 8.85], // Canal / San Blas
    [282.7, 8.3], [283, 7.5], [283.8, 6], [284, 0] // Darién / Colombia
];

// Forced spawn coordinates are authoritative for basin identity. Keep this
// separate from basinConfig because the latter describes random genesis
// boxes, not the full operational basin boundaries.
export function inferBasinFromCoordinates(lon, lat, fallback = 'WPAC') {
    const numericLon = Number(lon);
    const numericLat = Number(lat);
    if (!Number.isFinite(numericLon) || !Number.isFinite(numericLat)) {
        return fallback;
    }

    const lon360 = ((numericLon % 360) + 360) % 360;
    if (numericLat < 0) {
        if (lon360 >= 20 && lon360 < 140) return 'SIO';
        if (lon360 >= 140 && lon360 < 310) return 'SHEM';
        return 'SATL';
    }

    if (lon360 >= 40 && lon360 < 100) return 'NIO';
    if (lon360 >= 100 && lon360 < 180) return 'WPAC';
    if (lon360 >= 180 && lon360 < 260) return 'EPAC';
    if (lon360 >= 260 && lon360 < 284) {
        for (let i = 1; i < AMERICAS_BASIN_DIVIDE.length; i++) {
            const [east, north] = AMERICAS_BASIN_DIVIDE[i];
            if (lon360 > east) continue;
            const [west, south] = AMERICAS_BASIN_DIVIDE[i - 1];
            const boundaryLat = south + (north - south) * (lon360 - west) / (east - west);
            return numericLat < boundaryLat ? 'EPAC' : 'NATL';
        }
    }
    return 'NATL';
}

const MODEL_STEP_HOURS = 3;
// Forecast-only calibration of positive tropical wind production.
// Ordinary and rapid growth use separate scales, never stacked together.
// Keep environmental losses, land decay and baroclinic development intact.
const FORECAST_INTENSIFICATION_RATE_SCALE = 0.80;
const FORECAST_RI_INTENSIFICATION_RATE_SCALE = 0.60;
const ERC_MIN_INTENSITY = 80;
const ERC_ABORT_ADVERSE_DECAY_HOURS = 15;
const ERC_ABORT_BENIGN_DECAY_HOURS = 24;
const ERC_MPI_WEAKENING_RESPONSE_HOURS = 18;
const ERC_MPI_RECOVERY_RESPONSE_HOURS = 9;
const ERC_STRUCTURAL_PEAK_SMOOTHING_HOURS = 5;
const ERC_PERSISTENT_CLASSIC_HANDOFF_HOURS = 36;
const ERC_PERSISTENT_FUSION_HANDOFF_HOURS = 21;
const ERC_STALLED_CYCLE_ABORT_HOURS = 60;
const ERC_SETTLING_TIMEOUT_HOURS = 30;
const MAX_TROPICAL_WIND_KT = 220;
const MIN_RMW_KM = 8;
const MPI_REFERENCE_CIRCULATION_KM = 300;
const MPI_REFERENCE_RMW_KM = 30;
const EARTH_RADIUS_M = 6371000;
const EARTH_OMEGA = 7.292115e-5;
const GRAVITY = 9.80665;
const MODERN_FIELD_VERSION = 3;
const ZONAL_PROFILE_VERSION = 10;
// Small global persistence calibration, not a storm-speed floor. Shorten
// both clocks of the correlated ridge-shape process by 10%, keeping its
// amplitude/geometry and the relative forcing/response times unchanged.
// Version-2 weather snapshots retain the original clocks for replay.
const RIDGE_WEATHER_EVOLUTION_TIME_SCALE = .90;
const LAND_GEOMETRY_FALLBACK_PIXELS = 3;
const MIDLATITUDE_PLANETARY_WAVE_AMPLITUDE_SCALE = .84;
const MIDLATITUDE_PLANETARY_WAVE_AXIS_SCALE = .80;
const MIDLATITUDE_COMPOSITE_HEIGHT_LIMIT_M = 70;
// ERA5 spot checks and the standard 2-8-day storm-track diagnostic both show
// that the moving k=4-8 bank is too quiet relative to the planetary background.
// Increase only transient waves; the k=1-3 ridge/jet geometry remains fixed.
const MIDLATITUDE_SHORT_WAVE_AMPLITUDE_SCALE = 1.65;
// The Southern Hemisphere's stronger, more continuous westerly belt damps
// subtropical-ridge meandering relative to the Northern Hemisphere. Keep the
// wave phase and height anomaly intact; reduce only the geometric axis motion.
const SOUTHERN_HEMISPHERE_AXIS_VARIABILITY_SCALE = .60;
// Southern Hemisphere westerlies and their embedded Rossby-wave guide sit
// farther equatorward than the mirrored Northern Hemisphere monthly proxy.
// Shift the shared SH jet axis itself, so its winds, waves, and troughs stay
// collocated instead of applying separate offsets to transient features.
const SOUTHERN_HEMISPHERE_WESTERLY_EQUATORWARD_SHIFT_DEG = 4;
// Retain the existing SIO 500-hPa barotropic calibration. The 850/200-hPa
// differences are now reconstructed from the shared monthly thickness
// climatology, not from a shear boost selected by the storm's genesis basin.
const SIO_MIDLEVEL_WINTER_WESTERLY_MS = 4.2;
// In the Southern Hemisphere, let climatological ET contact follow the
// shifted westerly axis instead of waiting for the unrelated fixed 40S gate.
// Resolved fronts/troughs can still initiate ET equatorward of this envelope.
const SOUTHERN_WESTERLY_ET_FLANK_DEG = 8;
const SOUTHERN_WESTERLY_ET_MIN_CONTACT_LATITUDE = 25;
// Apply the Southern Hemisphere pre-40S exposure window year-round.
// Seasonal variation comes from the local front, shear and SST, not a
// calendar-month switch. This remains gradual exposure, not forced ET.
const SOUTHERN_ET_ONSET_LATITUDE = 25;
const SOUTHERN_ET_WINDOW_START = 27;
const SOUTH_ASIAN_HIGH_500_SCALE = .40;
// The reference ET closure lets the upper cold core establish before the
// cyclone is labelled extratropical.  SST gates are kept separate for the
// ordinary and polar branches because the latter reaches colder water first.
// Upper bound for the exposure-weighted progress coordinate; it is not a
// minimum elapsed-time requirement for declaring ET.
const EXTRATROPICAL_TRANSITION_MAX_HOURS = 36;
const EXTRATROPICAL_SST_MAX_C = 25.5;
const EXTRATROPICAL_POLAR_SST_MAX_C = 23.5;
const TROPICAL_CONVERSION_SST_MIN_C = 25.5;
const EXTRATROPICAL_LOWER_COLD_LAG_HOURS = 18;
const EXTRATROPICAL_LOWER_COLD_RAMP_HOURS = 18;
// The South Asian High is a seasonal mean, not a stationary Gaussian. Add a
// weak, correlated synoptic displacement/shape process so its eastern flank
// can open or tighten for a few days without randomizing every model step.
const SOUTH_ASIAN_HIGH_PERTURBATION_RESPONSE_HOURS = 42;
const SOUTH_ASIAN_HIGH_PERTURBATION_LON_SIGMA_DEG = 6.5;
const SOUTH_ASIAN_HIGH_PERTURBATION_LAT_SIGMA_DEG = 1.8;
const SOUTH_ASIAN_HIGH_PERTURBATION_STRENGTH_SIGMA = .13;
const SOUTH_ASIAN_HIGH_PERTURBATION_WIDTH_SIGMA = .10;
const LOW_LATITUDE_TROPICAL_UPPER_SCALE = .55;
// Easterly/convectively coupled tropical waves modulate the trade flow, but
// they are not vertically coherent subtropical highs.  Bound their shared
// height signal below the planetary/synoptic scale so several random modes
// cannot combine into a 5--7 m/s, multi-day meridional steering current.
const TROPICAL_WAVE_COMPOSITE_HEIGHT_LIMIT_M = 24;
// Keep the propagating equatorial trough visible at 500 hPa without letting a
// 10-20 m anomaly phase-lock the deep-layer steering for several days.
const EQUATORIAL_LOW_WAVE_500_SCALE = .65;
const LOW_LATITUDE_POLEWARD_RESTORING_WEIGHT = .28;
// Weather-scale WNP ridge displacement. The monthly ridge latitude remains
// unchanged; these zero-centred coordinates determine how often a realization
// places the western flank/col near a remote-ocean genesis point.
const WNP_RIDGE_LONGITUDE_VARIABILITY_DEG = 18;
const WNP_RIDGE_LATITUDE_VARIABILITY_BASE_DEG = 10;
const WNP_RIDGE_LATITUDE_VARIABILITY_EASTERN_DEG = 18;
// Concentrate the persistent summer trade/monsoon-ridge gradient west of the
// Philippine Sea. A broad 60-degree envelope contaminated 155-170E cols, yet
// was too weak to prevent repeated cancellations around 130E.
const WNP_SUMMER_TROPICAL_GRADIENT_SCALE = 4;
const WNP_SUMMER_TROPICAL_GRADIENT_CENTER_LON = 125;
const WNP_SUMMER_TROPICAL_GRADIENT_WIDTH_DEG = 20;
const WNP_RIDGE_RETREAT_EQUATORWARD_COUPLING = .60;
// Modest amplitude calibration of the resolved circulation, shared by the
// height maps and every steering layer. Keep the coupled lifecycle geometry
// and recurvature frequency unchanged; do not clip eastward track segments.
// The 1.55 -> 1.45 adjustment eases both the southern-flank westerlies and
// the northern-flank easterlies that can oppose the midlatitude current.
const WNP_MONSOON_CIRCULATION_AMPLITUDE_SCALE = 1.45;
const WNP_MONSOON_CIRCULATION_SIGMA_LON_OFFSET_DEG = 0;
const WNP_MONSOON_CIRCULATION_500_VERTICAL_SCALE = .58;
const WNP_MONSOON_CIRCULATION_200_VERTICAL_SCALE = .23;
const WNP_MONSOON_CIRCULATION_LONGITUDE_VARIABILITY_DEG = 18;
const WNP_MONSOON_CIRCULATION_LATITUDE_VARIABILITY_DEG = 8;
// Recurvature is a coupled atmosphere regime: an eastward-retreated ridge,
// a monsoon circulation west of the remote-ocean disturbance, and a broad
// midlatitude trough must coexist long enough for a real steering handoff.
// The frequency below selects initially active regimes; initially quiet
// regimes still pass through a slow lifecycle later, rather than freezing
// one Pacific-wide ridge shape for the storm's entire lifetime.
const WNP_RECURVATURE_REGIME_FREQUENCY = .35;
const WNP_RECURVATURE_MONSOON_AMPLITUDE_BOOST = 1.55;
const WNP_RECURVATURE_MONSOON_EAST_SHIFT_DEG = 10;
const WNP_RECURVATURE_MONSOON_NORTH_SHIFT_DEG = 10;
const WNP_RECURVATURE_RIDGE_EAST_SHIFT_DEG = 5;
const WNP_RECURVATURE_RIDGE_POLEWARD_SHIFT_DEG = 2.5;
const WNP_RECURVATURE_TROUGH_500_AMPLITUDE_M = 105;
const WNP_RECURVATURE_TROUGH_850_VERTICAL_SCALE = .50;
const WNP_RECURVATURE_TROUGH_200_VERTICAL_SCALE = .94;
const ENVIRONMENTAL_GUIDANCE_HEIGHT_SCALE = .93;
// The Bermuda-Azores high is one evolving ridge with a western extension,
// not an eastern Atlantic centre plus an unrelated permanent Gulf high.
// Its basin-mean longitude is near 45W (doi:10.1175/JCLI-D-20-0608.1).
// This geometry belongs to the ridge, regardless of the TC's genesis basin.
const NORTH_ATLANTIC_RIDGE_MEAN_LONGITUDE = 315;
// Basin-scale circulation regimes outside the WNP.  Each entry couples the
// active subtropical ridge to a broad tropical trough/ITCZ state and a
// poleward synoptic trough.  These are pressure-field features shared by all
// levels and diagnostics, not track impulses.  A substantial quiet fraction
// is retained so a stable subtropical high remains a normal realization.
const REGIONAL_CIRCULATION_CONFIGS = Object.freeze({
    EPAC: Object.freeze({
        ridgeId: '1:240', hemisphere: 1, activeFrequency: .46,
        tropicalLon: 232, tropicalLat: 12, tropicalAmplitudeM: 30,
        // Match the broad 500-hPa weakness used by the WNP coupled
        // recurvature state.  The former 76 m peak, followed by both the
        // lifecycle and tropical-tail tapers, could rearrange the positive
        // ridge lobes without ever opening the 5880-gpm belt.
        troughLon: 218, troughLat: 36, troughAmplitudeM: 135,
        troughLonVariabilityDeg: 10,
        ridgeLonShiftDeg: 9, ridgeLatShiftDeg: 3.0, ridgeWeakening: .24
    }),
    NATL: Object.freeze({
        ridgeId: '1:325', hemisphere: 1, activeFrequency: .48,
        tropicalLon: 305, tropicalLat: 14, tropicalAmplitudeM: 28,
        troughLon: 286, troughLat: 38, troughAmplitudeM: 82,
        ridgeLonShiftDeg: 10, ridgeLatShiftDeg: 3.5, ridgeWeakening: .27
    }),
    NIO: Object.freeze({
        ridgeId: '1:65', hemisphere: 1, activeFrequency: .52,
        tropicalLon: 82, tropicalLat: 15, tropicalAmplitudeM: 34,
        troughLon: 66, troughLat: 34, troughAmplitudeM: 70,
        ridgeLonShiftDeg: 8, ridgeLatShiftDeg: 3.0, ridgeWeakening: .22
    }),
    SHEM: Object.freeze({
        ridgeId: '-1:175', hemisphere: -1, activeFrequency: .43,
        tropicalLon: 168, tropicalLat: -13, tropicalAmplitudeM: 30,
        troughLon: 150, troughLat: -38, troughAmplitudeM: 76,
        ridgeLonShiftDeg: 9, ridgeLatShiftDeg: 3.2, ridgeWeakening: .24
    }),
    SIO: Object.freeze({
        ridgeId: '-1:65', hemisphere: -1, activeFrequency: .45,
        tropicalLon: 78, tropicalLat: -13, tropicalAmplitudeM: 31,
        troughLon: 58, troughLat: -38, troughAmplitudeM: 78,
        ridgeLonShiftDeg: 9, ridgeLatShiftDeg: 3.2, ridgeWeakening: .25
    }),
    SATL: Object.freeze({
        ridgeId: '-1:325', hemisphere: -1, activeFrequency: .38,
        tropicalLon: 335, tropicalLat: -15, tropicalAmplitudeM: 25,
        troughLon: 315, troughLat: -39, troughAmplitudeM: 72,
        ridgeLonShiftDeg: 8, ridgeLatShiftDeg: 3.0, ridgeWeakening: .22
    })
});
const WNP_RIDGE_SHOULDER_SIGMA_LON_DEG = 32;
const WNP_RIDGE_SHOULDER_MIN_HEIGHT_M = 0;
const WNP_RIDGE_SHOULDER_MAX_HEIGHT_M = 14;
const WNP_RIDGE_SHOULDER_SPLIT_DECAY = .72;
const WNP_MONSOON_RIDGE_CORRIDOR_HEIGHT_M = 34;
const WNP_RIDGE_CORRIDOR_DECAY_HOURS = 132;
const WNP_MONSOON_RIDGE_CORRIDOR_WIDTH_DEG = 22;
const WNP_MONSOON_RIDGE_CORRIDOR_EAST_OFFSET_DEG = 18;
// Reduced-order June-September WNP monsoon-trough departures from the
// reanalysis monthly mean.  The trough migrates poleward through September
// and is bottom-heavy; values are metres at 850 hPa.
const WNP_MONSOON_CIRCULATION = Object.freeze({
    6: Object.freeze({ lon: 132, lat: 12.5, amplitude: 16 }),
    // July's cyclonic monsoon circulation is anchored west of the Philippine
    // Sea while its broad trough extends eastward. Centering the whole
    // anomaly near 138E put 11N, 130E on the western (southward-flow) flank
    // and created a recurrent weak-steering cancellation with the ridge.
    7: Object.freeze({ lon: 124, lat: 15.0, amplitude: 20 }),
    8: Object.freeze({ lon: 143, lat: 17.0, amplitude: 24 }),
    9: Object.freeze({ lon: 145, lat: 18.5, amplitude: 20 })
});
// Vertical shear remains an environmental diagnostic. These parameters only
// control how much an already-organized vortex converts that stress into
// thermodynamic intensity loss; they do not reduce the 850/200-hPa wind field.
const SHEAR_DAMAGE_ONSET_KT = 10;
const SHEAR_DAMAGE_FULL_KT = 28;
const SHEAR_DAMAGE_RESPONSE_HOURS = 15;
const SHEAR_DAMAGE_RECOVERY_HOURS = 30;
// The existing size response already protects broad mature systems. Keep the
// new structural term conservative so genesis rates do not jump through the
// 34-kt threshold via a nonlinear feedback loop.
const SHEAR_RESILIENCE_MAX = .33;
const SHEAR_RESILIENCE_EXTREME_ONSET_KT = 24;
const SHEAR_RESILIENCE_EXTREME_FULL_KT = 32;
const SURFACE_UPPER_MASS_COUPLING = .032;
// A tropical cyclone is not a passive tracer: its mid-level mass deficit and
// upper-level outflow slightly reshape the surrounding ridge/trough field.
// Keep this projection weak and outer-only so it cannot become a second
// steering vortex or double-count the cyclone's own circulation.
const TC_ENVIRONMENT_FEEDBACK_500_SCALE = .13;
const TC_ENVIRONMENT_FEEDBACK_200_SCALE = .09;
const TC_ENVIRONMENT_FEEDBACK_MIN_INTENSITY = 35;
// Organization reaches maturity near hurricane strength, but the outer
// circulation/outflow response must keep increasing for a major typhoon.
// This extra tail is deliberately inactive below 95 kt and remains local to
// the existing response footprint rather than creating a basin-wide trough.
const TC_ENVIRONMENT_FEEDBACK_MAJOR_GAIN = .75;
// A minority of upper cold vortices are favourably phased to erode the
// western flank of the subtropical ridge. This is a transient geometry
// response, not a fixed global steering bias: the ridge centre moves east and
// briefly weakens over a 12-hour adjustment time.
const RIDGE_RETREAT_MAX_SHIFT_DEG = 9;
const RIDGE_RETREAT_MAX_WEAKENING = .35;
const RIDGE_RETREAT_RESPONSE_HOURS = 36;
// A split WNP ridge can contain a real western-flank weakness. Keep this as a
// geopotential-height anomaly so any poleward steering is diagnosed from the
// same 850/500/200-hPa field used by maps and every other cyclone.
const CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG = 2;

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const smoothstep = value => {
    const t = clamp(value, 0, 1);
    return t * t * (3 - 2 * t);
};

// One surface-roughness scale drives every near-surface land response. The
// pressure-gradient solver converts it to a drag coefficient, while the
// cyclone component uses the same scale for its 10-m transfer and inflow
// turning. Keeping one source of roughness avoids stacking unrelated land
// multipliers at different stages of the wind calculation.
const SURFACE_OCEAN_DRAG_COEFFICIENT = .0014;
const SURFACE_LAND_DRAG_RANGE = .0026;
const SURFACE_COASTAL_ROUGHNESS = .20;
const SURFACE_COASTAL_BLEND_DEG = .45;
const SURFACE_LAND_ROUGHNESS_BASE = .68;
const SURFACE_LAND_ROUGHNESS_ELEVATION_GAIN = .10;
const TERRAIN_SHELTER_SAMPLE_KM = 24;
const TERRAIN_SHELTER_RELIEF_ONSET_M = 40;
const TERRAIN_SHELTER_RELIEF_SCALE_M = 240;
const TERRAIN_SHELTER_MAX_REDUCTION = .32;

function surfaceRoughnessFromTerrain(terrainInfo = null) {
    if (!terrainInfo) return 0;
    if (terrainInfo.isLand) {
        const elevation = clamp(
            Math.max(0, Number(terrainInfo.elevation) || 0) / 680,
            0,
            1
        );
        const inlandRoughness = SURFACE_LAND_ROUGHNESS_BASE
            + SURFACE_LAND_ROUGHNESS_ELEVATION_GAIN * elevation;
        const coastDistanceDeg = Number(terrainInfo.coastDistanceDeg);
        if (Number.isFinite(coastDistanceDeg)) {
            const inlandProgress = smoothstep(
                coastDistanceDeg / SURFACE_COASTAL_BLEND_DEG
            );
            return SURFACE_COASTAL_ROUGHNESS
                + (inlandRoughness - SURFACE_COASTAL_ROUGHNESS) * inlandProgress;
        }
        return inlandRoughness;
    }
    const coastDistanceDeg = Number(terrainInfo.coastDistanceDeg);
    if (Number.isFinite(coastDistanceDeg)) {
        const proximity = 1 - smoothstep(
            coastDistanceDeg / SURFACE_COASTAL_BLEND_DEG
        );
        return SURFACE_COASTAL_ROUGHNESS * proximity;
    }
    // Compatibility fallback for callers that only have the legacy boolean
    // land status while the raster distance field is unavailable.
    return terrainInfo.isNearLand ? SURFACE_COASTAL_ROUGHNESS : 0;
}

function surfaceDragCoefficientFromRoughness(roughness) {
    return SURFACE_OCEAN_DRAG_COEFFICIENT
        + SURFACE_LAND_DRAG_RANGE * clamp(roughness, 0, 1);
}

function surfaceCycloneTransferFromRoughness(roughness) {
    // A 10-m land transfer retains roughly 69–73% of the cyclone component;
    // the coastal ramp remains close to the marine transfer.
    return 1 - 0.40 * clamp(roughness, 0, 1);
}

function surfaceInflowAngleFromRoughness(roughness) {
    // Rougher surfaces turn the 10-m flow further toward the pressure
    // gradient. This stays bounded and does not use elevation as a second
    // independent speed reduction.
    return 15 + 17 * clamp(roughness, 0, 1);
}

function terrainShelterFactor(lon, lat, windU, windV, terrainInfo) {
    if (!terrainInfo?.isLand || terrainInfo.rasterAvailable !== true) return 1;
    const windSpeed = Math.hypot(windU, windV);
    if (!(windSpeed > 8)) return 1;

    const radians = Math.PI / 180;
    const cosLat = Math.max(.20, Math.cos(lat * radians));
    const eastward = windU / windSpeed;
    const northward = windV / windSpeed;
    const distanceDeg = TERRAIN_SHELTER_SAMPLE_KM / 111.32;
    const upwindLon = normalizeLongitude(
        lon - eastward * distanceDeg / cosLat
    );
    const upwindLat = clamp(lat - northward * distanceDeg, -89.5, 89.5);
    const localElevation = Math.max(0, Number(terrainInfo.elevation) || 0);
    const upwindElevation = Math.max(0, getElevationAt(upwindLon, upwindLat) || 0);
    const relief = upwindElevation - localElevation;
    const reliefWeight = smoothstep(
        (relief - TERRAIN_SHELTER_RELIEF_ONSET_M) / TERRAIN_SHELTER_RELIEF_SCALE_M
    );
    return 1 - TERRAIN_SHELTER_MAX_REDUCTION * reliefWeight;
}

const vortexGeometryCache = new WeakMap();
const geopotentialHeightCache = new WeakMap();
const geopotentialHeightContextCache = new WeakMap();
const surfacePressureCache = new WeakMap();
const surfacePressureSamplerCache = new WeakMap();
const surfaceEnvironmentalWindCache = new WeakMap();
const surfaceEnvironmentGridCache = new WeakMap();
const SURFACE_ENVIRONMENT_GRID_SIZE = 41;
const SURFACE_ENVIRONMENT_GRID_MARGIN_KM = 60;
const SURFACE_ENVIRONMENT_EXACT_THRESHOLD_TOLERANCE_KT = 2;
const sioClimatologicalWindCache = new Map();

// Optional wind-field profiler. It is created by visualization.js only for
// `?wind-field-profile=1`; production runs take the same fast path as before.
function getWindFieldProfile() {
    const profile = globalThis.__windFieldProfile;
    return profile?.active ? profile : null;
}

// Opt-in diagnostics for one wind-field draw.  The normal sampling path does
// not create keys or touch these counters unless the profiler is active.
function recordWindFieldProfileSample(profile, kind, lon, lat) {
    if (!profile) return;
    const keySet = kind === 'pressure'
        ? profile.surfacePressureSampleKeys
        : profile.heightSampleKeys;
    if (!keySet) return;
    const key = `${lon},${lat}`;
    if (keySet.has(key)) {
        if (kind === 'pressure') profile.surfacePressureDuplicateSamples++;
        else profile.heightDuplicateSamples++;
        return;
    }
    keySet.add(key);
    if (kind === 'pressure') profile.surfacePressureUniqueSamples++;
    else profile.heightUniqueSamples++;
}
// The H10 outer constraint is a reduced-order closure in this simulator.
// Its broad-tail mapping starts outside the compact eyewall so circulation
// size can broaden R34 without moving the wind peak or adding a secondary
// maximum. The 280-km fit floor is not treated as a universal R34 radius.
const HOLLAND_FIT_RADIUS_MIN_KM = 280;
const HOLLAND_OUTER_PROFILE_CURVATURE = 0.10;
const HOLLAND_TAIL_BLEND_WIDTH_KM = 120;
const HOLLAND_TAIL_SHIFT_BASE_KM = 14;
const HOLLAND_TAIL_SHIFT_COMPACT_SCALE_KM = 24;
const HOLLAND_TAIL_SHIFT_BROADNESS_SCALE_KM = 6;
const OUTER_CORE_REMAP_AMPLITUDE = 0.075;

function getAtmospherePointCache(cacheStore, systems) {
    if (!systems || (typeof systems !== 'object' && typeof systems !== 'function')) return null;
    let cache = cacheStore.get(systems);
    if (!cache) {
        cache = new Map();
        cacheStore.set(systems, cache);
    }
    return cache;
}

function atmospherePointKey(lon, lat, extra = '') {
    return `${lon}|${lat}|${extra}`;
}

function clearAtmosphereEvaluationCache(systems) {
    if (!systems || (typeof systems !== 'object' && typeof systems !== 'function')) return;
    geopotentialHeightCache.delete(systems);
    geopotentialHeightContextCache.delete(systems);
    surfacePressureCache.delete(systems);
    surfacePressureSamplerCache.delete(systems);
    surfaceEnvironmentalWindCache.delete(systems);
    surfaceEnvironmentGridCache.delete(systems);
}

// Interactive edits mutate the existing pressure-system object in place.
// Expose a narrow invalidation hook so a newly placed/moved/removed handle is
// reflected by the very next map draw without advancing atmospheric time.
export function invalidatePressureSystemCaches(systems) {
    clearAtmosphereEvaluationCache(systems);
}

function isModernAtmosphericBackground(background) {
    return background?.flowModel === 'qg-barotropic-v1'
        || background?.fieldVersion >= MODERN_FIELD_VERSION;
}

// Monthly Northern Hemisphere western-Pacific circulation climatology.
// Ridge/jet positions are rounded 1981-2010 NCEP-NCAR monthly means over
// 120-170E: the 500-hPa easterly-to-westerly zero line and the 200-hPa maximum
// zonal wind, respectively. Jet strength preserves the model's reduced-order
// annual-mean amplitude but follows 35% of the observed monthly contrast; a
// literal 70 m/s winter jet would be too large for this coarse three-level
// steering model. South Asian High strength follows the regional 200-hPa
// height cycle, restricted to its meteorologically meaningful warm season.
// Transient Rossby and synoptic modes still supply event-to-event spread.
const MONTHLY_NH_CIRCULATION = [
    null,
    { summer: .05, monsoonAxis: 8,  ridgeLatitude: 16.0, jetLatitude: 32.5, jetStrength: 1.30, tradeStrength: 1.18, monsoonStrength: .50, waveFactor: 1.13, southAsianHighLongitude: 69, southAsianHighStrength: 0 },
    { summer: .10, monsoonAxis: 8,  ridgeLatitude: 15.5, jetLatitude: 32.5, jetStrength: 1.28, tradeStrength: 1.15, monsoonStrength: .52, waveFactor: 1.10, southAsianHighLongitude: 70, southAsianHighStrength: 0 },
    { summer: .20, monsoonAxis: 8,  ridgeLatitude: 16.0, jetLatitude: 32.5, jetStrength: 1.16, tradeStrength: 1.10, monsoonStrength: .58, waveFactor: 1.08, southAsianHighLongitude: 71, southAsianHighStrength: 0 },
    { summer: .35, monsoonAxis: 9,  ridgeLatitude: 17.0, jetLatitude: 32.5, jetStrength: 1.03, tradeStrength: 1.05, monsoonStrength: .68, waveFactor: 1.06, southAsianHighLongitude: 74, southAsianHighStrength: .15 },
    { summer: .50, monsoonAxis: 10, ridgeLatitude: 19.5, jetLatitude: 37.5, jetStrength: .97, tradeStrength: 1.00, monsoonStrength: .76, waveFactor: 1.02, southAsianHighLongitude: 78, southAsianHighStrength: .55 },
    { summer: .70, monsoonAxis: 13, ridgeLatitude: 23.0, jetLatitude: 37.5, jetStrength: .92, tradeStrength: .96, monsoonStrength: .88, waveFactor: 1.00, southAsianHighLongitude: 83, southAsianHighStrength: .86 },
    { summer: .90, monsoonAxis: 16, ridgeLatitude: 27.5, jetLatitude: 40.0, jetStrength: .80, tradeStrength: .90, monsoonStrength: .98, waveFactor: .96, southAsianHighLongitude: 89, southAsianHighStrength: 1.00 },
    { summer: 1.00, monsoonAxis: 17, ridgeLatitude: 30.0, jetLatitude: 45.0, jetStrength: .80, tradeStrength: .86, monsoonStrength: 1.00, waveFactor: .92, southAsianHighLongitude: 93, southAsianHighStrength: .99 },
    { summer: .85, monsoonAxis: 15, ridgeLatitude: 28.0, jetLatitude: 42.5, jetStrength: .94, tradeStrength: .94, monsoonStrength: .92, waveFactor: .99, southAsianHighLongitude: 90, southAsianHighStrength: .80 },
    { summer: .60, monsoonAxis: 11, ridgeLatitude: 24.0, jetLatitude: 40.0, jetStrength: 1.04, tradeStrength: 1.06, monsoonStrength: .72, waveFactor: 1.08, southAsianHighLongitude: 84, southAsianHighStrength: .45 },
    { summer: .30, monsoonAxis: 9,  ridgeLatitude: 21.0, jetLatitude: 35.0, jetStrength: 1.14, tradeStrength: 1.14, monsoonStrength: .58, waveFactor: 1.10, southAsianHighLongitude: 76, southAsianHighStrength: 0 },
    { summer: .10, monsoonAxis: 8,  ridgeLatitude: 18.0, jetLatitude: 35.0, jetStrength: 1.25, tradeStrength: 1.18, monsoonStrength: .50, waveFactor: 1.13, southAsianHighLongitude: 71, southAsianHighStrength: 0 }
];

function monthlyCirculation(month, hemisphere = 1, legacySeasonalShift = null) {
    const numericMonth = Number.isFinite(month)
        ? ((Math.round(month) - 1) % 12 + 12) % 12 + 1
        : 8;
    // A six-month phase reversal gives the Southern Hemisphere its own local
    // summer/winter evolution while preserving the same reduced-order shape.
    const northernMonth = hemisphere < 0
        ? (numericMonth + 5) % 12 + 1
        : numericMonth;
    const table = MONTHLY_NH_CIRCULATION[northernMonth];
    if (table) {
        if (hemisphere < 0) {
            // The Southern Hemisphere subtropical ridge and subtropical jet
            // are not a mirror image of the boreal field. The ocean-dominated
            // hemisphere keeps a stronger, more equatorward westerly belt;
            // even in its local summer the belt has a substantial 30S flank.
            // Keep the correction smooth through the seasons so it changes
            // the common height/wind field rather than forcing tracks later.
            const localSummer = table.summer;
            return {
                ...table,
                // The WNP 500-hPa zero line is not a transferable Southern
                // Hemisphere ridge index. Retain the oceanic SH climatology
                // near 25-27S instead of mirroring Asia's winter contraction.
                ridgeLatitude: 24.5 + 2.8 * localSummer
                    + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG,
                jetLatitude: Math.max(
                    33,
                    table.jetLatitude - (2 + 4 * localSummer)
                ) + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG
                    - SOUTHERN_HEMISPHERE_WESTERLY_EQUATORWARD_SHIFT_DEG,
                jetStrength: table.jetStrength * (1.12 + 0.08 * localSummer),
                northernMonth
            };
        }
        // The table already contains the observed cold-season contraction;
        // applying the former cosine correction here would double-count it.
        return {
            ...table,
            ridgeLatitude: table.ridgeLatitude
                + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG,
            jetLatitude: table.jetLatitude
                + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG,
            northernMonth
        };
    }

    const seasonalShift = Number.isFinite(legacySeasonalShift) ? legacySeasonalShift : 0;
    const summer = (1 + seasonalShift / 4 * hemisphere) / 2;
    const circulation = {
        summer,
        monsoonAxis: 8 + 5 * summer,
        ridgeLatitude: 26 + 5 * summer
            + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG,
        jetLatitude: 39 + 8 * summer
            + CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG,
        jetStrength: 1,
        tradeStrength: 1,
        monsoonStrength: .5 + .5 * summer,
        waveFactor: 1,
        southAsianHighLongitude: 70 + 24 * summer,
        southAsianHighStrength: summer,
        northernMonth
    };
    if (hemisphere < 0) {
        circulation.ridgeLatitude = Math.max(22, circulation.ridgeLatitude - (1.5 + 2.5 * summer));
        circulation.jetLatitude = Math.max(33, circulation.jetLatitude - (2 + 4 * summer))
            - SOUTHERN_HEMISPHERE_WESTERLY_EQUATORWARD_SHIFT_DEG;
        circulation.jetStrength *= 1.12 + 0.08 * summer;
    }
    return circulation;
}

function backgroundMonthlyCirculation(background, hemisphere, month = background.calendarMonth) {
    const circulation = monthlyCirculation(month, hemisphere, background.seasonalShift);
    // Old snapshots and the full WNP monthly field retain their own closure.
    // New procedural SH atmospheres locate the ridge/jet from the same column
    // that supplies their winds, not from a shifted northern-Pacific table.
    if (hemisphere < 0 && background.southernBasicStateVersion >= 2
        && !background.climatologyVersion) {
        return { ...circulation, ...southernMonthlyBasicState(month).axes };
    }
    return circulation;
}

// Reduced-order energy proxies, not resolved temperature gradients or PV dynamics.
// ET growth requires both a frontal zone and favourable phasing ahead of an upper low.
function resolvedSynopticTransitionFeatures(cyclone, background) {
    const state = background?.synoptic;
    if (!state) return { front: 0, frontLatitude: null, trough: 0 };
    const hemisphere = cyclone.lat < 0 ? -1 : 1;
    const latitude = Math.abs(cyclone.lat);
    let front = 0;
    let frontLatitude = null;
    let trough = 0;

    for (const low of state.frontalLows || []) {
        if (Math.sign(low.lat) !== hemisphere) continue;
        const lifecycle = frontalLifecycleEnvelope(low);
        if (lifecycle < .025) continue;
        const development = Number.isFinite(low.development) ? low.development : lifecycle;
        const strength = lifecycle * (.35 + .65 * clamp(development, 0, 1));
        const dx = normalizeLongitude(cyclone.lon - low.lon);
        const polewardOffset = (low.lat - cyclone.lat) * hemisphere;

        // A mobile frontal cyclone carries a baroclinic zone on its
        // equatorward flank.  The broad longitudinal window represents the
        // trailing front, while the narrower downstream/poleward window is
        // the favourable upper-trough phasing for structural conversion.
        const candidateLatitude = clamp(Math.abs(low.lat) - 2.5, 25, 55);
        const longitudinalOverlap = Math.exp(-.5 * ((dx - 2) / 18) ** 2);
        const candidateFront = strength * longitudinalOverlap
            * Math.exp(-.5 * ((latitude - candidateLatitude) / 7) ** 2);
        if (candidateFront > front) {
            front = candidateFront;
            frontLatitude = candidateLatitude;
        }
        trough = Math.max(
            trough,
            strength * Math.exp(-.5 * (
                ((dx - 6) / 12) ** 2 + ((polewardOffset - 4) / 10) ** 2
            ))
        );
    }

    for (const low of state.coldLows || []) {
        if (Math.sign(low.lat) !== hemisphere) continue;
        const lifecycle = Math.sin(Math.PI * clamp(
            (low.age || 0) / Math.max(1, low.life || 1), 0, 1
        )) ** 2;
        if (lifecycle < .025) continue;
        const dx = normalizeLongitude(cyclone.lon - low.lon);
        const polewardOffset = (low.lat - cyclone.lat) * hemisphere;
        trough = Math.max(
            trough,
            lifecycle * Math.exp(-.5 * (
                ((dx - 6) / 13) ** 2 + ((polewardOffset - 5) / 11) ** 2
            ))
        );
    }

    return { front, frontLatitude, trough };
}

function transitionEnvironment(cyclone, pressureSystems, frontalZone, totalShear) {
    const latitude = Math.abs(cyclone.lat);
    const background = pressureSystems?.upper?.find(c => c.role === 'height-background');
    const localCirculation = background
        ? backgroundMonthlyCirculation(background, cyclone.lat < 0 ? -1 : 1)
        : null;
    const localWinter = localCirculation ? localCirculation.summer < .35 : false;
    const hasWaveField = background && (background.waves || isModernAtmosphericBackground(background));
    const westerlyAxisLatitude = hasWaveField
        ? Math.abs(waveFieldComponents(cyclone.lon, cyclone.lat, background).jetLatitude)
        : null;
    const jetFlankFront = Number.isFinite(westerlyAxisLatitude)
        ? westerlyAxisLatitude - (localWinter ? 6 : 4)
        : null;
    const fallbackFrontLatitude = clamp(
        jetFlankFront ?? Math.abs(frontalZone?.latitude ?? 35), 25, 55
    );
    const synoptic = resolvedSynopticTransitionFeatures(cyclone, background);
    // Use the actual prognostic front where one is locally resolved. The jet
    // flank remains a climatological fallback, not a substitute for all
    // synoptic fronts in the 30-40 degree transition corridor.
    const useSynopticFront = Number.isFinite(synoptic.frontLatitude)
        && synoptic.front >= .12;
    const frontLatitude = useSynopticFront
        ? synoptic.frontLatitude : fallbackFrontLatitude;
    const climatologicalFront = Math.exp(-(((latitude - fallbackFrontLatitude) / 9) ** 2))
        * smoothstep((latitude - 20) / 8);
    const front = Math.max(climatologicalFront, synoptic.front)
        * smoothstep((latitude - 20) / 8);
    let trough = 0;
    for (const cell of pressureSystems?.upper || []) {
        if (!(cell.strength < 0) || !Number.isFinite(cell.x) || !Number.isFinite(cell.y)) continue;
        const dx = normalizeLongitude(cyclone.lon - cell.x);
        const dy = (cell.y - cyclone.lat) * (cyclone.lat < 0 ? -1 : 1);
        const phasing = Math.exp(-(((dx - 6) / 12) ** 2) - ((dy - 4) / 10) ** 2);
        trough = Math.max(trough, phasing * clamp(Math.abs(cell.strength) / 5, 0, 1));
    }
    if (background?.waves) {
        const local = waveFieldComponents(cyclone.lon, cyclone.lat, background);
        const center = getGeopotentialHeight500(cyclone.lon, cyclone.lat, pressureSystems, 500);
        const west = getGeopotentialHeight500(cyclone.lon - 5, cyclone.lat, pressureSystems);
        const east = getGeopotentialHeight500(cyclone.lon + 5, cyclone.lat, pressureSystems);
        const south = getGeopotentialHeight500(cyclone.lon, cyclone.lat - 5, pressureSystems, 500);
        const north = getGeopotentialHeight500(cyclone.lon, cyclone.lat + 5, pressureSystems, 500);
        // An eastward height rise also occurs on the western flank and inside
        // a subtropical high; it is not by itself evidence of a trough.  Require
        // positive local height curvature before treating the zonal slope as
        // a resolved wave trough for extratropical transition.
        const zonalCurvature = east + west - 2 * center;
        const totalCurvature = zonalCurvature + north + south - 2 * center;
        const cyclonicCurvature = smoothstep(
            (Math.max(zonalCurvature, totalCurvature) - .5) / 6
        );
        const waveTrough = smoothstep((east - west) / 60)
            * Math.exp(-(((latitude - Math.abs(local.jetLatitude)) / 14) ** 2))
            * cyclonicCurvature;
        trough = Math.max(trough, waveTrough);
    }
    trough = Math.max(trough, synoptic.trough);
    const shearCoupling = smoothstep((totalShear - 4) / 12)
        * (1 - 0.65 * smoothstep((totalShear - 35) / 25));
    return {
        front,
        trough,
        support: clamp(front * trough * shearCoupling, 0, 1),
        frontLatitude,
        frontSource: useSynopticFront ? 'synoptic' : 'climatological',
        synopticFront: synoptic.front,
        climatologicalFront,
        westerlyAxisLatitude,
        localWinter,
        transitionSummer: localCirculation?.summer ?? null,
        transitionMonth: Number.isFinite(background?.calendarMonth)
            ? background.calendarMonth : null
    };
}

function advanceExtratropicalTransition(cyclone, environment, sst, totalShear) {
    if (cyclone.isExtratropical) {
        cyclone.isTransitioning = false;
        cyclone.extratropicalAgeHours = (cyclone.extratropicalAgeHours || 0) + MODEL_STEP_HOURS;
        return;
    }
    const latitude = Math.abs(cyclone.lat);
    // Crossing poleward of the front must not switch transformation off as
    // the Gaussian local growth support falls. Transformation and growth differ.
    const winterLike = environment?.localWinter === true
        || (Number.isFinite(environment?.transitionSummer) && environment.transitionSummer < .35);
    // ET is a baroclinic/vertical-structure transition, not a latitude/SST
    // switch. A modest amount of deep-layer shear is therefore required even
    // in the subpolar fallback branch; cold water alone cannot declare ET.
    const shearThreshold = winterLike ? 6 : 8;
    const shearGate = totalShear >= shearThreshold;
    // Poleward of 50 degrees, a cold-core conversion that has reached the
    // westerlies must not depend on one noisy local shear sample clearing the
    // ordinary subtropical threshold. Keep a small, non-zero baroclinic gate
    // so latitude and cold water alone still cannot manufacture ET.
    const polarShearGate = totalShear >= 3;
    // Equatorward of the midlatitude belt, the climatological jet flank is
    // only a locator.  It cannot initiate ET without a resolved front or
    // cyclonically curved trough; otherwise a TC embedded in a closed
    // subtropical high can transform merely because shear is present.
    const resolvedBaroclinicContact = environment.synopticFront >= .12
        || environment.trough >= .12;
    const southernJetContactLatitude = cyclone.lat < 0
        && Number.isFinite(environment.westerlyAxisLatitude)
        ? Math.max(
            SOUTHERN_WESTERLY_ET_MIN_CONTACT_LATITUDE,
            environment.westerlyAxisLatitude - SOUTHERN_WESTERLY_ET_FLANK_DEG
        )
        : 40;
    const lowLatitudeContactGate = latitude >= southernJetContactLatitude
        || resolvedBaroclinicContact;
    // Allow the transition clock to start on the equatorward flank of a
    // resolved front instead of waiting until the centre crosses its axis.
    // Keep the independent front-strength, cold-SST and shear gates below.
    const frontalContact = latitude >= environment.frontLatitude - (winterLike ? 8 : 5)
        && (environment.front > 0.2 || latitude >= environment.frontLatitude)
        && shearGate
        && lowLatitudeContactGate;
    // The model has no resolved fronts: retain a climatological subpolar
    // exposure beyond 45 degrees, even if the sampled front/trough misses it.
    const subpolarContact = latitude >= 45 && shearGate;
    const polarContact = latitude >= 50
        && sst < EXTRATROPICAL_POLAR_SST_MAX_C && polarShearGate;
    // Year-round pre-40S frontal exposure/pace correction. SST, deep-layer
    // shear and structural completion gates remain mandatory; the window
    // alone cannot force an extratropical classification.
    const southernPre40 = cyclone.lat < -SOUTHERN_ET_WINDOW_START && cyclone.lat > -40;
    const pre40Exposure = southernPre40
        ? smoothstep((latitude - SOUTHERN_ET_ONSET_LATITUDE) / 13) : 0;
    const pre40Contact = southernPre40
        && (environment.front > 0.12 || latitude >= environment.frontLatitude - 2);
    const alreadyTransforming = cyclone.isTransitioning === true
        || (cyclone.transitionHours || 0) > 0;
    // Shear/front contact initiates ET, but once the structural transition has
    // started it is latched through completion. Only a sufficiently warm SST
    // can reverse that in-progress state.
    const transforming = alreadyTransforming
        ? sst < EXTRATROPICAL_SST_MAX_C
        : (((frontalContact || subpolarContact || pre40Contact)
            && sst < EXTRATROPICAL_SST_MAX_C && shearGate) || polarContact);
    // `transitionHours` is deliberately exposure-weighted: a storm in the
    // core of a front advances that progress clock faster than one skirting
    // its edge.  Do not use it as wall-clock duration for the EXT label.  A
    // separate elapsed counter is retained for diagnostics, while completion
    // itself is decided by the structural evidence below.
    if (transforming) {
        cyclone.transitionElapsedHours = Math.min(
            EXTRATROPICAL_TRANSITION_MAX_HOURS,
            (Number.isFinite(cyclone.transitionElapsedHours)
                ? cyclone.transitionElapsedHours : 0) + MODEL_STEP_HOURS
        );
    } else if ((cyclone.transitionHours || 0) <= 0) {
        cyclone.transitionElapsedHours = 0;
    } else {
        // A warm-water interruption erodes the elapsed structural memory too;
        // otherwise a later restart could inherit an old completion dwell.
        cyclone.transitionElapsedHours = Math.max(
            0,
            (Number.isFinite(cyclone.transitionElapsedHours)
                ? cyclone.transitionElapsedHours : 0) - MODEL_STEP_HOURS * 2
        );
    }
    const exposure = Math.max(
        environment.front,
        smoothstep((latitude - 40) / 10),
        pre40Exposure
    );
    const pre40Pace = southernPre40
        ? 1.20 + 0.80 * pre40Exposure : 1;
    const interruptionDecay = latitude >= 45 && (cyclone.transitionHours || 0) > 0
        ? MODEL_STEP_HOURS * .35
        : MODEL_STEP_HOURS * 2;
    cyclone.transitionHours = clamp((cyclone.transitionHours || 0)
        + (transforming
            ? MODEL_STEP_HOURS * (0.6 + 0.8 * exposure) * pre40Pace * 1.15
                * (1 + clamp(cyclone.frontalInteractionDamage || 0, 0, 1))
            : -interruptionDecay), 0, EXTRATROPICAL_TRANSITION_MAX_HOURS);
    if (cyclone.transitionHours <= 0) cyclone.transitionElapsedHours = 0;
    cyclone.isTransitioning = cyclone.transitionHours > 0;
    // Do not impose a fixed wall-clock minimum on ET.  The exposure clock is
    // only a smooth structural progress coordinate; completion requires the
    // upper and lower cold-core proxies to agree with the resolved baroclinic
    // support.  A previous resolved diagnostic, when available, takes
    // precedence so one newly negative upper-level sample cannot relabel the
    // storm by itself.
    const transitionProgress = smoothstep(
        (cyclone.transitionHours || 0) / EXTRATROPICAL_TRANSITION_MAX_HOURS
    );
    const upperColdReadiness = clamp(
        .62 * transitionProgress
            + .20 * clamp(environment?.trough || 0, 0, 1)
            + .18 * clamp(environment?.support || 0, 0, 1),
        0, 1
    );
    const lowerColdReadiness = smoothstep(
        ((cyclone.transitionHours || 0) - EXTRATROPICAL_LOWER_COLD_LAG_HOURS)
        / EXTRATROPICAL_LOWER_COLD_RAMP_HOURS
    );
    const phase = cyclone.phaseDiagnostics;
    const hasResolvedPhase = phase?.source === 'resolved-height-proxy'
        && Number.isFinite(phase.upperColdCore)
        && Number.isFinite(phase.deepWarmCore)
        && Number.isFinite(phase.vtLower);
    const phaseLagHours = Number.isFinite(phase?.lagHours)
        ? Math.max(0, phase.lagHours) : null;
    const currentLagHours = Number.isFinite(cyclone.transitionElapsedHours)
        ? Math.max(0, cyclone.transitionElapsedHours) : 0;
    const resolvedPhaseFresh = hasResolvedPhase
        && phaseLagHours !== null
        && Math.abs(phaseLagHours - currentLagHours) <= 12;
    const resolvedStructureReady = resolvedPhaseFresh
        && cyclone.transitionHours >= EXTRATROPICAL_LOWER_COLD_LAG_HOURS
        && phase.upperColdCore >= 0.40
        && phase.deepWarmCore <= 0.50
        && phase.vtLower <= 0
        && (phase.frontalAttachment >= 0.12
            || clamp(environment?.support || 0, 0, 1) >= 0.12);
    const proxyStructureReady = upperColdReadiness >= 0.55
        && lowerColdReadiness >= 0.45
        && (clamp(environment?.support || 0, 0, 1) >= 0.10
            || (clamp(environment?.front || 0, 0, 1) >= 0.35
                && clamp(environment?.trough || 0, 0, 1) >= 0.35));
    if (resolvedPhaseFresh ? !resolvedStructureReady : !proxyStructureReady) return;
    cyclone.isExtratropical = true;
    cyclone.isTransitioning = false;
    cyclone.isSubtropical = false;
    cyclone.extratropicalAgeHours = 0;
    cyclone.extratropicalStage = environment.support >= 0.3 ? 'developing' : 'decaying';
    cyclone.extratropicalDevelopmentEndTime = cyclone.age + 12 + 48 * environment.support;
    cyclone.extratropicalMaxIntensity = 45 + 50 * environment.support;
}

function diagnoseFrontalCycloneInteraction(cyclone, pressureSystems, totalShear) {
    if (!cyclone || cyclone.status !== 'active' || cyclone.isExtratropical) return null;
    const background = pressureSystems?.upper?.find(cell => cell.role === 'height-background');
    const frontalLows = background?.synoptic?.frontalLows || [];
    const hemisphere = Math.sign(cyclone.lat) || 1;
    const structurallyVulnerable = (cyclone.transitionHours || 0) >= 6
        || cyclone.intensity <= 50
        || (cyclone.intensity <= 75 && totalShear >= 18);
    // Compare pressure deficits, not absolute central pressures on different
    // backgrounds. Transition age alone cannot make a strong TC subordinate.
    // This is a reduced-order dominance proxy, not a resolved PV merger.
    const ambientPressure = getSurfacePressureAt(cyclone.lon, cyclone.lat, pressureSystems);
    const tcDepthHpa = Math.max(0, ambientPressure - windToPressure(
        cyclone.intensity, cyclone.circulationSize, cyclone.basin, ambientPressure
    ));
    if (!Number.isFinite(tcDepthHpa)) return null;

    let nearest = null;
    for (let index = 0; index < frontalLows.length; index++) {
        const low = frontalLows[index];
        if (Math.sign(low.lat) !== hemisphere) continue;
        const lifecycle = frontalLifecycleEnvelope(low);
        const development = Number.isFinite(low.development)
            ? clamp(low.development, 0, 1) : lifecycle;
        const alreadyMerging = (low.absorbedFraction || 0) > 0;
        if (!alreadyMerging && (lifecycle < .2 || development < .3)) continue;

        // Reject remote lows before the comparatively expensive closed-isobar
        // diagnosis. Absorption represents entry into the low's core, not a
        // generic encounter with its trailing front.
        const analyticDistanceKm = calculateDistance(
            cyclone.lat, cyclone.lon, low.lat, low.lon
        );
        if (analyticDistanceKm > 550) continue;
        const closure = getFrontalLowSurfaceClosure(low, pressureSystems);
        const lowDepthHpa = Math.max(0, closure.closureDepthHpa);
        if (!Number.isFinite(lowDepthHpa) || (!alreadyMerging && lowDepthHpa <= 0)) continue;
        const distanceKm = calculateDistance(
            cyclone.lat, cyclone.lon, closure.centerLat, closure.centerLon
        );
        const captureRadiusKm = clamp(
            frontalLowFootprintKm(low) * (.36 + .16 * development),
            180,
            420
        );
        if (distanceKm > captureRadiusKm) continue;
        const action = lowDepthHpa > tcDepthHpa && lowDepthHpa >= 4 && structurallyVulnerable
            ? 'tc-absorbed' : tcDepthHpa > lowDepthHpa ? 'frontal-low-absorbed' : null;
        if (!action) continue;
        if (!nearest || distanceKm < nearest.distanceKm) {
            nearest = {
                action,
                tcDepthHpa,
                lowIndex: index,
                centerLon: closure.centerLon,
                centerLat: closure.centerLat,
                centerPressure: closure.centerPressure,
                closureDepthHpa: lowDepthHpa,
                distanceKm,
                captureRadiusKm
            };
        }
    }
    return nearest;
}

function diagnoseFrontalCycloneAbsorption(cyclone, pressureSystems, totalShear) {
    const interaction = diagnoseFrontalCycloneInteraction(cyclone, pressureSystems, totalShear);
    return interaction?.action === 'tc-absorbed' ? interaction : null;
}

function advanceFrontalCycloneInteraction(cyclone, pressureSystems, interaction, environment, totalShear) {
    // Damage outlives the separate low, but relaxes rather than becoming a
    // permanent penalty. Reuse the existing shear-memory time scales.
    let damage = clamp(cyclone.frontalInteractionDamage || 0, 0, 1)
        * Math.exp(-MODEL_STEP_HOURS / SHEAR_DAMAGE_RECOVERY_HOURS);
    cyclone.frontalInteraction = interaction;
    if (interaction?.action === 'frontal-low-absorbed') {
        const background = pressureSystems.upper.find(cell => cell.role === 'height-background');
        const lows = background.synoptic.frontalLows;
        const low = lows[interaction.lowIndex];
        const depthSum = interaction.tcDepthHpa + interaction.closureDepthHpa;
        const dominance = (interaction.tcDepthHpa - interaction.closureDepthHpa) / depthSum;
        const overlap = Math.max(0, 1 - interaction.distanceKm / interaction.captureRadiusKm);
        // Entrain a fraction per circulation turnover, not an instantaneous
        // deletion of the entire environmental pressure/height anomaly.
        const turnoverHours = 2 * Math.PI * interaction.captureRadiusKm
            / Math.max(1, cyclone.intensity * .514444) / 3.6;
        const increment = Math.min(1 - (low.absorbedFraction || 0),
            MODEL_STEP_HOURS / Math.max(MODEL_STEP_HOURS, turnoverHours) * dominance * overlap);
        const absorbedFraction = clamp((low.absorbedFraction || 0) + increment, 0, 1);
        const entrainedFraction = increment * interaction.closureDepthHpa / depthSum;
        const shearStress = smoothstep((totalShear - SHEAR_DAMAGE_ONSET_KT)
            / (SHEAR_DAMAGE_FULL_KT - SHEAR_DAMAGE_ONSET_KT));
        const frontalContact = clamp(environment.synopticFront || 0, 0, 1);
        damage = clamp(damage + entrainedFraction * shearStress * frontalContact, 0, 1);
        cyclone.frontalInteraction = { ...interaction, absorbedFraction, entrainedFraction };
        if (absorbedFraction >= 1) {
            cyclone.absorbedFrontalLowCount = (cyclone.absorbedFrontalLowCount || 0) + 1;
        }
        // Copy-on-write: old pressureHistory snapshots may share these arrays.
        const nextLows = lows.flatMap((candidate, index) => index !== interaction.lowIndex
            ? [candidate] : absorbedFraction >= 1 ? [] : [{ ...candidate, absorbedFraction }]);
        pressureSystems.upper = pressureSystems.upper.map(cell => cell !== background ? cell
            : { ...background, synoptic: { ...background.synoptic, frontalLows: nextLows } });
        invalidatePressureSystemCaches(pressureSystems);
    }
    cyclone.frontalInteractionDamage = damage;
}

function expandRmwFromFrontalInteraction(cyclone) {
    const damage = clamp(cyclone.frontalInteractionDamage || 0, 0, 1);
    if (!(damage > 0)) return;
    const before = getPrimaryRmw(cyclone);
    const target = clamp(cyclone.circulationSize || before, before, 190);
    const response = 1 - Math.exp(-MODEL_STEP_HOURS * damage / SHEAR_DAMAGE_RESPONSE_HOURS);
    const after = clamp(before + (target - before) * response, MIN_RMW_KM, 190);
    const ratio = after / Math.max(MIN_RMW_KM, before);
    cyclone.rmw = after;
    if (cyclone.isERCActive) {
        cyclone.ercInnerRmw = after;
        if (Number.isFinite(cyclone.ercOuterRmw)) {
            cyclone.ercOuterRmw = clamp(cyclone.ercOuterRmw * ratio, after, 190);
        }
    }
    if (Number.isFinite(cyclone.radarRmwScale)) {
        cyclone.radarRmwScale = clamp(cyclone.radarRmwScale * ratio, .35, 3.2);
    }
}

function subtropicalIntensityChange(intensity, thermalChange, sst, humidity, totalShear, losses, trough) {
    // An existing upper cold core supplies a hybrid maintenance pathway over
    // mildly cool water. It fades in very cold water, dry air or destructive
    // shear, and targets storm strength rather than preserving arbitrary winds.
    const support = smoothstep((sst - 19) / 4)
        * smoothstep((humidity - 40) / 20)
        * (1 - smoothstep((totalShear - 18) / 20));
    // Dispersed convection couples less efficiently to the inner circulation.
    // Empirical response times, not a universal observed growth-rate cap.
    const thermalProduction = Math.max(0, thermalChange + losses);
    const adjustedThermal = thermalChange > -losses
        ? 0.40 * thermalProduction - losses : thermalChange;
    const hybridChange = (55 + 10 * trough - intensity) * 0.025 - losses;
    return adjustedThermal + support * Math.max(0, hybridChange - adjustedThermal);
}

function transitionIntensityChange(intensity, thermalChange, support, progress) {
    const weight = Math.min(0.9, support * (0.35
        + 0.65 * clamp(progress / EXTRATROPICAL_TRANSITION_MAX_HOURS, 0, 1)));
    const dynamicalChange = clamp((45 + 50 * support - intensity) * 0.08, -4, 1.5);
    return thermalChange * (1 - weight) + dynamicalChange * weight;
}

function rapidIntensificationRate(cyclone, mpi, sst, shear, humidity, normalRate, random = Math.random) {
    const favourable = !cyclone.isERCActive && !cyclone.isSubtropical
        && !cyclone.isTransitioning && !cyclone.isExtratropical && !cyclone.isMonsoonDepression
        && sst >= 29 && shear < 10 && humidity >= 65 && cyclone.intensity >= 55;
    if (!favourable) cyclone.riUntil = 0;
    if (favourable && cyclone.age >= (cyclone.riUntil || 0)
        && cyclone.age >= (cyclone.riCooldownUntil || 0) && mpi - cyclone.intensity >= 0) {
        const opportunity = smoothstep((sst - 28.5) / 2)
            * (1 - smoothstep(shear / 12)) * smoothstep((humidity - 55) / 25);
        if (random() < 0.05 * opportunity) {
            cyclone.riUntil = cyclone.age + 3 + 24 * random();
            cyclone.riCooldownUntil = cyclone.riUntil + 24;
            cyclone.riRate = 0.16 + 0.16 * random();
        }
    }
    cyclone.isRapidIntensifying = favourable && cyclone.age < (cyclone.riUntil || 0);
    return cyclone.isRapidIntensifying ? Math.max(normalRate, Number.isFinite(cyclone.riRate) ? cyclone.riRate : 0.32) : normalRate;
}

function updateShearDamageMemory(cyclone) {
    const effectiveShear = Math.max(
        0,
        Number.isFinite(cyclone.effectiveShear) ? cyclone.effectiveShear : 0
    );
    const stressTarget = smoothstep(
        (effectiveShear - SHEAR_DAMAGE_ONSET_KT)
            / (SHEAR_DAMAGE_FULL_KT - SHEAR_DAMAGE_ONSET_KT)
    );
    const previous = clamp(
        Number.isFinite(cyclone.shearDamage) ? cyclone.shearDamage : 0,
        0,
        1
    );
    const responseHours = stressTarget >= previous
        ? SHEAR_DAMAGE_RESPONSE_HOURS
        : SHEAR_DAMAGE_RECOVERY_HOURS;
    const relaxation = 1 - Math.exp(-MODEL_STEP_HOURS / responseHours);
    cyclone.shearDamage = clamp(
        previous + (stressTarget - previous) * relaxation,
        0,
        1
    );
    return cyclone.shearDamage;
}

function calculateShearResilience(cyclone, currentSize, effectiveHumidity) {
    const intensityMaturity = smoothstep(
        ((Number.isFinite(cyclone.intensity) ? cyclone.intensity : 25) - 28) / 42
    );
    const sizeMaturity = smoothstep((currentSize - 160) / 260);
    const moistureMaturity = smoothstep((effectiveHumidity - 50) / 25);
    const coreIntegrity = cyclone.isERCActive
        ? clamp(Number.isFinite(cyclone.ercInnerIntegrity) ? cyclone.ercInnerIntegrity : 1, 0, 1)
        : 1;
    const regimeFactor = cyclone.isMonsoonDepression
        ? 0.55
        : cyclone.isSubtropical
            ? 0.78
            : 1;
    const structuralSupport = clamp(
        (0.30 * intensityMaturity
            + 0.30 * sizeMaturity
            + 0.25 * moistureMaturity
            + 0.15 * coreIntegrity)
            * regimeFactor,
        0,
        1
    );
    const shearDamage = clamp(
        Number.isFinite(cyclone.shearDamage) ? cyclone.shearDamage : 0,
        0,
        1
    );
    const extremeShear = smoothstep(
        (cyclone.effectiveShear - SHEAR_RESILIENCE_EXTREME_ONSET_KT)
            / (SHEAR_RESILIENCE_EXTREME_FULL_KT - SHEAR_RESILIENCE_EXTREME_ONSET_KT)
    );
    return clamp(
        SHEAR_RESILIENCE_MAX
            * structuralSupport
            * (1 - 0.55 * shearDamage)
            * (1 - 0.75 * extremeShear),
        0,
        SHEAR_RESILIENCE_MAX
    );
}

function sampleEnvironmentalHumidity(cyclone, pressureSystems, month, globalTemp, prepareSampling = false) {
    // Same samples/formulas; prepare the immutable pressure closures once for
    // a forecast substep rather than rebuilding them at every ring node.
    const visualSampling = prepareSampling ? {
        pressure: createSurfacePressureSampler(pressureSystems, { includeTerrain: true }),
        windOptions: { pressureSampler: createSurfacePressureSampler(pressureSystems) }
    } : null;
    // Sample outside the self-moistened inner core rather than on one narrow
    // ring near the RMW. Keep the outer sample inside roughly 520 km: the old
    // 650-km reach let a compact depression ingest remote ridge/midlatitude
    // air that had not yet reached its circulation.
    const size = clamp(cyclone.circulationSize || 300, 150, 800);
    const radiiKm = [
        clamp(size * 0.45, 120, 220),
        clamp(size * 0.75, 220, 380),
        clamp(size * 1.05, 350, 520)
    ];
    const values = [];
    const anglesPerRing = 8;
    for (const radiusKm of radiiKm) {
        const radiusDeg = radiusKm / 111.32;
        for (let index = 0; index < anglesPerRing; index++) {
            const angle = index / anglesPerRing * 2 * Math.PI;
            const sampleLat = cyclone.lat + radiusDeg * Math.sin(angle);
            const longitudeScale = Math.max(0.25, Math.cos(sampleLat * Math.PI / 180));
            const sampleLon = cyclone.lon + radiusDeg * Math.cos(angle) / longitudeScale;
            values.push(calculateBackgroundHumidity(
                sampleLon,
                sampleLat,
                pressureSystems,
                month,
                cyclone,
                globalTemp,
                visualSampling
            ));
        }
    }
    const average = values.reduce((sum, value) => sum + value, 0) / values.length;
    const sorted = [...values].sort((a, b) => a - b);
    const drySectorCount = Math.max(1, Math.ceil(sorted.length * 0.25));
    const drySectorMean = sorted.slice(0, drySectorCount)
        .reduce((sum, value) => sum + value, 0) / drySectorCount;
    return {
        effective: 0.65 * average + 0.35 * drySectorMean,
        average,
        drySectorMean,
        minimum: sorted[0]
    };
}

function moistureIntensityResponse(effectiveHumidity, circulationSize = 300) {
    const growthFactor = 1;
    let dryAirFactor = 0;
    if (effectiveHumidity < 75) {
        const sizeSensitivity = 180
            + 0.65 * Math.max(0, 600 - circulationSize);
        // 60-75% RH produces a small but non-zero ventilation tendency. The
        // response steepens below 60%, then again below 50%, so moderate dry
        // air can interrupt an MPI plateau without behaving like a hostile
        // intrusion throughout otherwise developable conditions.
        dryAirFactor = (75 - effectiveHumidity) * 0.000012 * sizeSensitivity
            + Math.max(0, 60 - effectiveHumidity) * 0.00012 * sizeSensitivity
            + Math.max(0, 50 - effectiveHumidity) * 0.00008 * sizeSensitivity;
    }
    return { growthFactor, dryAirFactor };
}

function expandRmwOverLand(cyclone, elevation) {
    const terrain = clamp(Math.max(0, elevation || 0) / 1000, 0, 1);
    const oldRmw = getPrimaryRmw(cyclone);
    // Progressive core disruption, with stronger expansion over rough terrain.
    // Approach a bounded radius rather than compounding the old size multiplier.
    const ceiling = 120 + 40 * terrain;
    const expansion = (0.14 + 0.16 * terrain) * Math.max(0, 1 - oldRmw / ceiling);
    const newRmw = clamp(oldRmw * (1 + expansion), MIN_RMW_KM, 190);
    const ratio = newRmw / Math.max(MIN_RMW_KM, oldRmw);
    cyclone.rmw = newRmw;
    if (cyclone.isERCActive) {
        cyclone.ercInnerRmw = newRmw;
        if (Number.isFinite(cyclone.ercOuterRmw)) {
            cyclone.ercOuterRmw = clamp(cyclone.ercOuterRmw * ratio, newRmw, 190);
        }
    }
    if (Number.isFinite(cyclone.radarRmwScale)) {
        cyclone.radarRmwScale = clamp(cyclone.radarRmwScale * ratio, 0.35, 3.2);
    }
}

function fallbackRmwFromSize(size = 300) {
    return 5 + size * 0.105;
}

function radarBaseRmw(intensity, circulationSize) {
    const organization = clamp((intensity - 25) / 85, 0.01, 0.99);
    return (20 + circulationSize * 0.12) * (1.8 - 0.7 * organization);
}

function getPrimaryRmw(cyclone) {
    const radius = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerRmw)
        ? cyclone.ercInnerRmw : Number.isFinite(cyclone.rmw)
            ? cyclone.rmw : fallbackRmwFromSize(cyclone.circulationSize);
    return clamp(radius, MIN_RMW_KM, 190);
}

function normalizeCoreRadii(cyclone) {
    cyclone.rmw = clamp(Number.isFinite(cyclone.rmw) ? cyclone.rmw
        : fallbackRmwFromSize(cyclone.circulationSize), MIN_RMW_KM, 190);
    for (const key of ['ercInnerRmw', 'ercOuterRmw', 'ercPostRmwTarget']) {
        if (Number.isFinite(cyclone[key])) cyclone[key] = clamp(cyclone[key], MIN_RMW_KM, 190);
    }
}

function contractRmwDuringIntensification(cyclone) {
    // A finite structural target replaces indefinite per-step multiplication.
    // Size/intensity scaling is a simulation closure, not an RMW observation.
    const target = clamp(fallbackRmwFromSize(cyclone.circulationSize)
        / (1 + Math.max(0, cyclone.intensity) / 85), MIN_RMW_KM, 190);
    cyclone.rmw -= Math.max(0, cyclone.rmw - target) * 0.031;
}

function postErcContractionSupport(cyclone, thermodynamicMpi, baseIntensityChange) {
    if (!Number.isFinite(thermodynamicMpi) || !Number.isFinite(baseIntensityChange)) return 0;
    // After replacement, a broad new eye can lower the structure-adjusted MPI
    // to the current wind. Requiring intensification before allowing RMW to
    // contract then creates a circular, exact-intensity plateau. Use the
    // underlying thermodynamic headroom to permit slow, nearly steady-state
    // contraction, but stop it when the actual environment is weakening.
    if (baseIntensityChange < -0.25) return 0;
    const headroom = thermodynamicMpi - cyclone.intensity;
    const heatEngineSupport = smoothstep((headroom - 5) / 25);
    const activeIntensification = smoothstep(Math.max(0, baseIntensityChange) / 2);
    return heatEngineSupport * (0.35 + 0.65 * activeIntensification);
}

function contractPostErcRmw(cyclone, support) {
    if (!(support > 0) || !(cyclone.rmw > cyclone.ercPostRmwTarget + 0.5)) return false;
    const priorRmw = cyclone.rmw;
    const contractionRate = (1 - Math.exp(-MODEL_STEP_HOURS / 36)) * support;
    cyclone.rmw += (cyclone.ercPostRmwTarget - cyclone.rmw) * contractionRate;
    const priorRadarScale = Number.isFinite(cyclone.radarRmwScale)
        ? cyclone.radarRmwScale
        : 1;
    cyclone.radarRmwScale = clamp(
        priorRadarScale * cyclone.rmw / Math.max(1, priorRmw),
        0.35,
        3.2
    );
    return true;
}

function getOuterDecayEfficiency(circulationSize = 300) {
    // Large vortices retain a broad envelope, but their gale-force tail should
    // not expand in direct proportion to total circulation size. Compact and
    // average systems are essentially unchanged; the largest systems shorten
    // their radial decay scales by at most 28%.
    const largeCirculation = smoothstep((circulationSize - 250) / 450);
    return 1 - 0.28 * largeCirculation;
}

function getMpiEffectiveRmw(cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return innerRmw;

    // As the outer eyewall takes over, its much larger radius increasingly
    // represents the core over which the available heat engine is spread.
    const transition = getEnvelopeTransition(cyclone);
    return innerRmw + (cyclone.ercOuterRmw - innerRmw) * transition;
}

export function adjustMpiForStormStructure(thermodynamicMpi, cyclone) {
    if (!(thermodynamicMpi > 0)) return 0;

    const circulationSize = clamp(
        Number.isFinite(cyclone.circulationSize)
            ? cyclone.circulationSize
            : MPI_REFERENCE_CIRCULATION_KM,
        100,
        800
    );
    const effectiveRmw = clamp(
        getMpiEffectiveRmw(cyclone),
        MIN_RMW_KM,
        190
    );

    // Thermodynamic PI constrains the peak wind; total circulation size alone
    // is not a second independent PI limiter.  The previous 18% size penalty
    // could pin a compact-eye storm to a low "structural MPI" merely because
    // its outer circulation was broad.  Retain only an RMW-dependent spread
    // penalty, with size modulating it when the wind maximum itself is broad.
    const circulationDispersion = smoothstep(
        (circulationSize - MPI_REFERENCE_CIRCULATION_KM)
            / (800 - MPI_REFERENCE_CIRCULATION_KM)
    );
    const rmwDispersion = smoothstep(
        (effectiveRmw - MPI_REFERENCE_RMW_KM)
            / (190 - MPI_REFERENCE_RMW_KM)
    );
    const dispersionPenalty = 0.12 * rmwDispersion
        + 0.04 * circulationDispersion * rmwDispersion;
    const structuralEfficiency = clamp(1 - dispersionPenalty, 0.84, 1);

    return thermodynamicMpi * structuralEfficiency;
}

function hollandShapeParameter(cyclone, peakWind = cyclone?.intensity || 0) {
    // Holland (2008) environmental predictors for the surface-profile B
    // parameter. Pressure deficit is retained on the storm after every model
    // step; older saves fall back to a conservative wind-derived estimate.
    const environmentalPressure = Number.isFinite(cyclone?.environmentalPressure)
        ? cyclone.environmentalPressure : 1010;
    const centralPressure = Number.isFinite(cyclone?.centralPressure)
        ? cyclone.centralPressure
        : environmentalPressure - clamp(0.50 * peakWind, 8, 95);
    const pressureDeficit = clamp(environmentalPressure - centralPressure, 5, 120);
    const pressureTendency = clamp(cyclone?.pressureTendency || 0, -5, 5);
    const latitude = Math.abs(Number.isFinite(cyclone?.lat) ? cyclone.lat : 15);
    const translationMs = Math.max(0, cyclone?.speed || 0) * 0.514444;
    const delta = 0.6 * (1 - pressureDeficit / 215);
    const bs = 1
        - 4.4e-5 * pressureDeficit * pressureDeficit
        + 0.01 * pressureDeficit
        + 0.03 * pressureTendency
        - 0.014 * latitude
        + 0.15 * Math.pow(translationMs, delta);
    return clamp(bs, 0.8, 2.5);
}

function hollandWindAtFitRadius(
    radius,
    rmw,
    peakWind,
    fitRadius,
    hollandB,
    peripheralWind
) {
    if (!(radius > 0) || !(rmw > 0) || !(peakWind > 0)) return 0;

    const ratio = rmw / radius;
    const radialPower = Math.pow(ratio, hollandB);
    const normalizedGradientTerm = radialPower * Math.exp(1 - radialPower);

    // H10 Eq. (6), Vmax outside the brackets: solve x_n from (r_n, V_n).
    // No observed peripheral winds exist in this simulation, so the caller
    // supplies the 17 m/s fallback (or the weak-storm half-peak limit).
    const fitPower = Math.pow(rmw / fitRadius, hollandB);
    const fitLog = Math.log(fitPower) + 1 - fitPower;
    // A synthetic constraint requiring x_n < 0.5 would extrapolate toward
    // zero/negative x and eventually turn the tail upward. Reject that
    // broadening request (not an H10 requirement) to retain monotone decay.
    const peripheralX = Math.max(0.5, Math.log(peripheralWind / peakWind) / fitLog);
    // H10's linear x(r) continues beyond r_n; freezing it leaves an
    // artificially long power-law tail and a slope break at the fit radius.
    const outerFraction = Math.pow(
        Math.max(0, (radius - rmw) / (fitRadius - rmw)),
        HOLLAND_OUTER_PROFILE_CURVATURE
    );
    const x = 0.5 + (peripheralX - 0.5) * outerFraction;
    return peakWind * Math.pow(Math.max(0, normalizedGradientTerm), x);
}

function holland2010WindAtRadius(
    radius,
    rmw,
    peakWind,
    circulationSize,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    if (!(radius > 0) || !(rmw > 0) || !(peakWind > 0)) return 0;

    const size = clamp(circulationSize || 300, 100, 800);
    const broadness = clamp(outerWindBroadness, 0, 1);
    const peripheralWind = Math.min(17 / 0.514444, 0.5 * peakWind);

    // The Holland inversion supplies a shared inner-core decay. Circulation
    // size and broadness are applied by a separate finite tail shift outside
    // the eyewall, so they cannot move the wind peak.
    const coreFitRadius = Math.max(HOLLAND_FIT_RADIUS_MIN_KM, rmw + 120);
    const coreWind = hollandWindAtFitRadius(
        radius, rmw, peakWind, coreFitRadius, hollandB, peripheralWind
    );

    // Circulation size and outerWindBroadness set a bounded tail shift, rather
    // than a correction that vanishes for envelopes <=200 km. Small envelopes
    // receive the stronger shift; it fades as the storm grows so it does not
    // inflate already-large wind fields. Begin beyond the compact inner-core
    // maximum, and blend the shift over enough distance to keep the source
    // radius strictly increasing. A finite shift lifts gale radii without
    // flattening the far-field slope indefinitely or creating another peak.
    const compactness = 1 - smoothstep((size - 140) / 300);
    const tailShift = clamp(
        HOLLAND_TAIL_SHIFT_BASE_KM
            + HOLLAND_TAIL_SHIFT_COMPACT_SCALE_KM * compactness
            + HOLLAND_TAIL_SHIFT_BROADNESS_SCALE_KM * broadness,
        0,
        44
    );
    const tailStart = rmw + Math.max(34, 4 * rmw);
    if (!(radius > tailStart)) return coreWind;
    const distanceBeyondTail = radius - tailStart;
    const tailBlend = smoothstep(
        distanceBeyondTail / HOLLAND_TAIL_BLEND_WIDTH_KM
    );
    const sourceRadius = radius - tailShift * tailBlend;
    return hollandWindAtFitRadius(
        sourceRadius, rmw, peakWind, coreFitRadius, hollandB, peripheralWind
    );
}

function estimateSymmetricCoreR64(
    rmw,
    peakWind,
    circulationSize,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    if (!(peakWind > 64) || !(rmw > 0)) return rmw;
    const searchLimit = Math.max(220, Math.min(900, (circulationSize || 300) * 2.5));
    let previousRadius = rmw;
    let previousWind = peakWind;
    for (let radius = rmw + 2; radius <= searchLimit; radius += 2) {
        const wind = holland2010WindAtRadius(
            radius, rmw, peakWind, circulationSize, outerWindBroadness, hollandB
        );
        if (wind <= 64) {
            const fraction = (previousWind - 64) / Math.max(1e-6, previousWind - wind);
            return previousRadius + (radius - previousRadius) * clamp(fraction, 0, 1);
        }
        previousRadius = radius;
        previousWind = wind;
    }
    return searchLimit;
}

function primaryWindAtRadius(
    radius,
    rmw,
    peakWind,
    circulationSize,
    envelopePeakWind = peakWind,
    envelopeRmw = rmw,
    energyDispersion = 0,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    const coreWind = holland2010WindAtRadius(
        radius,
        rmw,
        peakWind,
        circulationSize,
        outerWindBroadness,
        hollandB
    );
    const envelopeWeight = clamp(energyDispersion, 0, 1);
    if (!(envelopeWeight > 0)
        || !(Number.isFinite(envelopeRmw) && envelopeRmw > rmw)
        || !(Number.isFinite(envelopePeakWind) && envelopePeakWind > 0)) {
        return coreWind;
    }
    // During a dual-eyewall cycle, angular momentum is distributed between
    // the compact inner core and a broader outer envelope. Blend the two
    // solved H10 profiles instead of interpolating RMW/peak parameters before
    // the nonlinear wind calculation. This lets ERC broadening reach R34
    // while preserving the distinct local RMW2 anomaly below.
    const envelopeWind = holland2010WindAtRadius(
        radius,
        envelopeRmw,
        envelopePeakWind,
        circulationSize,
        outerWindBroadness,
        hollandB
    );
    return coreWind + (envelopeWind - coreWind) * envelopeWeight;
}

function getEnvelopeTransition(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    return clamp(
        0.45 * (cyclone.ercOuterOrganization || 0)
            + 0.35 * Math.min(1, (cyclone.ercOuterShare || 0) * 1.5)
            + 0.55 * (1 - (cyclone.ercInnerIntegrity ?? 1)),
        0,
        1
    );
}

function getOuterEyewallDominance(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const organization = smoothstep(((cyclone.ercOuterOrganization || 0) - 0.28) / 0.62);
    const share = smoothstep(((cyclone.ercOuterShare || 0) - 0.20) / 0.52);
    const innerDecay = smoothstep((0.76 - (cyclone.ercInnerIntegrity ?? 1)) / 0.64);
    // A contracted replacement ring can have little *anomalous* momentum
    // because the parent background at RMW2 is already strong. Its small
    // anomaly share must not resurrect the inner eyewall at final handoff.
    // Full retirement matches the existing completion gates (integrity .14,
    // organization .90), continuously and independently of the stage label.
    const retirement = smoothstep((0.45 - (cyclone.ercInnerIntegrity ?? 1)) / 0.31);
    const dominance = organization * Math.max(share * innerDecay, retirement);
    return clamp(dominance, 0, 1);
}

function getErcEnergyDispersion(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const outerShare = clamp(cyclone.ercOuterShare || 0, 0, 1);
    const shareBalance = 4 * outerShare * (1 - outerShare);
    const organization = smoothstep(((cyclone.ercOuterOrganization || 0) - 0.08) / 0.82);
    return organization * smoothstep(shareBalance);
}

function baselineWindAtRadius(radius, cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    const innerWind = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
        ? cyclone.ercInnerWind
        : cyclone.intensity;
    const transition = getEnvelopeTransition(cyclone);
    const energyDispersion = getErcEnergyDispersion(cyclone);
    const envelopeRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? innerRmw + (cyclone.ercOuterRmw - innerRmw) * transition
        : innerRmw;
    return primaryWindAtRadius(
        radius,
        innerRmw,
        innerWind,
        cyclone.circulationSize,
        // Do not feed the already-resolved total intensity back into the
        // broad envelope. During ERC that value includes the outer-eyewall
        // anomaly below; reusing it here would double-count the ring and can
        // create a self-amplifying peak during settlement.
        innerWind,
        envelopeRmw,
        energyDispersion,
        Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
        hollandShapeParameter(cyclone, innerWind)
    );
}

function outerEyewallAnomalyAtRadius(radius, cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const innerRmw = Number.isFinite(cyclone.ercInnerRmw) ? cyclone.ercInnerRmw : getPrimaryRmw(cyclone);
    const gap = Math.max(8, cyclone.ercOuterRmw - innerRmw);
    const innerCutoff = smoothstep((radius - (innerRmw + 0.12 * gap)) / (0.30 * gap));
    const anomalyPeak = Math.max(0, cyclone.ercOuterWindAnomaly || 0);
    if (anomalyPeak <= 0) return 0;

    // RMW2 begins as a local annular maximum embedded in the parent
    // circulation. It only acquires the complete outer decay of the primary
    // vortex after organization, momentum share, and inner-eyewall decay show
    // that replacement is actually occurring.
    const organization = clamp(cyclone.ercOuterOrganization || 0, 0, 1);
    const ringWidth = clamp(cyclone.ercOuterWidth || 18, 8, 60);
    const innerSigma = Math.min(
        gap * (0.38 + 0.10 * (1 - organization)),
        ringWidth * (0.90 + 0.25 * (1 - organization))
    );
    const outerSigma = ringWidth * (1.10 + 0.35 * (1 - organization));
    const offset = radius - cyclone.ercOuterRmw;
    const sigma = Math.max(6, offset < 0 ? innerSigma : outerSigma);
    const coreShape = Math.exp(-0.5 * Math.pow(offset / sigma, 2));
    const baselineWind = baselineWindAtRadius(radius, cyclone);
    const outerBackground = baselineWindAtRadius(cyclone.ercOuterRmw, cyclone);
    const ringPeakWind = outerBackground + anomalyPeak;
    // A secondary wind maximum is a local perturbation, not a prescribed
    // gale-radius shelf. Its transition to a primary H10 envelope follows
    // continuous structural diagnostics (no ERC-state or V1=V2 switch).
    const localizedWind = baselineWind
        + Math.max(0, ringPeakWind * coreShape - baselineWind) * innerCutoff;
    const outerDominance = getOuterEyewallDominance(cyclone);
    const replacementWind = primaryWindAtRadius(
        radius,
        cyclone.ercOuterRmw,
        ringPeakWind,
        cyclone.circulationSize,
        ringPeakWind,
        cyclone.ercOuterRmw,
        0,
        Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
        hollandShapeParameter(cyclone, ringPeakWind)
    );
    // As the inner eyewall disappears or the rings merge, remove its residual
    // everywhere, so the limiting profile is the same one used after ERC.
    // These blend widths are closure assumptions, not observed universal rates.
    const remnantGone = smoothstep((0.45 - (cyclone.ercInnerIntegrity ?? 1)) / 0.31);
    const separated = smoothstep(Math.max(0, cyclone.ercOuterRmw - innerRmw) / Math.max(8, ringWidth));
    const replacementMask = 1 - (1 - innerCutoff) * separated * (1 - remnantGone);
    const resolvedWind = localizedWind
        + (replacementWind - localizedWind) * outerDominance * replacementMask;
    // Signed redistribution is needed to retire the inner remnant; clipping
    // this correction to positive values retains a ghost inner wind maximum.
    return resolvedWind - baselineWind;
}

const outerCoreRemapCache = new WeakMap();
const outerCoreRemapKeys = ['intensity', 'rmw', 'circulationSize', 'outerWindBroadness',
    'isERCActive', 'ercInnerRmw', 'ercInnerWind', 'ercOuterRmw', 'ercOuterWidth',
    'ercOuterWindAnomaly', 'ercOuterOrganization', 'ercOuterShare', 'ercInnerIntegrity',
    'environmentalPressure', 'centralPressure', 'pressureTendency', 'lat', 'speed'];

function unadjustedVortexWindAtRadius(radius, cyclone) {
    return baselineWindAtRadius(radius, cyclone) + outerEyewallAnomalyAtRadius(radius, cyclone);
}

// Empirical purple-curve adjustment, separate from the H08/H10 equations.
// Cache the R50 anchor once per physical state, never solve it per grid pixel.
export function getOuterCoreRemap(cyclone) {
    const cached = outerCoreRemapCache.get(cyclone);
    if (cached && outerCoreRemapKeys.every((key, i) => Object.is(cyclone[key], cached.values[i]))) {
        return cached;
    }
    const primary = getPrimaryRmw(cyclone);
    const start = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? cyclone.ercOuterRmw + Math.max(0, primary - cyclone.ercOuterRmw)
            * (1 - getOuterEyewallDominance(cyclone)) : primary;
    let end = start;
    if (unadjustedVortexWindAtRadius(start, cyclone) > 50) {
        let lo = start, hi = Math.max(start + 120, cyclone.circulationSize || 300);
        while (unadjustedVortexWindAtRadius(hi, cyclone) > 50 && hi < 1e6) hi *= 2;
        if (unadjustedVortexWindAtRadius(hi, cyclone) <= 50) {
            for (let i = 0; i < 36; i++) {
                const mid = (lo + hi) / 2;
                if (unadjustedVortexWindAtRadius(mid, cyclone) > 50) lo = mid;
                else hi = mid;
            }
            end = (lo + hi) / 2;
        }
    }
    const result = { start, end, values: outerCoreRemapKeys.map(key => cyclone[key]) };
    outerCoreRemapCache.set(cyclone, result);
    return result;
}

export function resolvedVortexWindAtRadius(radius, cyclone, remap = getOuterCoreRemap(cyclone)) {
    const { start, end } = remap;
    let sourceRadius = radius;
    if (radius > start && radius < end) {
        // Invert y=t-a sin²(pi t). Derivative >= 1-a*pi > 0;
        // Keep this secondary core remap small enough that the H10 outer
        // decay, rather than the empirical R50 warp, controls the knee.
        // C1 identity at both anchors preserves peaks and the <=50 kt tail.
        const y = (radius - start) / (end - start);
        let t = y;
        for (let i = 0; i < 5; i++) {
            const s = Math.sin(Math.PI * t);
            t -= (t - OUTER_CORE_REMAP_AMPLITUDE * s * s - y)
                / (1 - OUTER_CORE_REMAP_AMPLITUDE * Math.PI * Math.sin(2 * Math.PI * t));
        }
        sourceRadius = start + t * (end - start);
    }
    return unadjustedVortexWindAtRadius(sourceRadius, cyclone);
}

export function getEyewallWindProfile(cyclone, stepKm = 2) {
    const innerRmw = getPrimaryRmw(cyclone);
    const outerRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? cyclone.ercOuterRmw
        : null;
    const outerWidth = Math.max(8, cyclone.ercOuterWidth || 0);
    const maxRadius = outerRmw === null
        ? Math.max(innerRmw * 3, innerRmw + 80)
        : Math.max(innerRmw + 40, outerRmw + 3 * outerWidth);
    const radii = new Set([0, innerRmw]);
    if (outerRmw !== null) radii.add(outerRmw);
    for (let radius = Math.max(1, stepKm); radius <= maxRadius; radius += Math.max(1, stepKm)) {
        radii.add(radius);
    }
    const points = [...radii]
        .sort((a, b) => a - b)
        .map(radius => ({
            radius,
            wind: resolvedVortexWindAtRadius(radius, cyclone)
        }));
    const peaks = [];
    for (let i = 1; i < points.length - 1; i++) {
        if (points[i].wind >= points[i - 1].wind && points[i].wind > points[i + 1].wind) {
            peaks.push(points[i]);
        }
    }
    const maximum = points.reduce((best, point) => point.wind > best.wind ? point : best, points[0]);
    const significantPeaks = peaks.filter(peak => peak.wind >= Math.max(25, maximum.wind * 0.55));
    return {
        points,
        peaks: significantPeaks,
        maximum,
        hasDoublePeak: significantPeaks.length >= 2
            && significantPeaks.at(-1).radius - significantPeaks[0].radius >= 10
    };
}

/**
 * Returns the resolved two-eyewall structure.  The outer contribution is an
 * anomaly above the primary vortex, so ordinary background flow at RMW2 is
 * not mistaken for a second eyewall.
 */
export function getEyewallStructure(cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    const innerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
        ? cyclone.ercInnerWind
        : cyclone.intensity;
    const outerRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? cyclone.ercOuterRmw
        : null;
    const outerAnomaly = outerRmw === null ? 0 : Math.max(0, cyclone.ercOuterWindAnomaly || 0);
    const outerBackground = outerRmw === null ? 0 : baselineWindAtRadius(outerRmw, cyclone);
    const outerPeak = outerBackground + outerAnomaly;

    const innerMomentumSq = Math.pow(Math.max(0, innerPeak) * innerRmw, 2);
    const outerMomentumSq = Math.pow(outerAnomaly * (outerRmw || 0), 2);
    const totalMomentumSq = innerMomentumSq + outerMomentumSq;
    const outerShare = totalMomentumSq > 0 ? outerMomentumSq / totalMomentumSq : 0;
    const windProfile = getEyewallWindProfile(cyclone);

    return {
        innerRmw,
        innerPeak,
        outerRmw,
        outerBackground,
        outerAnomaly,
        outerPeak,
        outerShare,
        peakWind: windProfile.maximum.wind,
        dominantRmw: windProfile.maximum.radius,
        windPeaks: windProfile.peaks,
        hasDoubleWindPeak: windProfile.hasDoublePeak
    };
}

function smoothStructuralPeakIntoIntensity(cyclone, peakWind) {
    const currentAge = Number.isFinite(cyclone.age) ? cyclone.age : null;
    // beginEyewallSettlement can be reached after the regular active-ERC
    // writeback in the same model step. Do not apply the same transition twice.
    if (currentAge !== null && cyclone.structuralPeakSmoothingAge === currentAge) {
        return cyclone.intensity;
    }

    const target = Number.isFinite(peakWind) ? Math.max(10, peakWind) : null;
    if (target === null) return cyclone.intensity;

    const previous = Number.isFinite(cyclone.intensity)
        ? Math.max(10, cyclone.intensity)
        : target;
    // A five-hour e-folding response lets the scalar wind follow a genuine
    // eyewall-replacement dip without lagging an entire synoptic interval.
    const response = 1 - Math.exp(-MODEL_STEP_HOURS / ERC_STRUCTURAL_PEAK_SMOOTHING_HOURS);
    cyclone.intensity = previous + (target - previous) * response;
    if (currentAge !== null) cyclone.structuralPeakSmoothingAge = currentAge;
    return cyclone.intensity;
}

function clearEyewallStructure(cyclone, outcome = 'none') {
    cyclone.ercLastMode = cyclone.ercMode || cyclone.ercLastMode || 'none';
    cyclone.isERCActive = false;
    cyclone.ercState = 'none';
    cyclone.ercMode = 'none';
    cyclone.ercPotential = 0;
    cyclone.ercEligibleHours = 0;
    cyclone.ercFormationTargetHours = null;
    cyclone.ercStartTime = 0;
    cyclone.ercAdverseHours = 0;
    cyclone.ercInnerRmw = null;
    cyclone.ercInnerWind = null;
    cyclone.ercOuterRmw = null;
    cyclone.ercOuterWindAnomaly = 0;
    cyclone.ercOuterWidth = 0;
    cyclone.ercOuterRadarWidthKm = 0;
    cyclone.ercOuterShare = 0;
    cyclone.ercOuterOrganization = 0;
    cyclone.ercInnerIntegrity = 1;
    cyclone.ercSettlingUntil = 0;
    cyclone.ercCompletionOutcome = 'none';
    cyclone.ercCooldownHours = 0;
    cyclone.ercPostContractionHours = 0;
    cyclone.ercPace = 1;
    cyclone.ercRapid = false;
    cyclone.ercPeakSizeTarget = null;
    cyclone.ercMpiCeiling = null;
    cyclone.ercReplacementWindTarget = null;
    if (!['completed', 'fused'].includes(outcome)) {
        cyclone.ercPostSizeTarget = null;
        cyclone.ercPostSizeRelaxHours = 0;
        cyclone.ercPostSizeRelaxUntil = 0;
    }
    cyclone.ercLastOutcome = outcome;
}

function startEyewallReplacement(cyclone, support = 0.7, random = Math.random) {
    const innerRmw = getPrimaryRmw(cyclone);
    const mode = innerRmw > 95 || random() < 0.15 ? 'fusion' : 'classic';
    const compactness = 1 - smoothstep(((cyclone.circulationSize || 300) - 180) / 300);
    const rapidChance = clamp(0.16 + 0.25 * support + 0.11 * compactness, 0.16, 0.52);
    // Rapid cycles represent a pre-organized secondary eyewall taking over;
    // the separate fusion pathway keeps its own, more gradual geometry.
    const rapid = mode === 'classic' && random() < rapidChance;
    // Previous completed cycles leave a broader, already banded outer core.
    // Preserve a modest structural-memory advantage for later replacements so
    // the fourth cycle is not pushed to the very end of a 300 h storm.
    const priorCycleMemory = smoothstep((cyclone.ercCycleCount || 0) / 2);
    const pace = Math.min(3,
        (rapid ? 2.80 + random() * 0.20 : 2.55 + random() * 0.30)
            + 0.15 * priorCycleMemory
    );
    const outerRatio = mode === 'fusion'
        ? 1.52 + random() * 0.34
        : 2.15 + random() * 0.55;
    const minimumOuterRmw = innerRmw + (mode === 'fusion' ? 12 : 25);
    const sizeSupportedOuterRmw = Math.max(
        minimumOuterRmw,
        cyclone.circulationSize * (mode === 'fusion' ? 0.42 : 0.38)
    );
    const outerRmw = clamp(
        outerRatio * innerRmw,
        minimumOuterRmw,
        Math.min(190, sizeSupportedOuterRmw)
    );
    const initialWidth = mode === 'fusion'
        ? clamp((outerRmw - innerRmw) * 0.82, 14, 34)
        : clamp(outerRmw * 0.30, 20, 55);
    const initialRadarWidth = mode === 'fusion'
        ? clamp(70 + random() * 45, 60, 125)
        : clamp(60 + outerRmw * 0.45 + random() * 25, 55, 120);

    cyclone.isERCActive = true;
    cyclone.ercStartedCount = (cyclone.ercStartedCount || 0) + 1;
    cyclone.ercFormationTargetHours = null;
    cyclone.ercState = 'forming';
    cyclone.ercMode = mode;
    cyclone.ercStartTime = cyclone.age;
    cyclone.ercAdverseHours = 0;
    cyclone.ercInnerRmw = innerRmw;
    cyclone.ercInnerWind = cyclone.intensity;
    cyclone.ercOuterRmw = outerRmw;
    cyclone.ercOuterWidth = initialWidth;
    cyclone.ercOuterRadarWidthKm = initialRadarWidth;
    cyclone.ercOuterWindAnomaly = Math.max(1.5, cyclone.intensity * (rapid ? 0.050 : 0.025));
    cyclone.ercOuterShare = 0;
    cyclone.ercOuterOrganization = rapid ? 0.15 : 0.06;
    cyclone.ercInnerIntegrity = 1;
    cyclone.ercInitialIntensity = cyclone.intensity;
    cyclone.ercEnvironmentalPeak = cyclone.intensity;
    cyclone.ercMpiCeiling = cyclone.intensity;
    cyclone.ercInitialRmw = innerRmw;
    cyclone.ercCompactRecovery = random() < (0.20 + 0.25 * support + (rapid ? 0.10 : 0));
    cyclone.ercInitialSize = cyclone.circulationSize;
    cyclone.ercPace = pace;
    cyclone.ercRapid = rapid;
    cyclone.ercReplacementWindTarget = null;
    const peakExpansion = rapid
        ? 0.07 + random() * 0.07
        : (mode === 'fusion' ? 0.07 + random() * 0.08 : 0.10 + random() * 0.10);
    cyclone.ercPeakSizeTarget = Math.min(
        800,
        Math.max(
            cyclone.ercInitialSize * (1 + peakExpansion),
            outerRmw * (mode === 'fusion' ? 2.55 : 2.75)
        )
    );
    cyclone.ercPostSizeTarget = cyclone.ercInitialSize * (1.03 + random() * 0.05);
    cyclone.ercPostSizeRelaxHours = rapid
        ? 36 + random() * 48
        : 48 + random() * 72;
    cyclone.ercPostSizeRelaxUntil = 0;
    cyclone.ercPotential = 0;
}

function beginEyewallSettlement(cyclone, structure, outcome = 'completed', random = Math.random) {
    const completedMode = cyclone.ercMode || 'classic';
    const rapid = Boolean(cyclone.ercRapid);
    const peakSizeTarget = Number.isFinite(cyclone.ercPeakSizeTarget)
        ? cyclone.ercPeakSizeTarget
        : cyclone.ercInitialSize * 1.12;
    const completedSize = Math.max(
        cyclone.circulationSize,
        cyclone.ercInitialSize + (peakSizeTarget - cyclone.ercInitialSize) * 0.68
    );

    // Crossing the takeover threshold is not the same as instantly acquiring
    // a finished single eyewall.  Keep both radar rings alive while the inner
    // remnant fades and the new primary ring closes and narrows.
    cyclone.ercState = 'settling';
    cyclone.ercCompletionOutcome = outcome;
    cyclone.ercSettlingUntil = cyclone.age + (rapid
        ? 3 + random() * 3
        : (completedMode === 'fusion' ? 3 + random() * 6 : 6 + random() * 9));
    cyclone.rmw = structure.outerRmw;
    smoothStructuralPeakIntoIntensity(cyclone, structure.peakWind);
    cyclone.circulationSize = completedSize;
    // Permit another cycle somewhat sooner after the replacement ring has
    // settled, while retaining a finite recovery interval between cycles.
    cyclone.ercCooldownHours = 6 + random() * 9;
    cyclone.ercPostContractionHours = completedMode === 'fusion'
        ? 6 + random() * 18
        : 9 + random() * 24;
    // Anchor recovery to the replacement ring, not the retired inner eye.
    // Reusing an inherited tiny inner RMW makes every later ERC return there,
    // even after a much larger outer eyewall has taken over.
    cyclone.ercPostRmwTarget = cyclone.ercCompactRecovery
        ? structure.outerRmw * (0.65 + random() * 0.25)
        : structure.outerRmw * (0.85 + random() * 0.10);
    const minimumPostRmw = MIN_RMW_KM;
    cyclone.ercPostRmwTarget = clamp(
        cyclone.ercPostRmwTarget,
        minimumPostRmw,
        Math.max(MIN_RMW_KM, structure.outerRmw * 0.95)
    );
}

function finishEyewallSettlement(cyclone) {
    const outcome = cyclone.ercCompletionOutcome || 'completed';
    const outerRmw = cyclone.ercOuterRmw;
    const outerRadarWidth = Number.isFinite(cyclone.ercOuterRadarWidthKm)
        ? cyclone.ercOuterRadarWidthKm
        : 55;
    cyclone.rmw = outerRmw;
    // Close the final dual-to-single-eyewall handoff against the resolved
    // profile. The six-hour smoothing governs ordinary writebacks; this final
    // conservation step prevents clearing the ERC state from leaving the
    // scalar intensity and the single-eyewall profile out of sync.
    const finalStructuralPeak = getEyewallStructure(cyclone).peakWind;
    if (Number.isFinite(finalStructuralPeak)) cyclone.intensity = finalStructuralPeak;
    cyclone.ercCompletedAt = cyclone.age;
    cyclone.ercCycleCount = (cyclone.ercCycleCount || 0) + 1;
    cyclone.ercCooldownUntil = cyclone.age + Math.max(cyclone.ercCooldownHours || 15, cyclone.ercPostContractionHours || 24);
    cyclone.ercPostContractionUntil = cyclone.age + (cyclone.ercPostContractionHours || 36);
    cyclone.ercPostSizeRelaxUntil = cyclone.age + (cyclone.ercPostSizeRelaxHours || 72);
    cyclone.radarRmwScale = clamp(
        outerRmw / Math.max(1, radarBaseRmw(cyclone.intensity, cyclone.circulationSize)),
        0.35,
        3.2
    );
    // Store the convective-ring thickness separately from RMW.  A large eye
    // therefore remains compatible with a comparatively thin eyewall.
    cyclone.radarEyewallWidthKm = clamp(outerRadarWidth, 30, cyclone.ercMode === 'fusion' ? 130 : 120);
    cyclone.radarEyewallMaturity = 0;
    clearEyewallStructure(cyclone, outcome);
}

function evolveEyewallReplacement(cyclone, environment, applyBaseTendency = true, random = Math.random) {
    // Treat every ERC input as a physical boundary. A stale/invalid value from
    // a land-sea transition must not enter the multiplicative wind-profile
    // solver, where one non-finite ring value can contaminate the whole storm.
    const mpi = Number.isFinite(environment?.mpi)
        ? clamp(environment.mpi, 0, MAX_TROPICAL_WIND_KT)
        : clamp(cyclone.intensity, 10, MAX_TROPICAL_WIND_KT);
    const totalShear = Number.isFinite(environment?.totalShear)
        ? Math.max(0, environment.totalShear) : 0;
    const effectiveHumidity = Number.isFinite(environment?.effectiveHumidity)
        ? clamp(environment.effectiveHumidity, 0, 100) : 60;
    const isOverLand = Boolean(environment?.isOverLand);
    const baseIntensityChange = Number.isFinite(environment?.baseIntensityChange)
        ? clamp(environment.baseIntensityChange, -30, 15) : 0;

    // Once a secondary eyewall has formed, the temporary intensity dip is a
    // consequence of the replacement itself and must not be interpreted as
    // loss of structural maturity.
    const maturityIntensity = cyclone.isERCActive
        && Number.isFinite(cyclone.ercInitialIntensity)
        ? Math.max(cyclone.intensity, cyclone.ercInitialIntensity)
        : cyclone.intensity;
    const maturity = smoothstep((maturityIntensity - ERC_MIN_INTENSITY) / 35);
    // Mature storms commonly enter ERC close to their environmental ceiling;
    // only a substantial MPI overshoot should suppress secondary formation.
    const mpiSupport = 1 - smoothstep((cyclone.intensity - mpi + 5) / 20);
    const shearSupport = 1 - smoothstep((totalShear - 8) / 16);
    const moistureSupport = smoothstep((effectiveHumidity - 55) / 22);
    const oceanSupport = isOverLand || cyclone.isTransitioning || cyclone.isExtratropical || cyclone.isSubtropical ? 0 : 1;
    const structureSupport = smoothstep(((cyclone.circulationSize || 300) - 150) / 300);
    // Moderate shear or merely average humidity should slow organization, not
    // collapse the support product to almost zero. Truly hostile values are
    // handled separately by the adverse-environment test below.
    const shearOrganization = 0.35 + 0.65 * shearSupport;
    const moistureOrganization = 0.40 + 0.60 * moistureSupport;
    const support = oceanSupport * maturity * mpiSupport
        * shearOrganization * moistureOrganization
        * (0.78 + 0.22 * structureSupport);

    if (!cyclone.isERCActive) {
        if (cyclone.age < (cyclone.ercCooldownUntil || 0) || cyclone.intensity < ERC_MIN_INTENSITY) {
            // Brief weakening below the nominal threshold should not erase a
            // long period of prior inner-core organization. Cool the memory
            // gradually; a genuinely prolonged weak phase still removes it.
            cyclone.ercPotential = Math.max(0, (cyclone.ercPotential || 0) - 0.04);
            cyclone.ercEligibleHours = Math.max(
                0,
                (cyclone.ercEligibleHours || 0) - MODEL_STEP_HOURS
            );
            return;
        }

        // Treat this as accumulated favourable-structure exposure rather than
        // a brittle consecutive-hours counter. Marginal three-hour humidity
        // or shear samples no longer erase six hours of mature-core history.
        const structurallyEligible = oceanSupport > 0
            && cyclone.intensity >= 95
            && totalShear < 30
            && effectiveHumidity >= 40
            && mpi >= 75
            && cyclone.intensity <= mpi + 20;

        // Mature storms retain a weaker cycle-building signal even when one
        // humidity sample makes the instantaneous support score mediocre.
        // This prevents a long-lived major cyclone from remaining permanently
        // locked in an unrealistically steady, single-eyewall state.
        const sustainedStructureSupport = oceanSupport * maturity * mpiSupport
            * (0.40 + 0.60 * shearSupport)
            * (0.45 + 0.55 * moistureSupport);
        const formationSupport = Math.max(support, 0.72 * sustainedStructureSupport);
        const exposureGain = MODEL_STEP_HOURS * (
            0.75 + 0.25 * clamp(formationSupport, 0, 1)
        );
        cyclone.ercEligibleHours = structurallyEligible
            ? Math.min(144, (cyclone.ercEligibleHours || 0) + exposureGain)
            : Math.max(0, (cyclone.ercEligibleHours || 0) - 0.5 * MODEL_STEP_HOURS);

        const noisySupport = clamp(formationSupport + (random() - 0.5) * 0.08, 0, 1);
        const overdueCyclePressure = 0.090
            * smoothstep(((cyclone.ercEligibleHours || 0) - 6) / 18);
        cyclone.ercPotential = clamp(
            (cyclone.ercPotential || 0)
                + 0.32 * noisySupport * noisySupport
                - 0.012 * (1 - noisySupport)
                + overdueCyclePressure,
            0,
            1.15
        );
        if (structurallyEligible && !Number.isFinite(cyclone.ercFormationTargetHours)) {
            // A persistent mature core should not remain a single eyewall indefinitely.
            // Randomize once per cycle, not every step; exposure survives brief interruptions.
            const repeatOrganizationMemory = smoothstep(
                ((cyclone.ercCycleCount || 0) - 1) / 2
            );
            cyclone.ercFormationTargetHours = (18 + 20 * random())
                * (1 - 0.18 * repeatOrganizationMemory);
        }
        const matureCycleDue = structurallyEligible
            && cyclone.ercEligibleHours >= cyclone.ercFormationTargetHours;
        if (oceanSupport && (cyclone.ercPotential >= 1 || matureCycleDue)) startEyewallReplacement(cyclone, support, random);
        return;
    }

    const elapsed = cyclone.age - cyclone.ercStartTime;
    // Abort only for an actually hostile environment. The old support < 0.28
    // test also included current intensity, so ordinary ERC weakening could
    // incorrectly abort its own cycle.
    const adverse = oceanSupport <= 0
        || totalShear > 32
        || effectiveHumidity < 40
        || mpi < 65
        || isOverLand;
    // Hostile conditions may weaken both rings thermodynamically, but they
    // cannot keep driving an eyewall replacement. The former 0.65 floor in
    // innerLoss let a failed outer ring erode the inner eyewall throughout the
    // full 18-hour abort-confirmation window.
    const replacementSupport = adverse ? 0 : support;
    const replacementViability = adverse ? 0 : 1;
    cyclone.ercOuterOrganization = Number.isFinite(cyclone.ercOuterOrganization)
        ? cyclone.ercOuterOrganization
        : 0.04;
    cyclone.ercOuterRadarWidthKm = Number.isFinite(cyclone.ercOuterRadarWidthKm)
        ? cyclone.ercOuterRadarWidthKm
        : clamp((cyclone.ercOuterWidth || 18) * 3, 30, 120);
    cyclone.ercInnerIntegrity = Number.isFinite(cyclone.ercInnerIntegrity)
        ? cyclone.ercInnerIntegrity
        : 1;
    cyclone.ercMode = cyclone.ercMode === 'fusion' ? 'fusion' : 'classic';
    cyclone.ercPace = Number.isFinite(cyclone.ercPace) ? clamp(cyclone.ercPace, 0.7, 3) : 1;
    cyclone.ercRapid = Boolean(cyclone.ercRapid);
    cyclone.ercInitialSize = Number.isFinite(cyclone.ercInitialSize) && cyclone.ercInitialSize > 0
        ? cyclone.ercInitialSize
        : cyclone.circulationSize;
    cyclone.ercPeakSizeTarget = Number.isFinite(cyclone.ercPeakSizeTarget)
        ? cyclone.ercPeakSizeTarget
        : cyclone.ercInitialSize * 1.12;
    cyclone.ercPostSizeTarget = Number.isFinite(cyclone.ercPostSizeTarget)
        ? cyclone.ercPostSizeTarget
        : cyclone.ercInitialSize * 1.05;
    cyclone.ercPostSizeRelaxHours = Number.isFinite(cyclone.ercPostSizeRelaxHours)
        ? cyclone.ercPostSizeRelaxHours
        : 72;
    cyclone.ercAdverseHours = adverse
        ? cyclone.ercAdverseHours + MODEL_STEP_HOURS
        : Math.max(0, cyclone.ercAdverseHours - MODEL_STEP_HOURS);

    // Structural MPI can fall quickly as the diagnosed core shifts from RMW1
    // to a much larger RMW2. That is a geometric reclassification, not an
    // instantaneous removal of angular momentum. Let the ERC-specific wind
    // ceiling follow a falling MPI over a finite response time; environmental
    // losses still enter every step through baseIntensityChange.
    const previousMpiCeiling = Number.isFinite(cyclone.ercMpiCeiling)
        ? cyclone.ercMpiCeiling
        : Math.max(cyclone.intensity, mpi);
    const mpiResponseHours = mpi < previousMpiCeiling
        ? ERC_MPI_WEAKENING_RESPONSE_HOURS
        : ERC_MPI_RECOVERY_RESPONSE_HOURS;
    const mpiResponse = 1 - Math.exp(-MODEL_STEP_HOURS / mpiResponseHours);
    cyclone.ercMpiCeiling = previousMpiCeiling + (mpi - previousMpiCeiling) * mpiResponse;
    const ercWindCeiling = Math.max(10, cyclone.ercMpiCeiling);

    // During the dual-eyewall display the ordinary radar core represents the
    // inner eyewall.  Bring its rendered radius into physical agreement
    // gradually, so the outer-ring ratio is not magnified by an old scale.
    const innerRadarScaleTarget = clamp(
        cyclone.ercInnerRmw / Math.max(1, radarBaseRmw(cyclone.intensity, cyclone.circulationSize)),
        0.35,
        3.2
    );
    const currentRadarScale = Number.isFinite(cyclone.radarRmwScale) ? cyclone.radarRmwScale : 1;
    const radarAlignmentRate = cyclone.ercState === 'settling' ? 0.32 : 0.14;
    cyclone.radarRmwScale = currentRadarScale
        + (innerRadarScaleTarget - currentRadarScale) * radarAlignmentRate;

    cyclone.ercEnvironmentalPeak = clamp((cyclone.ercEnvironmentalPeak ?? cyclone.ercInitialIntensity)
        + baseIntensityChange, 10, ercWindCeiling);
    let structure = getEyewallStructure(cyclone);

    // A hostile environment cannot close a replacement ring by waiting out
    // the settlement timer. Use the existing gradual failure path instead.
    if (cyclone.ercState === 'settling' && adverse) cyclone.ercState = 'aborting';

    if (cyclone.ercState === 'settling') {
        const pace = cyclone.ercPace;
        const settlePace = pace * (cyclone.ercMode === 'fusion' ? 1.35 : 1);
        // Carry the replacement ring's own evolving target, not the retiring
        // inner peak. The old frozen target discarded all positive tendency
        // and repeatedly restored yesterday's wind after negative tendency.
        // Closure progressively releases intensification; a disorganized ring
        // loses support on the existing benign outer-ring decay timescale.
        const diagnosedReplacementPeak = Number.isFinite(cyclone.ercReplacementWindTarget)
            ? cyclone.ercReplacementWindTarget
            : structure.peakWind;
        const organization = clamp(cyclone.ercOuterOrganization, 0, 1);
        const recoveryReadiness = organization * (1 - clamp(cyclone.ercInnerIntegrity, 0, 1));
        const unsupportedWindLoss = diagnosedReplacementPeak * (1 - organization)
            * (1 - Math.exp(-MODEL_STEP_HOURS / ERC_ABORT_BENIGN_DECAY_HOURS));
        const replacementPeakTarget = clamp(
            diagnosedReplacementPeak + Math.min(0, baseIntensityChange)
                + Math.max(0, baseIntensityChange) * recoveryReadiness
                - unsupportedWindLoss,
            10,
            ercWindCeiling
        );
        cyclone.ercReplacementWindTarget = replacementPeakTarget;
        const settlingBackground = baselineWindAtRadius(cyclone.ercOuterRmw, cyclone);
        const settlingAnomalyTarget = Math.max(0, replacementPeakTarget - settlingBackground);
        cyclone.ercOuterWindAnomaly += (settlingAnomalyTarget - cyclone.ercOuterWindAnomaly)
            * Math.min(0.50, 0.18 * settlePace);
        const targetWidth = cyclone.ercMode === 'fusion'
            ? clamp(9 + cyclone.intensity * 0.045, 10, 18)
            : clamp(7 + cyclone.intensity * 0.035, 8, 15);
        const targetRadarWidth = cyclone.ercMode === 'fusion'
            ? clamp(48 + cyclone.circulationSize * 0.055, 50, 90)
            : clamp(30 + cyclone.circulationSize * 0.045, 35, 72);
        // Once the outer ring has already won the wind maximum, closure should
        // finish on a shorter convective timescale than the preceding eyewall
        // competition.  The old 0.16/0.44 relaxation commonly needed five or
        // more 3 h steps just to cross the 0.93 completion threshold, leaving
        // otherwise-finished cycles stranded in settling.
        cyclone.ercOuterOrganization += (1 - cyclone.ercOuterOrganization)
            * Math.min(0.56, 0.20 * settlePace);
        cyclone.ercOuterWidth += (targetWidth - cyclone.ercOuterWidth)
            * Math.min(0.54, 0.22 * settlePace);
        cyclone.ercOuterRadarWidthKm += (targetRadarWidth - cyclone.ercOuterRadarWidthKm)
            * Math.min(0.40, 0.14 * settlePace);
        const integrityRetention = cyclone.ercMode === 'fusion' ? 0.76 : 0.70;
        // Express the former per-step retention as a continuous decay time.
        // At the current 3 h model step this is numerically identical, while
        // remaining stable if the integration interval changes later.
        const integrityDecayHours = -MODEL_STEP_HOURS / Math.log(integrityRetention);
        cyclone.ercInnerIntegrity *= Math.exp(
            -MODEL_STEP_HOURS * settlePace * 1.15 / integrityDecayHours
        );
        cyclone.ercInnerWind = Math.max(20, cyclone.ercInnerWind
            + Math.min(0, baseIntensityChange)
            - (1.4 + 1.8 * support) * settlePace);

        const contractionFloor = cyclone.ercCompactRecovery && cyclone.ercInnerIntegrity < 0.20
            ? cyclone.ercPostRmwTarget : cyclone.ercMode === 'fusion'
            ? cyclone.ercInnerRmw * 1.10
            : Math.max(cyclone.ercInnerRmw + 12, cyclone.ercPostRmwTarget);
        // Relax toward the finite ring target.  A replacement eyewall can
        // contract while peak intensity is steady; requiring positive wind
        // tendency stranded mature plateauing storms in settlement until the
        // 48 h timeout. Genuine weakening still switches mechanical
        // contraction off.
        const contractionSupport = baseIntensityChange >= 0 ? 1 : 0;
        const settleContraction = (1 - Math.exp(-MODEL_STEP_HOURS / 24))
            * contractionSupport
            * Math.min(1.6, 0.65 * settlePace);
        cyclone.ercOuterRmw -= Math.max(0, cyclone.ercOuterRmw - contractionFloor) * settleContraction;
        cyclone.circulationSize += (cyclone.ercPeakSizeTarget - cyclone.circulationSize)
            * Math.min(0.34, 0.14 * settlePace);

        structure = getEyewallStructure(cyclone);
        // The resolved outer-wind blend consumes ercOuterShare. Refresh it
        // after the current geometry update before diagnosing the final peak;
        // otherwise settlement uses yesterday's weaker takeover state.
        cyclone.ercOuterShare = structure.outerShare;
        structure = getEyewallStructure(cyclone);
        // During settlement the inner remnant is removed from the blended
        // profile. Transfer that changing contribution to the already-dominant
        // replacement ring so the bookkeeping transition follows the existing
        // environmental target instead of creating a cliff or spike.
        for (let correctionStep = 0; correctionStep < 4; correctionStep++) {
            const peakError = replacementPeakTarget - structure.peakWind;
            if (Math.abs(peakError) < 0.1) break;
            cyclone.ercOuterWindAnomaly = Math.max(0, cyclone.ercOuterWindAnomaly + peakError);
            structure = getEyewallStructure(cyclone);
            cyclone.ercOuterShare = structure.outerShare;
            structure = getEyewallStructure(cyclone);
        }
        cyclone.ercOuterShare = structure.outerShare;
        smoothStructuralPeakIntoIntensity(cyclone, structure.peakWind);

        const visuallySettled = cyclone.ercInnerIntegrity <= (cyclone.ercRapid ? 0.14 : 0.06)
            && cyclone.ercOuterOrganization >= (cyclone.ercRapid ? 0.90 : 0.93)
            && Math.abs(cyclone.ercOuterWidth - targetWidth) <= (cyclone.ercRapid ? 2.5 : 1.5);
        // RMW contraction belongs to post-ERC recovery; it is not a condition
        // for an already closed single eyewall to finish replacement.
        if (cyclone.age >= cyclone.ercSettlingUntil && visuallySettled) {
            finishEyewallSettlement(cyclone);
        } else if (cyclone.age >= cyclone.ercSettlingUntil + ERC_SETTLING_TIMEOUT_HOURS) {
            cyclone.ercState = 'aborting';
        }
        return;
    }

    // An organized outer ring intercepts inflow even when the compact inner
    // eyewall still owns the maximum wind (especially in a merging cycle).
    const incipientInterception = adverse ? 0
        : replacementSupport
            * smoothstep((cyclone.ercOuterOrganization - 0.08) / 0.32)
            * smoothstep((elapsed - 3) / 12);
    const ringInterception = adverse ? 0
        : smoothstep((cyclone.ercOuterOrganization - 0.30) / 0.40)
            * smoothstep((elapsed - 12) / 36)
            * smoothstep((structure.outerPeak / Math.max(1, structure.innerPeak) - 0.65) / 0.25);
    const competition = Math.max(
        smoothstep((structure.outerShare - 0.08) / 0.48),
        ringInterception,
        0.45 * incipientInterception
    );
    if (applyBaseTendency) {
        cyclone.ercInnerWind += baseIntensityChange * (1 - 0.72 * competition);
    }

    if (cyclone.ercState === 'aborting') {
        const peakBeforeAbortStep = cyclone.intensity;
        // Dissolve a failed outer eyewall over a physical time scale. Multiplying
        // its anomaly by 0.52 every three hours removed nearly all of a dominant
        // ring in one or two samples, then exposed the already weakened inner
        // eyewall when the diagnosed profile was written back to total intensity.
        const anomalyDecayHours = adverse
            ? ERC_ABORT_ADVERSE_DECAY_HOURS
            : ERC_ABORT_BENIGN_DECAY_HOURS;
        const organizationDecayHours = adverse ? 12 : 18;
        cyclone.ercOuterWindAnomaly *= Math.exp(-MODEL_STEP_HOURS / anomalyDecayHours);
        cyclone.ercOuterOrganization *= Math.exp(-MODEL_STEP_HOURS / organizationDecayHours);
        cyclone.ercOuterWidth = Math.min(60, cyclone.ercOuterWidth * 1.04);
        cyclone.ercOuterRadarWidthKm = Math.min(130, cyclone.ercOuterRadarWidthKm * 1.025);
        cyclone.ercInnerIntegrity += (1 - cyclone.ercInnerIntegrity) * 0.24;
        structure = getEyewallStructure(cyclone);

        // Environmental weakening still applies, but structural bookkeeping may
        // only add a limited loss in one model step. If the decaying outer ring
        // remains the wind maximum, retain enough of its anomaly to keep the
        // resolved profile continuous rather than assigning an unsupported
        // scalar intensity above the profile.
        const environmentalLossAllowance = clamp(-Math.min(0, baseIntensityChange), 0, 8);
        const structuralLossAllowance = adverse
            ? clamp(4 + 0.15 * Math.max(0, totalShear - 32), 4, 8)
            : 3;
        const continuityFloor = Math.max(
            10,
            peakBeforeAbortStep - environmentalLossAllowance - structuralLossAllowance
        );
        if (structure.peakWind < continuityFloor) {
            cyclone.ercOuterWindAnomaly += continuityFloor - structure.peakWind;
            structure = getEyewallStructure(cyclone);
        }
        if (structure.peakWind < continuityFloor) {
            cyclone.ercInnerWind = Math.max(cyclone.ercInnerWind, continuityFloor);
            structure = getEyewallStructure(cyclone);
        }
        smoothStructuralPeakIntoIntensity(cyclone, structure.peakWind);
        cyclone.ercOuterShare = structure.outerShare;
        if (cyclone.ercOuterWindAnomaly < 0.8) {
            cyclone.rmw = cyclone.ercInnerRmw;
            cyclone.ercCooldownUntil = cyclone.age + 12 + random() * 12;
            clearEyewallStructure(cyclone, 'aborted');
        }
        return;
    }

    // Concentric eyewalls divide the available angular momentum between two
    // maxima. Make that diagnosed dispersion visible in Vmax instead of
    // allowing both rings to sit on one unchanged MPI plateau for days.
    const redistributionLoss = (2 + 8 * getErcEnergyDispersion(cyclone))
        * smoothstep((elapsed - 6) / 18);
    const outerTargetPeak = Math.min(
        ercWindCeiling,
        Math.max(35,
            Math.max(
                35,
            cyclone.ercInnerWind * (0.775 + 0.10 * replacementSupport),
            cyclone.ercEnvironmentalPeak * (0.525 + 0.24 * cyclone.ercOuterOrganization + 0.10 * replacementSupport)
            ) - redistributionLoss
        )
    );
    cyclone.ercReplacementWindTarget = outerTargetPeak;
    const anomalyTarget = Math.max(0, outerTargetPeak - structure.outerBackground);
    const pace = cyclone.ercPace;
    const growthRate = Math.min(
        0.42,
        (0.018 + 0.10 * replacementSupport + 0.025 * cyclone.ercOuterOrganization) * pace
    );
    cyclone.ercOuterWindAnomaly += (anomalyTarget - cyclone.ercOuterWindAnomaly) * growthRate;

    structure = getEyewallStructure(cyclone);
    const timeOrganization = smoothstep(elapsed / (48 / pace));
    const organizationTarget = clamp(
        Math.max(
            replacementSupport * (0.10 + 1.55 * structure.outerShare + 0.30 * timeOrganization),
            // Once seeded, a surviving ring axisymmetrizes over time. Multiplying
            // every stage by marginal support formerly trapped it in 'forming'.
            adverse ? 0 : timeOrganization * (0.55 + 0.30 * replacementSupport)
        ),
        0,
        1
    );
    cyclone.ercOuterOrganization += (organizationTarget - cyclone.ercOuterOrganization)
        * Math.min(0.42, (0.08 + 0.14 * replacementSupport) * pace);

    const organizedWidth = cyclone.ercMode === 'fusion'
        ? clamp(cyclone.ercOuterRmw * 0.16, 10, 26)
        : clamp(cyclone.ercOuterRmw * 0.105, 8, 22);
    const looseWidth = cyclone.ercMode === 'fusion'
        ? clamp((cyclone.ercOuterRmw - cyclone.ercInnerRmw) * 0.82, 14, 36)
        : clamp(cyclone.ercOuterRmw * 0.30, 20, 55);
    const widthTarget = looseWidth + (organizedWidth - looseWidth) * cyclone.ercOuterOrganization;
    cyclone.ercOuterWidth += (widthTarget - cyclone.ercOuterWidth)
        * Math.min(0.44, (0.10 + 0.12 * support) * pace);
    const looseRadarWidth = cyclone.ercMode === 'fusion'
        ? 115
        : clamp(75 + cyclone.ercOuterRmw * 0.30, 75, 120);
    const organizedRadarWidth = cyclone.ercMode === 'fusion'
        ? clamp(55 + cyclone.circulationSize * 0.055, 55, 95)
        : clamp(32 + cyclone.circulationSize * 0.05, 38, 78);
    const radarWidthTarget = looseRadarWidth
        + (organizedRadarWidth - looseRadarWidth) * cyclone.ercOuterOrganization;
    cyclone.ercOuterRadarWidthKm += (radarWidthTarget - cyclone.ercOuterRadarWidthKm)
        * Math.min(0.40, (0.08 + 0.10 * support) * pace);
    cyclone.ercOuterRadarWidthKm = clamp(cyclone.ercOuterRadarWidthKm, 30, 130);

    if (cyclone.ercMode === 'fusion') {
        const fusionFloor = cyclone.ercInnerRmw * 1.18;
        const contractionRate = (0.006 + 0.020 * cyclone.ercOuterOrganization * replacementSupport) * pace;
        cyclone.ercOuterRmw = Math.max(fusionFloor, cyclone.ercOuterRmw * (1 - contractionRate));
    } else if (cyclone.ercOuterOrganization < 0.16) {
        // A loose secondary rainband can drift outward before it axisymmetrizes.
        cyclone.ercOuterRmw = Math.min(190, cyclone.ercOuterRmw * 1.0015);
    } else {
        const classicFloor = Math.min(190, cyclone.ercInnerRmw * 1.52);
        const contractionRate = (0.0015 + 0.0085 * cyclone.ercOuterOrganization * replacementSupport) * pace;
        cyclone.ercOuterRmw = Math.max(classicFloor, cyclone.ercOuterRmw * (1 - contractionRate));
    }

    structure = getEyewallStructure(cyclone);
    const takeover = Math.max(smoothstep((structure.outerShare - 0.12) / 0.42), 0.8 * ringInterception);
    const dualCompetition = smoothstep((cyclone.ercOuterOrganization - 0.18) / 0.55)
        * smoothstep(elapsed / (24 / pace));
    const inflowInterceptionLoss = 0.42 * incipientInterception * pace;
    const innerLoss = (
        1.06 * dualCompetition * (0.30 + 2.35 * takeover)
            * (0.65 + 0.85 * replacementSupport) * pace
        + inflowInterceptionLoss
    ) * replacementViability;
    cyclone.ercInnerWind = Math.max(20, cyclone.ercInnerWind - innerLoss);
    const integrityLoss = Math.min(
        0.38,
        (0.008 + 0.12 * takeover) * cyclone.ercOuterOrganization
            * replacementSupport * pace * replacementViability
    );
    cyclone.ercInnerIntegrity = clamp(cyclone.ercInnerIntegrity * (1 - integrityLoss), 0, 1);
    if (adverse) {
        // Once replacement support is gone, release the inner core from ring
        // competition. Environmental intensity losses were already applied.
        cyclone.ercInnerIntegrity += (1 - cyclone.ercInnerIntegrity) * 0.10;
    }
    const windIntegrity = clamp(
        (cyclone.ercInnerWind - 20) / Math.max(20, cyclone.ercInitialIntensity - 20),
        0,
        1
    );
    cyclone.ercInnerIntegrity = Math.min(cyclone.ercInnerIntegrity, windIntegrity + 0.08);

    structure = getEyewallStructure(cyclone);
    cyclone.ercOuterShare = structure.outerShare;
    smoothStructuralPeakIntoIntensity(cyclone, structure.peakWind);
    const sizeProgress = Math.max(
        smoothstep(elapsed / (cyclone.ercRapid ? 15 : 36)),
        smoothstep((cyclone.ercOuterOrganization - 0.08) / 0.82),
        smoothstep((structure.outerShare - 0.04) / 0.64)
    );
    const activeSizeTarget = cyclone.ercInitialSize
        + (cyclone.ercPeakSizeTarget - cyclone.ercInitialSize) * sizeProgress;
    cyclone.circulationSize += (activeSizeTarget - cyclone.circulationSize)
        * Math.min(0.36, 0.13 * pace);

    if (cyclone.ercOuterOrganization < 0.32) cyclone.ercState = 'forming';
    else if (structure.outerPeak < structure.innerPeak * 0.94 && cyclone.ercInnerIntegrity > 0.52) cyclone.ercState = 'concentric';
    else cyclone.ercState = 'takeover';

    const separationRatio = structure.outerRmw / Math.max(1, structure.innerRmw);
    const persistentLateTakeover = !adverse
        && elapsed >= ERC_PERSISTENT_CLASSIC_HANDOFF_HOURS
        && cyclone.ercOuterOrganization >= 0.42
        && structure.outerShare >= 0.12
        && structure.outerPeak >= Math.max(
            structure.innerPeak * 0.86,
            cyclone.ercInitialIntensity * 0.60
        );
    const persistentFusion = !adverse
        && elapsed >= ERC_PERSISTENT_FUSION_HANDOFF_HOURS
        && cyclone.ercOuterOrganization >= 0.34
        && structure.outerPeak >= Math.max(
            structure.innerPeak * 0.80,
            cyclone.ercInitialIntensity * 0.55
        );
    if (!adverse && cyclone.ercMode === 'fusion'
        && ((elapsed >= (cyclone.ercRapid ? 6 : 12)
            && cyclone.ercOuterOrganization >= 0.34
            && separationRatio <= 1.50
            // Nearby merging maxima cease to be a clean anomaly above the
            // parent vortex. Diagnose fusion from organized geometry and the
            // resolved outer peak, not from anomalous momentum share alone.
            && structure.outerPeak >= structure.innerPeak * 0.90)
            || persistentFusion)) {
        const fusionWeight = 0.48 + 0.30 * smoothstep((structure.outerShare - 0.12) / 0.38);
        const fusedRmw = structure.innerRmw + (structure.outerRmw - structure.innerRmw) * fusionWeight;
        cyclone.ercOuterRmw = fusedRmw;
        beginEyewallSettlement(cyclone, { ...structure, outerRmw: fusedRmw }, 'fused', random);
    } else if (!adverse && cyclone.ercMode === 'classic'
        && ((elapsed >= (cyclone.ercRapid ? 6 : 12)
        // A replacement can pass its strongest outer-ring stage between
        // three-hour samples. Relax the simultaneous completion thresholds
        // gradually after 24 h, so a persistent near-takeover settles instead
        // of timing out solely because share and integrity peaked one step apart.
        && cyclone.ercOuterOrganization >= (cyclone.ercRapid
            ? 0.52
            : 0.62 - 0.12 * smoothstep((elapsed - 24) / 36))
        && cyclone.ercInnerIntegrity <= (cyclone.ercRapid
            ? 0.78
            : 0.63 + 0.16 * smoothstep((elapsed - 24) / 36))
        && structure.outerPeak >= Math.max(
            structure.innerPeak * (cyclone.ercRapid
                ? 0.90
                : 0.95 - 0.05 * smoothstep((elapsed - 24) / 36)),
            cyclone.ercInitialIntensity * (cyclone.ercRapid
                ? 0.68
                : 0.74 - 0.07 * smoothstep((elapsed - 24) / 36))
        )
        && structure.outerShare >= (cyclone.ercRapid
            ? 0.15
            : 0.24 - 0.07 * smoothstep((elapsed - 24) / 36)))
            || persistentLateTakeover)) {
        beginEyewallSettlement(cyclone, structure, 'completed', random);
    } else {
        // A vanishing anomaly only proves collapse while the secondary ring
        // is still disorganized. In fusion mode, a mature nearby ring is
        // expected to blend into the parent profile before settlement.
        const outerRingCollapsed = cyclone.ercOuterWindAnomaly < 0.5
            && (cyclone.ercMode !== 'fusion' || cyclone.ercOuterOrganization < 0.28);
        if (cyclone.ercAdverseHours >= 18
            || elapsed >= ERC_STALLED_CYCLE_ABORT_HOURS
            || outerRingCollapsed) {
            cyclone.ercState = 'aborting';
        }
    }
}

// The first native field was a useful visual prototype, but its ridge axis and
// height anomalies were generated by unrelated functions. Keep its evaluator
// for archived snapshots while new snapshots use the QG-inspired field below.
function legacyWaveFieldComponents(lon, lat, background, level = 500) {
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    const summer = (1 + background.seasonalShift / 4 * Math.tanh(lat / 5)) / 2;
    const waves = background.waves.filter(w => w.hemisphere === hemisphere);
    let meander = 0, disturbance = 0, shortWave = 0;
    for (const wave of waves) {
        const phase = wave.k * lon * radians + wave.phase;
        if (wave.k <= 4) meander += wave.amplitude * Math.sin(phase) / 28;
    }
    // Long-wave displacement smoothly tapers towards the equator and poles.
    const displacement = meander * smoothstep(latitude / 12) * Math.exp(-(((latitude - 39) / 28) ** 2));
    const ridgeLatitude = 25 + 5 * summer + displacement;
    const jetLatitude = 41 + 5 * summer + displacement;
    for (const wave of waves) {
        const tiltPhase = level === 200 ? 0.10 : level === 850 ? -0.10 : 0; // 弧度，不再乘k
        const phase = wave.k * lon * radians + wave.phase + tiltPhase
            + wave.tilt * (latitude - jetLatitude) * radians;
        const envelope = Math.exp(-0.5 * ((latitude - wave.latitude - displacement) / wave.width) ** 2);
        const value = wave.amplitude * Math.cos(phase) * envelope
            * (wave.k >= 5 ? smoothstep((latitude - 22) / 16) : 1);
        disturbance += value;
        if (wave.k >= 5) shortWave += value;
    }
    const tropicalTaper = smoothstep((latitude - 10) / 18);
    const poleTaper = Math.cos(latitude * radians) ** 2;
    disturbance *= tropicalTaper * poleTaper;
    // Finite-amplitude wave adjustment: constructive interference must not
    // create arbitrarily high crests. Applied to the shared model field (and
    // hence its winds), never to contour labels or only to the exported image.
    disturbance = MIDLATITUDE_COMPOSITE_HEIGHT_LIMIT_M
        * Math.tanh(disturbance / MIDLATITUDE_COMPOSITE_HEIGHT_LIMIT_M);
    const t = smoothstep((latitude - 32 - 4 * summer - displacement * .35) / 50);
    const polarDrop = 740 * t;
    const ridge = 16 * Math.exp(-0.5 * ((latitude - ridgeLatitude) / 10) ** 2);
    const tradeWindRamp = 5 * smoothstep((latitude - 3) / 22);
    // The barotropic wave component is shared; only thickness gradients and
    // modest vertical tilt create shear. Never multiply the entire field by 2.15.
    const polarFactor = level === 850 ? .55 : level === 200 ? 1.18 + .4 * (1 - summer) : 1;
    const ridgeFactor = level === 850 ? .85 : level === 200 ? 1.08 : 1;
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5790;
    return { height: datum - polarDrop * polarFactor + (ridge + tradeWindRamp) * ridgeFactor + disturbance, ridgeLatitude, jetLatitude, shortWave, displacement };
}

function interpolateProfile(profile, latitude) {
    if (!Array.isArray(profile) || profile.length === 0) return 0;
    const position = clamp(latitude / .25, 0, profile.length - 1);
    const lower = Math.floor(position);
    const upper = Math.min(profile.length - 1, lower + 1);
    const fraction = position - lower;
    return profile[lower] + (profile[upper] - profile[lower]) * fraction;
}

// Compile the fixed monthly-height lookup once per month/level context. The
// arithmetic mirrors sampleMonthlyHeight exactly; only the grid selection and
// row access are moved out of the pressure-node loop. This keeps the same
// Catmull-Rom interpolation and preserves the field values bit-for-bit.
function createMonthlyHeightSampler(month, level = 500) {
    const monthIndex = Math.max(0, Math.min(11, Math.round(month || 8) - 1));
    const grid = MONTHLY_HEIGHT_GRID[level][monthIndex];
    const cubic = (a, b, c, d, t) => b + .5 * t * (
        c - a + t * (2 * a - 5 * b + 4 * c - d
            + t * (3 * (b - c) + d - a))
    );
    return (lon, lat) => {
        const x = (((lon % 360) + 360) % 360) / 5;
        const y = (Math.max(-90, Math.min(90, lat)) + 90) / 2.5;
        const ix = Math.floor(x), iy = Math.floor(y);
        const tx = x - ix, ty = y - iy;
        const row = j => {
            const values = grid[Math.max(0, Math.min(72, j))];
            return cubic(
                values[(ix + 71) % 72], values[ix % 72],
                values[(ix + 1) % 72], values[(ix + 2) % 72], tx
            );
        };
        return cubic(row(iy - 1), row(iy), row(iy + 1), row(iy + 2), ty);
    };
}

// The surface closure always samples the same lower-layer snapshot. Compile
// its Gaussian sum once so each pressure node avoids array dispatch and the
// object/array shape checks in getPressureAt, while keeping the same operation
// order and the noise-layer branch used by the public evaluator.
function createLowerPressureSampler(lower) {
    const cells = Array.isArray(lower) ? lower : [];
    return (lon, lat) => {
        let pressureValue = 1013;
        for (const cell of cells) {
            let dx = lon - cell.x;
            if (dx > 180) dx -= 360;
            else if (dx < -180) dx += 360;
            const dy = lat - cell.y;
            const exponent = -(
                (dx ** 2) / (2 * cell.sigmaX ** 2)
                + (dy ** 2) / (2 * cell.sigmaY ** 2)
            );
            const pressureOffset = Math.exp(exponent) * cell.strength;
            if (cell.noiseLayers) {
                let noise = 0;
                for (const layer of cell.noiseLayers) {
                    noise += Math.sin((lon + layer.offsetX) / layer.freqX)
                        * Math.cos((lat + layer.offsetY) / layer.freqY)
                        * layer.amplitude;
                }
                pressureValue += noise;
            }
            pressureValue += pressureOffset;
        }
        return pressureValue;
    };
}

function sioMidlevelWindAdjustment(latitude, summer) {
    const tropicalEdge = smoothstep((latitude - 5) / 6);
    const polewardFade = 1 - smoothstep((latitude - 31) / 9);
    const offset = SIO_MIDLEVEL_WINTER_WESTERLY_MS * (1 - summer);
    return offset * tropicalEdge * polewardFade
        * Math.max(.12, Math.cos(latitude * Math.PI / 180));
}

function zonalWindProfile(latitude, summer, level, circulation = null, sioCalibration = false) {
    const radians = Math.PI / 180;
    // The subtropical jet sits poleward of the ridge core.  Placing this axis
    // three degrees too far equatorward makes the 20–25N steering vector flip
    // eastward almost simultaneously for every storm.  Its meridional width
    // must also remain close to a jet-scale feature: a broad Gaussian tail
    // otherwise fills the 25–35N ridge belt with spurious zonal flow.
    const jetLatitude = circulation?.jetLatitude ?? (39 + 8 * summer);
    const jetWidth = 9 + 1.5 * summer;
    const jetMaximum = (17 - 3 * summer) * (circulation?.jetStrength ?? 1);
    // The tropical easterly basic state extends well poleward of the
    // equatorial belt.  Letting it vanish by 20N makes the first few degrees
    // of every track depend on whichever random wave happens to be nearby.
    // The subtropical westerlies then take over gradually, rather than at a
    // sharp synthetic boundary.
    const tradeEasterly = -8.0 * (circulation?.tradeStrength ?? 1)
        * (1 - smoothstep((latitude - 4) / 42));
    // The first term is only the weak flow around the ridge belt.  The
    // stronger westerly acceleration belongs closer to the jet entrance and
    // should not turn every 25–30N disturbance into a flat eastward runner.
    const subtropicalWesterly = 0.45 * smoothstep((latitude - 27) / 12)
        + 1.8 * smoothstep((latitude - 38) / 15);
    const jet = jetMaximum * Math.exp(-0.5 * ((latitude - jetLatitude) / jetWidth) ** 2);
    const polarTail = (5 - 1.5 * summer)
        * smoothstep((latitude - 45) / 14)
        * (1 - smoothstep((latitude - 76) / 11));
    const scale = level === 850 ? .58 : level === 200 ? 1.12 : 1;
    // A small minimum westerly component poleward of the jet represents the
    // climatological polar-front flow without making the whole hemisphere a
    // uniform conveyor belt.
    const polarMinimum = 2.5 * smoothstep((latitude - 50) / 18);
    // JMA recurvature headings show that the model's zonal wind changed sign
    // at a reasonable latitude but had roughly twice the observed magnitude
    // on both shoulders of that zero line. Flatten the ridge-axis saddle while
    // preserving the zero crossing, tropical trades and the jet core.
    const ridgeLatitude = circulation?.ridgeLatitude ?? (26 + 5 * summer);
    const ridgeDistance = Math.abs(latitude - ridgeLatitude);
    const ridgeShoulderScale = .50 + .50 * smoothstep((ridgeDistance - 3) / 9);
    const modelWind = (tradeEasterly + subtropicalWesterly + jet + polarTail + polarMinimum)
        * ridgeShoulderScale * scale
        * Math.max(.12, Math.cos(latitude * radians));
    return modelWind + (sioCalibration && level === 500
        ? sioMidlevelWindAdjustment(latitude, summer)
        : 0);
}

const southernMonthlyThicknessCache = new Map();
const southernMonthlyBasicStateCache = new Map();

// A single monthly SH column, from the already bundled zonal means. These
// are only the basic state: regional cells, propagating waves and synoptic
// lifecycles still produce each run's weather. No live observations are used.
// Do not retain the attenuated WNP-fitted 500-hPa profile while imposing the
// full climate thickness gradients on its upper/lower layers.
function southernMonthlyBasicState(month) {
    const monthIndex = Math.max(0, Math.min(11, Math.round(month || 8) - 1));
    if (southernMonthlyBasicStateCache.has(monthIndex)) {
        return southernMonthlyBasicStateCache.get(monthIndex);
    }
    const profiles = {};
    for (const level of [850, 500, 200]) {
        const rows = MONTHLY_HEIGHT_GRID[level][monthIndex].map(row =>
            row.reduce((sum, height) => sum + height, 0) / row.length);
        const sample = latitude => {
            // Grid rows run from 90S to 90N; positive latitude here is
            // poleward distance in the SH, hence (90-latitude)/2.5.
            const position = (90 - latitude) / 2.5;
            const index = Math.floor(position), t = position - index;
            const a = rows[Math.max(0, index - 1)], b = rows[index];
            const c = rows[Math.min(rows.length - 1, index + 1)];
            const d = rows[Math.min(rows.length - 1, index + 2)];
            return b + .5 * t * (c - a + t * (2 * a - 5 * b + 4 * c - d
                + t * (3 * (b - c) + d - a)));
        };
        const equatorialHeight = sample(0);
        // Keep the established equatorial datums; subtracting a constant
        // preserves all three height/thickness gradients, without a new
        // discontinuity where the hemispheric columns blend.
        profiles[level] = Array.from({ length: 341 }, (_, index) =>
            sample(index * .25) - equatorialHeight);
    }
    const wind = (level, index) => {
        const radians = Math.PI / 180;
        const f = 2 * EARTH_OMEGA * Math.sin(index * .25 * radians);
        return -GRAVITY * f / (f * f + (2e-5) ** 2)
            * (profiles[level][index + 1] - profiles[level][index - 1])
            / (EARTH_RADIUS_M * .5 * radians);
    };
    let ridgeLatitude = null, ridgeHeight = -Infinity;
    for (let index = 1; index < 340; index++) {
        const middleWind = wind(500, index);
        if (index > 1 && middleWind >= 0 && wind(500, index - 1) < 0
            && profiles[500][index] > ridgeHeight) {
            const previousWind = wind(500, index - 1);
            ridgeLatitude = (index - 1 + (-previousWind / (middleWind - previousWind))) * .25;
            ridgeHeight = profiles[500][index];
        }
    }
    let jetLatitude = null, maximumUpperWind = -Infinity;
    for (let index = 1; index < 340; index++) {
        if (ridgeLatitude !== null && index * .25 > ridgeLatitude && wind(500, index) > 0) {
            const upperWind = wind(200, index);
            if (upperWind > maximumUpperWind) {
                maximumUpperWind = upperWind;
                jetLatitude = index * .25;
            }
        }
    }
    // All bundled months contain a subtropical zero crossing and westerly
    // maximum. Refuse to substitute an unrelated basin/hemisphere axis.
    if (ridgeLatitude === null || jetLatitude === null) {
        throw new Error('Southern monthly basic state has no ridge/jet axis');
    }
    const state = { profiles, axes: { ridgeLatitude, jetLatitude } };
    southernMonthlyBasicStateCache.set(monthIndex, state);
    return state;
}

// Use only the zonal-mean vertical structure of the already bundled
// 1981-2010 NCEP/NCAR monthly heights. Thermal-wind balance relates these
// thickness gradients to the vertical wind difference. Scaling one common
// wind shape at every level instead made the winter jet nearly barotropic.
// No live data, new stationary ridge, or extra map-node sampling is involved;
// longitude structure and synoptic variability still come from the native
// cells/waves. This hybrid closure is retained only for pre-fix snapshots;
// new procedural SH runs use the complete column above.
function southernMonthlyThicknessProfiles(month) {
    const monthIndex = Math.max(0, Math.min(11, Math.round(month || 8) - 1));
    if (southernMonthlyThicknessCache.has(monthIndex)) {
        return southernMonthlyThicknessCache.get(monthIndex);
    }
    const grids = MONTHLY_HEIGHT_GRID;
    const thickness = {};
    for (const level of [850, 200]) {
        const rows = grids[level][monthIndex].map((row, index) =>
            row.reduce((sum, height, longitude) => sum + height
                - grids[500][monthIndex][index][longitude], 0) / row.length);
        const sample = latitude => {
            const position = (90 - latitude) / 2.5;
            const index = Math.floor(position);
            const t = position - index;
            const a = rows[Math.max(0, index - 1)];
            const b = rows[index];
            const c = rows[Math.min(rows.length - 1, index + 1)];
            const d = rows[Math.min(rows.length - 1, index + 2)];
            return b + .5 * t * (c - a + t * (2 * a - 5 * b + 4 * c - d
                + t * (3 * (b - c) + d - a)));
        };
        const equatorialThickness = sample(0);
        // Match the existing 0.25-degree native profile. Subtract a constant
        // reference: replace layer gradients without changing height datums
        // or creating an equatorial step from the raw climate height offsets.
        thickness[level] = Array.from({ length: 341 }, (_, index) =>
            sample(index * .25) - equatorialThickness);
    }
    southernMonthlyThicknessCache.set(monthIndex, thickness);
    return thickness;
}

function buildZonalHeightProfiles(background) {
    const profiles = { 850: { 1: [], '-1': [] }, 500: { 1: [], '-1': [] }, 200: { 1: [], '-1': [] } };
    const stepRadians = .25 * Math.PI / 180;
    const radians = Math.PI / 180;
    // The modern 500-hPa profile is referenced to the tropical summer
    // geopotential-height climate, not to the 5800-gpm plotting contour.
    // The former 5790-gpm datum put the July WNP ridge maximum near 5822 gpm
    // and allowed the 5800 line to reach 33-35N before any synoptic trough was
    // present.  A 5845-gpm equatorial datum restores a roughly 5875-gpm ridge
    // crest while leaving the geostrophic wind gradients unchanged.
    const datums = { 850: 1490, 500: 5845, 200: 12320 };
    const coherentSouthernState = background.southernBasicStateVersion >= 2
        && !background.climatologyVersion
        ? southernMonthlyBasicState(background.calendarMonth) : null;
    if (coherentSouthernState) {
        // Serializable metadata lets GPU packing use the CPU's diagnosed
        // axes without independently fitting another monthly table.
        background.southernBasicStateAxes = { ...coherentSouthernState.axes };
    }
    for (const hemisphere of [1, -1]) {
        if (hemisphere < 0 && coherentSouthernState) {
            for (const level of [850, 500, 200]) {
                profiles[level][-1] = coherentSouthernState.profiles[level]
                    .map(height => datums[level] + height);
            }
            continue;
        }
        const seasonalShift = Number.isFinite(background.seasonalShift)
            ? background.seasonalShift : 0;
        const circulation = monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            seasonalShift
        );
        const summer = circulation.summer;
        for (const level of [850, 500, 200]) {
            // SH vertical differences are built below, around the unchanged
            // 500-hPa basic state. Do not stack the former SIO shear offsets
            // on top of the observed monthly thickness gradients.
            if (hemisphere < 0 && level !== 500) continue;
            const profile = [datums[level]];
            for (let index = 1; index <= 340; index++) {
                const latitude = index * .25;
                const priorLatitude = latitude - .25;
                const f0 = 2 * EARTH_OMEGA * Math.sin(priorLatitude * radians);
                const f1 = 2 * EARTH_OMEGA * Math.sin(latitude * radians);
                const calibrateSio = background.activeBasin === 'SIO'
                    && hemisphere < 0;
                const u0 = zonalWindProfile(
                    priorLatitude, summer, level, circulation, calibrateSio
                );
                const u1 = zonalWindProfile(
                    latitude, summer, level, circulation, calibrateSio
                );
                const dz = -EARTH_RADIUS_M * stepRadians * (f0 * u0 + f1 * u1) / (2 * GRAVITY);
                profile.push(profile.at(-1) + dz);
            }
            profiles[level][hemisphere] = profile;
        }
    }
    if (!coherentSouthernState) {
        const southernThickness = southernMonthlyThicknessProfiles(background.calendarMonth);
        for (const level of [850, 200]) {
            profiles[level][-1] = profiles[500][-1].map((height, index) =>
                height + (datums[level] - datums[500]) + southernThickness[level][index]);
        }
    }
    return profiles;
}

function ensureModernAtmosphericState(background) {
    if (!isModernAtmosphericBackground(background)) return false;
    if (!background.zonalProfiles
        || background.zonalProfileVersion !== ZONAL_PROFILE_VERSION
        || (background.southernBasicStateVersion >= 2 && !background.climatologyVersion
            && !background.southernBasicStateAxes)) {
        background.zonalProfiles = buildZonalHeightProfiles(background);
        background.zonalProfileVersion = ZONAL_PROFILE_VERSION;
    }
    // Some early v3 snapshots may have been serialized before the wave array
    // was added. Treat them as a quiet modern atmosphere, not as a legacy one.
    if (!Array.isArray(background.waves)) background.waves = [];
    if (!Array.isArray(background.tropicalWaves)) background.tropicalWaves = [];
    if (!Array.isArray(background.equatorialWaves)) background.equatorialWaves = [];
    return true;
}

function rossbyPhaseSpeedMS(wave) {
    const radians = Math.PI / 180;
    const latitude = clamp(Math.abs(wave.latitude), 12, 70);
    const cosLatitude = Math.max(.25, Math.cos(latitude * radians));
    const kx = wave.k / (EARTH_RADIUS_M * cosLatitude);
    const meridionalWavelength = Math.max(2500000, wave.meridionalWavelengthKm * 1000);
    const ky = Math.PI / meridionalWavelength;
    // beta is df/dy with y positive northward.  It is positive in both
    // hemispheres; changing its sign for the Southern Hemisphere would make
    // otherwise identical Rossby modes propagate eastward relative to the
    // mean flow there.
    const beta = 2 * EARTH_OMEGA * cosLatitude / EARTH_RADIUS_M;
    const dispersion = beta / Math.max(1e-14, kx * kx + ky * ky);
    return wave.meanFlowMS - dispersion;
}

function rossbyFrequencyFromSpeed(wave) {
    const radians = Math.PI / 180;
    const latitude = clamp(Math.abs(wave.latitude), 12, 70);
    const cosLatitude = Math.max(.25, Math.cos(latitude * radians));
    const degreesPerHour = wave.phaseSpeedMS * 3600 / (EARTH_RADIUS_M * cosLatitude) * 180 / Math.PI;
    // phase = k*lambda + phaseOffset; a positive phase speed therefore means
    // a decreasing phase offset, i.e. eastward propagation.
    return -wave.k * degreesPerHour * radians;
}

// Diagnose the slowly varying ridge/jet geometry independently of the point
// where the height field is sampled. A physical axis is a property of the
// longitude/time slice; allowing the query latitude to enter this calculation
// made the same jet appear at different latitudes in diagnostics, transition
// logic and steering footprints.
function modernAxisGeometryAt(lon, background, hemisphere, prepared = null) {
    const radians = Math.PI / 180;
    const circulation = prepared?.circulations?.[hemisphere]
        || backgroundMonthlyCirculation(background, hemisphere);
    const waves = prepared?.axisWaves?.[hemisphere]
        || (background.waves || [])
            .filter(wave => wave.hemisphere === hemisphere && wave.k <= 3
                && (!background.climatologyVersion || wave.isManual
                    || wave.isTransientAnomaly));
    let jetDisplacement = 0;
    let ridgeDisplacement = 0;

    for (const wave of waves) {
        const phase = wave.k * lon * radians + wave.phase;
        const axisScale = (wave.axisScaleDeg || 0)
            * MIDLATITUDE_PLANETARY_WAVE_AXIS_SCALE
            * (hemisphere < 0 ? SOUTHERN_HEMISPHERE_AXIS_VARIABILITY_SCALE : 1);
        const jetEnvelope = Math.exp(-0.5 * (
            (circulation.jetLatitude - wave.latitude)
                / Math.max(8, wave.width)
        ) ** 2);
        const phaseDisplacement = axisScale * Math.cos(phase);
        jetDisplacement += phaseDisplacement * jetEnvelope;
        // Preserve the former displacement at the ridge axis itself. Spatial
        // tapering belongs to the sampled height profile below, not to the
        // diagnosed location of the axis.
        ridgeDisplacement += 0.45 * phaseDisplacement;
    }

    return {
        circulation,
        jetDisplacement: clamp(jetDisplacement, -15, 15),
        ridgeDisplacement: clamp(ridgeDisplacement, -7, 7)
    };
}

function profileAxisDisplacement(latitude, displacement, mappingVersion = 1) {
    // The old latitude map y' = y - D*smoothstep((y-28)/12)
    // folds when the poleward shift D exceeds 8 degrees: max smoothstep' is 3/2.
    // Then a monotonically falling height profile generates false easterlies
    // on the jet entrance. Widen the joining interval with the displacement
    // itself, so dy'/dy >= 12/(12 + 1.5*|D|) > 0. Preserve the tropical
    // profile and full far-poleward displacement, without capping a real
    // ridge/trough anomaly or forcing any cyclone's heading.
    const transitionWidth = 12 + (mappingVersion >= 2
        ? 1.5 * Math.abs(displacement) : 0);
    return displacement * smoothstep((latitude - 28) / transitionWidth);
}

function climatologyLatitudeWithShiftedAxes(latitude, circulation, hemisphere = 1) {
    // NH sampling keeps the shared +2-degree poleward baseline. In the SH,
    // shift the sampled monthly height field four degrees toward the equator
    // with the diagnosed jet axis, tapering only toward the polar cap.
    const fadeStart = circulation.jetLatitude + 4;
    const circulationWeight = 1 - smoothstep((latitude - fadeStart) / 12);
    const baselineShift = CIRCULATION_AXIS_BASELINE_POLEWARD_SHIFT_DEG
        - (hemisphere < 0 ? SOUTHERN_HEMISPHERE_WESTERLY_EQUATORWARD_SHIFT_DEG : 0);
    return Math.max(0, latitude
        - baselineShift * circulationWeight);
}

function equatorialLowWaveHeight(lon, lat, background, level = 500) {
    const radians = Math.PI / 180;
    let anomaly = 0;
    for (const wave of (background.equatorialWaves || [])) {
        const phase = wave.k * lon * radians + wave.phase;
        // A squared half-wave gives broad, smooth low-height sectors without
        // pairing each trough with an artificial equatorial high.
        const trough = Math.max(0, Math.cos(phase)) ** 2;
        const envelope = Math.exp(-0.5 * (
            (lat - wave.latitude) / Math.max(7, wave.width)
        ) ** 2);
        anomaly -= wave.amplitude * trough * envelope;
    }
    const levelFactor = level === 850
        ? .75
        : level === 200
            ? .35
            : EQUATORIAL_LOW_WAVE_500_SCALE;
    return levelFactor * clamp(anomaly, -30, 0);
}

function wnpMonsoonLifecycleState(background) {
    const state = background?.wnpRecurvatureRegime;
    if (!state) return { strength: 0, progress: 0, pulse: 0 };
    const elapsed = background.elapsedHours || 0;
    if (Number.isFinite(state.periodHours)) {
        const wave = .5 + .5 * Math.sin(
            state.phase + 2 * Math.PI * elapsed / state.periodHours
        );
        const pulse = smoothstep(wave);
        return {
            strength: clamp((state.baseStrength || 0)
                + (state.cycleAmplitude || 0) * pulse, 0, 1),
            progress: pulse,
            pulse
        };
    }
    if (!state.strength) return { strength: 0, progress: 0, pulse: 0 };
    const progress = smoothstep(state.initialProgress
        + elapsed / state.developmentHours);
    return { strength: state.strength, progress, pulse: progress };
}

function regionalCirculationLifecycleState(background) {
    const config = REGIONAL_CIRCULATION_CONFIGS[background?.activeBasin];
    const state = background?.regionalCirculationRegime;
    if (!config || !state || state.basin !== background.activeBasin) {
        return { config: null, strength: 0, pulse: 0 };
    }
    const elapsed = background.elapsedHours || 0;
    const wave = .5 + .5 * Math.sin(
        state.phase + 2 * Math.PI * elapsed / Math.max(168, state.periodHours)
    );
    // A quiet draw describes the initial/background state, not an atmosphere
    // that is forbidden to develop for the storm's entire lifetime.  Let the
    // independently sampled lifecycle amplitude grow slowly on the same
    // 9--12 day phase.  This retains multi-day stable-ridge episodes while
    // preventing a low-latitude seed from being assigned permanent trades by
    // one initialization draw.
    const pulse = smoothstep(wave);
    const cycleAmplitude = Number.isFinite(state.cycleAmplitude)
        ? state.cycleAmplitude
        : .62 * (1 - state.strength);
    const strength = clamp(state.strength + cycleAmplitude * pulse, 0, 1);
    return { config, strength, pulse };
}

function regionalCirculationHeight(lon, lat, background, level = 500, prepared = null) {
    const lifecycle = prepared?.regionalLifecycle
        || regionalCirculationLifecycleState(background);
    const state = background?.regionalCirculationRegime;
    const { config, strength, pulse } = lifecycle;
    if (!config || !state || strength <= .01 || lat * config.hemisphere <= 0) return 0;
    const elapsed = background.elapsedHours || 0;

    // The tropical member represents the basin's ITCZ/monsoon-trough state.
    // Its poleward migration is tied to the same phase that retracts the
    // subtropical ridge, so "east extension without poleward lift" cannot be
    // sampled as an unrelated combination.
    const tropicalLon = normalizeLongitude(
        config.tropicalLon + state.tropicalLonOffset
            + 4 * Math.sin(state.phase * .73
                + 2 * Math.PI * elapsed / (state.periodHours * 1.25))
    );
    const tropicalLat = config.tropicalLat + state.tropicalLatOffset
        + config.hemisphere * 3.0 * pulse;
    const tropicalDx = normalizeLongitude(lon - tropicalLon);
    const tropicalAxisLat = tropicalLat + state.tilt * tropicalDx;
    const tropicalGaussian = Math.exp(-.5 * (
        (tropicalDx / 31) ** 2 + ((lat - tropicalAxisLat) / 7.5) ** 2
    ));
    const tropicalVertical = level === 850 ? 1 : level === 200 ? .24 : .58;

    // The poleward member is a broad long-wave trough. It supplies a genuine
    // handoff toward the westerlies in active cases without following the TC
    // or prescribing a turn. Its weak equatorward tail is phased with the
    // tropical trough and ridge rather than independently randomized.
    const troughLon = normalizeLongitude(
        config.troughLon + state.troughLonOffset
            + state.driftDegPerHour * elapsed
    );
    const troughLat = config.troughLat + state.troughLatOffset
        + config.hemisphere * 1.5 * Math.sin(
            state.phase + 2 * Math.PI * elapsed / (state.periodHours * .82)
        );
    const troughDx = normalizeLongitude(lon - troughLon);
    const troughAxisLat = troughLat + state.tilt * .55 * troughDx;
    const troughDy = lat - troughAxisLat;
    const troughGaussian = Math.exp(-.5 * (
        (troughDx / 25) ** 2 + (troughDy / 18) ** 2
    ));
    const tropicalLatitude = Math.abs(lat);
    // Use the same broad equatorward-tail geometry as the established WNP
    // recurvature trough. This remains a weak tail in the deep tropics, but
    // it can form a real subtropical ridge weakness instead of leaving two
    // split positive lobes connected by the monthly-mean high.
    const polewardCoupling = .28 + .72 * smoothstep((tropicalLatitude - 12) / 14);
    const troughVertical = level === 850 ? .48 : level === 200 ? .92 : 1;

    return -config.tropicalAmplitudeM * strength * tropicalVertical * tropicalGaussian
        - config.troughAmplitudeM * strength * troughVertical
            * polewardCoupling * troughGaussian;
}

// The NCEP 1981-2010 monthly height field is a calibration target here, not a
// replacement background. Its NIO winter upper jet is substantially stronger
// than this reduced-order model's generic NH profile. Add only a bounded,
// basin-local fraction of that missing geostrophic wind, smoothly integrated
// into the 200/500-hPa height field. The 850-hPa flow and transient weather
// remain generated by the existing model.
const NIO_WINTER_CIRCULATION_WEIGHT = Object.freeze([
    0.98, 0.95, 0.78, 0.52, 0.20, 0, 0, 0, 0.03, 0.38, 0.72, 0.95
]);
const NIO_CIRCULATION_HEIGHT_PROFILES = new Map();

function northIndianOceanWinterWeight(month) {
    const position = Number.isFinite(month)
        ? ((month - 1) % 12 + 12) % 12
        : 6;
    const lower = Math.floor(position);
    const upper = (lower + 1) % 12;
    const fraction = position - lower;
    return NIO_WINTER_CIRCULATION_WEIGHT[lower]
        + (NIO_WINTER_CIRCULATION_WEIGHT[upper]
            - NIO_WINTER_CIRCULATION_WEIGHT[lower]) * fraction;
}

function northIndianOceanCirculationHeightAdjustment(lon, lat, background, level) {
    if (background?.activeBasin !== 'NIO' || lat <= 0
        || ![200, 500].includes(level)) return 0;
    const month = background.calendarMonth;
    const winterWeight = northIndianOceanWinterWeight(month);
    if (winterWeight <= 0.01) return 0;

    const longitude = normalizeLongitude(lon);
    // Broad shoulders retain the calibration over the Arabian Sea and Bay of
    // Bengal, then fade before the adjacent western Pacific and southern Asia.
    const longitudeWeight = smoothstep((longitude - 42) / 10)
        * (1 - smoothstep((longitude - 100) / 9));
    if (longitudeWeight <= 0.001) return 0;

    const profileKey = `${month}:${level}`;
    let profile = NIO_CIRCULATION_HEIGHT_PROFILES.get(profileKey);
    if (!profile) {
        profile = [0];
        const stepDegrees = 0.25;
        const stepRadians = stepDegrees * Math.PI / 180;
        const radians = Math.PI / 180;
        const windAdjustment = latitude => {
            const upperJet = 4.3 * Math.exp(-0.5 * ((latitude - 18) / 10) ** 2)
                + 17.0 * Math.exp(-0.5 * ((latitude - 27.5) / 7.5) ** 2);
            const midlevelWesterly = 4.0 * Math.exp(-0.5 * ((latitude - 23) / 10) ** 2)
                - 3.0 * Math.exp(-0.5 * ((latitude - 33) / 5.5) ** 2);
            return winterWeight * (level === 200 ? upperJet : midlevelWesterly);
        };
        for (let index = 1; index <= 340; index++) {
            const latitude0 = (index - 1) * stepDegrees;
            const latitude1 = index * stepDegrees;
            const f0 = 2 * EARTH_OMEGA * Math.sin(latitude0 * radians);
            const f1 = 2 * EARTH_OMEGA * Math.sin(latitude1 * radians);
            const dz = -EARTH_RADIUS_M * stepRadians
                * (f0 * windAdjustment(latitude0)
                    + f1 * windAdjustment(latitude1)) / (2 * GRAVITY);
            profile.push(profile.at(-1) + dz);
        }
        NIO_CIRCULATION_HEIGHT_PROFILES.set(profileKey, profile);
    }
    return longitudeWeight * interpolateProfile(profile, Math.min(85, lat));
}

function monsoonCirculationHeight(lon, lat, background, level = 500, prepared = null) {
    const state = background?.monsoonCirculation;
    if (!state || lat < 0) return 0;
    const time = background.elapsedHours || 0;
    const lifecycle = prepared?.monsoonLifecycle
        || wnpMonsoonLifecycleState(background);
    const independentWobbleScale = 1 - .72 * lifecycle.strength;
    const longitude = normalizeLongitude(state.lon
        + WNP_RECURVATURE_MONSOON_EAST_SHIFT_DEG
            * lifecycle.strength * lifecycle.progress
        + independentWobbleScale * 5 * Math.sin(
            2 * Math.PI * time / state.longitudePeriodHours + state.longitudePhase
        ));
    const latitude = state.lat
        + WNP_RECURVATURE_MONSOON_NORTH_SHIFT_DEG
            * lifecycle.strength * lifecycle.progress
        + independentWobbleScale * 1.6 * Math.sin(
            2 * Math.PI * time / state.latitudePeriodHours + state.latitudePhase
        );
    const amplitude = state.amplitude * (.88 + .12 * Math.sin(
        2 * Math.PI * time / state.amplitudePeriodHours + state.amplitudePhase
    )) * (1 + .22 * lifecycle.strength * lifecycle.progress);
    const dx = normalizeLongitude(lon - longitude);
    // The observed WNP monsoon trough commonly tilts southwest-northeast.
    // This geometry yields low-level westerlies south of the axis, easterlies
    // north of it, and a poleward current on its eastern flank.
    const axisLatitude = latitude + state.tilt * dx;
    const dy = lat - axisLatitude;
    const gaussian = Math.exp(-.5 * (
        (dx / state.sigmaLon) ** 2 + (dy / state.sigmaLat) ** 2
    ));
    // The WNP monsoon gyre is bottom-heavy but not confined to 850 hPa. A
    // vanishingly shallow 500-hPa projection ended its poleward eastern-flank
    // current near 20N, after which every initially northbound storm fell back
    // under the ridge's easterlies. Keep a coherent, still-weaker midlevel
    // circulation while retaining very little signal at 200 hPa.
    const verticalScale = level === 850
        ? 1 : level === 200
            ? WNP_MONSOON_CIRCULATION_200_VERTICAL_SCALE
            : WNP_MONSOON_CIRCULATION_500_VERTICAL_SCALE;
    return -amplitude * verticalScale * gaussian;
}

function wnpRecurvatureTroughHeight(lon, lat, background, level = 500, prepared = null) {
    const state = background?.wnpRecurvatureRegime;
    const lifecycle = prepared?.monsoonLifecycle
        || wnpMonsoonLifecycleState(background);
    if (!background?.climatologyVersion || !state || lifecycle.strength <= .01 || lat <= 0) return 0;
    const time = background.elapsedHours || 0;
    // A slowly translating, meridionally elongated trough supplies the
    // southwest flow that links the monsoon trough to the westerlies. It is
    // deliberately broad: this is a synoptic long-wave configuration, not a
    // compact cyclone-following low or a prescribed track vector.
    const centerLon = normalizeLongitude(state.troughLon + state.driftDegPerHour * time);
    const centerLat = state.troughLat
        + .8 * Math.sin(2 * Math.PI * time / state.latitudePeriodHours + state.latitudePhase);
    const amplitudeEnvelope = .92 + .08 * Math.sin(
        2 * Math.PI * time / state.amplitudePeriodHours + state.amplitudePhase
    );
    const dx = normalizeLongitude(lon - centerLon);
    const axisLat = centerLat + state.tilt * dx;
    const dy = lat - axisLat;
    const gaussian = Math.exp(-.5 * (
        (dx / state.sigmaLon) ** 2 + (dy / state.sigmaLat) ** 2
    ));
    // This corridor is a deep, coupled monsoon/upper-trough state.  Keep its
    // 500-hPa steering geometry intact, but do not turn the tropical tail
    // into an upper-only anomaly: that creates 25-35 kt of synthetic shear
    // over otherwise moist open ocean and kills the seeds meant to enter the
    // corridor.  The modest remaining tilt still strengthens toward 200 hPa.
    const verticalScale = level === 850
        ? WNP_RECURVATURE_TROUGH_850_VERTICAL_SCALE
        : level === 200
            ? WNP_RECURVATURE_TROUGH_200_VERTICAL_SCALE
            : 1;
    // Taper with distance from the trough, not with an Earth-fixed latitude
    // switch. Multiplying height by the former 12--26N ramp contributed its
    // own meridional height gradient: an artificial westerly strip crossed
    // by every northbound vortex, independently of monsoon amplitude. A
    // nested Gaussian retains the weak outer tail and full trough core,
    // while both the height and its derivatives move with the trough axis.
    // These are the existing core/tail weights, not an added steering force.
    const troughCoupling = .28 + .72 * Math.exp(-.5 * (dy / state.sigmaLat) ** 2);
    return -WNP_RECURVATURE_TROUGH_500_AMPLITUDE_M * lifecycle.strength
        * (.62 + .38 * lifecycle.progress)
        * amplitudeEnvelope * verticalScale * troughCoupling * gaussian;
}

function wnpMonsoonRidgeCorridorHeight(lon, lat, background, level = 500) {
    const weather = background?.ridgeWeather;
    if (!background?.climatologyVersion || lat <= 0 || !weather) return 0;
    const activation = clamp(weather.corridorEnvelope || 0, 0, 1);
    if (activation <= 0) return 0;
    // When the oceanic ridge separates, its surviving eastern lobe and the
    // monsoon trough form a broad south-to-north steering corridor between
    // them. Represent that corridor as a smooth positive-height tongue tied
    // to the resolved ridge. Unlike the former negative notch, this field has no
    // compact minimum and therefore cannot manufacture a closed low inside
    // the subtropical high.
    const ridgeLongitude = Number.isFinite(weather.currentLon)
        ? weather.currentLon : weather.lon;
    const dx = normalizeLongitude(
        lon - ridgeLongitude - WNP_MONSOON_RIDGE_CORRIDOR_EAST_OFFSET_DEG
    );
    const easternRidgeTongue = Math.exp(-.5 * (
        dx / WNP_MONSOON_RIDGE_CORRIDOR_WIDTH_DEG
    ) ** 2);
    // The former 21--27N cutoff compressed about 70 m into the exact latitude
    // band used by recurving TCs.  Its artificial south-high/north-low wall
    // produced multi-day due-east tracks near 25N.  Keep the positive tongue
    // through the ridge's southern flank and let it decay over 14 degrees;
    // the eastward offset supplies the desired poleward flow from the same
    // smooth height field without a compact high or a sharp contour corner.
    const latitudeEnvelope = 1 - smoothstep((lat - 28) / 14);
    const levelScale = level === 850 ? .78 : level === 200 ? .88 : 1;
    return WNP_MONSOON_RIDGE_CORRIDOR_HEIGHT_M * levelScale
        * activation * easternRidgeTongue * latitudeEnvelope;
}

function wnpSummerTropicalGradientHeight(lon, lat, background, level = 500) {
    if (!background?.climatologyVersion || lat <= 0) return 0;
    const monthScale = { 6: .85, 7: 1, 8: 1, 9: .90 }[background.calendarMonth] || 0;
    if (monthScale <= 0) return 0;
    // The summer WNP ridge and monsoon trough maintain a regional background
    // height rise across the South China Sea and western Philippine Sea. Its
    // compact super-Gaussian longitude envelope prevents weak-flow trapping
    // near 130E while decaying before remote-ocean cols near 155-170E.
    const dx = normalizeLongitude(lon - WNP_SUMMER_TROPICAL_GRADIENT_CENTER_LON);
    const longitudeEnvelope = Math.exp(-.5
        * (dx / WNP_SUMMER_TROPICAL_GRADIENT_WIDTH_DEG) ** 4);
    const latitudeEnvelope = (1 - smoothstep((lat - 22) / 12))
        * smoothstep(lat / 8);
    const amplitude = (level === 850 ? 9 : level === 200 ? 5 : 7)
        * WNP_SUMMER_TROPICAL_GRADIENT_SCALE;
    return monthScale * longitudeEnvelope * latitudeEnvelope * amplitude
        * Math.tanh((lat - 10) / 10);
}

function modernWaveFieldComponents(lon, lat, background, level = 500, skipEquatorialBlend = false, prepared = null) {
    // The two hemispheric wave banks should join through an equatorial
    // transition zone. Selecting one bank with `lat < 0 ? -1 : 1` creates a
    // visible north/south seam in both contours and wind vectors.
    const equatorialWidth = 8;
    if (!background.climatologyVersion && !skipEquatorialBlend && Math.abs(lat) < equatorialWidth) {
        const north = modernWaveFieldComponents(
            lon, equatorialWidth, background, level, true, prepared
        );
        const south = modernWaveFieldComponents(
            lon, -equatorialWidth, background, level, true, prepared
        );
        const northWeight = smoothstep((lat + equatorialWidth) / (2 * equatorialWidth));
        const blend = (southValue, northValue) =>
            southValue + (northValue - southValue) * northWeight;
        return {
            height: blend(south.height, north.height)
                + equatorialLowWaveHeight(lon, lat, background, level),
            ridgeLatitude: blend(south.ridgeLatitude, north.ridgeLatitude),
            jetLatitude: blend(south.jetLatitude, north.jetLatitude),
            shortWave: blend(south.shortWave, north.shortWave),
            displacement: blend(south.displacement, north.displacement),
            tropicalWave: blend(south.tropicalWave, north.tropicalWave)
        };
    }
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    // Axis geometry depends on longitude/hemisphere, not query latitude.
    // A prepared immutable field can reuse it down each grid column.
    const axisCache = prepared?.axes[hemisphere];
    let axisGeometry = axisCache?.get(lon);
    if (!axisGeometry) {
        axisGeometry = modernAxisGeometryAt(lon, background, hemisphere, prepared);
        axisCache?.set(lon, axisGeometry);
    }
    const circulation = axisGeometry.circulation;
    const summer = circulation.summer;
    // The monthly mean contains stationary-wave structure but no day-to-day
    // Rossby-wave variance. Add only modes explicitly initialized as
    // zero-ensemble-mean transient anomalies; archived total-field modes stay
    // excluded so the stationary component is not counted twice.
    const waves = prepared?.waves[hemisphere] || (background.waves || []).filter(w => w.hemisphere === hemisphere
        && (!background.climatologyVersion || w.isManual || w.isTransientAnomaly));
    const phaseCache = prepared?.phaseCache?.[level];
    let wavePhaseCosines = phaseCache?.get(lon);
    if (!wavePhaseCosines) {
        wavePhaseCosines = waves.map(wave => Math.cos(
            wave.k * lon * radians + wave.phase
                + (level === 200
                    ? wave.verticalTiltRad
                    : level === 850 ? -wave.verticalTiltRad : 0)
        ));
        phaseCache?.set(lon, wavePhaseCosines);
    }
    const baseJetLatitude = circulation.jetLatitude;
    const jetDisplacement = axisGeometry.jetDisplacement;
    const ridgeDisplacement = axisGeometry.ridgeDisplacement;
    const totalDisplacement = jetDisplacement + ridgeDisplacement;
    // A displaced midlatitude jet cannot translate the entire tropical
    // height profile with it.  Applying the full axis displacement at 25–30N
    // samples the jet's steep gradient where no jet exists and produces
    // unrealistically strong, nearly zonal steering there.  Couple the
    // displacement into the barotropic profile only as the storm approaches
    // the jet latitude.
    // The reanalysis mean is a fixed Eulerian basic state. Moving the
    // whole height profile AND adding the explicit wave anomaly counts the
    // meander twice and drags the 200-hPa jet into the subtropics.
    const effectiveProfileDisplacement = background.climatologyVersion
        ? 0 : profileAxisDisplacement(
            latitude, totalDisplacement, background.axisMappingVersion
        );
    const profileLatitude = clamp(latitude - effectiveProfileDisplacement, 0, 85);
    const profile = background.zonalProfiles?.[level]?.[hemisphere]
        || background.zonalProfiles?.[level]?.[String(hemisphere)];
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5845;
    const climatologyLatitude = background.climatologyVersion
        ? climatologyLatitudeWithShiftedAxes(profileLatitude, circulation, hemisphere)
        : profileLatitude;
    const monthlyHeight = prepared?.sampleMonthlyHeight
        || ((x, y) => sampleMonthlyHeight(x, y, background.calendarMonth, level));
    let height = background.climatologyVersion
        ? monthlyHeight(
            lon, hemisphere * climatologyLatitude
        )
        : profile ? interpolateProfile(profile, profileLatitude) : datum;
    if (background.weatherSequence) height += sampleWeatherHeight(lon, lat, background, level);
    let shortWave = 0;
    let disturbance = 0;
    for (let waveIndex = 0; waveIndex < waves.length; waveIndex++) {
        const wave = waves[waveIndex];
        const waveLatitude = wave.latitude + .28 * effectiveProfileDisplacement;
        const envelope = Math.exp(-0.5 * ((latitude - waveLatitude) / Math.max(7, wave.width)) ** 2);
        // Midlatitude Rossby waves should not erase the tropical trade-wind
        // corridor. Their longitude gradients are the main source of
        // spurious eastward motion in synthetic tracks, so let planetary
        // waves enter only gradually through the subtropics and keep the
        // shorter baroclinic waves confined closer to the frontal zone. A
        // single taper for every wavenumber leaks too much random phase into
        // 25–35N and creates a false flat-eastward steering corridor.
        // Keep the mobile Rossby-wave bank on the poleward side of the
        // subtropical ridge.  Letting half of a 80-100 m planetary anomaly
        // reach 32-34N in boreal summer produced a second, broad closed high
        // over inland China that users could reasonably mistake for an
        // independently generated pressure system.
        // Let waves appear gradually north of the ridge, but place the maximum
        // slope of their latitude envelope 8-9 degrees poleward. A short
        // 8-degree ramp put that artificial gradient directly on the ridge
        // edge; moving the whole ramp poleward instead displaced the maximum
        // beyond 12 degrees.
        const westerlyWaveEdge = circulation.ridgeLatitude + 1;
        const longWaveTaper = smoothstep((latitude - westerlyWaveEdge) / 16);
        const shortWaveTaper = smoothstep((latitude - (westerlyWaveEdge + 1)) / 12);
        const latitudeTaper = (wave.k <= 3 ? longWaveTaper : shortWaveTaper)
            * (1 - smoothstep((latitude - 78) / 9));
        // Keep the wave nearly barotropic.  The zonal profile supplies the
        // climatological thermal-wind shear; making the wave itself much
        // larger aloft than below creates an artificial 30N shear wall.
        const levelFactor = level === 850 ? .84 : level === 200 ? 1.50 : 1;
        const baroclinicFactor = level === 850 ? -.12 : level === 200 ? .16 : 0;
        const amplitudeScale = wave.k <= 3
            ? MIDLATITUDE_PLANETARY_WAVE_AMPLITUDE_SCALE
            : MIDLATITUDE_SHORT_WAVE_AMPLITUDE_SCALE;
        const value = ((wave.amplitude * levelFactor
            + (wave.baroclinicAmplitude || 0) * baroclinicFactor)
            * amplitudeScale)
            * wavePhaseCosines[waveIndex] * envelope * latitudeTaper;
        disturbance += value;
        if (wave.k >= 4) shortWave += value;
    }
    let tropicalDisturbance = 0;
    const tropicalWaves = prepared?.tropicalWaves?.[hemisphere]
        || (background.tropicalWaves || []).filter(w => w.hemisphere === hemisphere);
    for (const wave of tropicalWaves) {
        const phase = wave.k * lon * radians + wave.phase
            + (level === 200 ? .06 : level === 850 ? -.04 : 0);
        const envelope = Math.exp(-0.5 * ((latitude - wave.latitude)
            / Math.max(4.5, wave.width)) ** 2);
        const levelFactor = level === 850 ? .82 : level === 200 ? .50 : 1;
        const upperProjection = level === 850
            ? 1
            : LOW_LATITUDE_TROPICAL_UPPER_SCALE
                + (1 - LOW_LATITUDE_TROPICAL_UPPER_SCALE)
                    * smoothstep((latitude - 8) / 14);
        tropicalDisturbance += wave.amplitude * levelFactor * upperProjection
            * Math.cos(phase) * envelope;
    }
    // Independent random modes can otherwise constructively interfere into a
    // height gradient much stronger than a planetary wave.  Bound the total
    // finite-amplitude anomaly in the field itself; this is a reduced-order
    // QG closure, not a cosmetic clamp applied only to the plotted contours.
    height += MIDLATITUDE_COMPOSITE_HEIGHT_LIMIT_M
        * Math.tanh(disturbance / MIDLATITUDE_COMPOSITE_HEIGHT_LIMIT_M);
    // Legacy standing tropical harmonics have no observed variance calibration.
    // In the reanalysis background, use the finite-lived tropical disturbances
    // below instead of adding a second independent planetary tropical wave bank.
    if (!background.climatologyVersion) {
        height += TROPICAL_WAVE_COMPOSITE_HEIGHT_LIMIT_M * Math.tanh(
            tropicalDisturbance / TROPICAL_WAVE_COMPOSITE_HEIGHT_LIMIT_M
        );
    }
    if (!skipEquatorialBlend) {
        height += equatorialLowWaveHeight(lon, lat, background, level);
    }
    height += monsoonCirculationHeight(lon, lat, background, level, prepared);
    height += wnpRecurvatureTroughHeight(lon, lat, background, level, prepared);
    height += wnpSummerTropicalGradientHeight(lon, lat, background, level);
    height += wnpMonsoonRidgeCorridorHeight(lon, lat, background, level);
    height += regionalCirculationHeight(lon, lat, background, level, prepared);
    height += northIndianOceanCirculationHeightAdjustment(lon, lat, background, level);
    return {
        height,
        ridgeLatitude: hemisphere * (circulation.ridgeLatitude + .35 * totalDisplacement),
        jetLatitude: hemisphere * (baseJetLatitude + jetDisplacement),
        shortWave,
        displacement: totalDisplacement,
        tropicalWave: tropicalDisturbance
    };
}

// A reduced-order quasi-geostrophic field. The prognostic state consists of
// zonal height profiles, dispersive Rossby-wave modes and a weak transient
// synoptic component. All three native levels are derived from that same
// state, rather than being independent pressure ellipses.
function waveFieldComponents(lon, lat, background, level = 500, prepared = null) {
    if (isModernAtmosphericBackground(background)) {
        return modernWaveFieldComponents(lon, lat, background, level, false, prepared);
    }
    return legacyWaveFieldComponents(lon, lat, background, level);
}

// Keep a narrow reference hook for the WebGPU field prototype. It exposes the
// production environmental wave component before transient synoptic systems,
// cyclone feedback, and editable pressure-cell anomalies are composed.
export function getWaveFieldHeightAt(lon, lat, background, level = 500) {
    return waveFieldComponents(lon, lat, background, level).height;
}

// Per-atmosphere RNG: rendering is pure and forecast clones cannot consume the
// live atmosphere's random sequence. Its state is included in every snapshot.
function synopticRandom(state) {
    state.rng = (Math.imul(state.rng,1664525)+1013904223) >>> 0;
    return state.rng / 4294967296;
}
function synopticNormal(state) {
    return Math.sqrt(-2*Math.log(Math.max(1e-9,synopticRandom(state))))
        * Math.cos(2*Math.PI*synopticRandom(state));
}
function southAsianHighRandom(cell) {
    cell.synopticRng = (Math.imul(cell.synopticRng || 1, 1664525) + 1013904223) >>> 0;
    return cell.synopticRng / 4294967296;
}
function southAsianHighNormal(cell) {
    return Math.sqrt(-2 * Math.log(Math.max(1e-9, southAsianHighRandom(cell))))
        * Math.cos(2 * Math.PI * southAsianHighRandom(cell));
}
function createColdLow(state, background, hemisphere, initial = false) {
    const circulation=backgroundMonthlyCirculation(background, hemisphere);
    const summer=circulation.summer;
    // Cold-core vortices belong to the westerly belt. The former fixed
    // 18-38-degree range placed summer lows inside the subtropical ridge and
    // could draw a closed low in the middle of the high.
    const equatorwardEdge = Math.max(
        circulation.ridgeLatitude + 4,
        circulation.jetLatitude - 10
    );
    const polewardEdge = Math.min(62, circulation.jetLatitude + 10);
    const sector=synopticRandom(state)<.65 ? state.sector : (synopticRandom(state)<.5?170:310);
    // These are weak synoptic/short-wave height lows, not a second set of
    // major pressure centers.  A 24–96 h lifetime and 24–38 m 500-hPa
    // amplitude is enough for a small closed contour or trough kink without
    // making the background field as busy as a chart analysis.
    const life=24+72*synopticRandom(state);
    return { lon:normalizeLongitude(sector+(synopticRandom(state)-.5)*55),
        lat:hemisphere*(equatorwardEdge
            +(polewardEdge-equatorwardEdge)*synopticRandom(state)),
        radius:4+2*synopticRandom(state),
        amplitude:24+14*synopticRandom(state), age:initial?life*.25:0, life,
        driftU:-.7-1.1*synopticRandom(state), driftV:(synopticRandom(state)-.5)*.5,
        // Only a minority of cold vortices have the right phase, depth and
        // position to force a rapid ridge retreat. Keep this in the
        // synoptic state so the event is reproducible and unrelated to the
        // cyclone's own random initialization.
        ridgeCoupling: synopticRandom(state) < .21
            ? .75 + .50 * synopticRandom(state) : 0,
        summer };
}

function upperVortexRidgeRetreatForcing(cell, background) {
    if (!cell || cell.role !== 'ridge' || cell.y <= 0) return 0;
    const lows = background?.synoptic?.coldLows || [];
    if (!lows.length) return 0;
    const ridgeLatitude = Math.abs(cell.y);
    let forcing = 0;
    for (const low of lows) {
        if (!low.ridgeCoupling || !Number.isFinite(low.lon) || !Number.isFinite(low.lat)) continue;
        const age = clamp((low.age || 0) / Math.max(1, low.life || 1), 0, 1);
        const lifecycle = Math.sin(Math.PI * age) ** 2;
        const westwardSeparation = -normalizeLongitude(low.lon - cell.x);
        // A trough/cold vortex west of the ridge erodes its upstream flank.
        // The broad envelope represents the surrounding trough, not just the
        // small closed low contour.
        const upstream = smoothstep((westwardSeparation - 8) / 14)
            * (1 - smoothstep((westwardSeparation - 62) / 20));
        const latitudeMatch = Math.exp(-.5 * ((Math.abs(low.lat)
            - (ridgeLatitude + 4)) / 10) ** 2);
        const strength = clamp((low.amplitude || 0) / 34, 0, 1.25);
        forcing += low.ridgeCoupling * lifecycle * upstream * latitudeMatch * strength;
    }
    return clamp(forcing, 0, 1);
}

function localSouthAsianHighBreakAt(lon, lat, systems) {
    const high = systems?.upper?.find(cell => cell.role === 'south-asian-high');
    if (!high || !high.ridgeBreakEnvelope) return 0;
    const dx = normalizeLongitude(lon - high.x);
    const proximity = Math.exp(-.5 * (
        (dx / 38) ** 2 + ((lat - high.y) / 14) ** 2
    ));
    return clamp(high.ridgeBreakEnvelope * proximity, 0, 1);
}
// Weak wave packets, not additional tropical-cyclone centres. WNP observed
// synoptic wavelengths are about 2500–3000 km (Tam & Li 2006,
// doi:10.1175/MWR3147.1). Amplitudes below are deliberately weak model design
// limits, not an asserted observational fit. No self-amplification is applied.
function createWeakTropicalWave(state, background, hemisphere, initial = false) {
    const summer = monthlyCirculation(background.calendarMonth, hemisphere, background.seasonalShift).summer;
    const life = 96 + 72 * synopticRandom(state);
    return {
        hemisphere,
        lon: normalizeLongitude(state.sector + (synopticRandom(state) - .5) * 70),
        lat: hemisphere * (10 + 6 * summer + (synopticRandom(state) - .5) * 4),
        wavelengthKm: 2500 + 500 * synopticRandom(state),
        widthLatKm: 1100 + 250 * synopticRandom(state),
        widthLonKm: 3500,
        amplitude: 1.5 + synopticRandom(state),
        tilt: -.25 * hemisphere,
        phase: 2 * Math.PI * synopticRandom(state),
        age: initial ? life * (.15 + .55 * synopticRandom(state)) : 0,
        life
    };
}
function weakTropicalWaveHeight(lon, lat, background, level = 500) {
    const state = background?.synoptic?.weakWaveState;
    if (!background?.weakTropicalWaveVersion || !state) return 0;
    const vertical = level === 850 ? 1 : level === 200 ? -.25 : .55;
    const latitudeGate = smoothstep((Math.abs(lat) - 2) / 5)
        * (1 - smoothstep((Math.abs(lat) - 25) / 10));
    let sum = 0;
    for (const wave of state.waves) {
        if (lat * wave.hemisphere <= 0) continue;
        const life = Math.sin(Math.PI * clamp(wave.age / wave.life, 0, 1)) ** 2;
        const longitudeDistance = normalizeLongitude(lon - wave.lon);
        const edge = 1 - smoothstep((Math.abs(longitudeDistance) - 90) / 30);
        if (life === 0 || edge === 0) continue;
        const x = longitudeDistance * 111.32 * Math.cos(wave.lat * Math.PI / 180);
        const y = (lat - wave.lat) * 111.32;
        const verticalPhase = level === 200 ? .3 : 0;
        const phase = 2 * Math.PI * (x - wave.tilt * y) / wave.wavelengthKm
            + wave.phase + verticalPhase;
        // Alternating trough/ridge wave train with long trough axes; no
        // isolated negative Gaussian monopole that can become another TC.
        sum -= wave.amplitude * life * edge * latitudeGate * Math.cos(phase)
            * Math.exp(-.5 * ((x / wave.widthLonKm) ** 2 + (y / wave.widthLatKm) ** 2));
    }
    return vertical * 4 * Math.tanh(sum / 4);
}
function advanceWeakTropicalWaves(background) {
    const state = background?.synoptic?.weakWaveState;
    if (!background?.weakTropicalWaveVersion || !state) return;
    for (const wave of state.waves) {
        // Advect the envelope by the broad 850-hPa flow, excluding its own
        // height perturbation. Intrinsic phase propagation uses the linear
        // beta-plane Rossby dispersion relation; it is a reduced-order model.
        const wind = gradientWind(wave.lon, wave.lat,
            (x,y) => waveFieldComponents(x,y,background,850).height, 9.80665);
        const latitude = wave.lat * Math.PI / 180;
        const k = 2 * Math.PI / (wave.wavelengthKm * 1000);
        const l = Math.PI / (2 * wave.widthLatKm * 1000);
        const beta = 2 * 7.292115e-5 * Math.cos(latitude) / 6371000;
        const intrinsicU = -beta / (k*k + l*l);
        const dt = MODEL_STEP_HOURS * 3600;
        wave.lon = normalizeLongitude(wave.lon + wind.u * dt / (111320 * Math.max(.3,Math.cos(latitude))));
        wave.lat = clamp(wave.lat + wind.v * dt / 111320, -40, 40);
        wave.phase = (wave.phase - k * intrinsicU * dt) % (2 * Math.PI);
        wave.age += MODEL_STEP_HOURS;
    }
    state.waves = state.waves.filter(wave => wave.age < wave.life);
    for (const hemisphere of [1,-1]) {
        while (state.waves.filter(wave => wave.hemisphere === hemisphere).length < 2) {
            state.waves.push(createWeakTropicalWave(state,background,hemisphere));
        }
    }
}

function createTropicalDisturbance(state, background, hemisphere, initial = false) {
    const summer = monthlyCirculation(
        background.calendarMonth,
        hemisphere,
        background.seasonalShift
    ).summer;
    const sector = state.sector + (synopticRandom(state) - .5) * 90;
    // These represent easterly-wave troughs, monsoon gyres and weak tropical
    // depressions that are too small/short-lived to be explicit pressure
    // centres.  Most are troughs; a minority are weak ridging pulses.  The
    // finite lifetime is important: the low-shear corridor must migrate and
    // decay instead of becoming a permanent basin-wide template.
    const life = 66 + 126 * synopticRandom(state);
    const amplitude = 10 + 13 * synopticRandom(state)
        + 4 * summer * synopticRandom(state);
    const isRidgePulse = synopticRandom(state) < .18;
    return {
        lon: normalizeLongitude(sector),
        lat: hemisphere * (8 + 12 * summer + (synopticRandom(state) - .5) * 7),
        radiusLon: 8 + 6 * synopticRandom(state),
        radiusLat: 4.5 + 3 * synopticRandom(state),
        amplitude: isRidgePulse ? -amplitude * (.45 + .25 * synopticRandom(state)) : amplitude,
        age: initial ? life * (.12 + .24 * synopticRandom(state)) : 0,
        life,
        driftU: -.12 - .20 * synopticRandom(state),
        driftV: (synopticRandom(state) - .5) * .06,
        tilt: (synopticRandom(state) - .5) * 10,
        summer
    };
}
function frontalGenesisLongitude(state, background, hemisphere, lookbackHours = 0) {
    const genesisSector = Number.isFinite(state.frontalSector)
        ? state.frontalSector : state.sector;
    const waves = (background.waves || [])
        .filter(wave => wave.hemisphere === hemisphere && wave.k <= 3);
    const waveSignal = waves.reduce((sum, wave) => sum
        + .22 * Math.sin(wave.phase - (wave.frequency || 0) * lookbackHours
            + wave.k * genesisSector * Math.PI / 180), 0);
    // New populations follow the resolved jet-wave phase, including the
    // birth phase of an older initial low. The legacy 84-hour clock moved
    // every birth sector back and forth independently of those waves.
    return normalizeLongitude(
        genesisSector + (background.frontalPopulationVersion >= 2 ? 0
            : 32 * Math.sin((background.elapsedHours || 0) / 84 + (state.frontalGenesisPhase ?? 0)))
            + 22 * waveSignal
    );
}

function nominalFrontalLifecycleEnvelope(low) {
    const age = Math.max(0, low.age || 0);
    const life = Math.max(1, low.life || 1);
    const growthHours = Math.max(18, low.growthHours || 42);
    const decayHours = Math.max(24, low.decayHours || 54);
    const decayStart = Math.max(growthHours + 18, life - decayHours);
    return smoothstep(age / growthHours)
        * (1 - smoothstep((age - decayStart) / decayHours));
}

function createFrontalLow(state, background, hemisphere, initial = false) {
    const circulation = backgroundMonthlyCirculation(background, hemisphere);
    const summer = circulation.summer;
    // The subtropical/front-zone track migrates equatorward in the local winter
    // and poleward in the local summer. It is deliberately distinct from
    // the polar jet latitude used by the steering profile: these are weak
    // baroclinic lows embedded in the subtropical jet entrance/exit region.
    const frontLatitude = 35 - 8 * (1 - summer);
    const life = 126 + 126 * synopticRandom(state);
    // Mid-tropospheric trough depth and surface pressure depth are related but
    // not interchangeable. Keeping separate amplitudes lets a frontal wave
    // bend/close the 500-hPa field without creating an unrealistically deep
    // sea-level cyclone.
    const surfacePeakAmplitude = 30 + 24 * synopticRandom(state);
    const peakAmplitude = 42 + 30 * synopticRandom(state);
    const growthHours = 30 + 24 * synopticRandom(state);
    const decayHours = 42 + 30 * synopticRandom(state);
    const stationaryInitial = initial && typeof initial === 'object'
        && background.frontalPopulationVersion >= 2;
    // Sample the population, not a cohort of newborn lows. Stratification
    // spreads a small initial population over its lifecycle without adding
    // a periodic birth schedule or changing the maintained population size.
    const age = initial ? life * (stationaryInitial
        ? (initial.index + synopticRandom(state)) / initial.count
        : .08 + .20 * synopticRandom(state)) : 0;
    // CNECT/ERA5 passages spend about 62 h inside 120E-180E, 25N-55N;
    // the former 6.25 m/s mean intrinsic drift left model lows there for
    // roughly 94 h. A 9 m/s mean restores realistic throughput without
    // shortening the documented long summer cyclone lifecycle.
    // WNP ET environments have two recurrent configurations (Klein et al.
    // 2000): a northwest pattern whose cyclone/trough moves north-northeast,
    // and a northeast pattern embedded in strong, nearly zonal flow. The old
    // ±0.05 m/s meridional drift reduced both to the latter. Represent the
    // distinction in the prognostic frontal-low field, not in TC motion.
    const northwestPattern = synopticRandom(state) < .55;
    const baseDriftU = northwestPattern
        ? 5.5 + 4.5 * synopticRandom(state)
        : 8 + 4.5 * synopticRandom(state);
    const baseDriftV = hemisphere * (northwestPattern
        ? 1.2 + 2.0 * synopticRandom(state)
        : (synopticRandom(state) - .5) * .30);
    const baseTilt = (2 * synopticRandom(state) - 1) * 9;
    const low = {
        lon: normalizeLongitude(frontalGenesisLongitude(state, background, hemisphere,
            stationaryInitial ? age : 0)
            + (initial ? (synopticRandom(state) - .5) * 28 : (synopticRandom(state) - .5) * 10)),
        lat: hemisphere * clamp(
            frontLatitude + (synopticRandom(state) - .5) * 8,
            25,
            55
        ),
        radiusLon: 6 + 5 * synopticRandom(state),
        radiusLat: 4 + 3 * synopticRandom(state),
        amplitude: peakAmplitude,
        peakAmplitude,
        surfaceAmplitude: surfacePeakAmplitude,
        age,
        life,
        growthHours,
        decayHours,
        baseDriftU,
        baseDriftV,
        transitionPattern: northwestPattern ? 'northwest' : 'northeast',
        driftU: baseDriftU,
        driftV: baseDriftV,
        baseTilt,
        tilt: baseTilt,
        development: initial ? .28 + .20 * synopticRandom(state) : .01,
        // A newly spawned low is a weak precursor. It is present in the
        // prognostic state immediately, but has no chart-scale closed low
        // yet; the field signal grows continuously from this value.
        fieldEnvelope: initial ? .12 + .25 * synopticRandom(state) : .008,
        fadeHours: 0,
        cutoff: 0,
        phase: 'incipient',
        summer
    };
    if (stationaryInitial) {
        // Older lows have already travelled downstream. Leaving every age
        // near the genesis sector piled several mature trough/ridge couplets
        // over the same coast. Back-project their birth wave phase, then
        // advect using the same background/intrinsic-drift closure as below.
        const wind = gradientWind(low.lon, low.lat,
            (x, y) => waveFieldComponents(x, y, background).height, GRAVITY);
        const position = advectPosition(low.lon, low.lat,
            .25 * wind.u + low.driftU, .25 * wind.v + low.driftV, age);
        low.lon = position.lon;
        low.lat = clamp(position.lat, -65, 65);
        const nominalEnvelope = nominalFrontalLifecycleEnvelope(low);
        const jetSupport = frontalBaroclinicSupport(low, background);
        // Use the existing lifecycle target; age and strength must describe
        // the same snapshot. Retain the old draws above so other weather's
        // seeded random sequence is unaffected by this initialization fix.
        low.fieldEnvelope = clamp(nominalEnvelope * (.72 + .34 * jetSupport), 0, 1);
        low.development = clamp(.45 * jetSupport + .35 * nominalEnvelope, 0, 1);
        low.phase = age < growthHours ? 'incipient'
            : low.fieldEnvelope < .10 ? 'decaying' : 'developing';
    }
    return low;
}
function initializeSynopticField(background, cells, cyclone) {
    const state={rng:(Math.floor(background.waves[0].phase/Math.PI/2*4294967296)>>>0)||1,
        sector:({WPAC:160,EPAC:240,NATL:310,NIO:85,SIO:85,SHEM:170,SATL:340})[cyclone.basin]||160,
        // Frontal cyclones entering the WNP chart commonly form upstream over
        // East Asia/East China Sea. Keep this separate from the basin sector
        // used by tropical disturbances and upper cold lows.
        frontalSector:({WPAC:135,EPAC:215,NATL:285,NIO:65,SIO:65,SHEM:145,SATL:315})[cyclone.basin]||135,
        modes:[],baroclinicModes:[],coldLows:[],tropicalDisturbances:[],frontalLows:[],
        frontalGenesisPhase:0,births:0,expired:0};
    state.frontalGenesisPhase = 2 * Math.PI * synopticRandom(state);
    // A few metres of coherent height texture represent unresolved short
    // waves/fronts.  Keep the perturbation bounded so it adds structure to
    // the contours without competing with the planetary field.
    for(let i=0;i<8;i++) state.modes.push({kx:8+Math.floor(14*synopticRandom(state)),
        ky:6+Math.floor(12*synopticRandom(state)),phaseX:2*Math.PI*synopticRandom(state),
        phaseY:2*Math.PI*synopticRandom(state),amplitude:clamp(4.5*synopticNormal(state),-9,9),
        phaseSpeed:(synopticRandom(state)-.5)*.045});
    for(const hemisphere of [1,-1]) {
        const summer=monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        if(synopticRandom(state)<.55+.30*summer){state.coldLows.push(createColdLow(state,background,hemisphere,true));state.births++;}
        // A single-storm simulation must not seed additional tropical vortices
        // in its environment. Retain the old population only for archived
        // backgrounds without the singleStormEnvironment flag.
        const disturbanceCount = background.singleStormEnvironment ? 0 : summer > .55 ? 2 : 1;
        for (let i = 0; i < disturbanceCount; i++) {
            state.tropicalDisturbances.push(
                createTropicalDisturbance(state, background, hemisphere, true)
            );
            state.births++;
        }
        // Initialize the same population maintained by advanceSynopticField,
        // but distribute its ages and downstream positions instead of
        // initializing every member in its first quarter of life.
        const frontalCount = summer < .30 ? 5 : 4;
        for (let i = 0; i < frontalCount; i++) {
            state.frontalLows.push(createFrontalLow(state, background, hemisphere,
                background.frontalPopulationVersion >= 2
                    ? { index: i, count: frontalCount } : true));
            state.births++;
        }

        for (let i = 0; i < 5; i++) {
            const amplitude = 18 + 10 * synopticRandom(state);
            state.baroclinicModes.push({
                hemisphere,
                k: 1 + Math.floor(3 * synopticRandom(state)),
                phase: 2 * Math.PI * synopticRandom(state),
                phaseSpeed: (synopticRandom(state) - .5) * .018,
                latitude: hemisphere * (10 + 15 * synopticRandom(state)),
                width: 7 + 5 * synopticRandom(state),
                amplitude,
                baseAmplitude: amplitude
            });
        }
    }
    for(const cell of cells.filter(c=>c.role==='ridge')) {
        cell.synopticAnchor={x:cell.x,y:cell.y,dx:0,dy:0,amplitude:0};
    }
    if (background.weakTropicalWaveVersion) {
        // Separate random stream: weak-wave evolution cannot perturb the
        // existing cold-low/front population or global intensity randomness.
        state.weakWaveState = {rng:(state.rng ^ 0x6a09e667) >>> 0,sector:state.sector,waves:[]};
        for (const hemisphere of [1,-1]) for (let i=0;i<2;i++) {
            state.weakWaveState.waves.push(createWeakTropicalWave(state.weakWaveState,background,hemisphere,true));
        }
    }
    background.synoptic=state;
}
function pacificTuttHeight(lon, lat, background, level) {
    // A broad TUTT extends from the central/eastern Pacific toward the lower
    // latitudes west of the date line. It is upper-tropospheric, but a small
    // vertically coherent projection prevents the 200-hPa feature from being
    // completely disconnected from the deep-layer steering mass field.
    const vertical = level === 200 ? 1 : level === 500 ? .15 : .025;
    if (!vertical || lat <= 0) return 0;
    const summer = monthlyCirculation(background.calendarMonth, 1, background.seasonalShift).summer;
    if (summer <= .08) return 0;
    const state = background.pacificTutt || {
        centerLon: 200,
        baseLat: 24,
        tilt: .16,
        sigmaLon: 40,
        sigmaLat: 7,
        strength: 1,
        longitudePeriodHours: 480,
        latitudePeriodHours: 360,
        amplitudePeriodHours: 360,
        longitudePhase: background.waves?.[0]?.phase || 0,
        latitudePhase: background.waves?.[0]?.phase || 0,
        amplitudePhase: background.waves?.[0]?.phase || 0
    };
    const time = background.elapsedHours || 0;
    const epacLifecycle = background.activeBasin === 'EPAC'
        ? regionalCirculationLifecycleState(background)
        : { strength: 0, pulse: 0 };
    const coupling = clamp(epacLifecycle.strength || 0, 0, 1);
    const centerLon = normalizeLongitude(state.centerLon
        + 8 * Math.sin(2 * Math.PI * time / state.longitudePeriodHours
            + state.longitudePhase)
        + 6 * coupling * epacLifecycle.pulse);
    const dx = normalizeLongitude(lon - centerLon);
    // During an active EPAC ridge/trough lifecycle the TUTT extends a few
    // degrees equatorward while the subtropical ridge retracts. Both changes
    // therefore appear together instead of requiring two unrelated draws.
    const axis = state.baseLat + state.tilt * dx
        + 2.2 * Math.sin(2 * Math.PI * time / state.latitudePeriodHours
            + state.latitudePhase)
        - 3.5 * coupling * epacLifecycle.pulse;
    const envelope = Math.exp(-.5 * (
        (dx / state.sigmaLon) ** 2
        + ((lat - axis) / state.sigmaLat) ** 2
    ));
    const amplitudeCycle = .76 + .24 * Math.sin(
        2 * Math.PI * time / state.amplitudePeriodHours + state.amplitudePhase
    ) ** 2;
    const amplitude = 120 * summer * state.strength * amplitudeCycle
        * (1 + .25 * coupling * epacLifecycle.pulse);
    return -amplitude * vertical * envelope;
}

function transientHeight(lon,lat,background,level) {
    const state=background.synoptic;
    if(!state)return 0;
    const radians=Math.PI/180;
    let height=pacificTuttHeight(lon, lat, background, level);
    // Spatially coherent, temporally correlated weather noise, shared by all
    // levels so restoring track variability does not inflate deep-layer shear.
    const taper=Math.exp(-Math.pow(lat/55,4));
    // Unresolved texture is not a resolved tropical ridge/trough. A fixed
    // height variance at every wavenumber gives velocity variance ~k²/f²,
    // so short modes can dominate deep-layer steering at low latitude.
    // Filter the height itself (all levels and charts share this field).
    // The smooth latitude response avoids a cusp at the equator; organized
    // tropical disturbances and basin ridges retain their own full dynamics.
    const sinLatSq = Math.sin(lat * radians) ** 2;
    const tropicalResponse = (sinLatSq + Math.sin(3 * radians) ** 2)
        / (sinLatSq + Math.sin(20 * radians) ** 2);
    for(const mode of state.modes) {
        const waveNumber = Math.hypot(mode.kx / Math.max(.15, Math.cos(lat * radians)), mode.ky);
        const spectralResponse = 8 / Math.max(8, waveNumber);
        height += mode.amplitude * spectralResponse * tropicalResponse
            * Math.cos(mode.kx*lon*radians+mode.phaseX)
            * Math.cos(mode.ky*lat*radians+mode.phaseY)*taper;
    }
    for(const low of state.coldLows) {
        const envelope=Math.sin(Math.PI*clamp(low.age/low.life,0,1))**2;
        const hemisphere=low.lat<0?-1:1;
        const circulation=backgroundMonthlyCirculation(background, hemisphere);
        const westerlyEdge=Math.max(
            circulation.ridgeLatitude+3,
            circulation.jetLatitude-11
        );
        const westerlyGate=smoothstep((Math.abs(lat)-westerlyEdge)/6);
        if(westerlyGate<=0)continue;
        const tilt=level===200?1:level===850?-.5:0;
        const dx=normalizeLongitude(lon-low.lon+tilt)*Math.cos(low.lat*radians);
        const dy=lat-low.lat;
        const vertical=level===200?1.05:level===850?.28:1;
        height-=low.amplitude*vertical*envelope*westerlyGate
            *Math.exp(-.5*((dx/low.radius)**2+(dy/low.radius)**2));
    }
    return height;
}

function transientBaroclinicHeight(lon, lat, background, level) {
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.baroclinicModes) || level === 500) return 0;
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    const tropicalEnvelope = smoothstep((latitude - 5) / 7)
        * (1 - smoothstep((latitude - 34) / 10));
    if (tropicalEnvelope <= 0) return 0;
    // Synoptic baroclinic modes may extend equatorward of the ridge, but their
    // deep-layer thermal-wind projection is much weaker in the tropical
    // column. Giving the 10-20N tail its full midlatitude amplitude produced
    // a recurrent 25-45 kt 850/200-hPa shear wall over the open WNP. Preserve
    // the evolving full-field anomaly, then recover its full amplitude only
    // as it approaches the subtropical baroclinic zone.
    const lowLatitudeProjection = .28
        + .72 * smoothstep((latitude - 18) / 12);
    const verticalSign = level === 200 ? 1 : level === 850 ? -0.72 : 0;
    const height = state.baroclinicModes
        .filter(mode => mode.hemisphere === hemisphere)
        .reduce((sum, mode) => {
            const phase = mode.k * lon * radians + mode.phase;
            const envelope = Math.exp(-0.5 * ((latitude - Math.abs(mode.latitude)) / mode.width) ** 2);
            return sum + mode.amplitude * verticalSign * Math.cos(phase) * envelope * tropicalEnvelope;
        }, 0);
    // Several independent modes can otherwise construct an unrealistically
    // deep composite anomaly when they align. Preserve their gradients and
    // phase relationships, but keep the finite-amplitude QG closure bounded.
    return lowLatitudeProjection * 70 * Math.tanh(height / 70);
}

function transientTropicalDisturbanceHeight(lon, lat, background, level) {
    if (background.singleStormEnvironment) return weakTropicalWaveHeight(lon,lat,background,level);
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.tropicalDisturbances)) return 0;
    const radians = Math.PI / 180;
    let height = 0;
    for (const disturbance of state.tropicalDisturbances) {
        const envelope = Math.sin(
            Math.PI * clamp(disturbance.age / Math.max(1, disturbance.life), 0, 1)
        ) ** 2;
        if (envelope <= 0) continue;
        const vertical = level === 850 ? .92 : level === 200 ? -.56 : .48;
        // A tropical disturbance is normally a lower/mid-tropospheric trough
        // with weak upper divergence/outflow.  The sign reversal aloft is
        // intentionally modest: it varies shear direction without creating a
        // synthetic hurricane anticyclone around every weak wave.
        const centerLon = normalizeLongitude(
            disturbance.lon + (level === 200 ? disturbance.tilt : 0)
        );
        const dx = normalizeLongitude(lon - centerLon)
            * Math.cos(disturbance.lat * radians);
        const dy = lat - disturbance.lat;
        const gaussian = Math.exp(-.5 * (
            (dx / disturbance.radiusLon) ** 2
            + (dy / disturbance.radiusLat) ** 2
        ));
        height -= disturbance.amplitude * vertical * envelope * gaussian;
    }
    return 42 * Math.tanh(height / 42);
}

function frontalLifecycleEnvelope(low) {
    const remaining = 1 - clamp(low.absorbedFraction || 0, 0, 1);
    if (Number.isFinite(low.fieldEnvelope)) return clamp(low.fieldEnvelope, 0, 1) * remaining;
    // Compatibility path for saved/hand-authored fields created before the
    // stateful frontal lifecycle existed.
    const age = Math.max(0, low.age || 0);
    const life = Math.max(1, low.life || 1);
    return Math.sin(Math.PI * clamp(age / life, 0, 1)) ** 2 * remaining;
}

// Diagnose whether an analytic frontal low actually closes an isobar in the
// composed MSLP field. The minimum pressure on an elliptical ring is used,
// because a low on a strong background gradient must be enclosed on every
// side before it deserves an L marker.
export function getFrontalLowSurfaceClosure(low, pressureSystems) {
    if (!low || !Number.isFinite(low.lon) || !Number.isFinite(low.lat)) {
        return { centerLon: null, centerLat: null, centerPressure: null,
            closureDepthHpa: 0, meanDepthHpa: 0 };
    }
    // The analytic anomaly centre is not necessarily the MSLP minimum after
    // it is superposed on a sloping background field. Search a compact area
    // first, otherwise a real but slightly displaced closed low is rejected.
    let centerLon = low.lon;
    let centerLat = low.lat;
    let centerPressure = getSurfacePressureAt(centerLon, centerLat, pressureSystems);
    for (const yFraction of [-.4, -.2, 0, .2, .4]) {
        for (const xFraction of [-.4, -.2, 0, .2, .4]) {
            const candidateLon = normalizeLongitude(
                low.lon + (low.radiusLon || 8) * xFraction
            );
            const candidateLat = clamp(
                low.lat + (low.radiusLat || 6) * yFraction,
                -78,
                78
            );
            const candidatePressure = getSurfacePressureAt(
                candidateLon, candidateLat, pressureSystems
            );
            if (candidatePressure < centerPressure) {
                centerLon = candidateLon;
                centerLat = candidateLat;
                centerPressure = candidatePressure;
            }
        }
    }
    let best = { closureDepthHpa: -Infinity, meanDepthHpa: -Infinity, ringScale: null };
    // Search both the compact inner closure and the broader synoptic-scale
    // circulation. A cyclone embedded in a strong meridional gradient can
    // close one or two inner isobars even while its outermost wave stays open.
    for (const ringScale of [.65, .85, 1.15, 1.45, 1.80]) {
        const pressures = [];
        for (let index = 0; index < 16; index++) {
            const angle = index / 16 * Math.PI * 2;
            const sampleLat = clamp(
                centerLat + (low.radiusLat || 6) * ringScale * Math.sin(angle),
                -78,
                78
            );
            const sampleLon = normalizeLongitude(
                centerLon + (low.radiusLon || 8) * ringScale * Math.cos(angle)
            );
            pressures.push(getSurfacePressureAt(sampleLon, sampleLat, pressureSystems));
        }
        const closureDepthHpa = Math.min(...pressures) - centerPressure;
        const meanDepthHpa = pressures.reduce((sum, pressure) => sum + pressure, 0)
            / pressures.length - centerPressure;
        if (closureDepthHpa > best.closureDepthHpa) {
            best = { closureDepthHpa, meanDepthHpa, ringScale };
        }
    }
    return { centerLon, centerLat, centerPressure, ...best };
}

function geographicFrontCurve(lon, lat, direction, lengthKm, bendKm, samples = 15) {
    const magnitude = Math.max(1e-6, Math.hypot(direction.east, direction.north));
    const alongEast = direction.east / magnitude;
    const alongNorth = direction.north / magnitude;
    const crossEast = -alongNorth;
    const crossNorth = alongEast;
    const latitudeRadians = lat * Math.PI / 180;
    const longitudeScale = 111.32 * Math.max(.22, Math.cos(latitudeRadians));
    const points = [];
    for (let index = 0; index < samples; index++) {
        const t = index / (samples - 1);
        const along = lengthKm * t;
        const cross = bendKm * Math.sin(Math.PI * t) * (.35 + .65 * t);
        const eastKm = alongEast * along + crossEast * cross;
        const northKm = alongNorth * along + crossNorth * cross;
        points.push([
            normalizeLongitude(lon + eastKm / longitudeScale),
            clamp(lat + northKm / 111.32, -78, 78)
        ]);
    }
    return points;
}

function geographicOffsetPoint(lon, lat, eastKm, northKm) {
    const longitudeScale = 111.32 * Math.max(.22, Math.cos(lat * Math.PI / 180));
    return [
        normalizeLongitude(lon + eastKm / longitudeScale),
        clamp(lat + northKm / 111.32, -78, 78)
    ];
}

function appendCycloneFronts(result, owner, strength, development, phase, lifecycle = {}) {
    if (!owner || strength < .08) return;
    const hemisphere = Math.sign(owner.lat) || 1;
    // Front topology follows the baroclinic/environmental flow. A tracked low
    // can briefly move retrograde under blocking, but that must not rotate its
    // warm sector and triple point by 180 degrees on the next chart.
    const driftEast = Number.isFinite(owner.frontOrientationU)
        ? owner.frontOrientationU
        : Number.isFinite(owner.driftU)
            ? owner.driftU : Number.isFinite(owner.steeringU) ? owner.steeringU : 7;
    const driftNorth = Number.isFinite(owner.frontOrientationV)
        ? owner.frontOrientationV
        : Number.isFinite(owner.driftV)
            ? owner.driftV : Number.isFinite(owner.steeringV) ? owner.steeringV : 0;
    // Front families are organised along the downstream baroclinic/westerly
    // axis, not by the instantaneous displacement of the low centre. A low
    // can move retrograde or equatorward under blocking without exchanging
    // its warm and cold sectors. Keep the axis eastward and retain only the
    // physically useful meridional tilt: warm front downstream/poleward,
    // cold front upstream/equatorward in either hemisphere.
    const downstreamEast = Math.max(2, Math.abs(driftEast));
    const polewardSlope = clamp(
        hemisphere * driftNorth / downstreamEast,
        -.10,
        .55
    );
    const downstreamNorth = hemisphere * polewardSlope * downstreamEast;
    const driftMagnitude = Math.hypot(downstreamEast, downstreamNorth);
    const forward = {
        east: downstreamEast / driftMagnitude,
        north: downstreamNorth / driftMagnitude
    };
    const equatorward = { east: 0, north: -hemisphere };
    const diagnosedOcclusion = phase === 'cutoff' || phase === 'decaying'
        ? clamp(.45 + .55 * development, 0, 1)
        : smoothstep((development - .48) / .42);
    const occlusion = Number.isFinite(lifecycle.occlusion)
        ? clamp(lifecycle.occlusion, 0, 1) : diagnosedOcclusion;
    // During occlusion the triple point moves downstream, the surface warm
    // sector narrows and the cold front rotates toward the warm front.
    const coldDirection = {
        east: (-.48 + .32 * occlusion) * forward.east + .92 * equatorward.east,
        north: (-.48 + .32 * occlusion) * forward.north + .92 * equatorward.north
    };
    const warmDirection = {
        east: forward.east - (.24 - .10 * occlusion) * equatorward.east,
        north: forward.north - (.24 - .10 * occlusion) * equatorward.north
    };
    const scale = .70 + .60 * development;
    const junctionDistanceKm = 230 * occlusion;
    const [frontLon, frontLat] = geographicOffsetPoint(
        owner.lon,
        owner.lat,
        forward.east * junctionDistanceKm,
        forward.north * junctionDistanceKm
    );
    const symbolSide = hemisphere > 0 ? 1 : -1;
    result.push({
        ownerType: owner.ownerType,
        ownerId: owner.ownerId,
        centerPressure: owner.centerPressure,
        closureDepthHpa: owner.closureDepthHpa,
        showCenterLabel: owner.showCenterLabel,
        type: 'cold',
        strength,
        symbolSide,
        center: [owner.lon, owner.lat],
        points: geographicFrontCurve(
            frontLon, frontLat, coldDirection,
            (430 + 610 * development) * scale * (1 - .18 * occlusion),
            hemisphere * (85 + 75 * development + 80 * occlusion)
        )
    });
    result.push({
        ownerType: owner.ownerType,
        ownerId: owner.ownerId,
        centerPressure: owner.centerPressure,
        closureDepthHpa: owner.closureDepthHpa,
        showCenterLabel: owner.showCenterLabel,
        type: 'warm',
        strength,
        symbolSide,
        center: [owner.lon, owner.lat],
        points: geographicFrontCurve(
            frontLon, frontLat, warmDirection,
            (330 + 480 * development) * scale * (1 - .32 * occlusion),
            // Curve toward the poleward side of the front regardless of
            // whether the downstream axis points east or west.
            (Math.sign(hemisphere * warmDirection.east) || hemisphere)
                * (55 + 45 * development + 45 * occlusion)
        )
    });

    if (occlusion <= .06) return;
    // The occluded segment joins the low centre to the triple point. Its bend
    // must remain subordinate to that chord: using a fixed 45-170 km bow on a
    // newly formed 15-100 km segment creates the small loop/self-crossing seen
    // on synoptic charts. Scale curvature with the actual junction distance.
    const occludedBendKm = hemisphere * Math.min(
        45 + 125 * occlusion,
        junctionDistanceKm * .38
    );
    result.push({
        ownerType: owner.ownerType,
        ownerId: owner.ownerId,
        centerPressure: owner.centerPressure,
        closureDepthHpa: owner.closureDepthHpa,
        showCenterLabel: owner.showCenterLabel,
        type: 'occluded',
        strength: strength * occlusion,
        symbolSide,
        center: [owner.lon, owner.lat],
        points: geographicFrontCurve(
            owner.lon, owner.lat, forward,
            junctionDistanceKm,
            occludedBendKm,
            12
        )
    });
}

function buildColdSurgeFront(cell, ownerId) {
    if (!cell?.isColdSurge) return null;
    const envelope = coldSurgeFieldEnvelope(cell);
    const marineFactor = coldSurgeMarineFactor(cell);
    const strength = clamp(
        Math.max(0, cell.strength || 0) / 18 * marineFactor,
        0,
        1
    );
    // Do not draw a fully developed front around a weak continental
    // precursor. The line appears only after the cold tongue has established
    // a usable surface-pressure gradient, then fades with that shared field.
    if (envelope < .18 || strength < .16) return null;

    const hemisphere = cell.y < 0 ? -1 : 1;
    const centerLon = normalizeLongitude(cell.x + 12);
    const centerLat = clamp(
        cell.y - hemisphere * (17 + 3 * envelope),
        -72,
        72
    );
    const radians = Math.PI / 180;
    const tilt = hemisphere * (10 + .45 * (cell.wedgeTiltDeg || 18)) * radians;
    const alongEast = Math.cos(tilt);
    const alongNorth = Math.sin(tilt);
    // This normal points toward the advancing, equatorward/downstream side
    // in both hemispheres.
    const advanceEast = hemisphere * alongNorth;
    const advanceNorth = -hemisphere * alongEast;
    const halfLengthKm = clamp(
        (cell.sigmaX || cell.baseSigmaX || 16) * 111.32
            * Math.max(.35, Math.cos(cell.y * radians)) * (.58 + .28 * envelope),
        620,
        1450
    );
    const bowKm = 70 + 90 * envelope;
    const longitudeScale = 111.32 * Math.max(.22, Math.cos(centerLat * radians));
    const points = [];
    // Store east-to-west. With the chart's hemisphere symbol side this makes
    // cold-front triangles point into the advancing equatorward air mass.
    for (let index = 0; index < 25; index++) {
        const t = index / 24;
        const along = halfLengthKm * (1 - 2 * t);
        const cross = bowKm * Math.sin(Math.PI * t);
        const eastKm = alongEast * along + advanceEast * cross;
        const northKm = alongNorth * along + advanceNorth * cross;
        points.push([
            normalizeLongitude(centerLon + eastKm / longitudeScale),
            clamp(centerLat + northKm / 111.32, -78, 78)
        ]);
    }
    return {
        ownerType: 'cold-surge',
        ownerId,
        showCenterLabel: false,
        type: 'cold',
        strength,
        symbolSide: hemisphere > 0 ? 1 : -1,
        center: [cell.x, cell.y],
        points
    };
}

function frontsOverlap(first, second, thresholdKm = 420) {
    const firstPoints = first?.points || [];
    const secondPoints = second?.points || [];
    for (let i = 0; i < firstPoints.length; i += 3) {
        for (let j = 0; j < secondPoints.length; j += 3) {
            if (calculateDistance(
                firstPoints[i][1], firstPoints[i][0],
                secondPoints[j][1], secondPoints[j][0]
            ) < thresholdKm) return true;
        }
    }
    return false;
}

function frontalLowFootprintKm(candidate) {
    const latitudeScale = Math.max(.25, Math.cos(candidate.lat * Math.PI / 180));
    const zonalKm = (candidate.radiusLon || 8) * FRONTAL_SURFACE_RADIUS_SCALE
        * 111.32 * latitudeScale;
    const meridionalKm = (candidate.radiusLat || 6) * FRONTAL_SURFACE_RADIUS_SCALE * 111.32;
    return Math.sqrt(zonalKm * meridionalKm);
}

function trimFrontOutsideCyclone(front, cyclone, exclusionRadiusKm) {
    let longest = [];
    let current = [];
    for (const point of front.points) {
        const outside = calculateDistance(cyclone.lat, cyclone.lon, point[1], point[0])
            >= exclusionRadiusKm;
        if (outside) {
            current.push(point);
            if (current.length > longest.length) longest = current.slice();
        } else {
            current = [];
        }
    }
    return longest.length >= 3 ? { ...front, points: longest } : null;
}

function cycloneFrontExclusionRadiusKm(cyclone) {
    if (!cyclone) return 0;
    const r34Km = Array.isArray(cyclone.r34)
        ? Math.max(0, ...cyclone.r34.filter(Number.isFinite).map(radius => Math.abs(radius) * 111.32))
        : 0;
    const circulationKm = Math.max(0, cyclone.circulationSize || 0);
    const intensity = Math.max(0, cyclone.intensity || 0);
    const fallback = circulationKm * (
        .72 + .34 * smoothstep((intensity - 34) / 86)
    );
    // Keep unrelated fronts outside the resolved gale circulation. R34 is
    // preferred because it follows the historical state displayed by the
    // chart; circulation size supplies a bounded fallback for older records.
    return clamp(Math.max(r34Km * .90, fallback), 180, 720);
}

// Return chart-ready surface fronts for both prognostic baroclinic lows and
// a user cyclone that has completed extratropical transition. Geometry is
// tied to motion, hemisphere and lifecycle, so the symbols describe the same
// evolving systems that shape MSLP/steering rather than decorative random arcs.
export function getSurfaceFrontAnalysis(cyclone, pressureSystems) {
    const result = [];
    const background = pressureSystems?.upper?.find(
        cell => cell.role === 'height-background'
    );
    const resolvedLows = background?.synoptic?.frontalLows || [];
    const hasTrackedExt = Boolean(cyclone?.isExtratropical
        && Number.isFinite(cyclone.lon) && Number.isFinite(cyclone.lat));
    // A completing ET often sits directly on the resolved frontal wave that
    // triggered its conversion. It is one coupled cyclone, not two surface
    // lows. Merge the closest background centre into the tracked EXT so the
    // chart cannot print a shallow environmental L beside the deeper storm L.
    const couplingRadiusKm = hasTrackedExt
        ? clamp((cyclone.circulationSize || 300) * 1.6, 450, 1000) : 0;
    let coupledLow = null;
    let coupledDistance = Infinity;
    if (hasTrackedExt) {
        for (const low of resolvedLows) {
            if (frontalLifecycleEnvelope(low) < .10) continue;
            const distance = calculateDistance(cyclone.lat, cyclone.lon, low.lat, low.lon);
            if (distance < couplingRadiusKm && distance < coupledDistance) {
                coupledLow = low;
                coupledDistance = distance;
            }
        }
    }

    const candidates = [];
    for (const [index, low] of resolvedLows.entries()) {
        const envelope = frontalLifecycleEnvelope(low);
        if (envelope < .10 || low === coupledLow) continue;
        const closure = getFrontalLowSurfaceClosure(low, pressureSystems);
        const development = clamp(low.development || 0, 0, 1);
        candidates.push({
            ...low,
            lon: closure.centerLon,
            lat: closure.centerLat,
            ownerType: 'synoptic',
            ownerId: `frontal-${index}`,
            centerPressure: closure.centerPressure,
            closureDepthHpa: closure.closureDepthHpa,
            envelope,
            development,
            score: Math.max(0, closure.closureDepthHpa) + 4 * development + 2 * envelope,
            // With 2-hPa chart contours, require enough depth to enclose at
            // least one contour plus a small interpolation margin.
            showCenterLabel: closure.closureDepthHpa >= 2.25
        });
    }

    // These generated geometries represent fronts attached to a resolved
    // cyclone centre. An open wave without a chart-scale closed isobar must
    // not appear as a complete, centreless frontal cyclone.
    const closedCandidates = candidates.filter(candidate => candidate.showCenterLabel);

    // Several analytic waves can contribute to one composed MSLP minimum.
    // Keep one dominant front family when their surface footprints overlap;
    // otherwise one physical cyclone is drawn as two or three independent lows.
    const selectedCandidates = [];
    for (const candidate of closedCandidates.sort((a, b) => b.score - a.score)) {
        const overlaps = selectedCandidates.some(selected => {
            const mergeRadius = .72
                * (frontalLowFootprintKm(candidate) + frontalLowFootprintKm(selected));
            return calculateDistance(candidate.lat, candidate.lon, selected.lat, selected.lon)
                < mergeRadius;
        });
        if (!overlaps) selectedCandidates.push(candidate);
    }

    const hasWarmCoreCyclone = Boolean(cyclone && !hasTrackedExt
        && Number.isFinite(cyclone.lon) && Number.isFinite(cyclone.lat));
    const interactionRadiusKm = hasWarmCoreCyclone
        ? clamp((cyclone.circulationSize || 300) * 1.6, 450, 1000) : 0;
    const nearbyCandidates = hasWarmCoreCyclone
        ? selectedCandidates.filter(candidate => calculateDistance(
            cyclone.lat, cyclone.lon, candidate.lat, candidate.lon
        ) < interactionRadiusKm)
        : [];
    const dominantNearby = nearbyCandidates[0] || null;

    for (const candidate of selectedCandidates) {
        if (nearbyCandidates.includes(candidate) && candidate !== dominantNearby) continue;
        appendCycloneFronts(result, {
            ...candidate,
            // Until ET completes, the TC remains the sole labelled centre in
            // its interaction zone. The environmental front may approach but
            // must not create extra L labels inside the warm-core circulation.
            showCenterLabel: candidate.showCenterLabel
                && !(hasWarmCoreCyclone && candidate === dominantNearby)
        }, candidate.envelope, candidate.development, candidate.phase || 'incipient');
    }

    // A mature continental cold high carries a distinct cold-surge front on
    // the leading edge of its pressure/cold-air wedge. Suppress it when a
    // resolved cyclone already owns the same frontal segment.
    for (const [index, surge] of (pressureSystems?.lower || []).entries()) {
        const surgeFront = buildColdSurgeFront(surge, `cold-surge-${index}`);
        if (!surgeFront) continue;
        const overlapsCycloneFront = result.some(front =>
            front.type === 'cold' && frontsOverlap(front, surgeFront));
        const cycloneExclusionRadiusKm = cycloneFrontExclusionRadiusKm(cyclone);
        const intrudesCyclone = Boolean(cyclone && surgeFront.points.some(point =>
            calculateDistance(cyclone.lat, cyclone.lon, point[1], point[0])
                < cycloneExclusionRadiusKm));
        const overlapsTrackedExt = hasTrackedExt && intrudesCyclone;
        if (!overlapsCycloneFront && !overlapsTrackedExt) result.push(surgeFront);
    }

    if (hasWarmCoreCyclone && result.length) {
        const exclusionRadiusKm = cycloneFrontExclusionRadiusKm(cyclone);
        const trimmed = result
            .map(front => trimFrontOutsideCyclone(front, cyclone, exclusionRadiusKm))
            .filter(Boolean);
        result.splice(0, result.length, ...trimmed);
    }

    if (hasTrackedExt) {
        const frontAge = Math.max(0, Number.isFinite(cyclone.extratropicalAgeHours)
            ? cyclone.extratropicalAgeHours : cyclone.hoursSinceExtratropical || 0);
        const trackedDevelopment = clamp(
            .25 + .55 * smoothstep(frontAge / 36)
                + (cyclone.extratropicalStage === 'developing' ? .10 : 0),
            .25,
            1
        );
        // The parent frontal wave may strengthen a new EXT, but cannot donate
        // its mature/occluded age. A converted TC starts a new frontal clock.
        const development = clamp(
            trackedDevelopment
                + (coupledLow ? .15 * clamp(coupledLow.development || 0, 0, 1) : 0),
            .25,
            1
        );
        const occlusion = smoothstep((frontAge - 18) / 30);
        const phase = cyclone.extratropicalStage === 'decaying' && frontAge >= 18
            ? 'decaying' : occlusion > .55 ? 'cutoff' : 'developing';
        const strength = clamp(
            .42 + .38 * development + .20 * smoothstep((cyclone.intensity - 24) / 50)
                + (coupledLow ? .12 * frontalLifecycleEnvelope(coupledLow) : 0),
            0,
            1
        );
        let frontOrientationU = null;
        let frontOrientationV = null;
        if (background && ensureModernAtmosphericState(background)) {
            const ambient = gradientWind(
                cyclone.lon,
                cyclone.lat,
                (lon, lat) => getGeopotentialHeight500(lon, lat, pressureSystems, 500),
                GRAVITY
            );
            if (Number.isFinite(ambient.u) && Number.isFinite(ambient.v)
                && Math.hypot(ambient.u, ambient.v) >= 1) {
                frontOrientationU = ambient.u;
                // Retain a little of the cyclone's poleward/equatorward motion
                // without allowing a retrograde zonal track to flip the front.
                const cycloneV = Number.isFinite(cyclone.steeringV)
                    ? cyclone.steeringV : Number.isFinite(cyclone.driftV) ? cyclone.driftV : 0;
                frontOrientationV = .75 * ambient.v + .25 * cycloneV;
            }
        }
        appendCycloneFronts(result, {
            ...cyclone,
            ownerType: 'tracked-ext',
            ownerId: 'tracked-ext',
            frontOrientationU,
            frontOrientationV,
            absorbedSynopticLow: Boolean(coupledLow)
        }, strength, development, phase, { occlusion });
    }
    return result;
}

function frontalBaroclinicSupport(low, background) {
    const local = waveFieldComponents(low.lon, low.lat, background);
    const latitude = Math.abs(low.lat);
    const jetDistance = Math.abs(latitude - Math.abs(local.jetLatitude));
    const jetEnvelope = Math.exp(-.5 * (jetDistance / 8) ** 2);
    const shortWaveSupport = .55 + .45 * smoothstep((Math.abs(local.shortWave) - 6) / 22);
    return clamp(jetEnvelope * shortWaveSupport, 0, 1);
}

function frontalColdSurgeInteraction(low, systems, summer) {
    if (low.lat <= 0 || summer > .55) {
        return { upstream: 0, blocking: 0 };
    }
    let upstream = 0;
    let blocking = 0;
    for (const surge of systems?.lower || []) {
        if (!surge.isColdSurge || !Number.isFinite(surge.x) || !Number.isFinite(surge.y)) continue;
        const downstreamDistance = normalizeLongitude(low.lon - surge.x);
        const crossFront = Math.exp(-.5 * ((low.lat - surge.y) / 10) ** 2);
        const strength = clamp((surge.strength || 0) / 24, 0, 1);
        // A cold high arriving upstream initially sharpens the baroclinic
        // zone. Once its wedge reaches the low, the same ridge turns the
        // trough more meridionally and cuts off development.
        const developmentOverlap = Math.exp(-.5 * ((downstreamDistance - 34) / 24) ** 2);
        const blockingOverlap = Math.exp(-.5 * ((downstreamDistance - 9) / 15) ** 2);
        upstream = Math.max(upstream, crossFront * strength * developmentOverlap);
        blocking = Math.max(blocking, crossFront * strength * blockingOverlap);
    }
    return { upstream, blocking };
}

function transientFrontalLowHeight(lon, lat, background, level) {
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.frontalLows)) return 0;
    const radians = Math.PI / 180;
    let height = 0;
    for (const low of state.frontalLows) {
        const envelope = frontalLifecycleEnvelope(low);
        if (envelope <= 0) continue;
        // A frontal cyclone is cyclonic through the middle troposphere and
        // usually tilts downstream with height. Its 200-hPa signature is
        // weaker than the 500-hPa trough, unlike a mature tropical warm core.
        const vertical = level === 850 ? .50 : level === 200 ? .68 : 1;
        const centerLon = normalizeLongitude(
            low.lon + (level === 200 ? low.tilt : 0)
        );
        const dx = normalizeLongitude(lon - centerLon)
            * Math.cos(low.lat * radians);
        const dy = lat - low.lat;
        const hemisphere = low.lat < 0 ? -1 : 1;
        // Frontal troughs follow the sloping baroclinic wave, rather than an
        // axis-aligned lon/lat oval.  A weak quadratic bend prevents a broad
        // trough from acquiring a flat base and nearly vertical sidewalls
        // when it is superposed on the zonal-mean height gradient.
        const orientation = hemisphere * (low.transitionPattern === 'northwest' ? 30 : 16)
            * radians + .25 * (low.baseTilt || 0) * radians;
        const along = dx * Math.cos(orientation) + dy * Math.sin(orientation);
        const across = -dx * Math.sin(orientation) + dy * Math.cos(orientation)
            - hemisphere * .018 * along * along / Math.max(5, low.radiusLon);
        const gaussian = Math.exp(-.5 * (
            (along / (low.radiusLon * 1.22)) ** 2
            + (across / (low.radiusLat * .88)) ** 2
        ));
        height -= low.amplitude * vertical * envelope * gaussian;
        // A mobile baroclinic wave is a trough-ridge couplet, not an isolated
        // circular negative Gaussian. The downstream ridge supplies the
        // resolved southerly flow between trough and ridge that carries a
        // northwest-pattern ET cyclone poleward; northeast-pattern cases keep
        // a weaker ridge and can remain in predominantly zonal flow.
        const ridgeCenterLon = normalizeLongitude(low.lon + 18);
        const ridgeCenterLat = low.lat + (low.lat < 0 ? -1 : 1) * 4;
        const ridgeDx = normalizeLongitude(lon - ridgeCenterLon)
            * Math.cos(ridgeCenterLat * radians);
        const ridgeDy = lat - ridgeCenterLat;
        const ridgeAlong = ridgeDx * Math.cos(orientation)
            + ridgeDy * Math.sin(orientation);
        const ridgeAcross = -ridgeDx * Math.sin(orientation)
            + ridgeDy * Math.cos(orientation);
        const ridge = Math.exp(-.5 * (
            (ridgeAlong / (low.radiusLon * 1.9)) ** 2
            + (ridgeAcross / (low.radiusLat * 1.35)) ** 2
        ));
        const ridgeRatio = low.transitionPattern === 'northwest' ? .48 : .20;
        height += low.amplitude * vertical * envelope * ridgeRatio * ridge;
    }
    return 60 * Math.tanh(height / 60);
}


const FRONTAL_SURFACE_PRESSURE_SCALE = 1.0;
const FRONTAL_SURFACE_RADIUS_SCALE = .60;

function combineFrontalPressureAnomalies(anomalies) {
    // A sixth-order norm behaves like a smooth maximum: one dominant cyclone
    // keeps its depth, while equal overlapping systems blend continuously
    // without either linear over-deepening or winner-switch seams.
    const power = 6;
    const magnitudePower = anomalies.reduce((sum, anomaly) => {
        const magnitude = Math.max(0, -anomaly);
        return sum + magnitude ** power;
    }, 0);
    return magnitudePower > 0 ? -(magnitudePower ** (1 / power)) : 0;
}

function transientSurfacePressureAnomaly(lon, lat, background) {
    const state = background?.synoptic;
    if (!state) return 0;
    const radians = Math.PI / 180;
    let pressure = 0;
    const gaussianAt = (feature, radiusScale = 1) => {
        const dx = normalizeLongitude(lon - feature.lon)
            * Math.cos(feature.lat * radians);
        const dy = lat - feature.lat;
        return Math.exp(-.5 * (
            (dx / ((feature.radiusLon || feature.radius || 8) * radiusScale)) ** 2
            + (dy / ((feature.radiusLat || feature.radius || 6) * radiusScale)) ** 2
        ));
    };
    const frontalAnomalies = [];
    for (const low of state.frontalLows || []) {
        const envelope = frontalLifecycleEnvelope(low);
        // A precursor should remain an open frontal wave, while a developed
        // baroclinic cyclone needs enough surface mass response to close
        // several isobars.  The old fixed 0.075 projection produced visible
        // fronts around 1006-1007 hPa centres that were not closed at all.
        const development = clamp(low.development || 0, 0, 1);
        const surfaceProjection = .10
            + .45 * smoothstep((development - .15) / .65);
        frontalAnomalies.push(-FRONTAL_SURFACE_PRESSURE_SCALE
            * surfaceProjection * (low.surfaceAmplitude || low.amplitude) * envelope
            * gaussianAt(low, FRONTAL_SURFACE_RADIUS_SCALE));
    }
    pressure += combineFrontalPressureAnomalies(frontalAnomalies);
    pressure += .06 * weakTropicalWaveHeight(lon,lat,background,850);
    for (const disturbance of background.singleStormEnvironment ? [] : state.tropicalDisturbances || []) {
        const envelope = Math.sin(Math.PI * clamp(
            disturbance.age / Math.max(1, disturbance.life), 0, 1
        )) ** 2;
        // Ridge pulses have negative amplitude and therefore add pressure.
        pressure -= .065 * disturbance.amplitude * envelope * gaussianAt(disturbance);
    }
    for (const low of state.coldLows || []) {
        const envelope = Math.sin(Math.PI * clamp(low.age / Math.max(1, low.life), 0, 1)) ** 2;
        pressure -= .035 * low.amplitude * envelope * gaussianAt(low);
    }
    return clamp(pressure, -36, 4);
}

// Compile the transient surface-pressure closure for one immutable field
// snapshot. Lifecycle envelopes, feature radii and latitude cosines are
// invariant during a contour search; evaluating them once avoids repeated
// object fallback checks while keeping the same anomaly ordering and clamp.
function createTransientSurfacePressureAnomalySampler(background) {
    const state = background?.synoptic;
    if (!state) return null;
    const radians = Math.PI / 180;
    const makeTerm = (feature, radiusScale = 1) => ({
        lon: feature.lon,
        lat: feature.lat,
        cosLat: Math.cos(feature.lat * radians),
        radiusLon: (feature.radiusLon || feature.radius || 8) * radiusScale,
        radiusLat: (feature.radiusLat || feature.radius || 6) * radiusScale
    });
    const gaussianAt = (lon, lat, term) => {
        const dx = normalizeLongitude(lon - term.lon) * term.cosLat;
        const dy = lat - term.lat;
        return Math.exp(-.5 * (
            (dx / term.radiusLon) ** 2 + (dy / term.radiusLat) ** 2
        ));
    };
    const frontalTerms = (state.frontalLows || []).map(low => ({
        ...makeTerm(low, FRONTAL_SURFACE_RADIUS_SCALE),
        anomaly: -FRONTAL_SURFACE_PRESSURE_SCALE
            * (.10 + .45 * smoothstep(
                (clamp(low.development || 0, 0, 1) - .15) / .65
            ))
            * (low.surfaceAmplitude || low.amplitude)
            * frontalLifecycleEnvelope(low)
    }));
    const disturbanceTerms = (background.singleStormEnvironment
        ? [] : state.tropicalDisturbances || []).map(disturbance => ({
        ...makeTerm(disturbance),
        anomaly: -.065 * disturbance.amplitude * Math.sin(
            Math.PI * clamp(
                disturbance.age / Math.max(1, disturbance.life), 0, 1
            )
        ) ** 2
    }));
    const coldTerms = (state.coldLows || []).map(low => ({
        ...makeTerm(low),
        anomaly: -.035 * low.amplitude * Math.sin(
            Math.PI * clamp(
                low.age / Math.max(1, low.life), 0, 1
            )
        ) ** 2
    }));
    return (lon, lat) => {
        const frontalAnomalies = new Array(frontalTerms.length);
        for (let index = 0; index < frontalTerms.length; index++) {
            const term = frontalTerms[index];
            frontalAnomalies[index] = term.anomaly * gaussianAt(lon, lat, term);
        }
        let pressure = combineFrontalPressureAnomalies(frontalAnomalies);
        pressure += .06 * weakTropicalWaveHeight(lon, lat, background, 850);
        for (const term of disturbanceTerms) {
            pressure += term.anomaly * gaussianAt(lon, lat, term);
        }
        for (const term of coldTerms) {
            pressure += term.anomaly * gaussianAt(lon, lat, term);
        }
        return clamp(pressure, -36, 4);
    };
}

function advanceSynopticField(systems,background) {
    const state=background.synoptic;
    const rho=Math.exp(-MODEL_STEP_HOURS/18);
    advanceWeakTropicalWaves(background);
    for(const mode of state.modes) {
        mode.amplitude=clamp(rho*mode.amplitude+4.5*Math.sqrt(1-rho*rho)*synopticNormal(state),-9,9);
        mode.phaseX+=mode.phaseSpeed*MODEL_STEP_HOURS;
    }
    for (const mode of state.baroclinicModes || []) {
        const modeRho = Math.exp(-MODEL_STEP_HOURS / 36);
        mode.amplitude = clamp(
            modeRho * mode.amplitude
                + 8 * Math.sqrt(1 - modeRho * modeRho) * synopticNormal(state),
            -32,
            32
        );
        mode.phase += mode.phaseSpeed * MODEL_STEP_HOURS;
        mode.latitude += mode.hemisphere * .015 * Math.sin(
            background.elapsedHours / 60 + mode.phase
        );
    }
    for(const cell of systems.upper.filter(c=>c.synopticAnchor)) {
        const anchor=cell.synopticAnchor;
        const oldX=cell.x,oldY=cell.y;
        const latitudeVariability = Number.isFinite(cell.latitudeVariabilityScale)
            ? cell.latitudeVariabilityScale : 1;
        const retention=Math.exp(-MODEL_STEP_HOURS/48),innovation=Math.sqrt(1-retention*retention);
        anchor.dx=clamp(retention*anchor.dx+3*innovation*synopticNormal(state),-7,7);
        anchor.dy=clamp(
            retention * anchor.dy + 1.4 * latitudeVariability * innovation * synopticNormal(state),
            -3.5 * latitudeVariability,
            3.5 * latitudeVariability
        );
        anchor.amplitude=clamp(retention*anchor.amplitude+innovation*synopticNormal(state),-2,2);
        const retreatTarget = upperVortexRidgeRetreatForcing(cell, background);
        const retreatResponse = 1 - Math.exp(-MODEL_STEP_HOURS / RIDGE_RETREAT_RESPONSE_HOURS);
        cell.ridgeRetreat = clamp(
            (cell.ridgeRetreat || 0)
                + (retreatTarget - (cell.ridgeRetreat || 0)) * retreatResponse,
            0,
            1
        );
        const retreatShift = cell.role === 'ridge'
            ? RIDGE_RETREAT_MAX_SHIFT_DEG * cell.ridgeRetreat : 0;
        const targetX=anchor.x+(cell.velocityX||0)*background.elapsedHours/MODEL_STEP_HOURS
            +anchor.dx+retreatShift;
        cell.x=normalizeLongitude(cell.x+.22*normalizeLongitude(targetX-cell.x));
        cell.y+=.22*(anchor.y+anchor.dy-cell.y);
        const priorStrength=cell.strength;
        const retreatStrength = cell.role === 'ridge'
            ? 1 - RIDGE_RETREAT_MAX_WEAKENING * cell.ridgeRetreat : 1;
        cell.strength+=.15*(cell.baseStrength*(1+.18*anchor.amplitude)*retreatStrength-cell.strength);
        const lower=systems.lower?.find(c=>c.fieldId===cell.fieldId);
        if(lower){lower.x+=normalizeLongitude(cell.x-oldX);lower.y+=cell.y-oldY;
            lower.strength*=cell.strength/Math.max(.1,priorStrength);}
    }
    for(const low of state.coldLows) {
        const wind=gradientWind(low.lon,low.lat,(x,y)=>waveFieldComponents(x,y,background).height,9.80665);
        const u=.3*wind.u+low.driftU,v=.3*wind.v+low.driftV;
        low.lon=normalizeLongitude(low.lon+u*MODEL_STEP_HOURS*3600/(111320*Math.max(.3,Math.cos(low.lat*Math.PI/180))));
        const hemisphere=low.lat<0?-1:1;
        const circulation=backgroundMonthlyCirculation(background, hemisphere);
        const equatorwardEdge=Math.max(
            circulation.ridgeLatitude+4,
            circulation.jetLatitude-10
        );
        const polewardEdge=Math.min(62,circulation.jetLatitude+10);
        const advectedLatitude=Math.abs(
            low.lat+v*MODEL_STEP_HOURS*3600/111320
        );
        low.lat=hemisphere*clamp(advectedLatitude,equatorwardEdge,polewardEdge);
        low.age+=MODEL_STEP_HOURS;
    }
    const before=state.coldLows.length;
    state.coldLows=state.coldLows.filter(low=>low.age<low.life);
    state.expired+=before-state.coldLows.length;
    for (const disturbance of state.tropicalDisturbances || []) {
        const radians = Math.PI / 180;
        disturbance.lon = normalizeLongitude(
            disturbance.lon + disturbance.driftU * MODEL_STEP_HOURS * 3600
                / (111320 * Math.max(.3, Math.cos(disturbance.lat * radians)))
        );
        disturbance.lat = clamp(
            disturbance.lat + disturbance.driftV * MODEL_STEP_HOURS * 3600 / 111320,
            -35,
            35
        );
        disturbance.age += MODEL_STEP_HOURS;
    }
    const disturbanceBefore = (state.tropicalDisturbances || []).length;
    state.tropicalDisturbances = (state.tropicalDisturbances || [])
        .filter(disturbance => disturbance.age < disturbance.life);
    state.expired += disturbanceBefore - state.tropicalDisturbances.length;
    for (const low of state.frontalLows || []) {
        const hemisphere = low.lat < 0 ? -1 : 1;
        low.summer = monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        const interaction = frontalColdSurgeInteraction(low, systems, low.summer);
        const jetSupport = frontalBaroclinicSupport(low, background);
        const age = Math.max(0, low.age || 0);
        const growthHours = Math.max(18, low.growthHours || 42);
        const nominalEnvelope = nominalFrontalLifecycleEnvelope(low);
        const targetEnvelope = clamp(
            nominalEnvelope
                * (.72 + .34 * jetSupport + .18 * interaction.upstream)
                * (1 - .78 * interaction.blocking),
            0,
            1
        );
        const envelopeResponse = 1 - Math.exp(-MODEL_STEP_HOURS / 18);
        low.fieldEnvelope = clamp(
            (Number.isFinite(low.fieldEnvelope) ? low.fieldEnvelope : nominalEnvelope)
                + (targetEnvelope - (Number.isFinite(low.fieldEnvelope) ? low.fieldEnvelope : nominalEnvelope))
                    * envelopeResponse,
            0,
            1
        );
        const developmentTarget = clamp(
            .45 * jetSupport + .32 * interaction.upstream
                + .35 * nominalEnvelope - .68 * interaction.blocking,
            0,
            1
        );
        low.development = clamp(
            (Number.isFinite(low.development) ? low.development : nominalEnvelope)
                + (developmentTarget - (Number.isFinite(low.development) ? low.development : nominalEnvelope))
                    * (1 - Math.exp(-MODEL_STEP_HOURS / 24)),
            0,
            1
        );
        low.cutoff = clamp(
            (low.cutoff || 0)
                + (interaction.blocking - (low.cutoff || 0))
                    * (1 - Math.exp(-MODEL_STEP_HOURS / 12)),
            0,
            1
        );
        low.phase = low.cutoff > .52
            ? 'cutoff'
            : low.fieldEnvelope < .10 && age >= growthHours
                ? 'decaying'
                : low.fieldEnvelope < .10
                    ? 'precursor'
                : age < growthHours
                    ? 'incipient'
                    : 'developing';
        low.tilt = (low.baseTilt || 0) + (low.lat < 0 ? -1 : 1) * 8 * low.cutoff;
        low.driftU = (low.baseDriftU || low.driftU || 0) * (1 - .34 * low.cutoff);
        low.driftV = (low.baseDriftV || low.driftV || 0)
            + (low.lat < 0 ? -1 : 1) * .38 * low.cutoff;
        low.fadeHours = low.fieldEnvelope < .025 ? (low.fadeHours || 0) + MODEL_STEP_HOURS : 0;
        const wind = gradientWind(
            low.lon,
            low.lat,
            (x, y) => waveFieldComponents(x, y, background).height,
            9.80665
        );
        const u = .25 * wind.u + low.driftU;
        const v = .25 * wind.v + low.driftV;
        low.lon = normalizeLongitude(
            low.lon + u * MODEL_STEP_HOURS * 3600
                / (111320 * Math.max(.3, Math.cos(low.lat * Math.PI / 180)))
        );
        low.lat = clamp(
            low.lat + v * MODEL_STEP_HOURS * 3600 / 111320,
            -65,
            65
        );
        low.age += MODEL_STEP_HOURS;
    }
    const frontalBefore = (state.frontalLows || []).length;
    state.frontalLows = (state.frontalLows || [])
        .filter(low => !(low.age >= low.life
            && (low.fadeHours || 0) >= 12
            && frontalLifecycleEnvelope(low) < .025));
    state.expired += frontalBefore - state.frontalLows.length;
    for(const hemisphere of [1,-1]) {
        const summer=monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        const count=state.coldLows.filter(low=>Math.sign(low.lat)===hemisphere).length;
        if(state.coldLows.length<4&&count<2&&synopticRandom(state)<1-Math.exp(-MODEL_STEP_HOURS/(180-60*summer))){
            state.coldLows.push(createColdLow(state,background,hemisphere));state.births++;
        }
        const disturbanceCount = state.tropicalDisturbances
            .filter(disturbance => Math.sign(disturbance.lat) === hemisphere).length;
        const targetCount = summer > .55 ? 2 : 1;
        if (!background.singleStormEnvironment && disturbanceCount < targetCount
            && synopticRandom(state) < 1 - Math.exp(-MODEL_STEP_HOURS / (42 - 12 * summer))) {
            state.tropicalDisturbances.push(
                createTropicalDisturbance(state, background, hemisphere)
            );
            state.births++;
        }
        const frontalCount = state.frontalLows
            .filter(low => Math.sign(low.lat) === hemisphere).length;
        const activeFrontalCount = state.frontalLows
            .filter(low => Math.sign(low.lat) === hemisphere
                && low.age < low.life
                && low.phase !== 'decaying'
                && frontalLifecycleEnvelope(low) >= .06).length;
        // Calibrated against CNECT ERA5 1980-89 JJA passage frequency. Winter
        // remains more active than summer, while four staggered warm-season
        // systems prevent the basin from becoming synoptically empty.
        const frontalTarget = summer < .30 ? 5 : 4;
        // Start a weak precursor before the previous low is removed. This
        // keeps the jet corridor populated during decay and prevents the next
        // cyclone from popping into existence at the exact deletion step.
        if (activeFrontalCount < frontalTarget
            && frontalCount < frontalTarget + 1
            && synopticRandom(state) < 1 - Math.exp(-MODEL_STEP_HOURS / (54 - 15 * summer))) {
            state.frontalLows.push(createFrontalLow(state, background, hemisphere));
            state.births++;
        }
    }
}

function normalizedCellDistance(lon, lat, cell) {
    const radians = Math.PI / 180;
    const meanLatitude = (lat + cell.y) * .5;
    const dxKm = normalizeLongitude(lon - cell.x) * 111.32 * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - cell.y) * 111.32;
    const sxKm = Math.max(90, (cell.sigmaX || cell.baseSigmaX || 20) * 111.32
        * Math.max(.20, Math.cos(cell.y * radians)));
    const syKm = Math.max(90, (cell.sigmaY || 12) * 111.32);
    return Math.hypot(dxKm / sxKm, dyKm / syKm);
}

function coldSurgeFieldEnvelope(cell) {
    if (!cell?.isColdSurge) return 0;
    if (Number.isFinite(cell.fieldEnvelope)) return clamp(cell.fieldEnvelope, 0, 1);
    const peak = Math.max(1, cell.peakStrength || cell.baseStrength || 20);
    return clamp(Math.max(0, cell.strength || 0) / peak, 0, 1);
}

// A Siberian cold high is a continental air-mass source.  Once its centre
// has travelled east over the marginal seas, the shallow ridge should lose
// amplitude through marine mixing; the detached upper trough can outlive it,
// but the 850-hPa pressure gradient must not remain a continent-sized wall.
// Track this from the source longitude rather than from a TC position so the
// decay is an atmospheric property and does not alter cyclone attributes.
function coldSurgeMarineFactor(cell) {
    if (!cell?.isColdSurge) return 1;
    const sourceX = Number.isFinite(cell.sourceX) ? cell.sourceX : cell.x;
    const eastwardTravel = Math.max(0, normalizeLongitude(cell.x - sourceX));
    const marineTransition = smoothstep((eastwardTravel - 7) / 13);
    const residence = smoothstep(((cell.ageHours || 0) - 48) / 96);
    return clamp(
        1 - marineTransition * (.50 + .20 * residence),
        .35,
        1
    );
}

function coldSurgeWedgeGaussian(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const hemisphere = cell.y < 0 ? -1 : 1;
    // The cold air does not remain a circular blob over Mongolia. Its
    // equatorward/eastward wedge reaches the downstream coast and ocean,
    // where it modifies the low-level ridge, SST and TC structure.
    const centerLon = normalizeLongitude(cell.x + 9);
    // The equatorward plume digs farther south as the continental high
    // matures; keeping it fixed near the source latitude leaves the SCS on
    // its weak-gradient fringe instead of in the cold-surge flow.
    const centerLat = cell.y - hemisphere * (7 + 4 * coldSurgeFieldEnvelope(cell));
    const radians = Math.PI / 180;
    const meanLatitude = (lat + centerLat) * .5;
    const dxKm = normalizeLongitude(lon - centerLon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - centerLat) * 111.32;
    // The low-level ridge plume must carry equatorward flow on its coastal
    // flank.  The former southeast-tilted ellipse put the SCS on the wrong
    // pressure-gradient side and often produced a northward low-level wind.
    // Mirror the ridge/trough tilt by hemisphere, with modest event-to-event
    // spread supplied when the surge is created.
    const tiltDegrees = Number.isFinite(cell.wedgeTiltDeg)
        ? cell.wedgeTiltDeg
        : 18;
    const tilt = hemisphere * tiltDegrees * radians;
    const alongKm = dxKm * Math.cos(tilt) + dyKm * Math.sin(tilt);
    const crossKm = -dxKm * Math.sin(tilt) + dyKm * Math.cos(tilt);
    // The 850-hPa cold-air tongue is broad across the front.  A narrow
    // ellipse creates a very steep height gradient at its southern edge and
    // can produce an impossible 50--60 kt reversal far from the front.
    const distance = Math.hypot(alongKm / 2100, crossKm / 1250);
    const cutoff = 1 - smoothstep((distance - 2.6) / 1.0);
    return cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
}

// A mature cold surge commonly has a weak frontal trough/low on the
// equatorward edge of the continental ridge.  It is deliberately broad and
// shallow: its purpose is to close the pressure-gradient saddle over the
// coastal seas, not to create a second TC-like vortex.
function coldSurgeFrontalLowGaussian(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const envelope = coldSurgeFieldEnvelope(cell);
    const frontalEnvelope = smoothstep((envelope - .08) / .30);
    if (frontalEnvelope <= 0) return 0;
    const hemisphere = cell.y < 0 ? -1 : 1;
    const centerLon = normalizeLongitude(cell.x + 12);
    const centerLat = cell.y - hemisphere * (17 + 3 * envelope);
    const radians = Math.PI / 180;
    const meanLatitude = (lat + centerLat) * .5;
    const dxKm = normalizeLongitude(lon - centerLon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - centerLat) * 111.32;
    // A cold-surge frontal trough is elongated along the subtropical jet and
    // narrow across it.  Keep the along-front tail finite: an infinitely
    // generous tail lets a storm outside the cold-air/front interaction zone
    // feel the same meridional pressure gradient as a directly affected TC.
    const distance = Math.hypot(dxKm / 3600, dyKm / 700);
    // The taper begins before the far-field Gaussian tail becomes dynamically
    // important.  It is C1-smooth, so the trough still grows/decays normally
    // while its remote ends no longer bend unrelated tracks southward.
    const cutoff = 1 - smoothstep((distance - 1.72) / .70);
    // The frontal low is coupled to the same cold-air reach as the surface
    // ridge.  Without this second, local gate, its free-tropospheric-looking
    // tail can steer a TC that is still outside the cold-surge corridor,
    // which is precisely the failure mode this feature is meant to avoid.
    const broadSurface = {
        ...cell,
        sigmaX: Math.max(24, (cell.sigmaX || cell.baseSigmaX || 16) * 1.65),
        sigmaY: Math.max(14, (cell.sigmaY || cell.baseSigmaY || 11) * 1.35)
    };
    const directCore = Math.exp(-0.5 * normalizedCellDistance(
        lon, lat, broadSurface
    ) ** 2);
    const directWedge = coldSurgeWedgeGaussian(lon, lat, cell);
    const directCoupling = clamp(
        Math.max(.55 * directCore, directWedge),
        0,
        1
    );
    const couplingGate = smoothstep((directCoupling - .035) / .10);
    return cutoff <= 0
        ? 0
        : Math.exp(-0.5 * distance * distance)
            * cutoff * frontalEnvelope * couplingGate;
}

// The free-tropospheric response of a continental cold surge is not locked
// above the surface high. As the cold dome reaches the coast and begins to
// decay, its upper PV anomaly can amplify downstream and cut off on the
// equatorward side. Keep that displacement as state derived from the same
// cold-surge lifecycle, rather than as a TC-specific steering correction.
function coldSurgeUpperTroughState(cell) {
    if (!cell?.isColdSurge) return null;
    const age = Math.max(0, Number.isFinite(cell.ageHours) ? cell.ageHours : 0);
    const growthHours = Math.max(24, cell.growthHours || 48);
    const decayStartHours = Math.max(
        growthHours + 24,
        cell.decayStartHours || Math.max(growthHours + 24, (cell.lifeHours || 384) - (cell.decayHours || 96))
    );
    const decayHours = Math.max(48, cell.decayHours || 96);
    const upperGrowth = smoothstep(age / Math.max(24, growthHours * .82));
    // The trough outlives the surface pressure maximum. This is the
    // decaying/cut-off stage in which a Central-Asian trough can still dig
    // southward after the cold high has already weakened at the ground.
    const upperDecay = 1 - smoothstep(
        (age - (decayStartHours + 18)) / (decayHours + 54)
    );
    const envelope = clamp(upperGrowth * upperDecay, 0, 1);
    const denominator = Math.max(72, decayStartHours - growthHours * .25);
    const progress = smoothstep((age - growthHours * .35) / denominator);
    const digging = clamp(
        Number.isFinite(cell.upperTroughDigging) ? cell.upperTroughDigging : .72,
        .35,
        1.15
    );
    const hemisphere = cell.y < 0 ? -1 : 1;
    const phase = Number.isFinite(cell.upperTroughPhase) ? cell.upperTroughPhase : 0;
    const meander = Math.sin(phase + age / 54);
    const longitude = normalizeLongitude(
        // Downstream displacement is intentionally large enough for the
        // mature/decaying trough core to reach the ocean east of Japan. A
        // trough core that remains over the source high cannot steer a TC on
        // the high's downstream/equatorward side.
        // Keep the upper trough downstream of the continental high, but not
        // so far east that the SCS sits outside its southern/western flank.
        // The old displacement detached the trough from the surface surge
        // and left the coastal low-level turn without a coherent mid-level
        // counterpart.
        cell.x + 7 + (4 + 4 * digging) * progress + 2.5 * meander
    );
    const latitude = cell.y - hemisphere * (
        2.5 + (8 + 18 * digging) * progress
            + 1.8 * Math.cos(phase + age / 72)
    );
    return {
        lon: longitude,
        lat: clamp(latitude, -65, 65),
        envelope,
        progress,
        digging,
        // The East-Asian trough is a tilted baroclinic feature, not an
        // axis-aligned oval.  Its long axis slopes southwest to northeast
        // in the NH (reversed in the SH), and broadens as the cold dome
        // reaches the coast and begins to cut off.
        tiltRad: hemisphere * (12 + 10 * progress) * Math.PI / 180,
        sigmaAlongKm: 1650 + 650 * progress,
        sigmaCrossKm: 720 + 180 * progress,
        // A weakening surge leaves a narrower, more cut-off trough core.
        coreScale: .72 + .48 * progress
    };
}

function coldSurgeUpperTroughGaussian(lon, lat, trough) {
    if (!trough) return 0;
    const radians = Math.PI / 180;
    const meanLatitude = (lat + trough.lat) * .5;
    const dxKm = normalizeLongitude(lon - trough.lon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - trough.lat) * 111.32;
    const tilt = Number.isFinite(trough.tiltRad) ? trough.tiltRad : 0;
    const alongKm = dxKm * Math.cos(tilt) + dyKm * Math.sin(tilt);
    const crossKm = -dxKm * Math.sin(tilt) + dyKm * Math.cos(tilt);
    const distance = Math.hypot(
        alongKm / Math.max(400, trough.sigmaAlongKm || 1800),
        crossKm / Math.max(250, trough.sigmaCrossKm || 800)
    );
    const cutoff = 1 - smoothstep((distance - 2.1) / 1.25);
    return cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
}

// Read-only station diagnostic. Reuse the actual cold-tongue footprint and
// marine modification of the pressure field; do not infer air temperature
// from the station's absolute sea-level pressure or its basin/city name.
export function getColdSurgeAirMassesAt(lon, lat, pressureSystems) {
    return (pressureSystems?.lower || []).filter(cell => cell?.isColdSurge
        && Number.isFinite(cell.x) && Number.isFinite(cell.y)).map(cell => ({
        sourceLon: Number.isFinite(cell.sourceX) ? cell.sourceX : cell.x,
        sourceLat: cell.y,
        coverage: coldSurgeWedgeGaussian(lon, lat, cell) * coldSurgeFieldEnvelope(cell),
        marineRetention: coldSurgeMarineFactor(cell),
        front: buildColdSurgeFront(cell, 'temperature-cold-surge')
    })).filter(mass => mass.coverage > 0 && mass.front);
}

export function getColdSurgeImpact(cyclone, pressureSystems) {
    const result = { influence: 0, sstCooling: 0, shearBoost: 0 };
    if (!cyclone || !Array.isArray(pressureSystems?.lower)) return result;
    for (const surge of pressureSystems.lower) {
        if (!surge?.isColdSurge) continue;
        const envelope = coldSurgeFieldEnvelope(surge);
        if (envelope <= 0) continue;
        const broadSurface = {
            ...surge,
            sigmaX: Math.max(24, (surge.sigmaX || surge.baseSigmaX || 16) * 1.65),
            sigmaY: Math.max(14, (surge.sigmaY || surge.baseSigmaY || 11) * 1.35)
        };
        const core = Math.exp(-0.5 * normalizedCellDistance(
            cyclone.lon, cyclone.lat, broadSurface
        ) ** 2);
        const wedge = coldSurgeWedgeGaussian(cyclone.lon, cyclone.lat, surge);
        const exposure = clamp(Math.max(.55 * core, wedge) * envelope, 0, 1);
        const sizeFactor = clamp(.85 + .15 * ((cyclone.circulationSize || 300) / 350), .75, 1.10);
        result.influence = Math.max(result.influence, exposure);
        // A cold surge cools the ocean gradually; this is an air-sea
        // response, not an arbitrary one-step SST replacement.
        result.sstCooling = Math.max(result.sstCooling, 1.8 * exposure * sizeFactor);
        result.shearBoost = 0;
    }
    return result;
}

function modernCellHeightAnomaly(lon, lat, cell, level) {
    if (!cell || cell.role === 'height-background' || cell.role === 'wave-handle') return 0;
    const distance = normalizedCellDistance(lon, lat, cell);
    // A synoptic anomaly is not allowed to exert a mathematically infinite
    // Gaussian tail across the hemisphere. The cosine taper is C1-smooth and
    // leaves the core unchanged through 2.25 normalized radii.
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    if (cutoff <= 0 && !cell.ridgeHeightAnomalyM && !cell.ridgeWeatherComponents) return 0;
    const gaussian = Math.exp(-.5 * distance * distance) * cutoff;
    // The South Asian High is much more vertically top-heavy than an ordinary
    // 500-hPa ridge. Keep the calibrated summer 200-hPa core strong, while
    // using a smaller 500-hPa projection so the mid-level field does not
    // dominate low-latitude TC steering.
    const roleScale = cell.role === 'south-asian-high'
        && level === 200
        && Number.isFinite(cell.level200AnomalyScale)
        ? cell.level200AnomalyScale
        : Number.isFinite(cell.anomalyScale)
            ? cell.anomalyScale
            : cell.role === 'ridge' && !cell.isManual ? .35 : 1;
    const levelScale = cell.role === 'south-asian-high'
        ? (level === 200 ? 1.35 : level === 500 ? SOUTH_ASIAN_HIGH_500_SCALE : .15)
        : level === 850 ? .72 : level === 200 ? 1.08 : 1;
    const verticalFactor = cell.role === 'monsoon'
        ? (level === 850 ? (cell.strength < 0 ? .65 : -.65) : level === 200 ? .40 : .35)
        : 1;
    // One evolving ridge mass anomaly supplies the 850/500/200-hPa column.
    // Similar lower/midlevel amplitudes strengthen steering without making
    // an artificial upper-only shear wall. Metres here are model scenario
    // amplitudes, not a fitted observed wind or an absolute contour offset.
    const weatherDistance = cell.ridgeWeatherGeometry
        ? normalizedCellDistance(lon,lat,cell.ridgeWeatherGeometry) : distance;
    const weatherGaussian = Math.exp(-.5 * weatherDistance * weatherDistance)
        * (1 - smoothstep((weatherDistance - 2.25) / 1.25));
    const ridgeWeather = (cell.ridgeWeatherComponents
        ? cell.ridgeWeatherComponents.reduce((sum, component) => sum + ridgeComponentHeight(lon,lat,component),0)
        : (cell.ridgeHeightAnomalyM || 0) * weatherGaussian)
        * (level === 850 ? .85 : level === 200 ? .70 : 1);
    const fieldScale = Number.isFinite(cell.ridgeFieldScale)
        ? clamp(cell.ridgeFieldScale, 0, 1.5)
        : 1;
    return fieldScale * (12 * cell.strength * roleScale * levelScale
        * verticalFactor * gaussian + ridgeWeather);
}

// Compile the weatherized ridge geometry once for an immutable field query.
// The evaluator below deliberately keeps the same operation order as
// modernCellHeightAnomaly; only object lookups and repeated fallback logic are
// moved out of the pressure-node loop.
function prepareModernCellHeightTerm(cell, level) {
    if (!cell) return null;
    const roleScale = cell.role === 'south-asian-high'
        && level === 200
        && Number.isFinite(cell.level200AnomalyScale)
        ? cell.level200AnomalyScale
        : Number.isFinite(cell.anomalyScale)
            ? cell.anomalyScale
            : cell.role === 'ridge' && !cell.isManual ? .35 : 1;
    const levelScale = cell.role === 'south-asian-high'
        ? (level === 200 ? 1.35 : level === 500 ? SOUTH_ASIAN_HIGH_500_SCALE : .15)
        : level === 850 ? .72 : level === 200 ? 1.08 : 1;
    const verticalFactor = cell.role === 'monsoon'
        ? (level === 850 ? (cell.strength < 0 ? .65 : -.65) : level === 200 ? .40 : .35)
        : 1;
    const fieldScale = Number.isFinite(cell.ridgeFieldScale)
        ? clamp(cell.ridgeFieldScale, 0, 1.5) : 1;
    const sigmaX = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20);
    const sigmaY = Math.max(1, cell.sigmaY || 12);
    const normalizedGeometry = {
        x: cell.x,
        y: cell.y,
        sxKm: Math.max(90, sigmaX * 111.32 * Math.max(.20, Math.cos(cell.y * Math.PI / 180))),
        syKm: Math.max(90, sigmaY * 111.32)
    };
    const weatherGeometry = cell.ridgeWeatherGeometry
        ? {
            x: cell.ridgeWeatherGeometry.x,
            y: cell.ridgeWeatherGeometry.y,
            sxKm: Math.max(90, (cell.ridgeWeatherGeometry.sigmaX || cell.ridgeWeatherGeometry.baseSigmaX || 20)
                * 111.32 * Math.max(.20, Math.cos(cell.ridgeWeatherGeometry.y * Math.PI / 180))),
            syKm: Math.max(90, (cell.ridgeWeatherGeometry.sigmaY || 12) * 111.32)
        }
        : null;
    const weatherComponents = cell.ridgeWeatherComponents
        ? cell.ridgeWeatherComponents.map(component => ({
            x: component.x,
            y: component.y,
            tilt: component.tilt,
            sigmaX: component.sigmaX,
            sigmaY: component.sigmaY,
            heightM: component.heightM
        }))
        : null;
    return {
        ...normalizedGeometry,
        coefficient: 12 * cell.strength * roleScale * levelScale * verticalFactor,
        fieldScale,
        ridgeWeatherScale: level === 850 ? .85 : level === 200 ? .70 : 1,
        ridgeHeightAnomalyM: cell.ridgeHeightAnomalyM || 0,
        weatherGeometry,
        weatherComponents,
        hasWeatherComponents: Boolean(cell.ridgeWeatherComponents)
    };
}

function evaluatePreparedModernCellHeightTerm(lon, lat, term) {
    if (!term) return 0;
    const meanLatitude = (lat + term.y) * .5 * Math.PI / 180;
    const dxKm = normalizeLongitude(lon - term.x) * 111.32
        * Math.max(.20, Math.cos(meanLatitude));
    const dyKm = (lat - term.y) * 111.32;
    const distance = Math.hypot(dxKm / term.sxKm, dyKm / term.syKm);
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    if (cutoff <= 0 && !term.ridgeHeightAnomalyM && !term.hasWeatherComponents) return 0;
    const gaussian = Math.exp(-.5 * distance * distance) * cutoff;
    const weatherDistance = term.weatherGeometry
        ? (() => {
            const weatherMeanLatitude = (lat + term.weatherGeometry.y) * .5 * Math.PI / 180;
            const weatherDxKm = normalizeLongitude(lon - term.weatherGeometry.x) * 111.32
                * Math.max(.20, Math.cos(weatherMeanLatitude));
            const weatherDyKm = (lat - term.weatherGeometry.y) * 111.32;
            return Math.hypot(
                weatherDxKm / term.weatherGeometry.sxKm,
                weatherDyKm / term.weatherGeometry.syKm
            );
        })()
        : distance;
    const weatherCutoff = 1 - smoothstep((weatherDistance - 2.25) / 1.25);
    const weatherGaussian = Math.exp(-.5 * weatherDistance * weatherDistance)
        * weatherCutoff;
    let ridgeWeather;
    if (term.hasWeatherComponents) {
        ridgeWeather = 0;
        for (const component of term.weatherComponents || []) {
            const dx = normalizeLongitude(lon - component.x);
            const dy = lat - component.y - component.tilt * dx;
            const componentDistance = Math.hypot(
                dx / component.sigmaX,
                dy / component.sigmaY
            );
            ridgeWeather += component.heightM * Math.exp(-.5 * componentDistance * componentDistance);
        }
    } else {
        ridgeWeather = term.ridgeHeightAnomalyM * weatherGaussian;
    }
    return term.fieldScale * (
        term.coefficient * gaussian + term.ridgeWeatherScale * ridgeWeather
    );
}


function modernHeightAnomalyFastTerm(cell, level) {
    if (!cell || cell.ridgeHeightAnomalyM || cell.ridgeWeatherComponents) return null;
    const roleScale = cell.role === 'south-asian-high'
        && level === 200
        && Number.isFinite(cell.level200AnomalyScale)
        ? cell.level200AnomalyScale
        : Number.isFinite(cell.anomalyScale)
            ? cell.anomalyScale
            : cell.role === 'ridge' && !cell.isManual ? .35 : 1;
    const levelScale = cell.role === 'south-asian-high'
        ? (level === 200 ? 1.35 : level === 500 ? SOUTH_ASIAN_HIGH_500_SCALE : .15)
        : 1;
    const verticalFactor = cell.role === 'monsoon'
        ? (level === 850 ? (cell.strength < 0 ? .65 : -.65) : level === 200 ? .40 : .35)
        : 1;
    const fieldScale = Number.isFinite(cell.ridgeFieldScale)
        ? clamp(cell.ridgeFieldScale, 0, 1.5) : 1;
    const sigmaX = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20);
    const sigmaY = Math.max(1, cell.sigmaY || 12);
    return {
        x: cell.x,
        y: cell.y,
        sxKm: Math.max(90, sigmaX * 111.32 * Math.max(.20, Math.cos(cell.y * Math.PI / 180))),
        syKm: Math.max(90, sigmaY * 111.32),
        coefficient: fieldScale * 12 * cell.strength * roleScale * levelScale * verticalFactor
    };
}

function evaluateModernHeightAnomalyFast(lon, lat, term) {
    const meanLatitude = (lat + term.y) * .5 * Math.PI / 180;
    const dxKm = normalizeLongitude(lon - term.x) * 111.32
        * Math.max(.20, Math.cos(meanLatitude));
    const dyKm = (lat - term.y) * 111.32;
    const distance = Math.hypot(dxKm / term.sxKm, dyKm / term.syKm);
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    return cutoff <= 0
        ? 0
        : term.coefficient * Math.exp(-.5 * distance * distance) * cutoff;
}

function coldSurgeUpperHeightAnomaly(lon, lat, cell, level) {
    if (!cell?.isColdSurge || level === 850) return 0;
    // A continental cold high is shallow at the surface but cold-core in the
    // free troposphere: its pressure maximum projects upward as a broad
    // trough/low-height anomaly, not as another anticyclone.  The broader
    // footprint aloft represents the cold dome spreading beyond the surface
    // centre while keeping the anomaly finite and lifecycle-continuous.
    const broadening = level === 200 ? 1.55 : 1.35;
    const footprint = {
        ...cell,
        sigmaX: (cell.sigmaX || cell.baseSigmaX || 16) * broadening,
        sigmaY: (cell.sigmaY || cell.baseSigmaY || 11) * (level === 200 ? 1.22 : 1.10)
    };
    const distance = normalizedCellDistance(lon, lat, footprint);
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    // This cutoff belongs only to the broad surface-cold-dome projection. It
    // must not short-circuit the delayed upper trough, whose core is allowed
    // to detach and dig southward while the surface high is already fading.
    const gaussian = cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
    const wedge = coldSurgeWedgeGaussian(lon, lat, cell);
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const marineFactor = coldSurgeMarineFactor(cell);
    // 500 hPa retains the main trough signal, but not the exaggerated 4.5x
    // amplification that made a mature cold high dominate a TC thousands of
    // kilometres away.  The detached upper trough is allowed to persist, but
    // its remote surface-linked part weakens as the cold high moves offshore.
    const levelScale = level === 200 ? 1.4 : 3.0;
    const upperTrough = coldSurgeUpperTroughState(cell);
    let diggingCore = 0;
    if (upperTrough?.envelope > 0) {
        diggingCore = coldSurgeUpperTroughGaussian(lon, lat, upperTrough)
            * upperTrough.envelope * upperTrough.coreScale;
    }
    const peakStrength = Math.max(
        strength,
        Number.isFinite(cell.peakStrength) ? cell.peakStrength : strength
    );
    // The surface cold dome, its downstream/equatorward streamer and the
    // delayed cut-off core are one vertical structure. The latter persists
    // after the surface high weakens, which allows late-life troughs to dig
    // from Central Asia into the mid/low latitudes without inventing an
    // unrelated pressure centre.
    const upperCore = 1.55 * peakStrength
        * (upperTrough?.envelope || 0) * diggingCore
        * (.75 + .25 * marineFactor);
    return -levelScale * (
        marineFactor * strength * (.58 * gaussian + .55 * wedge)
        + upperCore
    );
}

function coldSurgeLowerWedgeHeightAnomaly(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    // The coastal cold-surge ridge must be dynamically visible at 850 hPa;
    // otherwise the model can diagnose cooling and shear while leaving the
    // weakened vortex advected by the old tropical flow.
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const envelope = coldSurgeFieldEnvelope(cell);
    const marineFactor = coldSurgeMarineFactor(cell);
    // The wedge is a shallow 850-hPa extension, not a second synoptic-scale
    // high.  Its former amplitude generated 20--30 m/s reverse flow at the
    // far southern edge of the ellipse.  Keep the same geometry and lifecycle
    // while calibrating the pressure gradient to a realistic cold surge.
    const ridge = 12 * marineFactor * strength * envelope
        * coldSurgeWedgeGaussian(lon, lat, cell);
    const frontalLow = 10 * marineFactor * strength * envelope
        * coldSurgeFrontalLowGaussian(lon, lat, cell);
    return ridge - frontalLow;
}

function coldSurgeSurfacePressureAnomaly(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const envelope = coldSurgeFieldEnvelope(cell);
    const marineFactor = coldSurgeMarineFactor(cell);
    return marineFactor * (
        .35 * strength * envelope * coldSurgeWedgeGaussian(lon, lat, cell)
        - .08 * strength * envelope * coldSurgeFrontalLowGaussian(lon, lat, cell)
    );
}

// Seasonal source assumptions, not an observational fit. October is onset,
// not a switch to January air-mass strength. Occurrence and intensity have
// different seasonal cycles (winter-monsson surge frequency can peak in Nov/Mar).
function coldSurgeSeason(month) {
    const settings = {
        1: [240, 1, 1, .55], 2: [240, .95, .95, .50],
        3: [180, .75, .85, .45], 4: [360, .60, .75, .25],
        10: [360, .65, .75, .25], 11: [180, .85, .90, .45],
        12: [240, 1, 1, .55]
    };
    const [waitHours, strength, duration, initialProbability] = settings[month] || [Infinity, 0, 0, 0];
    return { waitHours, strength, duration, initialProbability };
}

function createColdSurge(initial = false, random = Math.random, month = 1) {
    const season = coldSurgeSeason(month);
    const peakStrength = (16 + 10 * random()) * season.strength;
    const lifeHours = (180 + 96 * random()) * season.duration;
    const growthHours = 30 + 18 * random();
    const decayHours = 48 + 24 * random();
    const baseSigmaX = 13 + 7 * random();
    const baseSigmaY = 9 + 5 * random();
    const sourceX = 100 + 25 * random();
    return {
        type: 'high',
        role: 'cold-surge-high',
        isColdSurge: true,
        // A Siberian cold high is a broad, elongated mass anomaly, not a
        // compact 6-degree pressure dot. The initial precursor is weak and
        // broad; the ridge grows continuously into its mature footprint.
        x: sourceX,
        sourceX,
        y: 43 + 8 * random(),
        baseSigmaX,
        sigmaX: baseSigmaX,
        baseSigmaY,
        sigmaY: baseSigmaY,
        peakStrength,
        baseStrength: peakStrength,
        strength: peakStrength * (initial ? .14 + .12 * random() : .01),
        fieldEnvelope: initial ? .14 + .12 * random() : .01,
        ageHours: initial ? 18 + 48 * random() : 0,
        growthHours,
        decayStartHours: lifeHours - decayHours,
        decayHours,
        lifeHours,
        phase: initial ? 'developing' : 'precursor',
        // Degrees per three-hour model step. The low-level cold surge moves
        // east/southeast on a multi-day time scale, with a weak meander rather
        // than a fixed diagonal or an instantaneous relocation.
        velocityX: .18 + .10 * random(),
        velocityY: -.050 - .060 * random(),
        flowAdvectionWeight: .10 + .05 * random(),
        meanderPhase: 2 * Math.PI * random(),
        meanderRate: .015 + .012 * random(),
        // The upper trough digs independently of the shallow surface-high
        // centre. This is sampled once per surge, then evolves smoothly with
        // age; it is not selected from the TC track.
        upperTroughDigging: .45 + .65 * random(),
        upperTroughPhase: 2 * Math.PI * random(),
        wedgeTiltDeg: 12 + 14 * random(),
        noiseLayers: []
    };
}

export function getGeopotentialHeight500(lon, lat, systems, level = 500) {
    const cache = getAtmospherePointCache(geopotentialHeightCache, systems);
    const key = atmospherePointKey(lon, lat, level);
    if (cache?.has(key)) return cache.get(key);

    // The same immutable atmosphere is queried at hundreds of stencil nodes
    // per model step. Prepare its layer terms once, using the point cache's
    // existing edit/time invalidation boundary. Keep the original (unprepared
    // wave) evaluator so even floating-point operation order is unchanged.
    const contexts = getAtmospherePointCache(geopotentialHeightContextCache, systems);
    let context = contexts?.get(level);
    if (!context) {
        context = createGeopotentialHeightEvaluationContext(systems, level);
        contexts?.set(level, context);
    }
    const height = calculateGeopotentialHeight500(lon, lat, systems, level, null, context);
    cache?.set(key, height);
    return height;
}

function scaleEnvironmentalGuidanceHeight(height, level) {
    // Scale the resolved mass-field gradient itself, not the cyclone's motion
    // after steering has been diagnosed. The datum is spatially constant, so
    // this preserves field geometry and direction while reducing all modern
    // environmental height gradients coherently by seven percent.
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5845;
    return datum + (height - datum) * ENVIRONMENTAL_GUIDANCE_HEIGHT_SCALE;
}

function createGeopotentialHeightEvaluationContext(systems, level = 500, prepareWave = false) {
    const upperCells = systems?.upper || [];
    const lowerCells = systems?.lower || [];
    const background = upperCells.find(c => c.role === 'height-background');
    const modernField = ensureModernAtmosphericState(background);
    const useExplicitLowerLayer = level === 850 && lowerCells.length > 0;
    const activeCells = (useExplicitLowerLayer ? lowerCells : upperCells)
        .filter(cell => cell.role !== 'height-background' && cell.role !== 'wave-handle');
    const fastCells = [];
    const slowCells = [];
    for (const cell of activeCells) {
        const term = modernField ? modernHeightAnomalyFastTerm(cell, level) : null;
        const referenceTerm = modernField && background?.climatologyVersion && cell.climatologyReference
            ? modernHeightAnomalyFastTerm(cell.climatologyReference, level) : null;
        if (term && (!cell.climatologyReference || referenceTerm)) {
            fastCells.push({ term, referenceTerm });
        } else {
            slowCells.push(cell);
        }
    }
    const preparedSlowCells = modernField
        ? slowCells.map(cell => ({
            cell,
            term: prepareModernCellHeightTerm(cell, level),
            referenceTerm: background?.climatologyVersion && cell.climatologyReference
                ? prepareModernCellHeightTerm(cell.climatologyReference, level)
                : null
        }))
        : null;
    const monthlyHeightSampler = modernField
        ? createMonthlyHeightSampler(background.calendarMonth, level)
        : null;
    const transientSurfacePressureSampler = modernField
        ? createTransientSurfacePressureAnomalySampler(background)
        : null;
    return {
        upperCells,
        lowerCells,
        background,
        modernField,
        cells: useExplicitLowerLayer ? lowerCells : upperCells,
        fastCells,
        slowCells,
        preparedSlowCells,
        surges: lowerCells.filter(cell => cell?.isColdSurge),
        waveContext: modernField && prepareWave ? {
            axes: { 1: new Map(), '-1': new Map() },
            phaseCache: { 850: new Map(), 500: new Map(), 200: new Map() },
            sampleMonthlyHeight: monthlyHeightSampler,
            monsoonLifecycle: wnpMonsoonLifecycleState(background),
            regionalLifecycle: regionalCirculationLifecycleState(background),
            circulations: Object.fromEntries([1, -1].map(hemisphere => [
                hemisphere,
                backgroundMonthlyCirculation(background, hemisphere)
            ])),
            axisWaves: Object.fromEntries([1, -1].map(hemisphere => [
                hemisphere,
                (background.waves || []).filter(wave => wave.hemisphere === hemisphere
                    && wave.k <= 3
                    && (!background.climatologyVersion || wave.isManual
                        || wave.isTransientAnomaly))
            ])),
            tropicalWaves: Object.fromEntries([1, -1].map(hemisphere => [hemisphere,
                (background.tropicalWaves || []).filter(w => w.hemisphere === hemisphere)])),
            waves: Object.fromEntries([1, -1].map(hemisphere => [hemisphere,
                (background.waves || []).filter(w => w.hemisphere === hemisphere
                    && (!background.climatologyVersion || w.isManual || w.isTransientAnomaly))]))
        } : null,
        useExplicitLowerLayer,
        monthlyHeightSampler,
        transientSurfacePressureSampler
    };
}

function calculateGeopotentialHeight500(lon, lat, systems, level = 500,
    precomputedWaveField = null, context = null) {
    const evaluation = context || createGeopotentialHeightEvaluationContext(systems, level);
    const { upperCells, lowerCells, background, modernField, cells,
        fastCells, slowCells, preparedSlowCells, surges, useExplicitLowerLayer } = evaluation;
    // The native waves provide the broad 850-hPa background, while explicit
    // lower-layer cells provide trades, monsoon troughs and low-level highs.
    // Previously a native background made every 850-hPa sample iterate only
    // upperCells, silently bypassing pressureSystems.lower.
    if (background?.waves || modernField) {
        const profile = getWindFieldProfile();
        const waveStartedAt = profile ? performance.now() : 0;
        const components = precomputedWaveField || waveFieldComponents(lon, lat, background, level, evaluation.waveContext);
        if (profile) profile.waveFieldMs += performance.now() - waveStartedAt;
        const transientStartedAt = profile ? performance.now() : 0;
        let height = components.height
            + (background.weatherSequence ? 0 : transientHeight(lon,lat,background,level)
            + transientBaroclinicHeight(lon,lat,background,level)
            + transientTropicalDisturbanceHeight(lon,lat,background,level)
            + transientFrontalLowHeight(lon,lat,background,level));
        if (profile) {
            profile.heightTransientMs += performance.now() - transientStartedAt;
            if (!background.weatherSequence) profile.heightTransientCalls++;
        }
        const cellsStartedAt = profile ? performance.now() : 0;
        if (modernField) {
            for (const { term, referenceTerm } of fastCells) {
                height += evaluateModernHeightAnomalyFast(lon, lat, term);
                if (referenceTerm) height -= evaluateModernHeightAnomalyFast(lon, lat, referenceTerm);
            }
        }
        const anomalyCells = modernField ? (preparedSlowCells || slowCells) : cells;
        for (const cell of anomalyCells) {
            if (modernField) {
                const sourceCell = cell.cell || cell;
                if (sourceCell.role === 'height-background' || sourceCell.role === 'wave-handle') continue;
                if (background.weatherSequence && !sourceCell.isManual) continue;
                height += cell.term
                    ? evaluatePreparedModernCellHeightTerm(lon, lat, cell.term)
                    : modernCellHeightAnomaly(lon, lat, sourceCell, level);
                // The observed mean already contains the ridge, monsoon and
                // South Asian High. Handles supply departures from their
                // initial reference, so their mean is not counted twice.
                if (background.climatologyVersion && sourceCell.climatologyReference) {
                    if (cell.referenceTerm) {
                        height -= evaluatePreparedModernCellHeightTerm(
                            lon, lat, cell.referenceTerm
                        );
                    } else {
                        const referenceTerm = modernHeightAnomalyFastTerm(
                            sourceCell.climatologyReference, level
                        );
                    height -= referenceTerm
                            ? evaluateModernHeightAnomalyFast(lon, lat, referenceTerm)
                            : modernCellHeightAnomaly(lon, lat, sourceCell.climatologyReference, level);
                    }
                }
                continue;
            }
            if (cell.role === 'height-background' || cell.role === 'wave-handle') continue;
            if (background.weatherSequence && !cell.isManual) continue;
            const dx = normalizeLongitude(lon - cell.x);
            const hemisphere = cell.y < 0 ? -1 : 1;
            // A curved monsoon axis and a ridge extension embedded in the waves.
            const axis = cell.y + hemisphere * ((cell.role === "ridge" ? components.displacement * .65 : 0)
                + 2 * Math.sin(dx * Math.PI / 35 + (background.elapsedHours || 0) / 100));
            const dy = lat - axis;
            const sx = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20);
            const sy = Math.max(1, cell.sigmaY || 12);
            // Lower monsoon cells already carry the negative anomaly sign.
            const verticalFactor = useExplicitLowerLayer
                ? (cell.role === 'monsoon' ? 0.65 : 1)
                : cell.role === 'monsoon'
                    ? (level === 850 ? -0.65 : level === 200 ? .40 : .35)
                    : 1;
            height += 12 * cell.strength * verticalFactor
                * Math.exp(-.5 * ((dx / sx) ** 2 + (dy / sy) ** 2));
        }
        if (profile) profile.heightCellAnomalyMs += performance.now() - cellsStartedAt;
        const surgeStartedAt = profile ? performance.now() : 0;
        if (modernField && !background.weatherSequence && level !== 850) {
            for (const surge of surges) {
                height += coldSurgeUpperHeightAnomaly(lon, lat, surge, level);
            }
        }
        if (modernField && !background.weatherSequence && level === 850) {
            for (const surge of surges) {
                height += coldSurgeLowerWedgeHeightAnomaly(lon, lat, surge);
            }
        }
        if (profile) profile.heightSurgeMs += performance.now() - surgeStartedAt;
        const scaleStartedAt = profile ? performance.now() : 0;
        const result = modernField
            ? scaleEnvironmentalGuidanceHeight(height, level)
            : height;
        if (profile) profile.heightScaleMs += performance.now() - scaleStartedAt;
        return result;
    }
    // Retain the prior field evaluator for archived runs, without rewriting history.
    if (!background) return (level === 200 ? 12400 : 5800) + (level === 200 ? 18 : 12) * (getPressureAt(lon, lat, cells, false) - 1010);
    const t = clamp((Math.abs(lat) - 24 - (background.seasonalShift || 0) * Math.sign(lat)) / 55, 0, 1);
    let height = (level === 200 ? 12400 : 5800) - 650 * t*t*(3-2*t) * (level === 200 ? 2.15 : 1);
    for (const cell of cells) {
        if (cell.role === 'height-background') continue;
        const dx = normalizeLongitude(lon - cell.x), dy = lat - cell.y;
        const sx = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20), sy = Math.max(1, cell.sigmaY || 12);
        const factor = level === 200 ? (cell.role === 'monsoon' ? .55 : cell.strength < 0 ? 1.65 : 1.15) : 1;
        height += 12 * cell.strength * factor * Math.exp(-.5*((dx/sx)**2+(dy/sy)**2));
    }
    return height;
}

// Compose an already-computed GPU background wave sample with the remaining
// CPU-resolved height terms. Callers must pass the matching point and system
// snapshot; omitting the sample preserves the normal production calculation.
export function getGeopotentialHeight500FromWaveFieldSample(
    lon, lat, systems, waveFieldSample, level = 500
) {
    if (!waveFieldSample || !Number.isFinite(waveFieldSample.height)) {
        return getGeopotentialHeight500(lon, lat, systems, level);
    }
    return calculateGeopotentialHeight500(
        lon, lat, systems, level, waveFieldSample
    );
}

// Build the invariant portion of the height evaluator once per map frame.
// The grid sampler calls the evaluator thousands of times; re-discovering
// the background cell, active layer and cold-surge list for every point adds
// avoidable CPU work without changing the field.
export function createGeopotentialHeight500Sampler(systems, level = 500) {
    const context = createGeopotentialHeightEvaluationContext(systems, level, true);
    return (lon, lat, waveFieldSample = null) => calculateGeopotentialHeight500(
        lon, lat, systems, level, waveFieldSample, context
    );
}

function modernZonalHeightAt(background, latitude, level = 500) {
    const profileFor = hemisphere => background?.zonalProfiles?.[level]?.[hemisphere]
        || background?.zonalProfiles?.[level]?.[String(hemisphere)];
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5845;
    const absoluteLatitude = Math.abs(latitude);
    if (absoluteLatitude < 8) {
        const south = profileFor(-1);
        const north = profileFor(1);
        const southValue = south ? interpolateProfile(south, absoluteLatitude) : datum;
        const northValue = north ? interpolateProfile(north, absoluteLatitude) : datum;
        return southValue + (northValue - southValue)
            * smoothstep((latitude + 8) / 16);
    }
    const hemisphere = latitude < 0 ? -1 : 1;
    const profile = profileFor(hemisphere);
    return profile ? interpolateProfile(profile, absoluteLatitude) : datum;
}

// Reduced-order sea-level pressure closure.  The surface field must not be a
// collection of isolated Gaussian symbols: the real MSLP pattern is a broad
// mass field shaped by the equatorial trough, subtropical ridges, subpolar
// lows, and the same synoptic height anomalies that steer the storm aloft.
// This maps the native 500-hPa height anomaly to MSLP while retaining the
// explicit lower-layer cells for monsoon troughs, ridges and cold surges.
export function getSurfacePressureAt(lon, lat, systems, options = {}) {
    const profile = getWindFieldProfile();
    if (profile) profile.surfacePressureCalls++;
    const includeTerrain = options?.includeTerrain !== false;
    const cache = getAtmospherePointCache(surfacePressureCache, systems);
    const key = atmospherePointKey(lon, lat, includeTerrain ? 'terrain' : 'marine');
    if (cache?.has(key)) {
        if (profile) profile.surfacePressureCacheHits++;
        return cache.get(key);
    }
    if (profile) profile.surfacePressureCacheMisses++;

    // Point queries share the same immutable atmosphere as a radius/grid
    // search. Reuse its exact prepared sampler until the existing edit/time
    // invalidation boundary, without changing the node or terrain branch.
    const samplers = getAtmospherePointCache(surfacePressureSamplerCache, systems);
    let sampler = samplers?.get(includeTerrain);
    if (!sampler) {
        sampler = createSurfacePressureSampler(systems, { includeTerrain });
        samplers?.set(includeTerrain, sampler);
    }
    const pressure = sampler(lon, lat);
    cache?.set(key, pressure);
    return pressure;
}

// A wind-radius search samples one immutable atmosphere thousands of times.
// Prepare its constants once, while retaining the same exact point caches,
// field evaluator and terrain branch used by the public point-query API.
export function createSurfacePressureSampler(systems, options = {}) {
    const useCache = options?.cache !== false;
    // Wind gradients use marine pressure; visual humidity also needs the
    // terrain-inclusive pressure at each node. Both can prepare one context.
    const includeTerrain = options?.includeTerrain === true;
    const lower = Array.isArray(systems) ? systems : systems?.lower || [];
    const background = Array.isArray(systems) ? null
        : systems?.upper?.find(c => c.role === 'height-background');
    const modern = background && ensureModernAtmosphericState(background);
    const context = modern ? {
        lower, background,
        lowerPressureSampler: createLowerPressureSampler(lower),
        northernCirculation: backgroundMonthlyCirculation(background, 1),
        southernCirculation: backgroundMonthlyCirculation(background, -1),
        surges: lower.filter(cell => cell.isColdSurge),
        // These closures preserve sampleMonthlyHeight and
        // transientSurfacePressureAnomaly arithmetic while hoisting their
        // immutable grid/feature preparation out of every pressure node.
        monthlyHeightSampler: createMonthlyHeightSampler(background.calendarMonth, 500),
        transientSurfacePressureSampler: createTransientSurfacePressureAnomalySampler(background),
        sampleHeight: createGeopotentialHeight500Sampler(systems, 500),
        // The radial search revisits the same latitude on many longitudes.
        // Cache only latitude-invariant closure terms; all longitude-dependent
        // height, transient and surge terms remain pointwise and unchanged.
        pressureLatitudeCache: new Map()
    } : null;
    const pressureCache = useCache
        ? getAtmospherePointCache(surfacePressureCache, systems)
        : null;
    const heightCache = useCache
        ? getAtmospherePointCache(geopotentialHeightCache, systems)
        : null;
    if (context) {
        const evaluateHeight = context.sampleHeight;
        context.sampleHeight = (lon, lat) => {
            if (!heightCache) return evaluateHeight(lon, lat);
            const key = atmospherePointKey(lon, lat, 500);
            if (heightCache.has(key)) return heightCache.get(key);
            const height = evaluateHeight(lon, lat);
            heightCache.set(key, height);
            return height;
        };
    }
    const sampler = (lon, lat) => {
        const profile = getWindFieldProfile();
        if (profile) {
            profile.surfacePressureSamplerCalls++;
            recordWindFieldProfileSample(profile, 'pressure', lon, lat);
        }
        if (pressureCache) {
            const key = atmospherePointKey(lon, lat, includeTerrain ? 'terrain' : 'marine');
            if (pressureCache.has(key)) {
                if (profile) profile.surfacePressureSamplerCacheHits++;
                return pressureCache.get(key);
            }
            if (profile) profile.surfacePressureSamplerCacheMisses++;
            const pressureStartedAt = profile ? performance.now() : 0;
            const pressure = calculateSurfacePressureAt(lon, lat, systems, includeTerrain, context);
            if (profile) profile.surfacePressureSamplerMs += performance.now() - pressureStartedAt;
            pressureCache.set(key, pressure);
            return pressure;
        }
        if (profile) profile.surfacePressureSamplerCacheMisses++;
        const pressureStartedAt = profile ? performance.now() : 0;
        const pressure = calculateSurfacePressureAt(lon, lat, systems, includeTerrain, context);
        if (profile) profile.surfacePressureSamplerMs += performance.now() - pressureStartedAt;
        return pressure;
    };
    return sampler;
}

function calculateSurfacePressureAt(lon, lat, systems, includeTerrain = true, context = null) {
    const systemsObj = Array.isArray(systems) ? null : systems;
    const lower = context?.lower || (Array.isArray(systems) ? systems : systemsObj?.lower || []);
    const background = context?.background || systemsObj?.upper?.find(c => c.role === 'height-background');

    if (!background || !ensureModernAtmosphericState(background)) {
        return getPressureAt(lon, lat, lower, false);
    }

    const northernCirculation = context?.northernCirculation
        || backgroundMonthlyCirculation(background, 1);
    const southernCirculation = context?.southernCirculation
        || backgroundMonthlyCirculation(background, -1);
    const latitudeCache = context?.pressureLatitudeCache;
    let latitudeTerms = latitudeCache?.get(lat);
    if (!latitudeTerms) {
        const latitude = Math.abs(lat);
        const circulationWeight = smoothstep((lat + 8) / 16);
        const summer = southernCirculation.summer
            + (northernCirculation.summer - southernCirculation.summer) * circulationWeight;
        const ridgeLatitude = southernCirculation.ridgeLatitude
            + (northernCirculation.ridgeLatitude - southernCirculation.ridgeLatitude)
                * circulationWeight;

        // Broad climatological mass distribution.  These are deliberately modest
        // pressure anomalies; the transient field and explicit cells provide the
        // event-scale structure on top of them.
        const equatorialTrough = -2.8 * Math.exp(-0.5 * (latitude / 13) ** 2);
        const subtropicalRidge = (4.0 + 0.8 * summer)
            * Math.exp(-0.5 * ((latitude - ridgeLatitude) / 14) ** 2);
        const subpolarLow = -(3.4 - 0.7 * summer)
            * Math.exp(-0.5 * ((latitude - (58 - 2 * summer)) / 14) ** 2);
        const polarHigh = 1.4 * (1 - summer)
            * Math.exp(-0.5 * ((latitude - 76) / 11) ** 2);
        const surfaceHemisphere = lat < 0 ? -1 : 1;
        const surfaceCirculation = surfaceHemisphere < 0
            ? southernCirculation : northernCirculation;
        const shiftedClimatologyLatitude = climatologyLatitudeWithShiftedAxes(
            latitude, surfaceCirculation, surfaceHemisphere
        );
        latitudeTerms = {
            latitude,
            summer,
            equatorialTrough,
            subtropicalRidge,
            subpolarLow,
            polarHigh,
            surfaceHemisphere,
            surfaceCirculation,
            shiftedClimatologyLatitude,
            surfaceDatum: 1007.0 + 4.0 * (1 - summer),
            summerAwareCeiling: 1034 + 8 * (1 - summer)
        };
        latitudeCache?.set(lat, latitudeTerms);
    }
    const {
        latitude, summer, equatorialTrough, subtropicalRidge,
        subpolarLow, polarHigh, surfaceHemisphere, surfaceCirculation,
        shiftedClimatologyLatitude, surfaceDatum, summerAwareCeiling
    } = latitudeTerms;

    const profile = getWindFieldProfile();
    if (profile) recordWindFieldProfileSample(profile, 'height', lon, lat);
    const heightStartedAt = profile ? performance.now() : 0;
    const height = context ? context.sampleHeight(lon, lat)
        : getGeopotentialHeight500(lon, lat, systems, 500);
    if (profile) profile.heightSamplerMs += performance.now() - heightStartedAt;
    const zonalHeight = background.climatologyVersion
        ? (context?.monthlyHeightSampler
            || ((x, y) => sampleMonthlyHeight(x, y, background.calendarMonth, 500)))(
            lon,
            surfaceHemisphere * shiftedClimatologyLatitude
        )
        : modernZonalHeightAt(background, lat, 500);
    const heightAnomaly = clamp(height - zonalHeight, -220, 220);
    const upperMassAnomaly = SURFACE_UPPER_MASS_COUPLING * heightAnomaly;

    const lowerPressure = context?.lowerPressureSampler
        ? context.lowerPressureSampler(lon, lat)
        : getPressureAt(lon, lat, lower, false);
    const lowerAnomaly = 0.6 * (lowerPressure - 1010)
        + (context?.surges || lower.filter(cell => cell.isColdSurge))
            .reduce((sum, cell) => sum + coldSurgeSurfacePressureAnomaly(lon, lat, cell), 0);
    const landStatus = includeTerrain ? getLandStatus(lon, lat, 0.5) : { isLand: false };
    const elevation = includeTerrain ? getElevationAt(lon, lat) : 0;
    const terrainFraction = clamp(elevation / 680, 0, 1);
    const terrainWeight = landStatus.isLand ? 1 : landStatus.isNearLand ? 0.35 : 0;
    const terrainAnomaly = -0.85 * terrainFraction * terrainWeight;
    const surfacePressure = clamp(
        surfaceDatum + equatorialTrough + subtropicalRidge + subpolarLow
            + polarHigh + upperMassAnomaly + lowerAnomaly + terrainAnomaly
            + (context?.transientSurfacePressureSampler
                ? context.transientSurfacePressureSampler(lon, lat)
                : transientSurfacePressureAnomaly(lon, lat, background)),
        945,
        summerAwareCeiling
    );
    return surfacePressure;
}

// The environmental height field deliberately excludes the full storm vortex
// so steering does not count the cyclone twice. A product chart can still
// show the cyclone's own 500-hPa closed circulation through this evaluator.
// Steering uses only the weak, outer-filtered projection defined below.
export function getCycloneFieldGeometryAt(lon, lat, cyclone) {
    const centerLon = Number.isFinite(cyclone?.lon) ? cyclone.lon : lon;
    const centerLat = Number.isFinite(cyclone?.lat) ? cyclone.lat : lat;
    const hemisphere = Math.sign(centerLat) || 1;
    const meanLatitude = (lat + centerLat) * .5 * Math.PI / 180;
    const eastKm = normalizeLongitude(lon - centerLon) * 111.32
        * Math.max(.12, Math.cos(meanLatitude));
    const northKm = (lat - centerLat) * 111.32;
    const transitionProgress = cyclone?.isTransitioning
        ? smoothstep((cyclone.transitionHours || 0) / EXTRATROPICAL_TRANSITION_MAX_HOURS) : 0;
    const extratropicalProgress = cyclone?.isExtratropical
        ? .55 + .45 * smoothstep((cyclone.extratropicalAgeHours || 0) / 24) : 0;
    const baroclinicWeight = clamp(
        Math.max(.55 * transitionProgress, extratropicalProgress),
        0,
        1
    );

    const orientationU = Number.isFinite(cyclone?.steeringU)
        ? cyclone.steeringU : 7;
    const orientationV = Number.isFinite(cyclone?.steeringV)
        ? cyclone.steeringV : 0;
    const downstreamEast = Math.max(2, Math.abs(orientationU));
    const polewardSlope = clamp(
        hemisphere * orientationV / downstreamEast,
        -.10,
        .55
    );
    const tilt = hemisphere * (10 * Math.PI / 180)
        + .55 * Math.atan(hemisphere * polewardSlope);
    const cosTilt = Math.cos(tilt), sinTilt = Math.sin(tilt);
    const alongKm = eastKm * cosTilt + northKm * sinTilt;
    const crossKm = -eastKm * sinTilt + northKm * cosTilt;
    // Preserve footprint area while converting the post-ET vortex into an
    // elongated baroclinic low. This avoids creating extra integrated mass
    // merely because the plotted circulation is no longer circular.
    const aspectRatio = 1 + .72 * baroclinicWeight;
    const majorScale = Math.sqrt(aspectRatio);
    const minorScale = 1 / majorScale;
    const scaledAlong = alongKm / majorScale;
    const scaledCross = crossKm / minorScale;
    const effectiveRadiusKm = Math.hypot(scaledAlong, scaledCross);
    let gradientAlong = alongKm / (majorScale * majorScale);
    let gradientCross = crossKm / (minorScale * minorScale);
    const gradientMagnitude = Math.hypot(gradientAlong, gradientCross);
    if (gradientMagnitude > 1e-9) {
        gradientAlong /= gradientMagnitude;
        gradientCross /= gradientMagnitude;
    } else {
        gradientAlong = 1;
        gradientCross = 0;
    }
    return {
        effectiveRadiusKm,
        physicalRadiusKm: Math.hypot(eastKm, northKm),
        normalEast: gradientAlong * cosTilt - gradientCross * sinTilt,
        normalNorth: gradientAlong * sinTilt + gradientCross * cosTilt,
        aspectRatio,
        tilt,
        baroclinicWeight
    };
}

function createCycloneFieldDistanceSampler(cyclone) {
    const centerLon = Number.isFinite(cyclone?.lon) ? cyclone.lon : 0;
    const centerLat = Number.isFinite(cyclone?.lat) ? cyclone.lat : 0;
    const hemisphere = Math.sign(centerLat) || 1;
    const transitionProgress = cyclone?.isTransitioning
        ? smoothstep((cyclone.transitionHours || 0) / EXTRATROPICAL_TRANSITION_MAX_HOURS) : 0;
    const extratropicalProgress = cyclone?.isExtratropical
        ? .55 + .45 * smoothstep((cyclone.extratropicalAgeHours || 0) / 24) : 0;
    const baroclinicWeight = clamp(
        Math.max(.55 * transitionProgress, extratropicalProgress), 0, 1
    );
    const orientationU = Number.isFinite(cyclone?.steeringU) ? cyclone.steeringU : 7;
    const orientationV = Number.isFinite(cyclone?.steeringV) ? cyclone.steeringV : 0;
    const downstreamEast = Math.max(2, Math.abs(orientationU));
    const polewardSlope = clamp(hemisphere * orientationV / downstreamEast, -.10, .55);
    const tilt = hemisphere * (10 * Math.PI / 180)
        + .55 * Math.atan(hemisphere * polewardSlope);
    const cosTilt = Math.cos(tilt), sinTilt = Math.sin(tilt);
    const aspectRatio = 1 + .72 * baroclinicWeight;
    const majorScale = Math.sqrt(aspectRatio);
    const minorScale = 1 / majorScale;

    return (lon, lat) => {
        const meanLatitude = (lat + centerLat) * .5 * Math.PI / 180;
        const eastKm = normalizeLongitude(lon - centerLon) * 111.32
            * Math.max(.12, Math.cos(meanLatitude));
        const northKm = (lat - centerLat) * 111.32;
        const alongKm = eastKm * cosTilt + northKm * sinTilt;
        const crossKm = -eastKm * sinTilt + northKm * cosTilt;
        return Math.hypot(alongKm / majorScale, crossKm / minorScale);
    };
}

export function createCycloneHeightAnomalySampler(cyclone, level = 500) {
    if (![850, 500, 200].includes(level) || !cyclone
        || !Number.isFinite(cyclone.lon) || !Number.isFinite(cyclone.lat)
        || !Number.isFinite(cyclone.intensity)) return () => 0;

    const intensity = clamp(cyclone.intensity, 15, 160);
    const circulationSize = clamp(cyclone.circulationSize || 300, 120, 700);
    const isExtratropical = Boolean(cyclone.isExtratropical);
    const transitionProgress = cyclone.isTransitioning
        ? smoothstep((cyclone.transitionHours || 0) / EXTRATROPICAL_TRANSITION_MAX_HOURS) : 0;
    const extratropicalAge = Number.isFinite(cyclone.extratropicalAgeHours)
        ? Math.max(0, cyclone.extratropicalAgeHours) : 0;
    // The reference project's ET closure separates the upper-cold-core clock
    // from the slower loss of the lower warm core. Keep this as a bounded
    // profile parameter: it changes the cyclone anomaly sampler and its
    // resolved phase evidence, but never directly changes forecast dynamics.
    const etBlend = isExtratropical ? 1 : transitionProgress;
    const upperColdForcing = clamp(
        .62 * etBlend
            + .20 * (Number.isFinite(cyclone.etTrough) ? clamp(cyclone.etTrough, 0, 1) : 0)
            + .18 * (Number.isFinite(cyclone.baroclinicSupport)
                ? clamp(cyclone.baroclinicSupport, 0, 1) : 0),
        0, 1
    );
    const upperColdBuild = clamp(
        upperColdForcing * (.78 + .22 * smoothstep(extratropicalAge / 24)), 0, 1
    );
    const lowerColdBuild = isExtratropical
        ? smoothstep((extratropicalAge - 12) / 36)
        : smoothstep(
            ((cyclone.transitionHours || 0) - EXTRATROPICAL_LOWER_COLD_LAG_HOURS)
            / EXTRATROPICAL_LOWER_COLD_RAMP_HOURS
        );
    // The tropical branch remains split at 500 hPa: a mature TC has a
    // closed low-height lower/middle circulation and a warm upper anomaly.
    // The ET branch below uses a separate, independently blended vertical
    // profile instead of applying that tropical sign pattern at every level.
    const sampleDistance = createCycloneFieldDistanceSampler(cyclone);
    const amplitudeBase = 15 + 0.62 * intensity + 0.03 * circulationSize;
    // Preserve the tropical closure exactly, then blend continuously into
    // the ET profile. A boolean phase switch here would make the 200-hPa
    // anomaly jump sign at the first transition hour.
    const warmCoreMaturity = smoothstep((intensity - 30) / 75);
    const lowerFactor = -(0.35 + 0.45 * warmCoreMaturity);
    const tropicalLevelFactor = level === 200
        ? 0.28 + 0.82 * warmCoreMaturity
        : level === 850
            ? 1.35 * lowerFactor
            : lowerFactor;
    const tropicalAmplitude = tropicalLevelFactor * amplitudeBase;
    const tropicalRadius = Math.max(
        level === 200 ? 180 : 140,
        circulationSize * (level === 200 ? 0.72 + 0.0035 * intensity : 0.55 + 0.003 * intensity)
    );

    // ET has an independently parameterized vertical structure. The upper
    // cold anomaly is allowed to appear first, while the lower levels retain
    // a shallow warm ordering until the slower lower-core clock advances.
    // Coefficients are height anomalies in metres and are deliberately
    // bounded so a phase change cannot create a jump.
    const lowerWarmRetention = 1 - lowerColdBuild;
    const etLevelCoefficient = level === 850
        ? .45 + .35 * lowerWarmRetention
        : level === 500
            ? .62 + .18 * lowerColdBuild
            : .72 + .36 * upperColdBuild;
    const etAmplitude = -etLevelCoefficient * amplitudeBase;
    const etRadius = Math.max(level === 200 ? 220 : level === 500 ? 180 : 150,
        circulationSize * (level === 200 ? .92 : level === 500 ? .78 : .68));
    const amplitude = tropicalAmplitude * (1 - etBlend) + etAmplitude * etBlend;
    const radius = tropicalRadius * (1 - etBlend) + etRadius * etBlend;
    return (lon, lat) => {
        const distance = sampleDistance(lon, lat);
        const core = Math.exp(-0.5 * (distance / radius) ** 2);
        const outerCompensation = Math.exp(-0.5
            * (distance / (radius * (level === 200 ? 2.4 : 2.2))) ** 2);
        return amplitude * (core - 0.18 * outerCompensation);
    };
}

export function getCycloneHeightAnomalyAt(lon, lat, cyclone, level = 500) {
    return createCycloneHeightAnomalySampler(cyclone, level)(lon, lat);
}

// Weak environmental feedback from a TC onto the surrounding synoptic field.
// The full vortex is intentionally not injected into the steering field: its
// symmetric core would be a double count and has no legitimate self-advection
// at the centre. Instead, use a broad, ridge-relative response representing
// the outer mass redistribution and upper outflow that can erode/displace a
// nearby subtropical ridge.
export function createCycloneEnvironmentalHeightFeedbackSampler(
    cyclone, level = 500, pressureSystems = null
) {
    if (![500, 200].includes(level) || !cyclone
        || !Number.isFinite(cyclone.lon) || !Number.isFinite(cyclone.lat)
        || !Number.isFinite(cyclone.intensity)) return () => 0;

    const intensity = clamp(cyclone.intensity, 15, 160);
    const organization = smoothstep(
        (intensity - TC_ENVIRONMENT_FEEDBACK_MIN_INTENSITY) / 50
    );
    if (organization <= 0) return () => 0;
    const majorIntensityGain = 1 + TC_ENVIRONMENT_FEEDBACK_MAJOR_GAIN
        * smoothstep((intensity - 95) / 50);

    const configuredScale = Number.isFinite(cyclone.environmentFeedbackScale)
        ? clamp(cyclone.environmentFeedbackScale, 0, 2.5)
        : 1;
    if (configuredScale <= 0) return () => 0;

    const stageScale = cyclone.isExtratropical
        ? 0
        : cyclone.isTransitioning
            ? .70
            : cyclone.isSubtropical
                ? .65
                : 1;
    const depthScale = .45 + .55 * getStormDepthFactor(cyclone);
    const referenceAnomaly = Math.abs(createCycloneHeightAnomalySampler(
        cyclone, level
    )(cyclone.lon, cyclone.lat));
    const background = pressureSystems?.upper?.find(
        cell => cell.role === 'height-background'
    );
    if (!background || !isModernAtmosphericBackground(background)) return () => 0;

    const hemisphere = Math.sign(cyclone.lat) || 1;
    const circulation = backgroundMonthlyCirculation(
        background, hemisphere, background.calendarMonth || cyclone.currentMonth || 8
    );
    const stormLatitude = Math.abs(cyclone.lat);
    const ridgeLatitude = Math.abs(circulation.ridgeLatitude);
    const ridgeGap = Math.max(0, ridgeLatitude - stormLatitude);
    // Activate only within broad synoptic reach of the ridge belt. Feedback
    // should strengthen as the vortex approaches the ridge edge.
    // The former lower gate did the opposite and switched the interaction
    // off entirely at ridgeGap <= 3 degrees, exactly where ridge erosion is
    // physically most relevant. Retain a weaker remote response for a large,
    // organized tropical vortex, then taper it out beyond synoptic reach.
    const ridgeGate = (1 - .65 * smoothstep((ridgeGap - 3) / 20))
        * (1 - smoothstep((ridgeGap - 34) / 12));
    if (ridgeGate <= 0) return () => 0;

    const circulationSize = clamp(cyclone.circulationSize || 300, 120, 700);
    const levelResponse = level === 200
        ? {
            // Broad, weak upper outflow response is displaced downstream and
            // poleward, where it can slightly extend or move the ridge edge.
            offsetLat: 5.5,
            offsetLon: 5,
            sigmaLat: Math.max(10, 9 + circulationSize * .010),
            sigmaLon: Math.max(20, 18 + circulationSize * .025),
            sign: 1
        }
        : {
            // The 500-hPa low-height response is placed on the poleward side
            // of the TC, producing local ridge erosion rather than self-drift.
            offsetLat: clamp(7 + .30 * ridgeGap, 7, 15),
            offsetLon: 3,
            sigmaLat: Math.max(9, 8 + circulationSize * .012),
            sigmaLon: Math.max(18, 17 + circulationSize * .035),
            sign: -1
        };
    const feedbackCenterLat = cyclone.lat + hemisphere * levelResponse.offsetLat;
    const feedbackCenterLon = normalizeLongitude(
        cyclone.lon + levelResponse.offsetLon
    );
    const levelScale = level === 200
        ? TC_ENVIRONMENT_FEEDBACK_200_SCALE
        : TC_ENVIRONMENT_FEEDBACK_500_SCALE;
    const fixedAmplitude = levelResponse.sign * configuredScale * levelScale * organization
        * majorIntensityGain * stageScale * depthScale
        * referenceAnomaly * ridgeGate;
    const latitudeScale = Math.cos(feedbackCenterLat * Math.PI / 180);

    return (lon, lat) => {
        const dx = normalizeLongitude(lon - feedbackCenterLon) * latitudeScale;
        const dy = lat - feedbackCenterLat;
        return fixedAmplitude * Math.exp(-0.5 * (
            (dx / levelResponse.sigmaLon) ** 2
            + (dy / levelResponse.sigmaLat) ** 2
        ));
    };
}

export function getCycloneEnvironmentalHeightFeedbackAt(
    lon, lat, cyclone, level = 500, pressureSystems = null
) {
    return createCycloneEnvironmentalHeightFeedbackSampler(
        cyclone, level, pressureSystems
    )(lon, lat);
}

// Public diagnostics for the map, forecast and future data-assimilation
// layers. Keeping these quantities next to the field evaluator prevents UI
// code from reverse-engineering the synthetic atmosphere from its contours.
export function getAtmosphericDiagnostics(lon, lat, systems) {
    const background = systems?.upper?.find(c => c.role === 'height-background');
    if (!background) return { fieldVersion: 0, flowModel: 'legacy', levels: {} };
    ensureModernAtmosphericState(background);
    const components = waveFieldComponents(lon, lat, background, 500);
    const levels = {};
    for (const level of [850, 500, 200]) {
        const wind = gradientWind(lon, lat,
            (x, y) => getGeopotentialHeight500(x, y, systems, level), GRAVITY);
        const derivatives = flowDerivatives(lon, lat, systems, level);
        levels[level] = {
            height: getGeopotentialHeight500(lon, lat, systems, level),
            u: wind.u,
            v: wind.v,
            speed: Math.hypot(wind.u, wind.v),
            ...derivatives
        };
    }
    const west = getGeopotentialHeight500(lon - 3, lat, systems, 500);
    const east = getGeopotentialHeight500(lon + 3, lat, systems, 500);
    const north = getGeopotentialHeight500(lon, lat + 3, systems, 500);
    const south = getGeopotentialHeight500(lon, lat - 3, systems, 500);
    return {
        fieldVersion: background.fieldVersion || 2,
        flowModel: background.flowModel || 'legacy',
        ridgeLatitude: components.ridgeLatitude,
        jetLatitude: components.jetLatitude,
        displacement: components.displacement,
        shortWave: components.shortWave,
        zonalGradient: (east - west) / 6,
        meridionalGradient: (north - south) / 6,
        levels
    };
}

// Diagnose the cyclone phase space directly from the resolved pressure field.
// The operational CPS definition uses 900--600 and 600--300 hPa thicknesses;
// this model resolves 850/500/200 hPa, so the two thicknesses below are an
// explicitly labelled proxy.  The diagnostic remains separate from forecast
// intensity, steering, and ERC dynamics.  ET completion may consume the last
// completed snapshot as structural evidence, while the diagnostic itself
// never mutates the cyclone state.
export function diagnoseCyclonePhaseSpace(cyclone, systems, options = {}) {
    if (!cyclone || !systems?.upper || !Array.isArray(systems.upper)) return null;
    const background = systems.upper.find(cell => cell.role === 'height-background');
    if (!background) return null;

    const innerRadiusKm = Number.isFinite(options.innerRadiusKm)
        ? Math.max(40, options.innerRadiusKm) : 120;
    const outerRadiusKm = Number.isFinite(options.outerRadiusKm)
        ? Math.max(innerRadiusKm + 40, options.outerRadiusKm) : 450;
    const sectorCount = Number.isFinite(options.sectorCount)
        ? Math.max(8, Math.floor(options.sectorCount)) : 8;
    if (!Number.isFinite(cyclone.lon) || !Number.isFinite(cyclone.lat)) return null;

    // Heading is taken from the observed track displacement.  A steering
    // vector is only a fallback for the first point or a stalled fix.
    const previous = Array.isArray(cyclone.track) && cyclone.track.length
        ? cyclone.track[cyclone.track.length - 1] : null;
    const latitudeScale = Math.max(.12, Math.cos(cyclone.lat * Math.PI / 180));
    let eastKm = previous && Number.isFinite(previous[0])
        ? normalizeLongitude(cyclone.lon - previous[0]) * 111.32 * latitudeScale : 0;
    let northKm = previous && Number.isFinite(previous[1])
        ? (cyclone.lat - previous[1]) * 111.32 : 0;
    if (Math.hypot(eastKm, northKm) < 1) {
        eastKm = Number.isFinite(cyclone.steeringU) ? cyclone.steeringU : 1;
        northKm = Number.isFinite(cyclone.steeringV) ? cyclone.steeringV : 0;
    }
    const motionKm = Math.hypot(eastKm, northKm) || 1;
    const headingEast = eastKm / motionKm;
    const headingNorth = northKm / motionKm;
    // Clockwise 90 degrees: positive sin(theta) is the storm's right side.
    const rightEast = headingNorth;
    const rightNorth = -headingEast;

    const height500Anomaly = createCycloneHeightAnomalySampler(cyclone, 500);
    const height200Anomaly = createCycloneHeightAnomalySampler(cyclone, 200);
    // Resolve all three CPS levels from the same blended cyclone profile so
    // the ET cold-core signal is not manufactured by a fixed 850/500 ratio.
    const height850Anomaly = createCycloneHeightAnomalySampler(cyclone, 850);
    const ringSums = {
        inner: { lower: 0, upper: 0, anomalyLower: 0, anomalyUpper: 0, count: 0, rightLower: 0, leftLower: 0,
            rightCount: 0, leftCount: 0 },
        outer: { lower: 0, upper: 0, anomalyLower: 0, anomalyUpper: 0, count: 0, rightLower: 0, leftLower: 0,
            rightCount: 0, leftCount: 0 }
    };
    let sampleCount = 0;

    const samplePoint = (radiusKm, theta) => {
        const radialEast = headingEast * Math.cos(theta) + rightEast * Math.sin(theta);
        const radialNorth = headingNorth * Math.cos(theta) + rightNorth * Math.sin(theta);
        const lat = cyclone.lat + radiusKm * radialNorth / 111.32;
        const lon = normalizeLongitude(
            cyclone.lon + radiusKm * radialEast / (111.32 * Math.max(.12, Math.cos(lat * Math.PI / 180)))
        );
        const anomaly850 = height850Anomaly(lon, lat);
        const anomaly500 = height500Anomaly(lon, lat);
        const anomaly200 = height200Anomaly(lon, lat);
        const z850 = getGeopotentialHeight500(lon, lat, systems, 850) + anomaly850;
        const z500 = getGeopotentialHeight500(lon, lat, systems, 500) + anomaly500;
        const z200 = getGeopotentialHeight500(lon, lat, systems, 200) + anomaly200;
        if (![z850, z500, z200].every(Number.isFinite)) return null;
        return {
            lower: z500 - z850,
            upper: z200 - z500,
            anomalyLower: anomaly500 - anomaly850,
            anomalyUpper: anomaly200 - anomaly500,
            rightSide: Math.sin(theta) > 0.08,
            leftSide: Math.sin(theta) < -0.08
        };
    };

    for (const [ringName, radiusKm] of [['inner', innerRadiusKm], ['outer', outerRadiusKm]]) {
        const ring = ringSums[ringName];
        for (let sector = 0; sector < sectorCount; sector++) {
            const sample = samplePoint(radiusKm, (2 * Math.PI * sector) / sectorCount);
            if (!sample) continue;
            ring.lower += sample.lower;
            ring.upper += sample.upper;
            ring.anomalyLower += sample.anomalyLower;
            ring.anomalyUpper += sample.anomalyUpper;
            ring.count++;
            sampleCount++;
            if (sample.rightSide) {
                ring.rightLower += sample.lower;
                ring.rightCount++;
            } else if (sample.leftSide) {
                ring.leftLower += sample.lower;
                ring.leftCount++;
            }
        }
    }

    if (!ringSums.inner.count || !ringSums.outer.count) return null;
    const mean = (sum, count) => count ? sum / count : 0;
    const innerLower = mean(ringSums.inner.lower, ringSums.inner.count);
    const outerLower = mean(ringSums.outer.lower, ringSums.outer.count);
    const innerUpper = mean(ringSums.inner.upper, ringSums.inner.count);
    const outerUpper = mean(ringSums.outer.upper, ringSums.outer.count);
    const innerAnomalyLower = mean(
        ringSums.inner.anomalyLower, ringSums.inner.count
    );
    const outerAnomalyLower = mean(
        ringSums.outer.anomalyLower, ringSums.outer.count
    );
    const innerAnomalyUpper = mean(
        ringSums.inner.anomalyUpper, ringSums.inner.count
    );
    const outerAnomalyUpper = mean(
        ringSums.outer.anomalyUpper, ringSums.outer.count
    );
    const radialSpan = outerRadiusKm - innerRadiusKm;
    // Positive values represent a warm-core radial thickness maximum.
    const vtLower = clamp((innerLower - outerLower) / radialSpan * 100, -150, 250);
    const vtUpper = clamp((innerUpper - outerUpper) / radialSpan * 100, -150, 250);
    const rightLower = mean(ringSums.outer.rightLower, ringSums.outer.rightCount);
    const leftLower = mean(ringSums.outer.leftLower, ringSums.outer.leftCount);
    const asymmetryB = clamp(rightLower - leftLower, -60, 60);
    // Core structure is diagnosed from the cyclone anomaly itself, while B
    // and -V_T retain the resolved total-height signal. This separation keeps
    // environmental baroclinicity from being mistaken for a warm/cold core.
    const lowerWarmContrast = innerAnomalyLower - outerAnomalyLower;
    const upperWarmContrast = innerAnomalyUpper - outerAnomalyUpper;
    const lowerWarmSignal = Math.tanh(lowerWarmContrast / 30);
    const upperWarmSignal = Math.tanh(upperWarmContrast / 30);
    const shallowWarmCore = clamp(.5 + .5 * lowerWarmSignal, 0, 1);
    const deepWarmCore = clamp(
        .5 + .5 * Math.min(lowerWarmSignal, upperWarmSignal), 0, 1
    );
    const upperColdCore = clamp(.5 - .5 * upperWarmSignal, 0, 1);
    const thermalAsymmetry = clamp(Math.abs(asymmetryB) / 9.5, 0, 1.35);
    const synopticFront = Number.isFinite(cyclone.etSynopticFront)
        ? clamp(cyclone.etSynopticFront, 0, 1)
        : 0;
    const climatologicalFront = Number.isFinite(cyclone.etFront)
        ? clamp(cyclone.etFront, 0, 1)
        : 0;
    const frontalAttachment = clamp(
        .72 * synopticFront + .28 * climatologicalFront, 0, 1
    );
    let upperAbsoluteVorticity = 0;
    try {
        upperAbsoluteVorticity = flowDerivatives(
            cyclone.lon, cyclone.lat, systems, 200
        ).absoluteVorticity;
    } catch {
        upperAbsoluteVorticity = 0;
    }
    const upperVorticityProxy = Number.isFinite(upperAbsoluteVorticity)
        ? clamp(Math.abs(upperAbsoluteVorticity) / 1e-4, 0, 1.2) : 0;
    const troughProxy = Number.isFinite(cyclone.etTrough)
        ? clamp(cyclone.etTrough, 0, 1) : 0;
    const pvProxy = clamp(.65 * upperVorticityProxy + .35 * troughProxy, 0, 1.35);
    const baroclinicEnergy = clamp(
        .45 * (Number.isFinite(cyclone.baroclinicSupport)
            ? clamp(cyclone.baroclinicSupport, 0, 1) : 0)
            + .25 * frontalAttachment + .20 * pvProxy
            + .10 * thermalAsymmetry,
        0, 1.35
    );
    // These are evidence scores modelled after the reference project's
    // conjunction logic. They are recorded for validation only; no forecast
    // state consumes them in this step.
    const etEvidence = clamp(
        baroclinicEnergy * .50
            + thermalAsymmetry * .23
            + upperColdCore * .18
            + (1 - deepWarmCore) * .16,
        0, 1.35
    );
    const latitude = Math.abs(cyclone.lat);
    const subtropicalLatitudeGate = smoothstep((latitude - 15) / 9)
        * (1 - smoothstep((latitude - 47) / 9));
    const detachedFrontGate = 1 - smoothstep((frontalAttachment - .22) / .48);
    const broadCirculationGate = clamp(
        .28 + .72 * smoothstep(((cyclone.circulationSize || 300) - 180) / 260),
        .28, 1
    );
    const subtropicalEvidence = clamp(
        subtropicalLatitudeGate * detachedFrontGate * broadCirculationGate
            * smoothstep((upperColdCore - .20) / .58)
            * smoothstep((shallowWarmCore - .16) / .58)
            * (1 - .72 * deepWarmCore),
        0, 1
    );
    const lagHours = Number.isFinite(cyclone.transitionElapsedHours)
        ? Math.max(0, cyclone.transitionElapsedHours)
        : Number.isFinite(cyclone.transitionHours)
            ? Math.max(0, cyclone.transitionHours)
        : cyclone.isExtratropical && Number.isFinite(cyclone.extratropicalAgeHours)
            ? Math.max(0, cyclone.extratropicalAgeHours) : 0;
    const motionSpeedKt = Math.hypot(
        Number.isFinite(cyclone.speed) ? cyclone.speed : 0,
        0
    );

    return {
        version: 2,
        source: 'resolved-height-proxy',
        levels: '850-500-200 hPa',
        b: Number(asymmetryB.toFixed(2)),
        vtLower: Number(vtLower.toFixed(2)),
        vtUpper: Number(vtUpper.toFixed(2)),
        deepWarmCore: Number(deepWarmCore.toFixed(3)),
        shallowWarmCore: Number(shallowWarmCore.toFixed(3)),
        upperColdCore: Number(upperColdCore.toFixed(3)),
        frontalAttachment: Number(frontalAttachment.toFixed(3)),
        pvProxy: Number(pvProxy.toFixed(3)),
        thermalAsymmetry: Number(thermalAsymmetry.toFixed(3)),
        lagHours: Number(lagHours.toFixed(1)),
        etEvidence: Number(etEvidence.toFixed(3)),
        subtropicalEvidence: Number(subtropicalEvidence.toFixed(3)),
        warmCore: {
            lower: Number(lowerWarmSignal.toFixed(3)),
            upper: Number(upperWarmSignal.toFixed(3)),
            deep: Number(deepWarmCore.toFixed(3)),
            shallow: Number(shallowWarmCore.toFixed(3))
        },
        coldCore: {
            upper: Number(upperColdCore.toFixed(3))
        },
        innerRadiusKm: Number(innerRadiusKm.toFixed(1)),
        outerRadiusKm: Number(outerRadiusKm.toFixed(1)),
        sampleCount,
        motionSpeedKt: Number(motionSpeedKt.toFixed(1))
    };
}

function advanceWaveField(background) {
    const prior = background.waves.map(w => ({...w}));
    background.elapsedHours = (background.elapsedHours || 0) + MODEL_STEP_HOURS;
    background.waves.forEach((wave, index) => {
        const neighbours = prior.filter(w => w.hemisphere === wave.hemisphere && Math.abs(w.k-wave.k) === 1);
        const coupling = neighbours.reduce((sum,w) => sum + Math.sin(w.phase-prior[index].phase), 0);
        if (isModernAtmosphericBackground(background)) {
            // Linearized barotropic Rossby-wave evolution: phase propagation
            // follows the initialized U-beta/K² dispersion relation. Coupling
            // is deliberately weak and bounded so it cannot reverse the
            // background wave propagation or create an arbitrary attractor.
            const frequency = Number.isFinite(wave.frequency)
                ? wave.frequency
                : rossbyFrequencyFromSpeed(wave);
            wave.phase = (wave.phase + frequency * MODEL_STEP_HOURS
                + .0015 * clamp(coupling, -2, 2)) % (2 * Math.PI);
            const envelope = 1 + .15 * Math.sin(
                background.elapsedHours / wave.envelopeHours + wave.envelopePhase
            );
            wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .035;
            wave.verticalTiltRad = wave.baseVerticalTiltRad
                + .04 * Math.sin(background.elapsedHours / 120 + wave.envelopePhase);
        } else {
            wave.phase = (wave.phase + wave.frequency * MODEL_STEP_HOURS + .006 * coupling) % (2*Math.PI);
            const envelope = 1 + .22 * Math.sin(background.elapsedHours / wave.envelopeHours + wave.envelopePhase);
            wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .045;
            wave.tilt = wave.baseTilt + .8 * Math.sin(background.elapsedHours / 90 + wave.envelopePhase);
        }
    });
    for (const wave of (background.tropicalWaves || [])) {
        const envelope = 1 + .18 * Math.sin(
            background.elapsedHours / wave.envelopeHours + wave.envelopePhase
        );
        wave.phase = (wave.phase + wave.frequency * MODEL_STEP_HOURS) % (2 * Math.PI);
        wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .055;
        wave.latitude += .025 * Math.sin(
            background.elapsedHours / 72 + wave.phaseOffset
        );
    }
    for (const wave of (background.equatorialWaves || [])) {
        const envelope = 1 + .12 * Math.sin(
            background.elapsedHours / wave.envelopeHours + wave.envelopePhase
        );
        wave.phase = (wave.phase + wave.frequency * MODEL_STEP_HOURS) % (2 * Math.PI);
        wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .04;
    }
}

function gradientWind(lon, lat, sample, factor) {
    const delta = 0.25;
    const radians = Math.PI / 180;
    const f = 2 * 7.292115e-5 * Math.sin(lat * radians);
    // Smooth equatorial regularization; no singular wind or discontinuity at 0°.
    const inverseF = f / (f * f + (2.0e-5) ** 2);
    const dy = 2 * delta * 6371000 * radians;
    const dx = dy * Math.max(0.087, Math.cos(lat * radians));
    return {
        u: -factor * inverseF * (sample(lon, lat + delta) - sample(lon, lat - delta)) / dy,
        v: factor * inverseF * (sample(lon + delta, lat) - sample(lon - delta, lat)) / dx
    };
}

// Environmental point shear for the optional map overlay. Reuse the model's
// exact gradient stencil and equatorial regularization, without TC feedback,
// storm-footprint averaging, temporal response or intensity-loss modifiers.
// Apply the same user percentage as the resolved shear in updateCycloneState.
export function createEnvironmentalShearSampler(systems, globalShearSetting = 100) {
    const lower = createGeopotentialHeight500Sampler(systems, 850);
    const upper = createGeopotentialHeight500Sampler(systems, 200);
    const shearScale = globalShearSetting / 100;
    return (lon, lat) => {
        const low = gradientWind(lon, lat, lower, GRAVITY);
        const high = gradientWind(lon, lat, upper, GRAVITY);
        const u = (high.u - low.u) * 1.94384 * shearScale;
        const v = (high.v - low.v) * 1.94384 * shearScale;
        return { u, v, magnitude: Math.hypot(u, v) };
    };
}

function flowDerivatives(lon, lat, systems, level = 500, heightSampler = null) {
    const delta = 1;
    const radians = Math.PI / 180;
    const dy = delta * EARTH_RADIUS_M * radians;
    const dx = dy * Math.max(.087, Math.cos(lat * radians));
    const wind = (x, y) => gradientWind(x, y,
        (sampleLon, sampleLat) => heightSampler
            ? heightSampler(sampleLon, sampleLat)
            : getGeopotentialHeight500(sampleLon, sampleLat, systems, level), GRAVITY);
    const west = wind(lon - delta, lat), east = wind(lon + delta, lat);
    const south = wind(lon, lat - delta), north = wind(lon, lat + delta);
    const dudx = (east.u - west.u) / (2 * dx);
    const dudy = (north.u - south.u) / (2 * dy);
    const dvdx = (east.v - west.v) / (2 * dx);
    const dvdy = (north.v - south.v) / (2 * dy);
    const relativeVorticity = dvdx - dudy;
    return {
        relativeVorticity,
        divergence: dudx + dvdy,
        deformation: Math.hypot(dudx - dvdy, dvdx + dudy),
        absoluteVorticity: relativeVorticity
            + 2 * EARTH_OMEGA * Math.sin(lat * radians)
    };
}

function calculateLayerWind(lon, lat, systems) {
    return gradientWind(lon, lat, (x, y) => getPressureAt(x, y, systems, false), 100 / 1.15);
}

function surfaceWindFromPressureForces(
    lon, lat, forceX, forceY, applyTerrainFriction = true, terrainInfo = null
) {
    const forceSq = forceX * forceX + forceY * forceY;
    if (!(forceSq > 0)) return { u: 0, v: 0 };

    const radians = Math.PI / 180;
    const f = 2 * EARTH_OMEGA * Math.sin(lat * radians);
    const landInfo = applyTerrainFriction
        ? (terrainInfo || queryTerrain(lon, lat))
        : null;
    const surfaceRoughness = applyTerrainFriction
        ? surfaceRoughnessFromTerrain(landInfo)
        : 0;
    const dragCoefficient = surfaceDragCoefficientFromRoughness(surfaceRoughness);
    const dragPerDepth = dragCoefficient / 600;
    const speedSq = 2 * forceSq / (f * f
        + Math.sqrt(f ** 4 + 4 * dragPerDepth * dragPerDepth * forceSq));
    const damping = dragPerDepth * Math.sqrt(speedSq);
    const denominator = f * f + damping * damping;
    return {
        u: 0.8 * (damping * forceX + f * forceY) / denominator,
        v: 0.8 * (damping * forceY - f * forceX) / denominator
    };
}

function buildSurfaceEnvironmentGrid(cyclone, systems, maxSearchKm, pressureSampler = null) {
    const size = SURFACE_ENVIRONMENT_GRID_SIZE;
    const radiusKm = Math.max(300, maxSearchKm) + SURFACE_ENVIRONMENT_GRID_MARGIN_KM;
    const stepKm = (2 * radiusKm) / (size - 1);
    const centerCosLat = Math.max(0.1, Math.cos(cyclone.lat * Math.PI / 180));
    const pressure = new Float32Array(size * size);
    const forceX = new Float32Array(size * size);
    const forceY = new Float32Array(size * size);

    // Materialize only nodes actually reached by the contour search. Keep
    // the original mesh, stencil and Float32 rounding at both stages.
    const pressureReady = new Uint8Array(size * size);
    const forceReady = new Uint8Array(size * size);
    const centerLon = cyclone.lon, centerLat = cyclone.lat;
    const pressureAt = (xIndex, yIndex) => {
        const index = yIndex * size + xIndex;
        if (pressureReady[index]) return pressure[index];
        const yKm = -radiusKm + yIndex * stepKm;
        const lat = centerLat + yKm / 111.32;
        const xKm = -radiusKm + xIndex * stepKm;
        const lon = normalizeLongitude(
            centerLon + xKm / (111.32 * centerCosLat)
        );
        pressure[index] = pressureSampler ? pressureSampler(lon, lat) : getSurfacePressureAt(
            lon, lat, systems, { includeTerrain: false }
        );
        pressureReady[index] = 1;
        return pressure[index];
    };
    const radians = Math.PI / 180;
    const prepareForce = (xIndex, yIndex) => {
        const index = yIndex * size + xIndex;
        if (forceReady[index]) return;
        const lat = centerLat + (-radiusKm + yIndex * stepKm) / 111.32;
        const southIndex = Math.max(0, yIndex - 1);
        const northIndex = Math.min(size - 1, yIndex + 1);
        const yDistanceM = Math.max(1, (northIndex - southIndex) * stepKm * 1000);
        const dy = yDistanceM;
        const westIndex = Math.max(0, xIndex - 1);
        const eastIndex = Math.min(size - 1, xIndex + 1);
        const lonDelta = eastIndex - westIndex;
        const xDistanceM = Math.max(
            1,
            lonDelta * stepKm * 1000
                * Math.max(0.1, Math.cos(lat * radians)) / centerCosLat
        );
        const fx = -(
            pressureAt(eastIndex, yIndex) - pressureAt(westIndex, yIndex)
        ) * 100 / (1.15 * xDistanceM);
        const fy = -(
            pressureAt(xIndex, northIndex) - pressureAt(xIndex, southIndex)
        ) * 100 / (1.15 * dy);
        // Interpolate forces before nonlinear drag, with original rounding.
        forceX[index] = fx;
        forceY[index] = fy;
        forceReady[index] = 1;
    };

    const interpolate = (values, x, y) => {
        const xPosition = clamp((x + radiusKm) / stepKm, 0, size - 1);
        const yPosition = clamp((y + radiusKm) / stepKm, 0, size - 1);
        const x0 = Math.floor(xPosition);
        const y0 = Math.floor(yPosition);
        const x1 = Math.min(size - 1, x0 + 1);
        const y1 = Math.min(size - 1, y0 + 1);
        const tx = xPosition - x0;
        const ty = yPosition - y0;
        prepareForce(x0, y0);
        prepareForce(x1, y0);
        prepareForce(x0, y1);
        prepareForce(x1, y1);
        const top = values[y0 * size + x0]
            + (values[y0 * size + x1] - values[y0 * size + x0]) * tx;
        const bottom = values[y1 * size + x0]
            + (values[y1 * size + x1] - values[y1 * size + x0]) * tx;
        return top + (bottom - top) * ty;
    };

    return {
        centerLon: cyclone.lon,
        centerLat: cyclone.lat,
        centerCosLat,
        radiusKm,
        sample(lon, lat, applyTerrainFriction = true, terrainInfo = null) {
            const xKm = normalizeLongitude(lon - this.centerLon)
                * 111.32 * this.centerCosLat;
            const yKm = (lat - this.centerLat) * 111.32;
            if (Math.abs(xKm) > this.radiusKm || Math.abs(yKm) > this.radiusKm) return null;

            // Preserve exact terrain transitions. Open-ocean points use the
            // smooth grid, while islands and coastal bands retain the exact
            // land/near-coast friction branch.
            if (applyTerrainFriction) {
                const landInfo = terrainInfo || getLandStatus(lon, lat);
                if (landInfo?.isLand || landInfo?.isNearLand) return null;
            }
            const fx = interpolate(forceX, xKm, yKm);
            const fy = interpolate(forceY, xKm, yKm);
            return {
                ...surfaceWindFromPressureForces(
                    lon,
                    lat,
                    fx,
                    fy,
                    applyTerrainFriction,
                    terrainInfo
                ),
                fromSurfaceGrid: true
            };
        }
    };
}

function getSurfaceEnvironmentGrid(cyclone, systems, maxSearchKm, pressureSampler = null) {
    const cache = getAtmospherePointCache(surfaceEnvironmentGridCache, systems);
    const signature = `${cyclone.lon}|${cyclone.lat}|${maxSearchKm}`;
    const cached = cache?.get(cyclone);
    if (cached?.signature === signature) return cached.grid;

    const grid = buildSurfaceEnvironmentGrid(cyclone, systems, maxSearchKm, pressureSampler);
    cache?.set(cyclone, { signature, grid });
    return grid;
}

export function getSurfaceEnvironmentalWind(
    lon, lat, systems, applyTerrainFriction = true, pressureSampler = null,
    terrainInfo = null, useCache = true
) {
    const profile = getWindFieldProfile();
    if (profile) profile.surfaceWindCalls++;
    const cache = useCache
        ? getAtmospherePointCache(surfaceEnvironmentalWindCache, systems)
        : null;
    const key = useCache
        ? atmospherePointKey(lon, lat, applyTerrainFriction ? 'friction' : 'marine')
        : null;
    if (cache?.has(key)) {
        if (profile) profile.surfaceWindCacheHits++;
        return cache.get(key);
    }
    if (profile && useCache) profile.surfaceWindCacheMisses++;

    const wind = calculateSurfaceEnvironmentalWind(
        lon, lat, systems, applyTerrainFriction, pressureSampler, terrainInfo
    );
    cache?.set(key, wind);
    return wind;
}

function calculateSurfaceEnvironmentalWind(
    lon, lat, systems, applyTerrainFriction = true, pressureSampler = null,
    terrainInfo = null
) {
    // Local steady bulk momentum balance:
    // (Cd |U| / h) U + f k×U = -grad(p)/rho.
    // It includes friction at the equator without an artificial inverse-f cap.
    // h=500 m, Cd and the 0.8 slab-to-10m factor are explicit diagnostic
    // assumptions, not a resolved/stability-dependent boundary-layer model.
    const delta = 0.25;
    const radians = Math.PI / 180;
    const dy = 2 * delta * EARTH_RADIUS_M * radians;
    const dx = dy * Math.max(0.087, Math.cos(lat * radians));
    const sample = pressureSampler || ((x, y) => getSurfacePressureAt(x, y, systems, { includeTerrain: false }));
    const forceX = -(sample(lon + delta, lat) - sample(lon - delta, lat)) * 100 / (1.15 * dx);
    const forceY = -(sample(lon, lat + delta) - sample(lon, lat - delta)) * 100 / (1.15 * dy);
    return surfaceWindFromPressureForces(
        lon,
        lat,
        forceX,
        forceY,
        applyTerrainFriction,
        terrainInfo
    );
}

export function getWindVectorAt(lon, lat, month, cyclone, pressureSystems, options = {}) {
    const profile = getWindFieldProfile();
    if (profile) profile.vectorCalls++;
    const applyTerrainFriction = typeof options === 'object'
        ? options.applyTerrainFriction !== false
        : true;
    // Environmental flow is optional because the wind-radii solver samples
    // both the earth-relative wind and the cyclone-only contribution.  The
    // former supplies physically real quadrant enhancement/cancellation; the
    // latter prevents a detached monsoon or westerly current being mistaken
    // for part of the storm's gale envelope.
    const includeEnvironmentalFlow = typeof options === 'object'
        ? options.includeEnvironmentalFlow !== false
        : true;
    const includeComponents = typeof options === 'object'
        ? options.includeComponents === true
        : false;
    const environmentSampler = typeof options === 'object'
        ? options.environmentSampler
        : null;
    const terrainCache = typeof options === 'object'
        ? options.terrainCache
        : null;
    let surfaceRoughness = 0;
    let terrainInfo = null;
    if (applyTerrainFriction) {
        if (terrainCache) {
            const terrainKey = atmospherePointKey(lon, lat, 'land');
            terrainInfo = terrainCache.get(terrainKey);
            if (!terrainInfo) {
                terrainInfo = queryTerrain(lon, lat);
                terrainCache.set(terrainKey, terrainInfo);
            }
        } else {
            terrainInfo = queryTerrain(lon, lat);
        }
        surfaceRoughness = surfaceRoughnessFromTerrain(terrainInfo);
    }

    const cycloneSurfaceTransfer = surfaceCycloneTransferFromRoughness(surfaceRoughness);
    const alphaDeg = surfaceInflowAngleFromRoughness(surfaceRoughness);
    const inflowAngle = alphaDeg * (Math.PI / 180);

    // Surface winds respond to surface pressure and drag, not the free
    // 850-hPa jet used for steering and shear.
    let envFlow = { u: 0, v: 0 };
    const environmentStartedAt = profile ? performance.now() : 0;
    if (includeEnvironmentalFlow) {
        const sampledFlow = environmentSampler?.sample?.(
            lon,
            lat,
            applyTerrainFriction,
            terrainInfo
        );
        envFlow = sampledFlow || getSurfaceEnvironmentalWind(
            lon,
            lat,
            pressureSystems,
            applyTerrainFriction,
            options?.pressureSampler,
            terrainInfo,
            options?.skipEnvironmentCache !== true
        );
    }
    if (profile) profile.environmentMs += performance.now() - environmentStartedAt;
    const envWind = { u: envFlow.u * 1.94384, v: envFlow.v * 1.94384 };
    
    // 2. Vortex Flow
    let u_vortex = 0;
    let v_vortex = 0;
    let u_trans = 0;
    let v_trans = 0;

    if (cyclone.status === 'active') {
        const fieldGeometry = getCycloneFieldGeometryAt(lon, lat, cyclone);
        const dist = fieldGeometry.effectiveRadiusKm;
        // Avoid rebuilding the full diagnostic radial profile for every wind
        // grid sample. Only the dominant RMW is needed for translation decay.
        const geometrySignature = [
            cyclone.intensity,
            cyclone.rmw,
            cyclone.circulationSize,
            cyclone.outerWindBroadness,
            cyclone.isERCActive ? 1 : 0,
            cyclone.ercInnerRmw,
            cyclone.ercInnerWind,
            cyclone.ercOuterRmw,
            cyclone.ercOuterWindAnomaly,
            cyclone.ercOuterOrganization,
            cyclone.ercOuterShare,
            cyclone.ercInnerIntegrity,
            cyclone.ercOuterWidth,
            cyclone.centralPressure,
            cyclone.environmentalPressure,
            cyclone.pressureTendency,
            cyclone.speed,
            cyclone.lat
        ].join('|');
        let geometry = vortexGeometryCache.get(cyclone);
        if (!geometry || geometry.signature !== geometrySignature) {
            const innerRmw = getPrimaryRmw(cyclone);
            const innerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
                ? cyclone.ercInnerWind
                : cyclone.intensity;
            const outerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
                ? baselineWindAtRadius(cyclone.ercOuterRmw, cyclone)
                    + Math.max(0, cyclone.ercOuterWindAnomaly || 0)
                : -Infinity;
            const takeover = getOuterEyewallDominance(cyclone);
            const RMW = innerRmw + ((cyclone.ercOuterRmw || innerRmw) - innerRmw) * takeover;
            const dominantPeak = Number.isFinite(outerPeak)
                ? innerPeak + (outerPeak - innerPeak) * takeover : innerPeak;
            let symmetricCoreR64 = estimateSymmetricCoreR64(
                RMW,
                dominantPeak,
                cyclone.circulationSize,
                Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
                hollandShapeParameter(cyclone, dominantPeak)
            );
            if (cyclone.isERCActive
                && Number.isFinite(cyclone.ercOuterRmw)
                && outerPeak > 54) {
                const outerOrganization = clamp(cyclone.ercOuterOrganization || 0, 0, 1);
                const outerRingWidth = clamp(cyclone.ercOuterWidth || 18, 8, 60);
                const outerCoreSigma = outerRingWidth
                    * (1.10 + 0.35 * (1 - outerOrganization));
                symmetricCoreR64 = Math.max(
                    symmetricCoreR64,
                    RMW + (cyclone.ercOuterRmw + 2.40 * outerCoreSigma - RMW)
                        * takeover * smoothstep((outerPeak - 54) / 20)
                );
            }
            geometry = { signature: geometrySignature, RMW, symmetricCoreR64,
                outerCoreRemap: getOuterCoreRemap(cyclone) };
            vortexGeometryCache.set(cyclone, geometry);
        }
        const { RMW, symmetricCoreR64 } = geometry;
        // Do not let the finite-domain taper erase the broad gale tail before
        // it can separate R34 from R64. The taper begins outside the expected
        // gale contour and remains tied to both circulation size and core size.
        const fadeStart = Math.max(
            cyclone.circulationSize * 1.4,
            symmetricCoreR64 * 2.65
        );
        const outerRadius = Math.max(
            cyclone.circulationSize * 4.0,
            fadeStart + Math.max(180, symmetricCoreR64)
        );

        if (dist < outerRadius) {
            let vortexSpeed = resolvedVortexWindAtRadius(dist, cyclone, geometry.outerCoreRemap);
            // Keep the existing finite circulation envelope outside the core.
            if (dist > fadeStart) {
                const t = (dist - fadeStart) / (outerRadius - fadeStart);
                const fade = (Math.exp(-2 * t) - Math.exp(-2)) / (1 - Math.exp(-2));
                vortexSpeed *= clamp(fade, 0, 1);
            }

            const speedMs = vortexSpeed; 
            if (fieldGeometry.baroclinicWeight > .01) {
                const hemisphere = Math.sign(cyclone.lat) || 1;
                const tangentEast = -hemisphere * fieldGeometry.normalNorth;
                const tangentNorth = hemisphere * fieldGeometry.normalEast;
                const inflow = Math.sin(inflowAngle);
                const tangential = Math.cos(inflowAngle);
                u_vortex = (tangentEast * tangential
                    - fieldGeometry.normalEast * inflow) * speedMs;
                v_vortex = (tangentNorth * tangential
                    - fieldGeometry.normalNorth * inflow) * speedMs;
            } else {
                const dx = lon - cyclone.lon;
                const dy = lat - cyclone.lat;
                const angleToCenter = Math.atan2(dy, dx);
                const rotationOffset = (cyclone.lat >= 0)
                    ? (Math.PI / 2 + inflowAngle)
                    : (-Math.PI / 2 - inflowAngle);
                const windAngle = angleToCenter + rotationOffset;
                u_vortex = Math.cos(windAngle) * speedMs;
                v_vortex = Math.sin(windAngle) * speedMs;
            }
            const moveSpeed = cyclone.speed;
            const moveAngleMath = (450 - cyclone.direction) % 360 * (Math.PI / 180);
            // Storm motion is not just a track displacement: it is added to
            // the near-core circulation and therefore enlarges the forward
            // side while partially cancelling the rear side.  A fixed 0.6
            // factor made a 15 kt translating storm look almost symmetric.
            // Keep the effect bounded so fast-moving systems do not acquire
            // an implausibly elongated wind field.
            const asymmetryFactor = clamp(0.45 + 0.018 * moveSpeed, 0.45, 0.75);
            u_trans = Math.cos(moveAngleMath) * moveSpeed * asymmetryFactor;
            v_trans = Math.sin(moveAngleMath) * moveSpeed * asymmetryFactor;
            // Translation is a storm-scale flow, not an eyewall-only
            // correction.  The old 45 km e-folding scale removed almost all
            // of it before the 34 kt contour, making moving storms look too
            // symmetric.  Let it persist through the inner circulation and
            // fade on a scale tied to the diagnosed storm size.
            const translationFadeStart = 1.1 * RMW;
            const translationDecayScale = Math.max(
                90,
                0.35 * cyclone.circulationSize,
                1.75 * RMW
            );
            let transDecay = 1.0;
            if (dist > translationFadeStart) {
                transDecay = Math.exp(-(dist - translationFadeStart) / translationDecayScale);
            }
            
            u_trans *= transDecay;
            v_trans *= transDecay;
        }
    }

    const cycloneU = (u_vortex + u_trans) * cycloneSurfaceTransfer;
    const cycloneV = (v_vortex + v_trans) * cycloneSurfaceTransfer;
    const rawTotalU = envWind.u + cycloneU;
    const rawTotalV = envWind.v + cycloneV;
    const terrainShelter = terrainShelterFactor(
        lon,
        lat,
        rawTotalU,
        rawTotalV,
        terrainInfo
    );
    const shelteredEnvU = envWind.u * terrainShelter;
    const shelteredEnvV = envWind.v * terrainShelter;
    const shelteredCycloneU = cycloneU * terrainShelter;
    const shelteredCycloneV = cycloneV * terrainShelter;
    const totalU = shelteredEnvU + shelteredCycloneU;
    const totalV = shelteredEnvV + shelteredCycloneV;
    const result = {
        u: totalU,
        v: totalV,
        magnitude: Math.hypot(totalU, totalV)
    };
    if (includeComponents) {
        result.cycloneU = shelteredCycloneU;
        result.cycloneV = shelteredCycloneV;
        result.cycloneMagnitude = Math.hypot(shelteredCycloneU, shelteredCycloneV);
    }
    if (envFlow.fromSurfaceGrid) result.environmentApproximate = true;
    return result;
}

/**
 * Resolve the cyclone-associated 34/50/64 kt contour in each operational
 * quadrant.  Wind radii are earth-relative (vortex + translation + local
 * environment), but a small cyclone-only contribution is required so a
 * detached monsoon surge or westerly belt cannot become part of the ring.
 * Searching outward from the dynamically relevant eyewall and stopping at
 * its first outer crossing also rejects a remote re-entry into an unrelated
 * wind maximum.  During an eyewall replacement cycle, the diagnosed outer
 * eyewall is a valid anchor even when the moat between the two eyewalls is
 * below the requested wind threshold.
 */
export function calculateWindRadii(cyclone, pressureSystems, month, maxSearchKm = 900) {
    const structure = getEyewallStructure(cyclone);
    const thresholds = [34, 50, 64].filter(threshold => cyclone.intensity >= threshold);
    const result = { 34: [0, 0, 0, 0], 50: [0, 0, 0, 0], 64: [0, 0, 0, 0] };
    const angularBinCount = 16;
    const angularResult = {
        34: Array(angularBinCount).fill(0),
        50: Array(angularBinCount).fill(0),
        64: Array(angularBinCount).fill(0)
    };
    result.angular = angularResult;
    if (thresholds.length === 0) return result;

    const pressureSampler = createSurfacePressureSampler(pressureSystems);
    const environmentSampler = getSurfaceEnvironmentGrid(
        cyclone,
        pressureSystems,
        maxSearchKm,
        pressureSampler
    );

    const distances = new Set([0, structure.innerRmw]);
    for (let radius = 5; radius <= maxSearchKm; radius += 10) distances.add(radius);

    const addPeakMesh = (peakRadius, halfWidth) => {
        if (!Number.isFinite(peakRadius)) return;
        for (let radius = Math.max(1, peakRadius - halfWidth); radius <= peakRadius + halfWidth; radius += 2) {
            distances.add(radius);
        }
        distances.add(peakRadius);
    };
    addPeakMesh(structure.innerRmw, Math.max(20, structure.innerRmw * 0.45));
    if (Number.isFinite(structure.outerRmw)) {
        addPeakMesh(structure.outerRmw, Math.max(25, 1.5 * (cyclone.ercOuterWidth || 15)));
    }

    const radialDistances = [...distances]
        .filter(radius => radius >= 0 && radius <= maxSearchKm)
        .sort((a, b) => a - b);
    const cosLat = Math.max(0.1, Math.cos(cyclone.lat * Math.PI / 180));
    const pointAt = (angleRad, distanceKm) => {
        const distanceDeg = distanceKm / 111.32;
        return [
            cyclone.lon + distanceDeg * Math.cos(angleRad) / cosLat,
            cyclone.lat + distanceDeg * Math.sin(angleRad)
        ];
    };

    const directionalCache = new Map();
    // A coastal point is queried once with the grid sampler and may be
    // queried again for the exact threshold refinement. Reuse its immutable
    // raster classification across both calls without changing the branch.
    const terrainCache = new Map();
    const resolveDirectionalRadii = angle => {
        const normalizedAngle = ((angle % 360) + 360) % 360;
        if (directionalCache.has(normalizedAngle)) {
            return directionalCache.get(normalizedAngle);
        }
        const angleRad = normalizedAngle * Math.PI / 180;
        // Evaluate only mesh points consumed by an eyewall search or a
        // connected threshold crossing. Preserve the exact mesh and order;
        // all three thresholds share the same per-direction sample cache.
        const profile = new Array(radialDistances.length);
        const sampleAt = index => {
            if (profile[index]) return profile[index];
            const distance = radialDistances[index];
            const [lon, lat] = pointAt(angleRad, distance);
            let wind = getWindVectorAt(
                lon, lat, month, cyclone, pressureSystems,
                {
                    includeEnvironmentalFlow: true,
                    includeComponents: true,
                    environmentSampler,
                    pressureSampler,
                    terrainCache
                }
            );
            if (wind.environmentApproximate
                && thresholds.some(threshold => Math.abs(
                    wind.magnitude - threshold
                ) <= SURFACE_ENVIRONMENT_EXACT_THRESHOLD_TOLERANCE_KT)) {
                wind = getWindVectorAt(
                    lon, lat, month, cyclone, pressureSystems,
                    {
                        includeEnvironmentalFlow: true,
                        includeComponents: true,
                        pressureSampler,
                        terrainCache
                    }
                );
            }
            return profile[index] = {
                distance,
                totalWind: wind.magnitude,
                cycloneWind: wind.cycloneMagnitude
            };
        };
        const outermost = { 34: 0, 50: 0, 64: 0 };

        thresholds.forEach(threshold => {
            const associationFloor = Math.min(12, threshold * 0.20);
            const marginAt = sample => Math.min(
                sample.totalWind - threshold,
                sample.cycloneWind - associationFloor
            );

            const findEyewallPeak = (center, halfWidth) => {
                let peakIndex = -1;
                let peakMargin = -Infinity;
                for (let i = 0; i < radialDistances.length; i++) {
                    if (Math.abs(radialDistances[i] - center) > halfWidth) continue;
                    const margin = marginAt(sampleAt(i));
                    if (margin >= 0 && margin > peakMargin) {
                        peakMargin = margin;
                        peakIndex = i;
                    }
                }
                return peakIndex;
            };

            // An ERC moat may be below the threshold while the outer eyewall
            // is fully valid.  Treat the resolved outer ring as the anchor,
            // rather than demanding a geometrically unbroken threshold band
            // all the way from the inner eyewall.
            let connectedIndex = -1;
            const outerEyewallIsRelevant = Number.isFinite(structure.outerRmw)
                && structure.outerPeak >= threshold;
            if (outerEyewallIsRelevant) {
                const outerHalfWidth = Math.max(
                    12,
                    2.5 * (cyclone.ercOuterWidth || 15)
                );
                connectedIndex = findEyewallPeak(structure.outerRmw, outerHalfWidth);
            }
            if (connectedIndex < 0) {
                connectedIndex = findEyewallPeak(
                    structure.innerRmw,
                    Math.max(10, structure.innerRmw * 0.65)
                );
            }
            if (connectedIndex < 0) return;

            outermost[threshold] = radialDistances[connectedIndex];
            for (let i = connectedIndex + 1; i < radialDistances.length; i++) {
                const previous = sampleAt(i - 1);
                const current = sampleAt(i);
                const previousMargin = marginAt(previous);
                const currentMargin = marginAt(current);
                if (currentMargin >= 0) {
                    outermost[threshold] = current.distance;
                    continue;
                }

                const fraction = previousMargin / Math.max(1e-6, previousMargin - currentMargin);
                outermost[threshold] = previous.distance
                    + (current.distance - previous.distance) * clamp(fraction, 0, 1);
                break;
            }
        });
        directionalCache.set(normalizedAngle, outermost);
        return outermost;
    };

    // Resolve a finer angular field as well as the four operational
    // quadrants.  The latter remain the public/advisory representation;
    // the former prevents the map from drawing an artificial four-sided
    // polygon and preserves translational asymmetry around the storm.
    for (let bin = 0; bin < angularBinCount; bin++) {
        const directional = resolveDirectionalRadii(bin * 360 / angularBinCount);
        thresholds.forEach(threshold => {
            angularResult[threshold][bin] = directional[threshold];
        });
    }

    // Standard advisory order: NE, SE, SW, NW. Angles here are mathematical
    // angles measured counter-clockwise from east.
    const quadrantRanges = [
        { start: 0, end: 90 },
        { start: 270, end: 360 },
        { start: 180, end: 270 },
        { start: 90, end: 180 }
    ];

    for (let quadrantIndex = 0; quadrantIndex < quadrantRanges.length; quadrantIndex++) {
        const range = quadrantRanges[quadrantIndex];
        const quadrantMax = { 34: 0, 50: 0, 64: 0 };
        for (let angle = range.start; angle <= range.end; angle += 10) {
            const outermost = resolveDirectionalRadii(angle);

            thresholds.forEach(threshold => {
                quadrantMax[threshold] = Math.max(quadrantMax[threshold], outermost[threshold]);
            });
        }

        thresholds.forEach(threshold => {
            result[threshold][quadrantIndex] = quadrantMax[threshold];
        });
    }

    return result;
}

function applyCalculatedWindRadii(cyclone, rawRadiiKm) {
    const previousRadii = cyclone.radiiState || {};
    const previousAngularRadii = cyclone.radiiAngularState || {};
    const eyewallStructure = getEyewallStructure(cyclone);
    // A completed ERC changes the reference eyewall in one physical event.
    // Let the stored radii catch up faster on that handoff, while retaining a
    // bounded response so the map and track do not jump to an unfiltered
    // contour in one frame.
    const structuralHandoff = cyclone.ercCompletedAt === cyclone.age;
    const radiiState = {};
    const radiiAngularState = {};
    [34, 50, 64].forEach(threshold => {
        const raw = rawRadiiKm[threshold];
        const previous = Array.isArray(previousRadii[threshold]) ? previousRadii[threshold] : null;
        const rawAngular = Array.isArray(rawRadiiKm.angular?.[threshold])
            ? rawRadiiKm.angular[threshold]
            : [];
        const previousAngular = Array.isArray(previousAngularRadii[threshold])
            && previousAngularRadii[threshold].length === rawAngular.length
            ? previousAngularRadii[threshold]
            : null;
        let rmwFloor = 0;
        if (eyewallStructure.innerPeak >= threshold) rmwFloor = eyewallStructure.innerRmw;
        if (Number.isFinite(eyewallStructure.outerRmw) && eyewallStructure.outerPeak >= threshold) {
            rmwFloor = Math.max(rmwFloor, eyewallStructure.outerRmw);
        }

        radiiState[threshold] = raw.map((rawRadius, quadrant) => {
            if (rawRadius <= 0 || cyclone.intensity < threshold) return 0;
            if (!previous || !Number.isFinite(previous[quadrant]) || previous[quadrant] <= 0) {
                return Math.max(rawRadius, rmwFloor);
            }
            const response = structuralHandoff
                ? (rawRadius >= previous[quadrant] ? 0.82 : 0.72)
                : (rawRadius >= previous[quadrant] ? 0.65 : 0.50);
            const smoothed = previous[quadrant] + (rawRadius - previous[quadrant]) * response;
            return Math.max(smoothed, rmwFloor);
        });

        radiiAngularState[threshold] = rawAngular.map((rawRadius, index) => {
            if (rawRadius <= 0 || cyclone.intensity < threshold) return 0;
            if (!previousAngular || !Number.isFinite(previousAngular[index]) || previousAngular[index] <= 0) {
                return Math.max(rawRadius, rmwFloor);
            }
            const response = structuralHandoff
                ? (rawRadius >= previousAngular[index] ? 0.82 : 0.72)
                : (rawRadius >= previousAngular[index] ? 0.65 : 0.50);
            const smoothed = previousAngular[index] + (rawRadius - previousAngular[index]) * response;
            return Math.max(smoothed, rmwFloor);
        });
    });

    for (let quadrant = 0; quadrant < 4; quadrant++) {
        radiiState[50][quadrant] = Math.min(radiiState[50][quadrant], radiiState[34][quadrant]);
        radiiState[64][quadrant] = Math.min(radiiState[64][quadrant], radiiState[50][quadrant]);
    }
    for (let index = 0; index < radiiAngularState[34].length; index++) {
        radiiAngularState[50][index] = Math.min(radiiAngularState[50][index], radiiAngularState[34][index]);
        radiiAngularState[64][index] = Math.min(radiiAngularState[64][index], radiiAngularState[50][index]);
    }
    cyclone.radiiState = radiiState;
    cyclone.radiiAngularState = radiiAngularState;

    const toDegrees = radiiKm => radiiKm.map(radius => radius / 111.32);
    cyclone.r34 = toDegrees(radiiState[34]);
    cyclone.r50 = toDegrees(radiiState[50]);
    cyclone.r64 = toDegrees(radiiState[64]);
    return cyclone;
}

// Commit the expensive diagnostic and its canonical track record together.
// The browser Worker path calls this only after the matching result returns;
// synchronous callers retain the exact same operation and output ordering.
export function finalizeCycloneStepDiagnostics(
    cyclone,
    rawRadiiKm,
    pressureSystems = null,
    options = {}
) {
    applyCalculatedWindRadii(cyclone, rawRadiiKm);
    const normalizeRadii = radii => Array.isArray(radii) && radii.length === 4
        ? radii
        : [0, 0, 0, 0];
    const radii34 = normalizeRadii(cyclone.r34);
    const radii50 = normalizeRadii(cyclone.r50);
    const radii64 = normalizeRadii(cyclone.r64);
    // Phase diagnostics are sampled at the six-hour product cadence.  The
    // forecast and wind-radii paths never consume this metadata, so a failed
    // diagnostic cannot alter the numerical storm state.
    const phaseIntervalHours = Number.isFinite(options.phaseIntervalHours)
        ? Math.max(3, options.phaseIntervalHours) : 6;
    const phaseDue = Number.isFinite(cyclone.age)
        && Math.abs(cyclone.age / phaseIntervalHours
            - Math.round(cyclone.age / phaseIntervalHours)) < 1e-6;
    const phase = pressureSystems && phaseDue
        ? diagnoseCyclonePhaseSpace(cyclone, pressureSystems, options.phaseOptions)
        : null;
    if (phase) cyclone.phaseDiagnostics = phase;
    cyclone.track.push([
        cyclone.lon,
        cyclone.lat,
        cyclone.intensity,
        cyclone.isTransitioning,
        cyclone.isExtratropical,
        cyclone.circulationSize,
        cyclone.isSubtropical,
        radii34,
        radii50,
        radii64,
        cyclone.centralPressure,
        {
            transitionHours: cyclone.transitionHours || 0,
            transitionElapsedHours: cyclone.transitionElapsedHours || 0,
            extratropicalStage: cyclone.extratropicalStage || 'none',
            extratropicalAgeHours: cyclone.extratropicalAgeHours || 0,
            ...(phase ? { phase } : {})
        }
    ]);
    return cyclone;
}

export function initializeCyclone(world, month, basin = 'WPAC', globalTemp, globalShear, customLon = null, customLat = null) {
    let lat, lon, isOverLand;

    let useCustomCoords = (customLon !== null && customLat !== null);
    
    if (useCustomCoords) {
        isOverLand = world.features.some(feature => d3.geoContains(feature, [customLon, customLat]));
        if (isOverLand) {
            console.warn(`Custom coordinates (${customLon}, ${customLat}) are on land. Falling back to random generation.`);
            useCustomCoords = false;
        } else {
            lon = customLon;
            lat = customLat;
            basin = inferBasinFromCoordinates(lon, lat, basin);
            // console.log(`Using custom generation point: ${lon}, ${lat}`);
        }
    }
    
    if (!useCustomCoords) {
        const selectedBasin = basinConfig[basin] || basinConfig['WPAC']; // WPAC default
        const lonRange = selectedBasin.lon;
        const latBaseRange = selectedBasin.lat;
        const latRangeSpan = latBaseRange.max - latBaseRange.min;
        const hem = latBaseRange.max > 0 ? 1 : -1;
        const seasonalFactor = basin === 'WPAC'
            ? monthlyCirculation(month, hem).summer
            : (Math.cos((month - 8) * (Math.PI / 6)) + 1) / 2;
        const seasonalShift = (latRangeSpan / 4) * (seasonalFactor - 0.5);
        const currentMinLat = latBaseRange.min + seasonalShift + hem*Math.max(0,(globalTemp / 2.89 - 100));
        const seasonalMaxLat = latBaseRange.max + (basin === 'WPAC' ? 2 : 4) * seasonalShift + hem*(globalTemp / 2.89 - 100);
        // In southern winter the legacy seasonal expansion can push the
        // equatorward edge all the way to 0S. Keep that edge within the
        // configured genesis band, including any warming-driven poleward
        // shift. Constrain the sampling interval, not individual draws, so
        // systems do not pile up on its boundary. Forced spawns are untouched.
        const currentMaxLat = hem < 0
            ? Math.min(seasonalMaxLat,
                latBaseRange.max + hem*Math.max(0,(globalTemp / 2.89 - 100)))
            : seasonalMaxLat;
        const latSpan = currentMaxLat - currentMinLat;

        // 4. Don't spawn on land
        let sst;
        // Colder synthetic seasons can make a genesis box unsuitable. Never
        // spin forever (especially with the experimental global-temperature
        // slider). Fail explicitly rather than invent warm water or a storm.
        const maxGenesisAttempts = 256;
        let genesisAttempts = 0;
        do {
            if (genesisAttempts++ >= maxGenesisAttempts) {
                throw new RangeError('No suitable ocean genesis point found (SST ≥ 25.4°C). Choose a warmer month/temperature or custom coordinates.');
            }
            // WPAC genesis has a low-latitude mode and a thinner poleward tail, not a uniform summer box.
            const genesisDraw = Math.random();
            lat = currentMinLat + Math.pow(genesisDraw, basin === 'WPAC' ? 1.6 : 1) * latSpan;
            if (basin === 'WPAC') {
                // Western North Pacific genesis is concentrated in the
                // Philippine Sea / Mariana corridor.  A uniform 100–180E
                // draw overpopulates the dateline and creates an artificial
                // eastern fast-track plume before steering is even applied.
                const sectorDraw = Math.random();
                const positionDraw = Math.random();
                if (sectorDraw < 0.03) lon = 100 + 10 * positionDraw;
                else if (sectorDraw < 0.33) lon = 110 + 20 * positionDraw;
                else if (sectorDraw < 0.79) lon = 130 + 20 * positionDraw;
                else if (sectorDraw < 0.99) lon = 150 + 20 * positionDraw;
                else lon = 170 + 10 * positionDraw;
            } else {
                lon = lonRange.min + Math.random() * (lonRange.max - lonRange.min);
            }
            const status = getLandStatus(lon, lat);
            isOverLand = status.isLand;

            sst = getSST(lat, lon, month, globalTemp);

        } while (isOverLand || sst < 25.4
            || ((basin === 'NATL' || basin === 'EPAC')
                && inferBasinFromCoordinates(lon, lat, basin) !== basin));
        // Genesis boxes can overlap the opposite coast of Central America;
        // reject those ocean points using the same boundary as custom spawns.
    }

    // --- Subtropical ---
    const initialSST = getSST(lat, lon, month, globalTemp);
    let isSubtropical = false;
    let subtropicalTransitionTime = 0;
    if (initialSST < 27.0 && Math.random() < 0.75 && (lon > 122 || lon < 40)) {
        isSubtropical = true;
        const durationSteps = 6 + Math.floor(Math.random() * 21);
        subtropicalTransitionTime = durationSteps * 3;
    }

    let isMonsoonDepression = false;
    let monsoonDepressionEndTime = 0;
    if (Math.random() < (0.2 + globalTemp / 72.25 - 4) && (lat > 0)) {
        isMonsoonDepression = true;
        const durationSteps = Math.floor(Math.random() * 50);
        monsoonDepressionEndTime = durationSteps * 3;
    }

    const initialCirculationSize = 150 + Math.random() * 350;

    return {
        lat: lat,
        lon: lon,
        intensity: 23 + Math.random() * 2,
        direction: Math.random() * 360,
        speed: 10 + Math.random() * 5,
        motionInitialized: false,
        // The dynamical center is kept separate from the operational center
        // fix. This lets weak/transitioning systems wander without turning
        // the environmental steering field into white-noise motion.
        centerFixOffsetEastKm: 0,
        centerFixOffsetNorthKm: 0,
        basin: basin,
        age: 0,
        named: false,
        namedAtAge: null,
        shearEventActive: false,
        shearEventEndTime: 0,
        shearEventMagnitude: 0,
        totalShear: 0,
        // Null means the first resolved environmental shear is adopted
        // immediately; subsequent steps use the 15-hour response memory.
        effectiveShear: null,
        shearDamage: 0,
        shearResilience: 0,
        steeringU: 0,
        steeringV: 0,
        lowLevelU: 0,
        lowLevelV: 0,
        track: [],
        status: 'active',
        isTransitioning: false,
        isLand: isOverLand || false,
        isExtratropical: false,
        isSubtropical: isSubtropical,
        subtropicalTransitionTime: subtropicalTransitionTime,
        subtropicalWarmHours: 0,
        transitionHours: 0,
        transitionElapsedHours: 0,
        baroclinicSupport: 0,
        isMonsoonDepression: isMonsoonDepression,
        monsoonDepressionEndTime: monsoonDepressionEndTime,
        extratropicalStage: 'none',
        extratropicalAgeHours: 0,
        extratropicalDevelopmentEndTime: 0,
        extratropicalMaxIntensity: 0,
        upwellingCoolingEffect: 0,
        oceanWake: [],
        oceanHeatDistribution: 50,
        coldSurgeCoolingEffect: 0,
        coldSurgeInfluence: 0,
        coldSurgeShearBoost: 0,
        isERCActive: false,
        ercState: 'none',
        ercMode: 'none',
        ercLastMode: 'none',
        ercPotential: 0,
        ercEligibleHours: 0,
        ercCycleCount: 0,
        ercStartedCount: 0,
        ercFormationTargetHours: null,
        ercCooldownUntil: 0,
        ercStartTime: 0,
        ercAdverseHours: 0,
        ercInnerRmw: null,
        ercInnerWind: null,
        ercOuterRmw: null,
        ercOuterWindAnomaly: 0,
        ercOuterWidth: 0,
        ercOuterRadarWidthKm: 0,
        ercOuterShare: 0,
        ercOuterOrganization: 0,
        ercInnerIntegrity: 1,
        ercSettlingUntil: 0,
        ercCompletionOutcome: 'none',
        ercCooldownHours: 0,
        ercPostContractionHours: 0,
        ercPace: 1,
        ercRapid: false,
        ercInitialIntensity: 0,
        ercMpiCeiling: null,
        ercReplacementWindTarget: null,
        ercInitialRmw: null,
        ercCompactRecovery: false,
        riUntil: 0,
        riCooldownUntil: 0,
        riRate: 0,
        isRapidIntensifying: false,
        ercInitialSize: 0,
        ercPeakSizeTarget: null,
        ercPostSizeTarget: null,
        ercPostSizeRelaxHours: 0,
        ercPostSizeRelaxUntil: 0,
        ercLastOutcome: 'none',
        ercCompletedAt: 0,
        ercPostContractionUntil: 0,
        ercPostRmwTarget: null,
        circulationSize: initialCirculationSize,
        outerWindBroadness: 0.08 + 0.92 * Math.pow(Math.random(), 0.65),
        rmw: fallbackRmwFromSize(initialCirculationSize),
        radarRmwScale: 1,
        radarEyewallWidthKm: null,
        radarEyewallMaturity: 1,
        environmentFeedbackScale: 1,
        structuralPeakSmoothingAge: null,
        r34: 0, r50: 0, r64: 0,
        forecastLogs: {},
        ace: 0
    };

}

export function initializePressureSystems(cyclone, month) {
    if (!Number.isFinite(month)) month = 8;
    const season = Math.cos((month - 8) * Math.PI / 6);
    const cell = (x,y,sx,sy,strength,role) => ({type:strength<0?'low':'high', x,y,
        sigmaX:sx,baseSigmaX:sx,sigmaY:sy,strength,baseStrength:strength,role,
        velocityX:.03,velocityY:0,oscillationPhase:0,oscillationSpeed:0,noiseLayers:[]});
    const background = {...cell(0,0,360,90,0,'height-background'), seasonalShift:season*4,
        fieldVersion:MODERN_FIELD_VERSION, flowModel:'qg-barotropic-v1',
        zonalProfileVersion: ZONAL_PROFILE_VERSION,
        calendarMonth: Math.round(month), elapsedHours:0, waves:[], tropicalWaves:[],
        equatorialWaves:[],
        activeBasin: cyclone?.basin || 'WPAC',
        singleStormEnvironment: true, weakTropicalWaveVersion: 1,
        frontalPopulationVersion: 2, northAtlanticRidgeVersion: 1,
        steeringClosureVersion: 3,
        axisMappingVersion: 2,
        southernBasicStateVersion: 2,
        climatologyVersion: cyclone?.basin === 'WPAC' && month >= 5 && month <= 10 ? 1 : 0};
    background.zonalProfiles = buildZonalHeightProfiles(background);
    const regionalConfig = REGIONAL_CIRCULATION_CONFIGS[background.activeBasin];
    if (regionalConfig) {
        const active = Math.random() < regionalConfig.activeFrequency;
        const isEpac = background.activeBasin === 'EPAC';
        background.regionalCirculationRegime = {
            basin: background.activeBasin,
            strength: active
                ? .42 + .28 * Math.random()
                : .04 + .12 * Math.random(),
            cycleAmplitude: active
                ? (isEpac ? .16 + .18 * Math.random()
                    : .24 + .18 * Math.random())
                : (isEpac ? .28 + .24 * Math.random()
                    : .64 + .12 * Math.random()),
            phase: 2 * Math.PI * Math.random(),
            // The ENP North Pacific High is allowed to remain in one broad
            // regime for weeks; mobile midlatitude troughs provide shorter
            // breaks. A compulsory 9--12 day full ridge/trough oscillation
            // reversed steering inside nearly every long EPAC simulation.
            periodHours: isEpac
                ? 360 + 240 * Math.random()
                : 216 + 72 * Math.random(),
            driftDegPerHour: .010 + .018 * Math.random(),
            tropicalLonOffset: (Math.random() - .5) * 14,
            tropicalLatOffset: (Math.random() - .5) * 4,
            troughLonOffset: (Math.random() - .5)
                * (regionalConfig.troughLonVariabilityDeg || 16),
            troughLatOffset: (Math.random() - .5) * 5,
            tilt: (Math.random() - .5) * .16
        };
    }
    // The tropical upper-tropospheric trough is its own Pacific-scale state,
    // not a stationary formula centred at one longitude.  Initialize a broad
    // oceanic trough for every atmosphere so it remains present when a TC
    // crosses from the eastern into the western Pacific.
    background.pacificTutt = {
        centerLon: 198 + 18 * Math.random(),
        baseLat: 22 + 4 * Math.random(),
        tilt: .10 + .09 * Math.random(),
        sigmaLon: 42 + 14 * Math.random(),
        sigmaLat: 7.5 + 2.5 * Math.random(),
        strength: .72 + .36 * Math.random(),
        longitudePeriodHours: 360 + 240 * Math.random(),
        latitudePeriodHours: 240 + 180 * Math.random(),
        amplitudePeriodHours: 216 + 192 * Math.random(),
        longitudePhase: 2 * Math.PI * Math.random(),
        latitudePhase: 2 * Math.PI * Math.random(),
        amplitudePhase: 2 * Math.PI * Math.random()
    };
    const monsoonReference = background.climatologyVersion
        ? WNP_MONSOON_CIRCULATION[background.calendarMonth]
        : null;
    if (background.climatologyVersion && month >= 6 && month <= 9) {
        const active = Math.random() < WNP_RECURVATURE_REGIME_FREQUENCY;
        const baseStrength = active ? .78 + .22 * Math.random() : 0;
        background.wnpRecurvatureRegime = {
            // Keep `strength` for snapshot compatibility; live field
            // consumers use the coupled lifecycle strength.
            strength: baseStrength,
            baseStrength,
            cycleAmplitude: active
                ? .04 + .10 * Math.random()
                : .52 + .18 * Math.random(),
            initiallyActive: active,
            phase: 2 * Math.PI * Math.random(),
            periodHours: 240 + 120 * Math.random(),
            initialProgress: .08 + .16 * Math.random(),
            developmentHours: 108 + 48 * Math.random(),
            // Keep the trough west/northwest of 155E so its eastern flank is
            // poleward and increasingly eastward toward the westerly belt.
            troughLon: 140 + 7 * Math.random(),
            troughLat: 34 + 3 * Math.random(),
            sigmaLon: 23 + 6 * Math.random(),
            sigmaLat: 19 + 2 * Math.random(),
            // Keep the trough axis gently southwest-to-northeast. A steep tilt
            // leaves 25--32N storms beneath the trough for days; an opposite
            // tilt disconnects its tropical tail from the poleward corridor.
            // The shallow range below preserves both the eastern-flank
            // poleward current and the later handoff into the westerlies.
            tilt: .06 + .08 * Math.random(),
            driftDegPerHour: .018 + .018 * Math.random(),
            latitudePeriodHours: 240 + 180 * Math.random(),
            amplitudePeriodHours: 216 + 168 * Math.random(),
            latitudePhase: 2 * Math.PI * Math.random(),
            amplitudePhase: 2 * Math.PI * Math.random()
        };
    }
    if (monsoonReference) {
        // This is an atmosphere realization, not a TC-motion perturbation.
        // Every pressure level, map and steering calculation samples the same
        // slowly evolving, tilted monsoon circulation.
        // Three bounded draws produce a smooth, zero-mean distribution with
        // occasional east-extended monsoon gyres over the Philippine Sea.
        // The former +/-6-degree range locked every July gyre west of 130E,
        // so a storm beginning near 155E inevitably left the short poleward
        // flank and re-entered the trades after only one or two days.
        const monsoonLongitudeCoordinate = Math.random() + Math.random()
            + Math.random() - 1.5;
        const monsoonLatitudeCoordinate = Math.random() + Math.random()
            + Math.random() - 1.5;
        const recurvatureStrength = wnpMonsoonLifecycleState(background).strength;
        const uncoupledLon = normalizeLongitude(monsoonReference.lon
            + WNP_MONSOON_CIRCULATION_LONGITUDE_VARIABILITY_DEG
                * monsoonLongitudeCoordinate);
        const uncoupledLat = monsoonReference.lat
            + WNP_MONSOON_CIRCULATION_LATITUDE_VARIABILITY_DEG
                * monsoonLatitudeCoordinate;
        const coupledMonsoonLon = 121 + 6 * Math.random();
        const coupledMonsoonLat = 15 + 2 * Math.random();
        const regimeBlend = .88 * recurvatureStrength;
        background.monsoonCirculation = {
            lon: normalizeLongitude(uncoupledLon
                + normalizeLongitude(coupledMonsoonLon - uncoupledLon) * regimeBlend),
            lat: clamp(
                uncoupledLat + (coupledMonsoonLat - uncoupledLat) * regimeBlend,
                8,
                26
            ),
            amplitude: monsoonReference.amplitude * (.75 + .50 * Math.random())
                * WNP_MONSOON_CIRCULATION_AMPLITUDE_SCALE
                * (1 + 1.15 * WNP_RECURVATURE_MONSOON_AMPLITUDE_BOOST
                    * recurvatureStrength),
            sigmaLon: 27 + WNP_MONSOON_CIRCULATION_SIGMA_LON_OFFSET_DEG
                + 6 * Math.random(),
            sigmaLat: 6.5 + 2 * Math.random(),
            tilt: .08 + .06 * Math.random(),
            longitudePeriodHours: 360 + 180 * Math.random(),
            latitudePeriodHours: 300 + 180 * Math.random(),
            amplitudePeriodHours: 240 + 180 * Math.random(),
            longitudePhase: 2 * Math.PI * Math.random(),
            latitudePhase: 2 * Math.PI * Math.random(),
            amplitudePhase: 2 * Math.PI * Math.random()
        };
    }
    const upper=[background],lower=[],upperOnly=[];
    for (const hemisphere of [1,-1]) {
        const circulation = backgroundMonthlyCirculation(background, hemisphere);
        const summer = circulation.summer;
        const jetLatitude = circulation.jetLatitude;
        const meanFlowMS = 13 + 5 * (1 - summer);
        for(let k=1;k<=8;k++) {
            const longWave = k <= 3;
            // Geopotential-height amplitudes are metres at 500 hPa.  The old
            // 34/12 m values were visually useful but dynamically too weak to
            // bend the jet or produce a meaningful trough passage.
            // Keep the planetary modes in the observed order of magnitude
            // without allowing eight unrelated harmonics to create a
            // 50-kt meridional jet at one longitude.  The jet profile carries
            // the climatological wind; these amplitudes only bend it.
            const amplitude = (longWave ? 96 : 32)
                * (.82 + Math.random()*.36) * circulation.waveFactor;
            const width = longWave ? 15 + Math.random() * 4 : 8 + Math.random() * 4;
            const latitude = (longWave ? jetLatitude - 1 : jetLatitude - 6)
                + (Math.random() - .5) * (longWave ? 7 : 6);
            const wave = {hemisphere,k,amplitude,baseAmplitude:amplitude,
                // A phase-randomized, propagating departure from the monthly
                // mean. This flag prevents archived total-field waves from
                // being re-enabled under the climatology background.
                isTransientAnomaly:true,
                phase:Math.random()*Math.PI*2,
                // Mean-flow-dependent Rossby dispersion: long waves can be
                // stationary or westward, while shorter waves generally move
                // eastward with the jet.
                meanFlowMS,
                latitude,
                width,
                meridionalWavelengthKm: longWave ? 3600 : 2200,
                // This is the meridional displacement of the jet axis, in
                // degrees latitude. Long-wave troughs/ridges should move the
                // jet by several degrees; short waves remain embedded in it.
                axisScaleDeg: longWave ? 4.5 + Math.random() * 3.0 : 0,
                baroclinicAmplitude: amplitude * (.04 + Math.random() * .06),
                verticalTiltRad: (Math.random() - .5) * .10,
                baseVerticalTiltRad: (Math.random() - .5) * .10,
                envelopeHours: longWave ? 168 + Math.random() * 180 : 72 + Math.random() * 120,
                envelopePhase:Math.random()*Math.PI*2};
            wave.phaseSpeedMS = rossbyPhaseSpeedMS(wave);
            wave.frequency = rossbyFrequencyFromSpeed(wave);
            background.waves.push(wave);
        }
        // Tropical easterly/monsoon waves supply the missing low-latitude
        // degrees of freedom.  They are weaker and shorter-lived than the
        // planetary modes, but their phase and sign differ by case, so the
        // trade-wind background does not collapse every storm into a parallel
        // track.  A minority of eastward-propagating modes represents Kelvin
        // or convectively coupled disturbances without making them dominant.
        for (let i = 0; i < 3; i++) {
            const amplitude = 22 + 16 * circulation.monsoonStrength + Math.random() * 8;
            const sign = Math.random() < .76 ? 1 : -1;
            const tropicalWave = {
                hemisphere,
                k: 1 + Math.floor(Math.random() * 3),
                amplitude: (Math.random() < .58 ? 1 : -1) * amplitude,
                baseAmplitude: 0,
                phase: Math.random() * Math.PI * 2,
                frequency: sign * (.012 + .016 * Math.random()),
                latitude: 7 + 10 * summer + (Math.random() - .5) * 3,
                width: 5.5 + Math.random() * 2.5,
                envelopeHours: 96 + Math.random() * 120,
                envelopePhase: Math.random() * Math.PI * 2,
                phaseOffset: Math.random() * Math.PI * 2
            };
            tropicalWave.baseAmplitude = tropicalWave.amplitude;
            background.tropicalWaves.push(tropicalWave);
        }
        // Basin-scale ridge extensions are small perturbations to the continuous ridge.
        for(const longitude of (hemisphere > 0
            ? [175,240,325,65,115]
            : [175,240,325,65])) {
            const latitudeVariability = hemisphere < 0
                ? SOUTHERN_HEMISPHERE_AXIS_VARIABILITY_SCALE : 1;
            // The WNP ridge extension must resolve its western-flank southerly
            // flow. Centering a very weak Gaussian near 175E left 130-150E
            // recurvature almost entirely to beta drift. Keep the synoptic
            // longitude spread and give this extension a real midlevel
            // height gradient.
            const isWesternPacificRidge = longitude === 175;
            const isActiveWesternPacificRidge = isWesternPacificRidge
                && background.activeBasin === 'WPAC';
            const isEasternPacificRidge = hemisphere > 0 && longitude === 240;
            const isNorthAtlanticRidge = hemisphere > 0 && longitude === 325
                && background.northAtlanticRidgeVersion >= 1;
            const isActiveEasternPacificRidge = isEasternPacificRidge
                && background.activeBasin === 'EPAC';
            const isRemoteWesternPacificRidge = isWesternPacificRidge
                && background.activeBasin === 'EPAC';
            const isAsianBridge = hemisphere > 0 && longitude === 115;
            const ridgeLongitude = isWesternPacificRidge ? 180
                : isNorthAtlanticRidge ? NORTH_ATLANTIC_RIDGE_MEAN_LONGITUDE : longitude;
            const x=ridgeLongitude+(Math.random()-.5)*36,
                y=hemisphere*(circulation.ridgeLatitude
                    +(Math.random()-.5)*5*latitudeVariability);
            // The ENP steering high is a zonally elongated extension from
            // southwestern North America, not a compact centre whose western
            // flank supplies basin-wide northerlies. Keep its southern flank
            // broad enough to yield the observed west-to-northwest steering.
            // Geometry belongs to this North Pacific ridge, not the basin in
            // which the TC was initialized. Reuse the existing EPAC widths;
            // do not make its Gulf-facing flank compact in NATL runs.
            const upperSigmaX = isEasternPacificRidge
                ? 44 + Math.random() * 8
                : 22 + Math.random() * 8;
            const ridgeCell = cell(x,y,upperSigmaX,11+Math.random()*2,4+Math.random()*2,'ridge');
            ridgeCell.anomalyScale = isAsianBridge ? 0
                : isActiveWesternPacificRidge ? .58
                    : isActiveEasternPacificRidge ? .48 : .35;
            // In an EPAC realization the continuous monthly/basic-state field
            // already carries the North Pacific ridge across the date line.
            // Do not add the independent 175E WNP weather handle a second
            // time; its western-flank geometry otherwise imposes systematic
            // northerlies near Hawaii despite being outside the active basin.
            ridgeCell.ridgeFieldScale = isRemoteWesternPacificRidge ? 0 : 1;
            ridgeCell.transientRidgeBridge = isAsianBridge;
            ridgeCell.latitudeVariabilityScale = latitudeVariability;
            ridgeCell.oscillationSpeed=.018;
            ridgeCell.oscillationAmount=.20 * latitudeVariability;
            ridgeCell.oscillationPhase=Math.random()*Math.PI*2;
            const ridgeWeatherId = `${hemisphere}:${longitude}`;
            ridgeCell.ridgeWeatherColumn = true;
            ridgeCell.ridgeWeatherId = ridgeWeatherId;
            ridgeCell.ridgeWeatherAnchorLongitude = longitude;
            if (isEasternPacificRidge) ridgeCell.ridgeGeometryProfile = 'enp-v1';
            if (isNorthAtlanticRidge) ridgeCell.ridgeGeometryProfile = 'natl-v1';
            upper.push(ridgeCell);
            // Preserve the calibrated EPAC RNG sequence exactly. Outside
            // EPAC, use a ridge-local stream seeded from an existing draw so
            // adding the width sample does not reshuffle other weather or RI.
            const lowerSigmaX = isActiveEasternPacificRidge
                ? 50 + Math.random() * 6
                : isEasternPacificRidge
                    ? 50 + 6 * synopticRandom({rng: Math.floor(
                        ridgeCell.oscillationPhase / (2 * Math.PI) * 4294967296
                    ) >>> 0})
                    : 30;
            const lowerRidge = cell(x+3,y,
                lowerSigmaX,
                13,3+Math.random()*2,'ridge');
            lowerRidge.anomalyScale = isAsianBridge ? 0
                : isActiveWesternPacificRidge ? .82
                    : isActiveEasternPacificRidge ? .76 : .65;
            lowerRidge.ridgeFieldScale = isRemoteWesternPacificRidge ? 0 : 1;
            lowerRidge.transientRidgeBridge = isAsianBridge;
            lowerRidge.ridgeWeatherColumn = true;
            lowerRidge.ridgeWeatherId = ridgeWeatherId;
            lowerRidge.ridgeWeatherAnchorLongitude = longitude;
            if (isEasternPacificRidge) lowerRidge.ridgeGeometryProfile = 'enp-v1';
            if (isNorthAtlanticRidge) lowerRidge.ridgeGeometryProfile = 'natl-v1';
            lower.push(lowerRidge);
        }
        for(const longitude of (hemisphere>0?[90,140]:[85,155])) {
            const y=hemisphere*circulation.monsoonAxis;
            upper.push(cell(longitude,y,23,6,1.2+1.1*circulation.monsoonStrength,'monsoon'));
            lower.push(cell(longitude,y,28,8,
                -(2+2*summer) * (.90 + .10*circulation.monsoonStrength), 'monsoon'));
        }
        // Boreal-summer upper anticyclone over South Asia.  This is kept as
        // an upper-only cell so it can steer a deep tropical vortex from its
        // southern flank without turning the low-level monsoon trough into a
        // continent-wide westward conveyor.  The seasonal longitude follows
        // the observed west/east migration of the monsoon anticyclone.
        if (hemisphere > 0 && circulation.southAsianHighStrength > .12) {
            const sah = cell(
                circulation.southAsianHighLongitude,
                24 + 3 * circulation.summer,
                23 + 4 * circulation.summer,
                6 + .7 * circulation.summer,
                3.8 + 2.8 * circulation.southAsianHighStrength,
                'south-asian-high'
            );
            sah.anomalyScale = .78;
            // In July–August the South Asian High's 200-hPa geopotential
            // height should commonly approach 12,560 m, with stronger and
            // weaker realizations still represented by the stochastic cell
            // amplitude and planetary-wave background. The 500-hPa projection
            // is calibrated separately because it directly affects
            // low-latitude steering.
            sah.level200AnomalyScale = .78 + .84 * circulation.southAsianHighStrength;
            sah.velocityX = 0;
            sah.velocityY = 0;
            // The climatological cell is only the mean state.  Give each
            // synthetic case its own displaced/elongated version, then let
            // the cell breathe and wobble on synoptic (multi-day) time
            // scales instead of stamping the same westward corridor onto
            // every storm.
            sah.baseX = sah.x;
            sah.baseY = sah.y;
            sah.baseStrength = sah.strength;
            sah.baseSigmaX = sah.sigmaX;
            sah.baseSigmaY = sah.sigmaY;
            // Subtract the nominal seasonal cell, not this run's random
            // realization. Otherwise every initial SAH displacement/strength
            // perturbation cancels exactly and the displayed handle has no
            // corresponding initial weather anomaly in the steering field.
            if (background.climatologyVersion) sah.climatologyReference = { ...sah };
            sah.x = normalizeLongitude(sah.x + (Math.random() - .5) * 8);
            sah.y += (Math.random() - .5) * 2;
            sah.strength *= .84 + .32 * Math.random();
            sah.sigmaX *= .90 + .20 * Math.random();
            sah.sigmaY *= .90 + .20 * Math.random();
            sah.baseX = sah.x;
            sah.baseY = sah.y;
            sah.baseStrength = sah.strength;
            sah.baseSigmaX = sah.sigmaX;
            sah.baseSigmaY = sah.sigmaY;
            sah.variabilityPhase = Math.random() * Math.PI * 2;
            sah.wavePhaseOffset = Math.random() * Math.PI * 2;
            sah.oscillationSpeed = .08 + .05 * Math.random();
            sah.oscillationAmount = 0;
            sah.synopticDisplacementLon = 0;
            sah.synopticDisplacementLat = 0;
            sah.synopticStrengthPerturbation = 0;
            sah.synopticWidthPerturbation = 0;
            sah.synopticRng = (
                Math.floor((sah.baseX + 180) * 100000)
                ^ Math.floor((sah.baseY + 90) * 10000)
                ^ Math.floor(sah.baseStrength * 1000)
            ) >>> 0 || 1;
            sah.ridgeBreakRemainingHours = 0;
            sah.ridgeBreakTotalHours = 0;
            sah.ridgeBreakLonShift = 0;
            sah.ridgeBreakLatShift = 0;
            sah.ridgeBreakStrength = 0;
            upperOnly.push(sah);
        }
    }
    // Broad, propagating equatorial low-height sectors restore a modest
    // 500-hPa zonal gradient near the equator. Keep them at planetary scale
    // and cap their combined depression at 20 m in the field calculation so
    // they cannot masquerade as compact tropical or cold-core vortices.
    for (let i = 0; i < 2; i++) {
        const amplitude = 10 + Math.random() * 10;
        background.equatorialWaves.push({
            k: 1 + Math.floor(Math.random() * 2),
            amplitude,
            baseAmplitude: amplitude,
            phase: Math.random() * Math.PI * 2,
            frequency: (Math.random() < .78 ? 1 : -1)
                * (.006 + .008 * Math.random()),
            latitude: (Math.random() - .5) * 4,
            width: 7 + Math.random() * 3,
            envelopeHours: 96 + Math.random() * 96,
            envelopePhase: Math.random() * Math.PI * 2
        });
    }
    // Append upper-only cells after the paired upper/lower cells so the
    // diagnostic fieldId correspondence below remains intact.
    upper.push(...upperOnly);
    lower.forEach((entry,index)=>{entry.fieldId=`environment-${index}`;upper[index+1].fieldId=entry.fieldId;});
    // Keep a weak winter precursor in the Siberian source region from the
    // start of a run. This represents the slowly varying continental high;
    // individual cold surges then grow out of it instead of appearing as a
    // fully formed pressure centre on an arbitrary update step.
    if (coldSurgeSeason(month).initialProbability > 0
        && Math.random() < coldSurgeSeason(month).initialProbability) {
        lower.push(createColdSurge(true, Math.random, month));
    }
    for (const wave of background.waves.filter(w => (w.k === 3 || w.k === 6)
        && (!background.climatologyVersion || w.isManual))) {
        const handle = cell(140,wave.hemisphere*wave.latitude,12,10,-8,'wave-handle');
        handle.waveKey = `${wave.hemisphere}:${wave.k}`;
        handle.velocityX=0;
        upper.push(handle);
    }
    if (background.climatologyVersion) {
        for (const entry of [...upper,...lower]) {
            if (['ridge','monsoon','south-asian-high'].includes(entry.role) && !entry.isManual) {
                if (!entry.climatologyReference) entry.climatologyReference = { ...entry };
            }
        }
    }
    initializeSynopticField(background,upper,cyclone);
    if (cyclone?.useObservedWeather !== true) {
        // A monthly mean cannot represent a strong weather-scale ridge core.
        // V2 samples mature amplitude and shape states, rather than forcing
        // every new storm through a shared periodic growth/decay cycle.
        // These are model scenario choices, not observational calibration.
        const ridges = upper.filter(entry => entry.ridgeWeatherColumn);
        background.ridgeWeathers = ridges.map((ridge, index) =>
            initializeSubtropicalRidgeWeather(
                ridge,
                (background.synoptic.rng ^ 0x3c6ef372
                    ^ (ridge.ridgeWeatherId === '1:175'
                        ? 0 : Math.imul(index + 1, 0x9e3779b1))) >>> 0 || index + 1
                ,background
            )
        );
        // Preserve the original WNP handle for diagnostics and archived tests.
        background.ridgeWeather = background.ridgeWeathers.find(
            weather => weather.id === '1:175'
        ) || background.ridgeWeathers[0];
        updateSubtropicalRidgeWeather({upper,lower},background);
    }
    if (background.climatologyVersion && cyclone?.useObservedWeather === true) {
        background.weatherSequence = initializeWeatherSequence(month,background.synoptic.rng);
        // The observed sequence already contains transient troughs and highs.
        // Remove procedural weather rather than doubling its field/ET effects.
        background.synoptic = null;
        upper.splice(1); lower.splice(0);
    }
    synchronizeWaveHandles(upper,background);
    return {upper,lower};
}

function ridgeComponentHeight(lon,lat,component) {
    const dx = normalizeLongitude(lon-component.x);
    const dy = lat-component.y-component.tilt*dx;
    const distance = Math.hypot(dx/component.sigmaX,dy/component.sigmaY);
    // Ridge lobes are broad mass-field features, so use the Gaussian tail
    // directly.  The former finite-radius C1 cutoff changed curvature at two
    // fixed radii; where that edge met the monthly field it produced pointed
    // contour cusps and abrupt steering-direction changes.
    return component.heightM * Math.exp(-.5*distance*distance);
}

function initializeSubtropicalRidgeWeather(ridge,seed,background = null) {
    const weather={version:3,rng:seed,lastElapsedHours:0,
        id:ridge.ridgeWeatherId,
        anchorLongitude:ridge.ridgeWeatherAnchorLongitude,
        geometryProfile:ridge.ridgeGeometryProfile,
        lon:ridge.x,lat:ridge.y,sigmaX:ridge.sigmaX,sigmaY:ridge.sigmaY,latent:{},forcing:{}};
    // Weather regimes are persistent. Most ridge realizations remain in a
    // stable configuration for several days, while a minority are genuinely
    // active. Sampling that persistence once per atmosphere avoids making
    // every ridge deform at the same compulsory synoptic rate.
    const isWnp = weather.id === '1:175'
        && background?.activeBasin === 'WPAC';
    const stableRegime = synopticRandom(weather) < (isWnp ? .42 : .62);
    weather.regimePersistenceScale = stableRegime
        ? (isWnp ? 1.45 + .45 * synopticRandom(weather)
            : 2.2 + .8 * synopticRandom(weather))
        : (isWnp ? .78 + .37 * synopticRandom(weather)
            : .78 + .32 * synopticRandom(weather));
    // Keep the nominal stationary initial spread and random draws unchanged:
    // no age-zero growth envelope or prescribed weak-to-strong start.
    // This predates the regime-dependent clocks used during evolution.
    for(const [key,tau] of Object.entries(ridgeWeatherTimescales())) {
        const r=Math.exp(-MODEL_STEP_HOURS/tau),s=Math.exp(-MODEL_STEP_HOURS/36);
        const covariance=(1-s)/(1-s*r);
        const variance=((1-s)**2+2*s*(1-s)*r*covariance)/(1-s*s);
        weather.forcing[key]=synopticNormal(weather);
        weather.latent[key]=covariance*weather.forcing[key]
            + Math.sqrt(Math.max(0,variance-covariance*covariance))*synopticNormal(weather);
    }
    return weather;
}

function ridgeWeatherTimescales() {
    return {strength:72,lon:96,lat:96,width:72,aspect:72,tilt:72,split:72,balance:72};
}

function updateSingleSubtropicalRidgeWeather(systems, background, weather) {
    if (!weather) return;
    if (weather.version >= 2) {
        const elapsed=background.elapsedHours || 0;
        const dt=Math.max(0,elapsed-weather.lastElapsedHours);
        if(dt>0) {
            // Independent correlated shape coordinates replace a rigid
            // periodic template. Amplitude, displacement and splitting need
            // not peak together. RNG advances only with atmospheric time.
            for(const [key,tau] of Object.entries(ridgeWeatherTimescales())) {
                const persistence = Number.isFinite(weather.regimePersistenceScale)
                    ? weather.regimePersistenceScale : 1;
                const timeScale = weather.version >= 3
                    ? RIDGE_WEATHER_EVOLUTION_TIME_SCALE : 1;
                const retention=Math.exp(-dt/(tau*persistence*timeScale));
                weather.forcing[key]=retention*weather.forcing[key]
                    + Math.sqrt(1-retention*retention)*synopticNormal(weather);
                // Filter the stochastic tendency over a regime-dependent
                // multi-day response so six-hour
                // chart frames deform continuously instead of changing
                // topology when a shape coordinate crosses a threshold.
                const shapeResponseHours = 42 * Math.sqrt(persistence) * timeScale;
                weather.latent[key]+=(weather.forcing[key]-weather.latent[key])
                    *(1-Math.exp(-dt/shapeResponseHours));
            }
            weather.lastElapsedHours=elapsed;
        }
        const q=weather.latent;
        // WNP-specific geometry belongs only to a WNP atmosphere. In an EPAC
        // run the 175E handle is disabled and the 240E ridge owns the active
        // North Pacific lifecycle.
        const isWnp = weather.id === '1:175'
            && background.activeBasin === 'WPAC';
        const regionalLifecycle = regionalCirculationLifecycleState(background);
        const isActiveBasinRidge = Boolean(regionalLifecycle.config
            && weather.id === regionalLifecycle.config.ridgeId);
        // New atmospheres share the EPAC-calibrated geometry by ridge
        // identity. The basin fallback preserves archived EPAC snapshots;
        // other unversioned snapshots retain their previous geometry.
        const usesEasternPacificGeometry = weather.id === '1:240'
            && (weather.geometryProfile === 'enp-v1'
                || background.activeBasin === 'EPAC');
        const usesNorthAtlanticGeometry = weather.id === '1:325'
            && weather.geometryProfile === 'natl-v1';
        const regionalStrength = isActiveBasinRidge ? regionalLifecycle.strength : 0;
        const variabilityScale = isWnp || isActiveBasinRidge ? 1 : .85;
        const wnpLifecycle = isWnp
            ? wnpMonsoonLifecycleState(background)
            : { strength: 0, progress: 0 };
        const split=smoothstep((q.split+.40
            +.32*Math.max(regionalStrength, wnpLifecycle.strength))/1.6);
        const corridorTarget = isWnp ? smoothstep((split - .48) / .34) : 0;
        const previousCorridor = Number.isFinite(weather.corridorEnvelope)
            ? weather.corridorEnvelope : corridorTarget;
        const corridorResponseHours = corridorTarget > previousCorridor
            ? 36 * Math.sqrt(weather.regimePersistenceScale || 1)
            : WNP_RIDGE_CORRIDOR_DECAY_HOURS;
        weather.corridorEnvelope = previousCorridor
            + (corridorTarget - previousCorridor)
                * (1 - Math.exp(-Math.max(MODEL_STEP_HOURS, dt) / corridorResponseHours));
        // Keep the weather-scale ridge as a positive-height feature. The old
        // -15..105 m range both over-tightened its gradient and could turn a
        // strongly negative realization into another artificial low. A
        // -12..40 m envelope retains meaningful ridge pulses while reducing
        // the strongest contour packing by roughly 20-25 m.
        const regionalWeakening = isActiveBasinRidge
            ? regionalLifecycle.config.ridgeWeakening * regionalStrength
                * (.55 + .45 * regionalLifecycle.pulse)
            : 0;
        // In the WNP lifecycle the monsoon trough, poleward channel and ridge
        // retreat are one state. Previously the trough strengthened while the
        // positive ridge anomaly kept its full mass, so the "opening" merely
        // deformed an otherwise unbroken Pacific slab.
        const wnpWeakening = isWnp
            ? .38 * wnpLifecycle.strength * (.45 + .55 * wnpLifecycle.progress)
            : 0;
        // The WNP monthly reanalysis field already contains its broad mean
        // subtropical high. Its procedural component is weather departure,
        // not a second full-strength ridge laid over that mean.
        const height=(isWnp
            ? clamp(30+36*Math.tanh(q.strength),0,34)
            : clamp(36+44*Math.tanh(q.strength),0,40))
            * (isWnp || isActiveBasinRidge ? 1 : .85)
            * (1-regionalWeakening)
            * (1-wnpWeakening);
        const recurvatureStrength = isWnp ? wnpLifecycle.strength : 0;
        const recurvatureProgress = isWnp ? wnpLifecycle.progress : 0;
        const stochasticX = normalizeLongitude(weather.lon
            + (isWnp ? WNP_RIDGE_LONGITUDE_VARIABILITY_DEG : 26) * Math.tanh(q.lon));
        const lifecycleX = normalizeLongitude(weather.lon
            + WNP_RECURVATURE_RIDGE_EAST_SHIFT_DEG * recurvatureProgress);
        const lifecycleBlend = .88 * recurvatureStrength;
        const wnpX = normalizeLongitude(stochasticX
            + normalizeLongitude(lifecycleX - stochasticX) * lifecycleBlend);
        const regionalTargetX = isActiveBasinRidge
            ? normalizeLongitude(weather.lon
                + regionalLifecycle.config.ridgeLonShiftDeg * regionalLifecycle.pulse)
            : wnpX;
        const regionalBlend = .72 * regionalStrength;
        const blendedX = normalizeLongitude(wnpX
            + normalizeLongitude(regionalTargetX - wnpX) * regionalBlend);
        // The ENP high may retract toward North America or extend westward,
        // but its synoptic centre cannot jump west of a central-Pacific TC
        // and turn the whole basin into the compact high's eastern flank.
        const blendedX360 = ((blendedX % 360) + 360) % 360;
        const x = usesEasternPacificGeometry
            ? normalizeLongitude(clamp(blendedX360,218,258))
            : blendedX;
        weather.currentLon = x;
        // Synoptic WNP ridge axes can shift far enough equatorward that a
        // genesis point near 168E, 16N lies on the western flank rather than
        // beneath the same zonal southern edge in every realization.  Keep
        // this displacement in the common height field; the long response
        // time prevents it from becoming a track-level random velocity.
        const easternAxisFreedom = smoothstep(normalizeLongitude(x-145)/25);
        const latitudeFreedom = isWnp
            ? WNP_RIDGE_LATITUDE_VARIABILITY_BASE_DEG
                + WNP_RIDGE_LATITUDE_VARIABILITY_EASTERN_DEG*easternAxisFreedom
            : usesEasternPacificGeometry ? 8 : 18*variabilityScale;
        // Eastward-retreating WNP ridges commonly expose an equatorward,
        // poleward-flowing western flank. Represent that covariance in the
        // height feature itself instead of requiring two independent extreme
        // draws (east displacement and south displacement) at once.
        const ridgeLatitudeCoordinate = isWnp
            ? q.lat-WNP_RIDGE_RETREAT_EQUATORWARD_COUPLING*q.lon
            : q.lat;
        const stochasticY = weather.lat
            + latitudeFreedom * Math.tanh(ridgeLatitudeCoordinate);
        const lifecycleY = weather.lat
            + WNP_RECURVATURE_RIDGE_POLEWARD_SHIFT_DEG * recurvatureProgress;
        const wnpY = stochasticY + (lifecycleY - stochasticY) * lifecycleBlend;
        const regionalTargetY = isActiveBasinRidge
            ? weather.lat + regionalLifecycle.config.hemisphere
                * regionalLifecycle.config.ridgeLatShiftDeg * regionalLifecycle.pulse
            : wnpY;
        const rawY = wnpY + (regionalTargetY - wnpY) * regionalBlend;
        // Weather-scale ridge displacement must not relocate a July WNP
        // subtropical axis into the deep tropics or the polar-front belt.
        // Those 6N/55N realizations removed the gradient near 16N and created
        // recurrent calm cols. Retain substantial synoptic freedom inside a
        // climatologically plausible envelope around the monthly axis.
        const y = isWnp
            ? clamp(rawY,weather.lat-12,weather.lat+14)
            : usesEasternPacificGeometry
                ? clamp(rawY,weather.lat-6,weather.lat+8)
                : isActiveBasinRidge
                    ? clamp(rawY,weather.lat-12,weather.lat+14)
                    : rawY;
        // A split ridge is still one planetary-scale anticyclonic belt.  The
        // old combination (40 degrees between centres and only 35% of the
        // original lobe width) excavated an unrealistically narrow col whose
        // gradient rotated almost discontinuously across a few grid cells.
        const sampledWidth=weather.sigmaX*(isWnp?.92:1)
            *(1+.20*Math.tanh(q.width))*(1-.48*split);
        const width=usesEasternPacificGeometry?Math.max(36,sampledWidth):sampledWidth;
        const sy=weather.sigmaY*(.9+.2*Math.tanh(q.aspect));
        const tilt=(usesEasternPacificGeometry ? .075 : .22)*Math.tanh(q.tilt);
        const separation=(usesEasternPacificGeometry?10:18)*split;
        const normalization=1+Math.exp(-.5*(2*separation/width)**2);
        const components=[-1,1].map(sign=>({
            x:normalizeLongitude(x+sign*separation),y:y+sign*separation*tilt,
            sigmaX:width,sigmaY:sy,tilt,
            heightM:height*(1+sign*.18*Math.tanh(q.balance)*split)/normalization
        }));
        // Preserve a western maritime shoulder on the southern flank of the
        // WNP ridge. It is deliberately west of the oceanic centre and has no
        // positive floor: the old 38-degree, always-on shoulder followed the
        // core to the dateline and filled nearly the whole 145E-145W sector,
        // erasing genuine ridge weaknesses for a week or more.
        components.push({
            kind:'ridge-maritime-shoulder',
            x:normalizeLongitude(x+(isWnp?-20+6*split
                : usesNorthAtlanticGeometry ? -width : 0)),
            y:isWnp?y-3:y,
            // Reuse the parent's width and strength for its Atlantic western
            // extension. It retreats, weakens and splits with the same high;
            // there is no independent always-on positive floor over the Gulf.
            sigmaX:isWnp?WNP_RIDGE_SHOULDER_SIGMA_LON_DEG
                : usesNorthAtlanticGeometry ? weather.sigmaX : 42,
            sigmaY:isWnp?10.5:12,
            tilt:.04*Math.tanh(q.tilt),
            heightM:clamp((isWnp?.34:.38)*height,
                isWnp?WNP_RIDGE_SHOULDER_MIN_HEIGHT_M
                    : usesNorthAtlanticGeometry ? 0 : 7,
                isWnp?WNP_RIDGE_SHOULDER_MAX_HEIGHT_M:18)
                *(1-(isWnp?WNP_RIDGE_SHOULDER_SPLIT_DECAY:.45)*split)
        });
        // The WNP high is not confined to the oceanic mean centre. During a
        // west-displaced phase its western ridge can extend across Indochina;
        // if the parent ridge simultaneously splits, the bridge narrows into
        // a small residual land high. This remains one evolving height field,
        // not an independent pressure system or a cyclone-motion correction.
        const westwardExtension=isWnp?smoothstep((-q.lon-.20)/1.10):0;
        const landIsolation=westwardExtension*smoothstep((q.split-.42)/.50);
        if(westwardExtension>0) {
            const strengthGate=smoothstep((q.strength+.45)/1.35);
            // Detachment is a continuous morphology change.  The former
            // boolean switch relocated the centre by 10 degrees and narrowed
            // it in one frame, creating a visible height-field jump even
            // though the underlying weather coordinates were smooth.
            const detachment=smoothstep((landIsolation-.38)/.34);
            const westernHeight=(14+24*strengthGate)*westwardExtension
                *(1+1.15*landIsolation);
            components.push({
                kind:detachment>.5?'ridge-land-high':'ridge-western-extension',
                // Move only the detached continental core eastward; the
                // parent ridge and its ordinary western extension stay put.
                x:normalizeLongitude(x-24-13*westwardExtension-5*landIsolation
                    +10*detachment),
                y:y-3-2*landIsolation,
                sigmaX:18-10*landIsolation,
                sigmaY:9-3*landIsolation,
                tilt:-.05,
                heightM:clamp((1-.16*detachment)*westernHeight,
                    0,45-7*detachment)
            });
        }
        // A split ridge now forms a gap only through separation of its two
        // positive-height lobes. Do not excavate the bridge with a negative
        // Gaussian: that turns a ridge weakness into a spurious closed low.
        weather.splitFraction=split;
        for(const cell of [...systems.upper,...systems.lower]) {
            if(!cell.ridgeWeatherColumn
                || (weather.id && cell.ridgeWeatherId !== weather.id))continue;
            cell.ridgeHeightAnomalyM=height;
            cell.ridgeWeatherComponents=components;
        }
        return;
    }
    const phase = weather.phase + 2 * Math.PI * (background.elapsedHours || 0) / weather.periodHours;
    const height = weather.meanM + weather.amplitudeM * Math.sin(phase);
    for (const cell of [...systems.upper,...systems.lower]) {
        if (!cell.ridgeWeatherColumn
            || (weather.id && cell.ridgeWeatherId !== weather.id)) continue;
        cell.ridgeHeightAnomalyM = height;
        cell.ridgeWeatherGeometry = {
            x: normalizeLongitude(weather.lon + 4 * Math.sin(phase) - 4 * Math.sin(weather.phase)),
            y: weather.lat + 1.5 * (Math.cos(phase) - Math.cos(weather.phase)),
            sigmaX: weather.sigmaX, sigmaY: weather.sigmaY
        };
    }
}

function updateSubtropicalRidgeWeather(systems, background) {
    const weathers = Array.isArray(background?.ridgeWeathers)
        ? background.ridgeWeathers
        : background?.ridgeWeather ? [background.ridgeWeather] : [];
    for (const weather of weathers) {
        updateSingleSubtropicalRidgeWeather(systems, background, weather);
    }
}

function synchronizeWaveHandles(cells,background) {
    for (const handle of cells.filter(c => c.role === 'wave-handle')) {
        const wave=background.waves.find(w => `${w.hemisphere}:${w.k}` === handle.waveKey);
        if (!wave) continue;
        const period=360/wave.k;
        const base=(Math.PI-wave.phase)/wave.k*180/Math.PI;
        handle.x=base+Math.round((handle.x-base)/period)*period;
        handle.y=wave.hemisphere*wave.latitude;
    }
}

export function updatePressureSystems(systemsObj, month) {
    // This object is evolved in place. Drop point-evaluation results before
    // changing wave phases or synoptic cells so a new model step can never
    // reuse the previous step's atmosphere.
    clearAtmosphereEvaluationCache(systemsObj);
    const background = systemsObj.upper?.find(c => c.role === "height-background");
    ensureModernAtmosphericState(background);
    if (background && Number.isFinite(month)) {
        const calendarMonth = ((Math.round(month) - 1) % 12 + 12) % 12 + 1;
        if (background.calendarMonth !== calendarMonth) {
            background.calendarMonth = calendarMonth;
            background.zonalProfiles = buildZonalHeightProfiles(background);
            background.zonalProfileVersion = ZONAL_PROFILE_VERSION;
        }
    }
    if (background?.waves) { advanceWaveField(background); synchronizeWaveHandles(systemsObj.upper,background); }
    const updateList = (list) => {
        for (let i = list.length - 1; i >= 0; i--) {
            const cell = list[i];

            // Cold-surge highs need their own slow mass-field lifecycle. The
            // previous generic cell update moved a compact high diagonally and
            // then multiplied its pressure by a hard latitude cutoff, which
            // made the high appear, jump and vanish as a single symbol.
            if (cell.isColdSurge) {
                const ageHours = Math.max(0, cell.ageHours || 0);
                const growthHours = Math.max(24, cell.growthHours || 48);
                const decayHours = Math.max(48, cell.decayHours || 96);
                const lifeHours = Math.max(
                    growthHours + decayHours + 24,
                    cell.lifeHours || 384
                );
                const decayStartHours = Math.max(
                    growthHours + 24,
                    cell.decayStartHours || lifeHours - decayHours
                );
                const growth = smoothstep(ageHours / growthHours);
                const decay = 1 - smoothstep(
                    (ageHours - decayStartHours) / decayHours
                );
                const targetEnvelope = clamp(growth * decay, 0, 1);
                const currentEnvelope = Number.isFinite(cell.fieldEnvelope)
                    ? cell.fieldEnvelope
                    : clamp((cell.strength || 0) / Math.max(1, cell.baseStrength || 1), 0, 1);
                const response = 1 - Math.exp(-MODEL_STEP_HOURS / 24);
                cell.fieldEnvelope = clamp(
                    currentEnvelope + (targetEnvelope - currentEnvelope) * response,
                    0,
                    1
                );
                const peakStrength = Number.isFinite(cell.peakStrength)
                    ? cell.peakStrength
                    : Math.max(1, cell.baseStrength || cell.strength || 20);
                cell.peakStrength = peakStrength;
                cell.baseStrength = peakStrength;
                cell.strength = peakStrength * cell.fieldEnvelope;
                cell.sigmaX = (cell.baseSigmaX || cell.sigmaX || 16)
                    * (.92 + .30 * cell.fieldEnvelope);
                cell.sigmaY = (cell.baseSigmaY || cell.sigmaY || 11)
                    * (.94 + .18 * cell.fieldEnvelope);
                cell.meanderPhase = (cell.meanderPhase || 0)
                    + (cell.meanderRate || .02);
                const meander = Math.sin(cell.meanderPhase);
                const lowLevelFlow = gradientWind(
                    cell.x,
                    cell.y,
                    (x, y) => waveFieldComponents(x, y, background, 850).height,
                    9.80665
                );
                const flowLon = lowLevelFlow.u * MODEL_STEP_HOURS * 3600
                    / (111320 * Math.max(.3, Math.cos(cell.y * Math.PI / 180)));
                const flowLat = lowLevelFlow.v * MODEL_STEP_HOURS * 3600 / 111320;
                const transportFactor = .72 + .68 * cell.fieldEnvelope;
                cell.x = normalizeLongitude(
                    cell.x + (cell.velocityX || .18) * transportFactor
                        + (cell.flowAdvectionWeight || .14) * flowLon
                        + .018 * meander
                );
                cell.y = clamp(
                    cell.y + (cell.velocityY || -.06) * transportFactor
                        + (cell.flowAdvectionWeight || .14) * .55 * flowLat
                        + .010 * Math.cos(cell.meanderPhase * .73),
                    15,
                    60
                );
                cell.ageHours = ageHours + MODEL_STEP_HOURS;
                cell.phase = cell.fieldEnvelope < .04
                    ? 'precursor'
                    : cell.fieldEnvelope > .72
                        ? 'mature'
                        : cell.ageHours >= decayStartHours
                            ? 'decaying'
                            : 'developing';
                cell.fadeHours = cell.fieldEnvelope < .02
                    ? (cell.fadeHours || 0) + MODEL_STEP_HOURS
                    : 0;
                const upperTrough = coldSurgeUpperTroughState(cell);
                if (cell.ageHours >= lifeHours + 48
                    && cell.fadeHours >= 12
                    && cell.fieldEnvelope < .02
                    && (upperTrough?.envelope || 0) < .02) {
                    list.splice(i, 1);
                    continue;
                }
            } else {
                cell.x += cell.velocityX;
                cell.y += cell.velocityY;
                if (cell.x > 360) cell.x -= 360;
                if (cell.x < 0) cell.x += 360;
            }

            if (cell.oscillationSpeed) {
                cell.oscillationPhase = (cell.oscillationPhase || 0) + cell.oscillationSpeed;
                const stretch = Math.sin(cell.oscillationPhase) * cell.oscillationAmount;
                if (cell.baseSigmaX) {
                    cell.sigmaX = cell.baseSigmaX * (1 + stretch);
                }
            }

            if (cell.role === 'south-asian-high' && Number.isFinite(cell.baseX)) {
                const phase = cell.oscillationPhase || 0;
                const longWaveSignal = (background?.waves || [])
                    .filter(wave => wave.hemisphere > 0 && wave.k <= 3)
                    .reduce((sum, wave) => sum
                        + .24 * Math.sin(wave.phase + (cell.wavePhaseOffset || 0) + wave.k * .35), 0);
                // Add a low-frequency, atmosphere-owned perturbation. An
                // independent redraw on every step would make the high jump
                // and would inject noise into the shear field; the AR(1)
                // update keeps the displacement coherent for roughly two days
                // and is shared by all three pressure levels.
                const synopticState = background?.synoptic;
                let ridgeBreakEnvelope = 0;
                if (synopticState) {
                    const retention = Math.exp(-MODEL_STEP_HOURS
                        / SOUTH_ASIAN_HIGH_PERTURBATION_RESPONSE_HOURS);
                    const innovation = Math.sqrt(1 - retention * retention);
                    cell.synopticDisplacementLon = clamp(
                        retention * (cell.synopticDisplacementLon || 0)
                            + innovation * SOUTH_ASIAN_HIGH_PERTURBATION_LON_SIGMA_DEG
                                * southAsianHighNormal(cell),
                        -11,
                        11
                    );
                    cell.synopticDisplacementLat = clamp(
                        retention * (cell.synopticDisplacementLat || 0)
                            + innovation * SOUTH_ASIAN_HIGH_PERTURBATION_LAT_SIGMA_DEG
                                * southAsianHighNormal(cell),
                        -3.2,
                        3.2
                    );
                    cell.synopticStrengthPerturbation = clamp(
                        retention * (cell.synopticStrengthPerturbation || 0)
                            + innovation * SOUTH_ASIAN_HIGH_PERTURBATION_STRENGTH_SIGMA
                                * southAsianHighNormal(cell),
                        -.24,
                        .24
                    );
                    cell.synopticWidthPerturbation = clamp(
                        retention * (cell.synopticWidthPerturbation || 0)
                            + innovation * SOUTH_ASIAN_HIGH_PERTURBATION_WIDTH_SIGMA
                                * southAsianHighNormal(cell),
                        -.18,
                        .18
                    );
                    // A small fraction of monsoon-anticyclone realizations
                    // experience a short upper-trough intrusion. Represent it
                    // as a smooth, finite-lived ridge break: the high retreats
                    // east, weakens, and broadens for roughly 1–2 days before
                    // recovering. This is the directional perturbation needed
                    // to open occasional non-westward tracks near 119E, 19N.
                    if ((cell.ridgeBreakRemainingHours || 0) <= 0
                        && southAsianHighRandom(cell) < 1 - Math.exp(-MODEL_STEP_HOURS / 240)) {
                        cell.ridgeBreakTotalHours = 30 + 24 * southAsianHighRandom(cell);
                        cell.ridgeBreakRemainingHours = cell.ridgeBreakTotalHours;
                        cell.ridgeBreakLonShift = 5 + 5 * southAsianHighRandom(cell);
                        cell.ridgeBreakLatShift = (southAsianHighRandom(cell) - .5) * 2.4;
                        cell.ridgeBreakStrength = .10 + .10 * southAsianHighRandom(cell);
                    }
                    if ((cell.ridgeBreakRemainingHours || 0) > 0) {
                        const breakAge = Math.max(
                            0,
                            (cell.ridgeBreakTotalHours || 0) - cell.ridgeBreakRemainingHours
                        );
                        ridgeBreakEnvelope = Math.sin(
                            Math.PI * clamp(
                                breakAge / Math.max(1, cell.ridgeBreakTotalHours || 1),
                                0,
                                1
                            )
                        ) ** 2;
                        cell.ridgeBreakRemainingHours = Math.max(
                            0,
                            cell.ridgeBreakRemainingHours - MODEL_STEP_HOURS
                        );
                    }
                }
                cell.ridgeBreakEnvelope = ridgeBreakEnvelope;
                // A monsoon anticyclone is a slowly varying upper ridge, not
                // a fixed Gaussian.  Let Rossby-wave phase modulate its
                // centroid and amplitude, while keeping the perturbation
                // bounded enough that the monthly climatology remains the
                // dominant signal.
                cell.x = normalizeLongitude(cell.baseX
                    + 4.2 * Math.sin(phase)
                    + 1.6 * Math.sin(.43 * phase + (cell.variabilityPhase || 0))
                    + 3.0 * longWaveSignal
                    + (cell.synopticDisplacementLon || 0)
                    + (cell.ridgeBreakLonShift || 0) * ridgeBreakEnvelope);
                cell.y = cell.baseY
                    + 1.1 * Math.sin(.71 * phase + (cell.variabilityPhase || 0) * .7)
                    + .8 * longWaveSignal
                    + (cell.synopticDisplacementLat || 0)
                    + (cell.ridgeBreakLatShift || 0) * ridgeBreakEnvelope;
                cell.strength = cell.baseStrength * clamp(
                    1 + .13 * Math.sin(.63 * phase + (cell.variabilityPhase || 0))
                        + .07 * longWaveSignal
                        + (cell.synopticStrengthPerturbation || 0)
                        - (cell.ridgeBreakStrength || 0) * ridgeBreakEnvelope,
                    .72,
                    1.30
                );
                cell.sigmaX = cell.baseSigmaX * (1
                    + .08 * Math.sin(.52 * phase + (cell.wavePhaseOffset || 0))
                    + (cell.synopticWidthPerturbation || 0)
                    + .12 * ridgeBreakEnvelope);
                cell.sigmaY = cell.baseSigmaY * (1
                    + .10 * Math.sin(.47 * phase + (cell.variabilityPhase || 0))
                    + .65 * (cell.synopticWidthPerturbation || 0)
                    + .08 * ridgeBreakEnvelope);
            }
        }
    };

    if (systemsObj.upper) updateList(systemsObj.upper);
    
    if (systemsObj.lower) {
        updateList(systemsObj.lower);
        
        // --- Generation ---
        const surgeSeason = coldSurgeSeason(month);
        
        const activeSurges = systemsObj.lower.filter(s => s.isColdSurge).length;
        const atmosphericRandom = background?.synoptic
            ? () => synopticRandom(background.synoptic)
            : Math.random;

        if (!background?.weatherSequence && activeSurges < 1
            && atmosphericRandom() < 1 - Math.exp(-MODEL_STEP_HOURS / surgeSeason.waitHours)) {
            systemsObj.lower.push(createColdSurge(false, atmosphericRandom, month));
        }
    }
    
    if(background?.synoptic) advanceSynopticField(systemsObj,background);
    updateSubtropicalRidgeWeather(systemsObj,background);
    return systemsObj;
}

export function updateFrontalZone(pressureSystemsObj, month) {
    const list = Array.isArray(pressureSystemsObj) ? pressureSystemsObj : pressureSystemsObj.upper;
    
    // The public frontal-zone latitude is unsigned so the same transition
    // code works for north and south storms. Do not discard Southern
    // Hemisphere highs by filtering on raw (negative) latitude.
    const highs = list.filter(p => p.strength > 8 && Math.abs(p.y) > 10);
    if (highs.length === 0) return { latitude: 35 };
    
    const avgLat = highs.reduce((sum, p) => sum + Math.abs(p.y), 0) / highs.length;
    return { latitude: clamp(avgLat + 8, 32, 52) };
}

// A newly formed depression is a shallow, low-topped vortex advected mostly
// by the low-level flow; as convection organizes and the warm core builds,
// its circulation extends into the mid/upper troposphere and the deep-layer
// mean increasingly dominates its motion. Baroclinically supported stages
// (subtropical, transitioning, extratropical) are treated as already deep
// regardless of surface wind, since their steering is tied to the jet/trough
// pattern rather than to how strong the surface winds happen to be.
// Returns a 0 (shallow) .. 1 (deep, mature) factor.
export function getStormDepthFactor(cyclone) {
    if (!cyclone) return 0.65;
    if (cyclone.isExtratropical || cyclone.isTransitioning) return 0.9;
    const intensityDepth = smoothstep((cyclone.intensity - 25) / 55);
    const sizeDepth = smoothstep(((cyclone.circulationSize || 300) - 150) / 350);
    const subtropicalBoost = cyclone.isSubtropical ? 0.15 : 0;
    return clamp(0.30 + 0.45 * intensityDepth + 0.10 * sizeDepth + subtropicalBoost, 0.25, 0.95);
}

// Nine-point disk quadrature. The outer eight equal-area sectors are sampled
// at their area-centroid radius; Gaussian weights retain the inner circulation.
function steeringFootprint(lon, lat, size) {
    const radius = clamp(0.8 * (size || 300), 150, 500);
    const points = [{ lon, lat, weight: 1 / 9 }];
    for (let i = 0; i < 8; i++) {
        const angle = i * Math.PI / 4;
        const point = advectPosition(lon, lat, Math.sin(angle), Math.cos(angle), radius * 0.72 / 3.6);
        points.push({ ...point, weight: Math.exp(-(0.72 ** 2)) / 9 });
    }
    return points;
}

// Great-circle displacement; hours and m/s, safe at the dateline and poles.
function advectPosition(lon, lat, u, v, hours) {
    const distance = Math.hypot(u, v) * hours * 3600 / 6371000;
    const bearing = Math.atan2(u, v), phi = lat * Math.PI / 180;
    const nextPhi = Math.asin(clamp(Math.sin(phi) * Math.cos(distance)
        + Math.cos(phi) * Math.sin(distance) * Math.cos(bearing), -1, 1));
    const delta = Math.atan2(Math.sin(bearing) * Math.sin(distance) * Math.cos(phi),
        Math.cos(distance) - Math.sin(phi) * Math.sin(nextPhi));
    return { lon: normalizeLongitude(lon + delta * 180 / Math.PI), lat: nextPhi * 180 / Math.PI };
}

// Recurvature is an environmental-flow handoff, not a prescribed turn angle.
// Diagnose when a resolved trough is close enough and vertically coherent
// enough for the TC to sample progressively more of the mid/upper-level flow.
function steeringTroughCapture(lon, lat, pressureSystems, background, mid, high, cyclone,
    heightSamplers = null) {
    if (!cyclone || !background || Math.abs(lat) < 20) {
        return {
            capture: 0,
            resolvedTrough: 0,
            synopticTrough: 0,
            waveTrough: 0,
            coherentWesterlies: 0,
            latitudeGate: 0
        };
    }
    const sampleCyclone = { ...cyclone, lon, lat };
    const synoptic = resolvedSynopticTransitionFeatures(sampleCyclone, background);
    let waveTrough = 0;
    if (background.waves) {
        const local = waveFieldComponents(lon, lat, background);
        const sampleHeight500 = heightSamplers?.[500]
            || ((sampleLon, sampleLat) => getGeopotentialHeight500(
                sampleLon, sampleLat, pressureSystems, 500));
        const west = sampleHeight500(lon - 5, lat);
        const east = sampleHeight500(lon + 5, lat);
        waveTrough = smoothstep((east - west) / 60)
            * Math.exp(-(((Math.abs(lat) - Math.abs(local.jetLatitude)) / 14) ** 2));
    }
    const resolvedTrough = Math.max(synoptic.trough, waveTrough);
    const coherentWesterlies = smoothstep((Math.min(mid.u, high.u) - .5) / 6);
    const latitudeGate = smoothstep((Math.abs(lat) - 20) / 12);
    return {
        capture: clamp(resolvedTrough * coherentWesterlies * latitudeGate, 0, 1),
        resolvedTrough,
        synopticTrough: synoptic.trough,
        waveTrough,
        coherentWesterlies,
        latitudeGate
    };
}

function enforceDevelopingBaroclinicWesterlies(totalU, midU, highU, latitude, cyclone) {
    const developingStage = cyclone?.isTransitioning
        || (cyclone?.isExtratropical && cyclone.extratropicalStage !== 'decaying');
    if (!developingStage || Math.abs(latitude) < 28 || midU <= 2 || highU <= 2) {
        return totalU;
    }
    // A vertically coherent westerly column cannot advect an attached,
    // developing baroclinic vortex westward merely because the 850-hPa and
    // beta terms cancel in the layer average. Cut-off/decaying lows are left
    // untouched so genuine retrogression remains possible.
    const latitudeGate = smoothstep((Math.abs(latitude) - 28) / 10);
    const consensus = Math.min(midU, highU);
    const floor = consensus * (.18 + .22 * latitudeGate);
    return Math.max(totalU, floor);
}

// Archived analytic atmospheres and other basins retain their prior closure.
// The observational correction below is scoped to new WNP climatology runs.
function calculateLegacySteering(lon, lat, pressureSystemsObj, bias = { u: 0, v: 0 }, stormDepth = 0.65, cyclone = null) {
    const nativeField = pressureSystemsObj.upper?.some(c => c.role === 'height-background'
        && (Array.isArray(c.waves) || isModernAtmosphericBackground(c)));
    const background = nativeField
        ? pressureSystemsObj.upper.find(c => c.role === 'height-background')
        : null;
    const layers = [{u:0,v:0}, {u:0,v:0}, {u:0,v:0}];
    let total = 0;
    for (const point of steeringFootprint(lon, lat, cyclone?.circulationSize)) {
        [850,500,200].forEach((level, index) => {
            const wind = level === 850 && !nativeField
                ? calculateLayerWind(point.lon, point.lat, pressureSystemsObj.lower)
                : gradientWind(
                    point.lon,
                    point.lat,
                    // A vortex may modify its environment, but it must not
                    // advect itself through the gradient generated from that
                    // cyclone-relative response.  Steering is sampled only
                    // from the common prognostic height field shared by every
                    // system in the run.
                    (x, y) => getGeopotentialHeight500(
                        x, y, pressureSystemsObj, level
                    ),
                    9.80665
                );
            layers[index].u += wind.u * point.weight;
            layers[index].v += wind.v * point.weight;
        });
        total += point.weight;
    }
    for (const layer of layers) { layer.u /= total; layer.v /= total; }
    // Intermediate levels are log-pressure interpolations, not independent
    // prognostic fields. This preserves the existing atmosphere and vertical tilt.
    const interpolate = (a,b,f) => ({u:a.u+(b.u-a.u)*f,v:a.v+(b.v-a.v)*f});
    const [low,mid,high] = layers;
    const winds = [low, interpolate(low,mid,Math.log(850/700)/Math.log(850/500)),
        mid, interpolate(mid,high,Math.log(500/300)/Math.log(500/200)), high];
    const weak = [.40,.30,.20,.08,.02], mature = [.15,.20,.30,.22,.13], extratropical = [.10,.15,.30,.25,.20];
    const depth = smoothstep((clamp(stormDepth,0,1)-.30)/.55);
    const transition = cyclone?.isExtratropical ? 1 : cyclone?.isTransitioning ? .5 : 0;
    const troughDiagnosis = steeringTroughCapture(
        lon, lat, pressureSystemsObj, background, mid, high, cyclone
    );
    const diagnosedTroughCapture = troughDiagnosis.capture;
    // An approaching trough deepens the steering layer before the thermodynamic
    // ET flag completes. This lets the resolved southwesterly flow turn the TC;
    // no compass direction or fixed rotation angle is imposed here. Retain a
    // gradual handoff until its observed directional bias is calibrated.
    // A TC does not instantaneously become shallow again as the trough signal
    // crosses one grid-scale threshold.  Retain about one synoptic time step
    // of steering-layer memory to keep the handoff continuous.
    const troughCapture = Math.max(
        diagnosedTroughCapture,
        .72 * (cyclone?.troughCapture || 0)
    );
    const deepFlowCoupling = Math.max(transition, .82 * troughCapture);
    let steerU = bias.u, steerV = bias.v;
    winds.forEach((wind,i) => {
        const weight = (weak[i] + depth * (mature[i] - weak[i]))
            * (1 - deepFlowCoupling) + extratropical[i] * deepFlowCoupling;
        steerU += weight*wind.u; steerV += weight*wind.v;
    });
    // The resolved wave field is allowed to perturb tropical systems, but it
    // must not replace the basin-scale trade flow before the storm reaches
    // the subtropical baroclinic zone.  Blend toward the same zonal basic
    // state used to construct the QG height field; the taper is broad enough
    // to avoid an artificial 25N steering wall.
    if (background && isModernAtmosphericBackground(background)
        && !cyclone?.isTransitioning && !cyclone?.isExtratropical) {
        const latitude = Math.abs(lat);
        const hemisphere = lat < 0 ? -1 : 1;
        const circulation = backgroundMonthlyCirculation(background, hemisphere);
        const coherentSouthernColumn = hemisphere < 0
            && background.southernBasicStateVersion >= 2 && !background.climatologyVersion;
        const tradeAnchor = coherentSouthernColumn || background.activeBasin === 'SIO'
            ? gradientWind(
                lon,
                lat,
                (x, y) => {
                    const height = modernZonalHeightAt(background, y, 500);
                    return coherentSouthernColumn
                        ? scaleEnvironmentalGuidanceHeight(height, 500) : height;
                },
                GRAVITY
            ).u
            : zonalWindProfile(latitude, circulation.summer, 500, circulation);
        // Keep the tropical basic state present through the ridge belt.  A
        // short taper ending near 24N makes the mean track direction flip
        // abruptly at the same latitude for every storm; the real subtropical
        // transition is broad and individual systems still retain a poleward
        // beta component while crossing it.
        // The resolved field already contains its tropical basic state.
        // In summer, a deep vortex must retain the resolved monsoon/ridge
        // meridional flow instead of being pulled back toward a zonal mean
        // after the intensity-dependent layer average has been calculated.
        // Regional atmospheres already contain the zonal profile in their
        // height field.  Retain only a weak closure for shallow vortices;
        // applying the historical full re-anchor here counted the trades
        // twice, suppressed meridional departures, and made 7--9N tracks
        // insensitive to the evolving basin-scale trough/ridge lifecycle.
        const regionalClosure = background.regionalCirculationRegime ? .30 : 1;
        const tradeBlend = 0.52 * regionalClosure
            * (1 - smoothstep((latitude - 8) / 30))
            * (1 - circulation.summer * depth)
            * (1 - .85 * troughCapture);
        steerU = steerU * (1 - tradeBlend) + tradeAnchor * tradeBlend;
        steerV *= 1 - 0.55 * tradeBlend;

        // During a short South Asian High break, relax the local easterly
        // steering on its southern/eastern flank. This is an atmosphere-led
        // response tied to the evolving high, not a permanent eastward bias
        // applied to every storm at 119E, 19N.
        const southAsianHighBreak = localSouthAsianHighBreakAt(
            lon,
            lat,
            pressureSystemsObj
        );
        const southAsianBreakGate = smoothstep((latitude - 13) / 4)
            * (1 - smoothstep((latitude - 29) / 8));
        steerU += Math.min(
            2.5,
            2.5 * southAsianHighBreak * southAsianBreakGate
        );
    }
    const betaFactor = Math.sin(Math.min(Math.PI/2,1.2*Math.abs(lat*Math.PI/180)+Math.PI/12));
    // Keep beta propagation separate from the environmental field. Its
    // magnitude is intentionally independent of the footprint used to sample
    // that field, preserving a clean distinction between steering and vortex
    // propagation in diagnostics and forecast experiments.
    // Calibrated vortex beta drift.  It is deliberately modest compared with
    // the environmental flow, but it supplies the persistent poleward bias
    // that keeps tropical vortices from orbiting indefinitely in weak-flow
    // pockets and from forming an artificial low-latitude track reservoir.
    const sizeFactor = 0.75 + 0.45 * smoothstep(((cyclone?.circulationSize || 300) - 150) / 350);
    const persistentTropical = cyclone
        ? smoothstep(((cyclone.age || 0) - 72) / 120)
            * (1 - smoothstep((Math.abs(lat) - 8) / 14))
            * smoothstep((cyclone.intensity - 32) / 35)
        : 0;
    // Beta drift is a tropical-vortex propagation term, not an additional
    // midlatitude jet. Let it fade as the storm approaches the baroclinic
    // zone; otherwise its westward component needlessly cancels the resolved
    // westerlies just where a transitioning system should accelerate east.
    // Beta drift is a propagation correction for a vortex in weak steering;
    // it must give way once the resolved environmental current dominates.
    // Keeping the full poleward beta term inside a strong ridge-edge/trough
    // flow made both legs of recurvature too meridional and encouraged loops.
    const environmentalDominance = smoothstep(
        (Math.hypot(steerU, steerV) - 1.5) / 5
    );
    const betaEnvelope = (1 - smoothstep((Math.abs(lat) - 28) / 18))
        * (1 - .60 * environmentalDominance);
    const tropicalBetaBoost = 0.70 * (1 - smoothstep((Math.abs(lat) - 18) / 18));
    const betaU = -1.05 * betaFactor * sizeFactor * betaEnvelope;
    const betaV = Math.sign(lat) * (2.55 * betaFactor * sizeFactor * (1 + tropicalBetaBoost)
        + 0.75 * persistentTropical) * betaEnvelope;
    // Do not hard-clip equatorward motion: a genuine deep trough may still
    // drive a storm southward. Instead, weak southward vectors in the deep
    // tropics are blended partway back toward the resolved beta drift, so a
    // noisy high-level tropical-wave gradient cannot create repeated south
    // turns by itself.
    if (cyclone && Math.abs(lat) > 0.5 && !cyclone.isTransitioning && !cyclone.isExtratropical) {
        const polewardSign = Math.sign(lat);
        const lowLatitudeWeight = LOW_LATITUDE_POLEWARD_RESTORING_WEIGHT
            * smoothstep((18 - Math.abs(lat)) / 10);
        if (steerV * polewardSign < 0 && lowLatitudeWeight > 0) {
            steerV = steerV * (1 - lowLatitudeWeight) + betaV * lowLatitudeWeight;
        }
    }
    // Ahead of a diagnosed trough, vertically coherent westerlies should be
    // southwesterly in the Northern Hemisphere (northwesterly in the Southern
    // Hemisphere). If the reduced layer average contradicts that geometry,
    // blend only its meridional component toward the resolved westerly-column
    // scale. This is gated by the evolving trough diagnosis and vanishes away
    // from the interaction; it is not a prescribed recurvature angle.
    const troughPolewardBlend = smoothstep((troughCapture - .04) / .16);
    const signedEnvironmentalV = steerV * Math.sign(lat);
    const troughPolewardTarget = .75 * Math.max(0, Math.min(mid.u, high.u));
    if (signedEnvironmentalV < troughPolewardTarget) {
        steerV += Math.sign(lat) * (troughPolewardTarget - signedEnvironmentalV)
            * troughPolewardBlend;
    }
    // Retained as a diagnostic compatibility field; there is no unconditional
    // climatological poleward correction.
    const ridgePolewardV = 0;
    const coldSurgeImpact = getColdSurgeImpact(cyclone, pressureSystemsObj);
    const totalSteerU = enforceDevelopingBaroclinicWesterlies(
        steerU + betaU,
        mid.u,
        high.u,
        lat,
        cyclone
    );
    const coherentEnvironmentU = totalSteerU - betaU;
    return {steerU:totalSteerU,
        steerV:steerV + betaV,
        environmentU:coherentEnvironmentU, environmentV:steerV,
        lowU: low.u, lowV: low.v,
        midU: mid.u, midV: mid.v,
        highU: high.u, highV: high.v,
        shearU:high.u-low.u, shearV:high.v-low.v, betaU, betaV, ridgePolewardV,
        troughCapture, diagnosedTroughCapture,
        resolvedTrough: troughDiagnosis.resolvedTrough,
        synopticTrough: troughDiagnosis.synopticTrough,
        waveTrough: troughDiagnosis.waveTrough,
        coherentWesterlies: troughDiagnosis.coherentWesterlies,
        troughLatitudeGate: troughDiagnosis.latitudeGate,
        coldSurgeInfluence: coldSurgeImpact.influence,
        coldSurgeBlend: 0};
}


export function calculateSteering(lon, lat, pressureSystemsObj, bias = { u: 0, v: 0 }, stormDepth = 0.65, cyclone = null, options = {}) {
    const nativeField = pressureSystemsObj.upper?.some(c => c.role === 'height-background'
        && (Array.isArray(c.waves) || isModernAtmosphericBackground(c)));
    const background = nativeField
        ? pressureSystemsObj.upper.find(c => c.role === 'height-background')
        : null;
    // All new resolved atmospheres use one pressure-mass operator. Selecting
    // the old point weights / second trade re-anchor by genesis basin made
    // an identical height column advect SIO and EPAC storms differently.
    // Retain the previous operator only for archived version-2 atmospheres
    // and analytic backgrounds; no basin-specific acceleration is added.
    const coherentSteering = background?.steeringClosureVersion >= 3
        && isModernAtmosphericBackground(background);
    if (!coherentSteering && !background?.climatologyVersion
        && background?.activeBasin !== 'EPAC') {
        return calculateLegacySteering(lon,lat,pressureSystemsObj,bias,stormDepth,cyclone);
    }
    const layers = [{u:0,v:0}, {u:0,v:0}, {u:0,v:0}];
    // New procedural runs follow their own resolved weather. A climatological
    // track residual would otherwise impose the mean recurvature/poleward
    // motion even when this run has a different ridge configuration.
    // Preserve the former closure only for pre-versioned saved backgrounds.
    const useCalibratedPropagation = !(background.steeringClosureVersion >= 2)
        && cyclone?.basin === 'WPAC' && !cyclone?.isExtratropical;
    const meanLayers = [{u:0,v:0}, {u:0,v:0}, {u:0,v:0}];
    let total = 0;
    const heightSamplers = options?.heightSamplers || null;
    // Feedback geometry is fixed throughout this diagnosis. Construct each
    // layer once, not once per finite-difference point (108 calls/diagnosis).
    const feedbackSamplers = [850, 500, 200].map(level =>
        createCycloneEnvironmentalHeightFeedbackSampler(cyclone, level, pressureSystemsObj));
    for (const point of steeringFootprint(lon, lat, cyclone?.circulationSize)) {
        [850,500,200].forEach((level, index) => {
            const sampleHeight = heightSamplers?.[level]
                || ((sampleLon, sampleLat) => getGeopotentialHeight500(
                    sampleLon, sampleLat, pressureSystemsObj, level));
            const wind = level === 850 && !nativeField
                ? calculateLayerWind(point.lon, point.lat, pressureSystemsObj.lower)
                : gradientWind(
                    point.lon,
                    point.lat,
                    (x, y) => sampleHeight(x, y)
                        + feedbackSamplers[index](x, y),
                    9.80665
                );
            layers[index].u += wind.u * point.weight;
            layers[index].v += wind.v * point.weight;
            if (useCalibratedPropagation) {
                const meanWind=gradientWind(point.lon,point.lat,
                    (x,y)=>sampleMonthlyHeight(
                        x,y,background.calendarMonth,level),9.80665);
                meanLayers[index].u+=meanWind.u*point.weight;
                meanLayers[index].v+=meanWind.v*point.weight;
            }
        });
        total += point.weight;
    }
    for (const layer of [...layers,...meanLayers]) { layer.u /= total; layer.v /= total; }
    // Intermediate levels are log-pressure interpolations, not independent
    // prognostic fields. This preserves the existing atmosphere and vertical tilt.
    const interpolate = (a,b,f) => ({u:a.u+(b.u-a.u)*f,v:a.v+(b.v-a.v)*f});
    const [low,mid,high] = layers;
    const winds = [low, interpolate(low,mid,Math.log(850/700)/Math.log(850/500)),
        mid, interpolate(mid,high,Math.log(500/300)/Math.log(500/200)), high];
    // Trapezoidal pressure-mass quadrature, rather than arbitrary point
    // weights. Shallow: 850-500 hPa; deep: 850-200 hPa. The end-point
    // 200-hPa weight is 50/650, not the former 20% in transitioning storms.
    const weak = [75/350,175/350,100/350,0,0];
    const mature = [75/650,175/650,200/650,150/650,50/650];
    const extratropical = mature;
    const depth = smoothstep((clamp(stormDepth,0,1)-.30)/.55);
    const transition = cyclone?.isExtratropical ? 1 : cyclone?.isTransitioning ? .5 : 0;
    const troughDiagnosis = steeringTroughCapture(
        lon, lat, pressureSystemsObj, background, mid, high, cyclone,
        heightSamplers
    );
    const diagnosedTroughCapture = troughDiagnosis.capture;
    // An approaching trough deepens the steering layer before the thermodynamic
    // ET flag completes. This lets the resolved southwesterly flow turn the TC;
    // no compass direction or fixed rotation angle is imposed here. Retain a
    // gradual handoff until its observed directional bias is calibrated.
    // A TC does not instantaneously become shallow again as the trough signal
    // crosses one grid-scale threshold.  Retain about one synoptic time step
    // of steering-layer memory to keep the handoff continuous.
    const troughMemory = cyclone?.isTransitioning || cyclone?.isExtratropical
        ? .84 : .72;
    const troughCapture = Math.max(
        diagnosedTroughCapture,
        troughMemory * (cyclone?.troughCapture || 0)
    );
    const deepFlowCoupling = Math.max(transition, .82 * troughCapture);
    const [meanLow,meanMid,meanHigh]=meanLayers;
    const meanWinds=[meanLow,interpolate(meanLow,meanMid,Math.log(850/700)/Math.log(850/500)),meanMid,interpolate(meanMid,meanHigh,Math.log(500/300)/Math.log(500/200)),meanHigh];
    let meanU=0,meanV=0;
    let steerU = bias.u, steerV = bias.v;
    winds.forEach((wind,i) => {
        const weight = (weak[i] + depth * (mature[i] - weak[i]))
            * (1 - deepFlowCoupling) + extratropical[i] * deepFlowCoupling;
        steerU += weight*wind.u; steerV += weight*wind.v;
        meanU += weight*meanWinds[i].u; meanV += weight*meanWinds[i].v;
    });
    // In the diagnosed warm sector of a coherent trough, unresolved vortex-
    // wave interaction cannot leave the deep-layer current equatorward while
    // both 500 and 200 hPa are westerly. Blend only that contradictory part
    // toward a small fraction of the resolved westerly-column scale. The
    // diagnosis comes from the common height field and fades continuously;
    // no preferred compass bearing is assigned outside the interaction.
    const warmSectorBlend = smoothstep((diagnosedTroughCapture - .04) / .22);
    const signedEnvironmentalV = steerV * Math.sign(lat);
    const warmSectorPolewardTarget = .20 * Math.max(0, Math.min(mid.u, high.u));
    if (signedEnvironmentalV < warmSectorPolewardTarget) {
        steerV += Math.sign(lat) * (warmSectorPolewardTarget - signedEnvironmentalV)
            * warmSectorBlend;
    }
    // Environmental steering is the normalized layer mean above. Do not
    // re-anchor it to zonal trades or add compass corrections after sampling:
    // ridge, monsoon and trough influences already enter through the heights.
    // Chan (2005), doi:10.1146/annurev.fluid.37.061903.175702;
    // Ito et al. (2020), doi:10.2151/jmsj.2020-001.
    const betaFactor = Math.sin(Math.min(Math.PI/2,1.2*Math.abs(lat*Math.PI/180)+Math.PI/12));
    // Keep beta propagation separate from the environmental field. Its
    // magnitude is intentionally independent of the footprint used to sample
    // that field, preserving a clean distinction between steering and vortex
    // propagation in diagnostics and forecast experiments.
    // Calibrated vortex beta drift.  It is deliberately modest compared with
    // the environmental flow, but it supplies the persistent poleward bias
    // that keeps tropical vortices from orbiting indefinitely in weak-flow
    // pockets and from forming an artificial low-latitude track reservoir.
    const sizeFactor = 0.75 + 0.45 * smoothstep(((cyclone?.circulationSize || 300) - 150) / 350);
    // A uniform background translation is not a vorticity gradient. Do not
    // suppress vortex propagation solely because |environmental wind| grows,
    // or add northward drift solely because the storm is old. Retain the
    // existing size-dependent baseline closure and the baroclinic-zone taper;
    // these coefficients are a reduced-order approximation, not a PV solver.
    const betaEnvelope = 1 - smoothstep((Math.abs(lat) - 28) / 18);
    // Spatial residual calibrated on 2000-2011 JMA tracks against this
    // mean steering operator, following Zhang et al. (2018),
    // doi:10.1016/j.accre.2018.06.002. It includes unresolved propagation and
    // mean-state error; it must not be interpreted as a resolved beta gyre.
    const fitted = useCalibratedPropagation
        ? sampleWnpPropagation(lon,lat,background.calendarMonth) : null;
    // Smooth observed motion first, then subtract the LOCAL mean using the
    // identical layer/footprint operator. Smoothing residuals across a sharp
    // jet instead leaves a spurious current proportional to that gradient.
    const priorU=3.2*Math.sin(319*Math.PI/180),priorV=3.2*Math.cos(319*Math.PI/180);
    let betaU = fitted
        ? fitted.confidence*(fitted.u-meanU)+(fitted.domainWeight-fitted.confidence)*priorU
        : cyclone?.isExtratropical ? 0 : -1.05*betaFactor*sizeFactor*betaEnvelope;
    let betaV = fitted
        ? fitted.confidence*(fitted.v-meanV)+(fitted.domainWeight-fitted.confidence)*priorV
        : cyclone?.isExtratropical ? 0 : Math.sign(lat)*4.8*betaFactor*sizeFactor*betaEnvelope;
    // In a resolved col, deformation dominates rotation while the local
    // mid-level current is weak. A fixed westward beta component must not
    // fill that opening and recreate easterly steering that is absent from
    // the height field. Attenuate only the westward part of the reduced-order
    // propagation closure; retain its poleward component so the vortex does
    // not stall, orbit, or acquire an equatorward bias.
    const midlevelGeometry = flowDerivatives(
        lon, lat, pressureSystemsObj, 500, heightSamplers?.[500]
    );
    const deformationDominance = midlevelGeometry.deformation
        / (midlevelGeometry.deformation + Math.abs(midlevelGeometry.relativeVorticity) + 1e-9);
    const weakMidlevelFlow = 1 - smoothstep((Math.hypot(mid.u, mid.v) - .75) / 3.25);
    const colSupport = cyclone?.isExtratropical || fitted ? 0
        : smoothstep((deformationDominance - .52) / .28)
            * weakMidlevelFlow
            * (1 - smoothstep((Math.abs(lat) - 25) / 10));
    betaU *= 1 - .70 * colSupport;
    // Retained as a diagnostic compatibility field; there is no unconditional
    // climatological poleward correction.
    const ridgePolewardV = 0;
    // The spatial fit mixes recurving and non-recurving historical tracks.
    // Its climatological mean-state correction must not cancel an already
    // resolved coherent westerly current. Bound only the opposing along-flow
    // component by the existing vortex-propagation scale, retaining the
    // transverse correction and leaving tropical/weak-flow regimes unchanged.
    // This is a reduced-order closure, not a regional speed multiplier.
    const westerlyHandoff = fitted
        ? troughDiagnosis.coherentWesterlies * troughDiagnosis.latitudeGate : 0;
    const environmentalSpeed = Math.hypot(steerU, steerV);
    let propagationBrakeRelease = 0;
    if (westerlyHandoff > 0 && environmentalSpeed > 1e-6) {
        const along = (betaU * steerU + betaV * steerV) / environmentalSpeed;
        const vortexScale = Math.hypot(1.05, 2.55) * betaFactor * sizeFactor * betaEnvelope;
        propagationBrakeRelease = westerlyHandoff * Math.max(0, -vortexScale - along);
        betaU += propagationBrakeRelease * steerU / environmentalSpeed;
        betaV += propagationBrakeRelease * steerV / environmentalSpeed;
    }
    const coldSurgeImpact = getColdSurgeImpact(cyclone, pressureSystemsObj);
    const totalSteerU = steerU + betaU;
    const coherentEnvironmentU = steerU;
    return {steerU:totalSteerU,
        steerV:steerV + betaV,
        environmentU:coherentEnvironmentU, environmentV:steerV,
        meanU, meanV,
        westerlyHandoff, propagationBrakeRelease, colSupport,
        lowU: low.u, lowV: low.v,
        midU: mid.u, midV: mid.v,
        highU: high.u, highV: high.v,
        shearU:high.u-low.u, shearV:high.v-low.v, betaU, betaV, ridgePolewardV,
        troughCapture, diagnosedTroughCapture,
        resolvedTrough: troughDiagnosis.resolvedTrough,
        synopticTrough: troughDiagnosis.synopticTrough,
        waveTrough: troughDiagnosis.waveTrough,
        coherentWesterlies: troughDiagnosis.coherentWesterlies,
        troughLatitudeGate: troughDiagnosis.latitudeGate,
        coldSurgeInfluence: coldSurgeImpact.influence,
        coldSurgeBlend: 0};
}

function motionResponseHours(cyclone, steering) {
    const size = smoothstep(((cyclone.circulationSize || 300)-100)/600);
    const strength = smoothstep((cyclone.intensity-25)/100);
    let hours = 1.5 + 5*size + 3*strength;
    // Compare environmental steering, not the lagging translation vector.
    // Ignore directions in near-calm flow where bearing is undefined.
    const history = cyclone.steeringHistory || [];
    let turn = 0;
    for (const old of history.slice(-2)) {
        const product = Math.hypot(old.u,old.v)*Math.hypot(steering.steerU,steering.steerV);
        if (Math.hypot(old.u,old.v)>1.5 && Math.hypot(steering.steerU,steering.steerV)>1.5) {
            turn = Math.max(turn, Math.acos(clamp((old.u*steering.steerU+old.v*steering.steerV)/product,-1,1))*180/Math.PI);
        }
    }
    // A sudden change in the sampled steering field is precisely when vortex
    // inertia should reject high-frequency direction noise. The former rule
    // shortened the response to 3.5 h and made the storm follow each ridge
    // deformation faster, amplifying zig-zags. Retain the physical base lag
    // and add modest damping only while the environmental vector turns.
    hours += 3.5 * smoothstep((turn-20)/30);
    return hours;
}

// Compatibility limiter for old atmospheres. New version-3 steering is
// already a normalized vertical / circulation-footprint mean, not a single
// jet-level wind. A second latitude/stage speed ceiling falsely brakes that
// diagnosed current; finite vortex response time supplies the motion lag.
function translationCeiling(cyclone, latitude) {
    const absLat = Math.abs(latitude);
    let maximum = 10
        + 5 * smoothstep((absLat - 22) / 12)
        + 4 * smoothstep((absLat - 35) / 15);
    if (cyclone?.isTransitioning) {
        maximum += 3.5;
    }
    if (cyclone?.isExtratropical) {
        maximum += 6;
    }
    return maximum;
}

function translationTarget(steering, cyclone, latitude) {
    const maximum = translationCeiling(cyclone, latitude);
    const speed = Math.hypot(steering.steerU, steering.steerV);
    const onset = .8 * maximum;
    if (speed <= onset || speed < 1e-6) return steering;
    // Identity up to 80% of the ceiling, then C1 monotone saturation at the
    // original ceiling. The old branch jumped DOWN by 24% at its join.
    const shoulder = maximum - onset;
    const scale = (onset + shoulder * Math.tanh((speed - onset) / shoulder)) / speed;
    return {
        ...steering,
        steerU: steering.steerU * scale,
        steerV: steering.steerV * scale
    };
}

// Spatial midpoint integration with exact velocity relaxation at each stage.
// Weather is held at the supplied snapshot: sampling never advances its RNG.
export function integrateStormMotion(cyclone, systems, first, hours = MODEL_STEP_HOURS, options = {}) {
    const tau = motionResponseHours(cyclone, first);
    const background = systems?.upper?.find(cell => cell.role === 'height-background');
    const resolvedMotion = background?.steeringClosureVersion >= 3
        && isModernAtmosphericBackground(background);
    const firstTarget = resolvedMotion ? first : translationTarget(first, cyclone, cyclone.lat);
    const direction = cyclone.direction*Math.PI/180, speed = cyclone.speed/1.94384;
    // Genesis belongs to the resolved environmental current. Do not inject a
    // random initial translation vector and then spend a day relaxing it away.
    const u0 = cyclone.motionInitialized === false
        ? firstTarget.steerU : speed*Math.sin(direction);
    const v0 = cyclone.motionInitialized === false
        ? firstTarget.steerV : speed*Math.cos(direction);
    const relax = (u,v,targetU,targetV,t) => {
        const fraction = 1-Math.exp(-t/tau);
        return {u:u+(targetU-u)*fraction,v:v+(targetV-v)*fraction};
    };
    // Integrate the predictor velocity, avoiding an Euler displacement with the
    // already-relaxed end velocity when accelerating out of weak steering.
    const half = hours/2, average = tau/half*(1-Math.exp(-half/tau));
    const midpoint = advectPosition(cyclone.lon,cyclone.lat,
        firstTarget.steerU+(u0-firstTarget.steerU)*average,
        firstTarget.steerV+(v0-firstTarget.steerV)*average,half);
    const second = options?.midpoint === false
        ? first
        : calculateSteering(
            midpoint.lon,
            midpoint.lat,
            systems,
            {u:0,v:0},
            getStormDepthFactor(cyclone),
            cyclone,
            options
        );
    const secondTarget = resolvedMotion ? second : translationTarget(second, cyclone, midpoint.lat);
    // Keep the response-time lag in the realized motion. New resolved fields
    // have no additional target-speed ceiling; old snapshots retain theirs
    // before this relaxation. Neither path clips the relaxed velocity again.
    const middleVelocity = relax(u0,v0,secondTarget.steerU,secondTarget.steerV,half);
    const position = advectPosition(cyclone.lon,cyclone.lat,middleVelocity.u,middleVelocity.v,hours);
    const velocity = relax(u0,v0,secondTarget.steerU,secondTarget.steerV,hours);
    return {...position,...velocity,tau};
}

function randomNormal() {
    return Math.sqrt(-2 * Math.log(Math.max(1e-9, Math.random())))
        * Math.cos(2 * Math.PI * Math.random());
}

// Operational center fixes are not the same thing as bulk vortex motion.
// Weak storms, subtropical/transitioning systems, and ERC phases can have an
// ambiguous or precessing LLCC, so successive fixes wander around a smoother
// dynamical center.  Model that as a bounded, autocorrelated position offset
// in local east/north kilometres.  The environmental trajectory remains the
// deterministic component passed through integrateStormMotion().
function evolveCenterFixOffset(cyclone) {
    const intensity = clamp(Number.isFinite(cyclone?.intensity) ? cyclone.intensity : 25, 10, 160);
    const size = clamp(cyclone?.circulationSize || 300, 100, 800);
    const weak = 1 - smoothstep((intensity - 25) / 55);
    const broad = 1 - smoothstep((size - 160) / 360);
    const structuralAmbiguity = cyclone?.isExtratropical
        ? .20
        : cyclone?.isTransitioning
            ? .55
        : cyclone?.isSubtropical
            ? 0.65
            : cyclone?.isERCActive || ['takeover', 'settling', 'aborting'].includes(cyclone?.ercState)
                ? 0.75
                : 0;

    // Stationary 1-sigma center-fix uncertainty.  These are deliberately
    // kilometre-scale offsets, not a random heading impulse: a mature,
    // compact TC stays coherent while a weak/ambiguous center visibly wobbles.
    const rawSigmaKm = 7
        + 22 * weak
        + 8 * broad
        + 18 * structuralAmbiguity;
    // A weak LLCC is still less certain than a mature vortex, but the prior
    // uncertainty was large enough to look like random track noise.  Reduce
    // the low-intensity component to 30% of its former amplitude and restore
    // the mature value smoothly as the circulation consolidates.
    const lowIntensityScale = .30 + .70 * smoothstep((intensity - 25) / 55);
    // Retain the operational-fix wobble requested by the track presentation,
    // but reduce its displacement amplitude by 30 percent.
    const sigmaKm = rawSigmaKm * lowIntensityScale * .70;
    const retention = Math.exp(-MODEL_STEP_HOURS / 18);
    const innovation = Math.sqrt(1 - retention * retention) * sigmaKm;
    let east = retention * (cyclone?.centerFixOffsetEastKm || 0) + innovation * randomNormal();
    let north = retention * (cyclone?.centerFixOffsetNorthKm || 0) + innovation * randomNormal();

    // Bound the tails so center ambiguity cannot move a storm across a whole
    // synoptic feature or create an accidental landfall by itself.
    const maximum = 16 + 1.45 * sigmaKm;
    const magnitude = Math.hypot(east, north);
    if (magnitude > maximum) {
        const scale = maximum / magnitude;
        east *= scale;
        north *= scale;
    }
    return { east, north };
}

// Exact coastline checks are retained as a narrow-band correction and as a
// confirmation for raster land cells. The raster distance field handles the
// vast majority of ocean samples; when a correction is needed, a conservative
// geographic index prevents the point from traversing the full collection.
const landFeatureIndexCache = new WeakMap();
const exactLandResultCache = new WeakMap();
const LAND_INDEX_CELL_DEGREES = 1;
const EXACT_LAND_RESULT_CACHE_LIMIT = 8192;

function getLandFeatureIndex(world) {
    if (!world || !Array.isArray(world.features) || !globalThis.d3?.geoBounds) return null;
    const cached = landFeatureIndexCache.get(world);
    if (cached) return cached;

    const lonCells = Math.ceil(360 / LAND_INDEX_CELL_DEGREES);
    const latCells = Math.ceil(180 / LAND_INDEX_CELL_DEGREES);
    const buckets = new Map();
    const clampCell = (value, count) => clamp(value, 0, count - 1);
    const lonCell = lon => clampCell(
        Math.floor((clamp(lon, -180, 180) + 180) / LAND_INDEX_CELL_DEGREES),
        lonCells
    );
    const latCell = lat => clampCell(
        Math.floor((clamp(lat, -90, 90) + 90) / LAND_INDEX_CELL_DEGREES),
        latCells
    );
    const addRange = (entry, west, east, south, north) => {
        const x0 = lonCell(west), x1 = lonCell(east);
        const y0 = latCell(south), y1 = latCell(north);
        for (let y = y0; y <= y1; y++) {
            for (let x = x0; x <= x1; x++) {
                const key = y * lonCells + x;
                let bucket = buckets.get(key);
                if (!bucket) {
                    bucket = [];
                    buckets.set(key, bucket);
                }
                if (bucket[bucket.length - 1] !== entry && !bucket.includes(entry)) {
                    bucket.push(entry);
                }
            }
        }
    };
    const splitFeature = feature => {
        const geometry = feature?.geometry;
        if (!geometry) return [];
        if (geometry.type === 'MultiPolygon') {
            return geometry.coordinates.map(coordinates => ({
                type: 'Feature',
                properties: feature.properties || {},
                geometry: { type: 'Polygon', coordinates }
            }));
        }
        if (geometry.type === 'GeometryCollection') {
            return geometry.geometries.flatMap(child => splitFeature({
                type: 'Feature',
                properties: feature.properties || {},
                geometry: child
            }));
        }
        return [feature];
    };

    try {
        world.features.flatMap(splitFeature).forEach(feature => {
            const bounds = globalThis.d3.geoBounds(feature);
            if (!bounds || bounds.length !== 2) return;
            const west = bounds[0][0], south = bounds[0][1];
            const east = bounds[1][0], north = bounds[1][1];
            if (![west, south, east, north].every(Number.isFinite)) return;
            const entry = { feature, west, east, south, north };
            if (west <= east) {
                addRange(entry, west, east, south, north);
            } else {
                // d3 represents antimeridian-crossing bounds with west > east.
                addRange(entry, west, 180, south, north);
                addRange(entry, -180, east, south, north);
            }
        });
    } catch (error) {
        console.warn('Land feature index unavailable; using exact world scan.', error);
        return null;
    }

    const index = { buckets, lonCells, latCells };
    landFeatureIndexCache.set(world, index);
    return index;
}

// Build the immutable coastline accelerator while the loading screen is still
// active, rather than paying its one-time cost on the first coastal model step.
export function prepareLandFeatureIndex(world) {
    return Boolean(getLandFeatureIndex(world));
}

function indexedGeoContains(world, lon, lat) {
    const exactContains = globalThis.d3?.geoContains;
    if (!exactContains || !world) return false;
    const normalizedLon = normalizeLongitude(lon);
    let resultCache = exactLandResultCache.get(world);
    if (!resultCache) {
        resultCache = new Map();
        exactLandResultCache.set(world, resultCache);
    }
    // Coordinates are deliberately not rounded: this removes repeated exact
    // coastline work without changing the geometric land/sea classification.
    const cacheKey = `${normalizedLon}|${lat}`;
    if (resultCache.has(cacheKey)) {
        const cached = resultCache.get(cacheKey);
        resultCache.delete(cacheKey);
        resultCache.set(cacheKey, cached);
        return cached;
    }
    const index = getLandFeatureIndex(world);
    if (!index) return exactContains(world, [normalizedLon, lat]);

    const x = clamp(
        Math.floor((normalizedLon + 180) / LAND_INDEX_CELL_DEGREES),
        0,
        index.lonCells - 1
    );
    const y = clamp(
        Math.floor((clamp(lat, -90, 90) + 90) / LAND_INDEX_CELL_DEGREES),
        0,
        index.latCells - 1
    );
    const candidates = index.buckets.get(y * index.lonCells + x) || [];
    const contained = candidates.some(entry => {
        const withinLongitude = entry.west <= entry.east
            ? normalizedLon >= entry.west && normalizedLon <= entry.east
            : normalizedLon >= entry.west || normalizedLon <= entry.east;
        if (!withinLongitude || lat < entry.south || lat > entry.north) return false;
        return exactContains(entry.feature, [normalizedLon, lat]);
    });
    resultCache.set(cacheKey, contained);
    if (resultCache.size > EXACT_LAND_RESULT_CACHE_LIMIT) {
        resultCache.delete(resultCache.keys().next().value);
    }
    return contained;
}

function sampleTrackLandInteraction(startLon, startLat, endLon, endLat, world, checkLandFunc = null) {
    let lonDelta = endLon - startLon;
    if (lonDelta > 180) lonDelta -= 360;
    if (lonDelta < -180) lonDelta += 360;
    const pathLengthKm = calculateDistance(startLat, startLon, endLat, startLon + lonDelta);
    // Six-kilometre sampling resolves most islands represented by the map
    // data and is independent of the visible wind/map resolution.
    const segments = clamp(Math.ceil(pathLengthKm / 6), 2, 72);
    const samples = [];
    let firstLandfall = null;
    let previousLand = false;
    let landWeight = 0;
    let elevationWeight = 0;
    let maxElevation = 0;
    let endpointStatus = { isLand: false, isNearLand: false };

    for (let index = 0; index <= segments; index++) {
        const fraction = index / segments;
        const lon = normalizeLongitude(startLon + lonDelta * fraction);
        const lat = startLat + (endLat - startLat) * fraction;
        const terrain = typeof queryTerrain === 'function'
            ? queryTerrain(lon, lat, 0.08)
            : {
                ...(getLandStatus(lon, lat, 0.08) || { isLand: false, isNearLand: false }),
                elevation: getElevationAt(lon, lat) || 0,
                coastDistancePixels: null,
                rasterAvailable: false
            };
        let isLand = typeof checkLandFunc === 'function'
            ? Boolean(checkLandFunc(lon, lat)) : Boolean(terrain.isLand);
        // The raster is authoritative for open ocean. Keep exact vector
        // geometry inside a narrow uncertainty band and for raster land cells,
        // where coarse pixels can bridge channels or merge small islands.
        const needsExactGeometry = terrain.rasterAvailable !== true
            || terrain.coastDistancePixels === null
            || terrain.coastDistancePixels <= LAND_GEOMETRY_FALLBACK_PIXELS
            // Confirm raster land cells as well. A mask cell can still bridge
            // a narrow channel or merge nearby islands into a false land strip.
            || terrain.isLand;
        if (typeof checkLandFunc !== 'function' && needsExactGeometry && world && globalThis.d3?.geoContains) {
            isLand = indexedGeoContains(world, lon, lat);
        }
        const elevation = isLand ? Math.max(0, terrain.elevation || 0) : 0;
        const trapezoidWeight = index === 0 || index === segments ? 0.5 : 1;
        if (isLand && !previousLand && index > 0 && !firstLandfall) {
            firstLandfall = { lon, lat };
        }
        if (isLand) {
            landWeight += trapezoidWeight;
            elevationWeight += elevation * trapezoidWeight;
        }
        maxElevation = Math.max(maxElevation, elevation);
        previousLand = isLand;
        endpointStatus = {
            isLand,
            isNearLand: Boolean(terrain.isNearLand)
        };
        samples.push(isLand);
    }

    return {
        landFraction: clamp(landWeight / segments, 0, 1),
        maxElevation,
        meanElevation: landWeight > 0 ? elevationWeight / landWeight : 0,
        startpointIsLand: samples[0],
        endpointIsLand: endpointStatus.isLand,
        endpointIsNearLand: endpointStatus.isNearLand,
        crossedLand: samples.some(Boolean),
        firstLandfall
    };
}

export function updateCycloneState(cyclone, pressureSystems, frontalZone, world, month, globalTemp, globalShearSetting, heatDistribution = 50, nameIndex, options = {}) {
    const random = typeof options.random === 'function' ? options.random : Math.random;
    let updatedCyclone = { ...cyclone };
    // Repair corrupt legacy/runtime state before ACE or any nonlinear vortex
    // calculation sees it. The ERC component fields are validated separately
    // below, so this fallback cannot manufacture a new intensity maximum.
    updatedCyclone.intensity = clamp(
        Number.isFinite(cyclone.intensity)
            ? cyclone.intensity
            : Number.isFinite(cyclone.ercInnerWind) ? cyclone.ercInnerWind : 10,
        10,
        MAX_TROPICAL_WIND_KT
    );
    updatedCyclone.isRapidIntensifying = false;
    updatedCyclone.landDecayExposure = 0;
    updatedCyclone.age += 3;
    normalizeCoreRadii(updatedCyclone);
    updatedCyclone.rmw = Number.isFinite(updatedCyclone.rmw)
        ? updatedCyclone.rmw
        : fallbackRmwFromSize(updatedCyclone.circulationSize);
    updatedCyclone.outerWindBroadness = Number.isFinite(updatedCyclone.outerWindBroadness)
        ? clamp(updatedCyclone.outerWindBroadness, 0, 1)
        : 0.08 + 0.92 * Math.pow(random(), 0.65);
    updatedCyclone.ercPotential = Number.isFinite(updatedCyclone.ercPotential) ? updatedCyclone.ercPotential : 0;
    updatedCyclone.ercEligibleHours = Number.isFinite(updatedCyclone.ercEligibleHours)
        ? updatedCyclone.ercEligibleHours
        : 0;
    updatedCyclone.ercCycleCount = Number.isFinite(updatedCyclone.ercCycleCount)
        ? updatedCyclone.ercCycleCount
        : 0;
    updatedCyclone.ercCooldownUntil = Number.isFinite(updatedCyclone.ercCooldownUntil) ? updatedCyclone.ercCooldownUntil : 0;
    // Migrate saves made by the former timer-only weakening/recovery model.
    if (!updatedCyclone.isERCActive && ['weakening', 'recovering'].includes(updatedCyclone.ercState)) {
        updatedCyclone.ercState = 'none';
    }
    const hasValidEyewallState = Number.isFinite(updatedCyclone.ercInnerRmw)
        && Number.isFinite(updatedCyclone.ercInnerWind)
        && Number.isFinite(updatedCyclone.ercOuterRmw)
        && Number.isFinite(updatedCyclone.ercOuterWindAnomaly);
    if (updatedCyclone.isERCActive && !hasValidEyewallState) {
        clearEyewallStructure(updatedCyclone, 'interrupted');
    }

    // --- ACE Calculation ---
    if (updatedCyclone.age % 6 === 0 && updatedCyclone.intensity >= 34 && !updatedCyclone.isExtratropical) {
        const ace_contribution = (updatedCyclone.intensity ** 2) / 10000;
        updatedCyclone.ace += ace_contribution;
    }

    if (updatedCyclone.isMonsoonDepression && updatedCyclone.age >= updatedCyclone.monsoonDepressionEndTime) {
        updatedCyclone.isMonsoonDepression = false;
    }

    // --- Steering ---
    // Remove the previous operational-fix offset before advancing the smooth
    // dynamical center. Otherwise a center-fix error would accumulate as a
    // false environmental displacement over the storm's whole lifetime.
    const previousFixOffset = {
        east: cyclone.centerFixOffsetEastKm || 0,
        north: cyclone.centerFixOffsetNorthKm || 0
    };
    const dynamicalStart = advectPosition(
        cyclone.lon,
        cyclone.lat,
        -previousFixOffset.east * 1000,
        -previousFixOffset.north * 1000,
        1 / 3600
    );
    const dynamicalCyclone = { ...cyclone, lon: dynamicalStart.lon, lat: dynamicalStart.lat };
    const steering = calculateSteering(
        dynamicalStart.lon,
        dynamicalStart.lat,
        pressureSystems,
        options.steeringBias || { u: 0, v: 0 },
        getStormDepthFactor(cyclone),
        dynamicalCyclone,
        options.steeringOptions || {}
    );
    const { shearU, shearV } = steering;
    updatedCyclone.steeringU = steering.steerU;
    updatedCyclone.steeringV = steering.steerV;
    updatedCyclone.lowLevelU = steering.lowU;
    updatedCyclone.lowLevelV = steering.lowV;
    updatedCyclone.midLevelU = steering.midU;
    updatedCyclone.midLevelV = steering.midV;
    updatedCyclone.upperLevelU = steering.highU;
    updatedCyclone.upperLevelV = steering.highV;
    updatedCyclone.troughCapture = steering.troughCapture;
    updatedCyclone.diagnosedTroughCapture = steering.diagnosedTroughCapture;
    updatedCyclone.resolvedTrough = steering.resolvedTrough;
    updatedCyclone.synopticTrough = steering.synopticTrough;
    updatedCyclone.waveTrough = steering.waveTrough;
    updatedCyclone.coherentWesterlies = steering.coherentWesterlies;
    updatedCyclone.troughLatitudeGate = steering.troughLatitudeGate;
    let motion = integrateStormMotion(dynamicalCyclone, pressureSystems, steering,
        MODEL_STEP_HOURS, options.steeringOptions || {});
    // Forecasts follow the dynamical centre, not future observation-fix noise.
    const nextFixOffset = options.forecast
        ? { east: 0, north: 0 } : evolveCenterFixOffset(cyclone);
    const fixedPosition = advectPosition(
        motion.lon,
        motion.lat,
        nextFixOffset.east * 1000,
        nextFixOffset.north * 1000,
        1 / 3600
    );
    motion = { ...motion, lon: fixedPosition.lon, lat: fixedPosition.lat };
    updatedCyclone.centerFixOffsetEastKm = nextFixOffset.east;
    updatedCyclone.centerFixOffsetNorthKm = nextFixOffset.north;
    const trackLand = sampleTrackLandInteraction(
        cyclone.lon,
        cyclone.lat,
        motion.lon,
        motion.lat,
        world,
        options.checkLandFunc
    );
    // Every environmental diagnostic below belongs to the new valid time.
    // Previously lon/lat were updated only after intensity, producing a
    // systematic one-step landfall lag.
    updatedCyclone.lon = motion.lon;
    updatedCyclone.lat = motion.lat;
    updatedCyclone.landExposure = trackLand.landFraction;
    if (trackLand.firstLandfall) {
        updatedCyclone.landfallEvent = {
            age: updatedCyclone.age,
            lon: trackLand.firstLandfall.lon,
            lat: trackLand.firstLandfall.lat,
            intensity: cyclone.intensity,
            isTransitioning: cyclone.isTransitioning,
            isExtratropical: cyclone.isExtratropical,
            isSubtropical: cyclone.isSubtropical
        };
    }
    const physicalShear = Math.hypot(shearU, shearV) * 1.94384;
    const coldSurgeImpact = getColdSurgeImpact(updatedCyclone, pressureSystems);

    // Wind shear is diagnosed only from the resolved 850/200-hPa winds.
    // Cold-surge influence changes those winds through the shared height
    // field; it is not added again as a separate intensity penalty.
    let totalShear = physicalShear * (globalShearSetting / 100.0);
    // Reuse the circulation's hemisphere-aware calendar for both event
    // frequency and amplitude. Austral winter maps to boreal winter instead
    // of incorrectly receiving the weak August event while January is strong.
    const shearSeasonMonth = monthlyCirculation(
        month, updatedCyclone.lat < 0 ? -1 : 1
    ).northernMonth;
    const isWinterHalf = (shearSeasonMonth >= 11 || shearSeasonMonth <= 4);
    const shearEventProb = (isWinterHalf && updatedCyclone.lon > 100 && updatedCyclone.lon < 121 && updatedCyclone.lat > 16) ? 0.55 : (isWinterHalf ? 0.045 * (globalShearSetting ** 2 / 10000) : 0.03 * (globalShearSetting ** 2 / 10000));
    // Random shear event
    if (updatedCyclone.shearEventActive) {
        if (updatedCyclone.age >= updatedCyclone.shearEventEndTime) {
            updatedCyclone.shearEventActive = false;
            updatedCyclone.shearEventMagnitude = 0;
        } else {
            totalShear += Math.max(0, updatedCyclone.shearEventMagnitude);
        }
    } else if (random() < shearEventProb && !updatedCyclone.isTransitioning) {
        updatedCyclone.shearEventActive = true;
        updatedCyclone.shearEventEndTime = updatedCyclone.age + (1 + random()*48);
        updatedCyclone.shearEventMagnitude = -3 + random() * 6 + 3.8 * Math.abs(shearSeasonMonth - 8) ** 0.5 + Math.max(0,(globalShearSetting / 10 - 10));
    }
    updatedCyclone.totalShear = totalShear;
    const shearResponseHours = 15;
    const shearRelax = 1 - Math.exp(-MODEL_STEP_HOURS / shearResponseHours);
    updatedCyclone.effectiveShear = Number.isFinite(updatedCyclone.effectiveShear)
    ? updatedCyclone.effectiveShear + (totalShear - updatedCyclone.effectiveShear) * shearRelax
    : totalShear;
    const shearDamage = updateShearDamageMemory(updatedCyclone);

    updatedCyclone.direction = (Math.atan2(motion.u,motion.v)*180/Math.PI+360)%360;
    updatedCyclone.speed = Math.hypot(motion.u,motion.v)*1.94384;
    updatedCyclone.motionInitialized = true;
    updatedCyclone.motionResponseHours = motion.tau;
    updatedCyclone.steeringHistory = [...(cyclone.steeringHistory || []).slice(-1),
        {u:steering.steerU,v:steering.steerV}];

    const surgeCoolingResponse = 1 - Math.exp(-MODEL_STEP_HOURS / 18);
    const previousSurgeCooling = Number.isFinite(updatedCyclone.coldSurgeCoolingEffect)
        ? updatedCyclone.coldSurgeCoolingEffect : 0;
    updatedCyclone.coldSurgeCoolingEffect = previousSurgeCooling
        + (coldSurgeImpact.sstCooling - previousSurgeCooling) * surgeCoolingResponse;
    updatedCyclone.coldSurgeInfluence = coldSurgeImpact.influence;
    updatedCyclone.coldSurgeShearBoost = 0;
    updatedCyclone.oceanHeatDistribution = heatDistribution;
    // Deposit this step's wind work at the previous center, but consume SST
    // at the new center. Use the source's land mask, not the new endpoint's.
    const oceanUpdate = advanceStormOcean(updatedCyclone, month, globalTemp,
        heatDistribution, MODEL_STEP_HOURS * (1 - trackLand.landFraction), trackLand.startpointIsLand,
        cyclone);
    updatedCyclone.oceanWake = oceanUpdate.oceanWake;
    updatedCyclone.oceanThermal = oceanUpdate.ocean;
    // Compatibility diagnostic only: the legacy moving scalar no longer
    // drives cooling. Old saves without an ocean wake start unperturbed.
    updatedCyclone.upwellingCoolingEffect = Math.max(0,
        oceanUpdate.ocean.coolingC - updatedCyclone.coldSurgeCoolingEffect);
    const sst = oceanUpdate.ocean.sstC;
    
    const etEnvironment = transitionEnvironment(updatedCyclone, pressureSystems, frontalZone, totalShear);
    updatedCyclone.baroclinicSupport = etEnvironment.support;
    updatedCyclone.etFront = etEnvironment.front;
    updatedCyclone.etTrough = etEnvironment.trough;
    updatedCyclone.etFrontLatitude = etEnvironment.frontLatitude;
    updatedCyclone.etFrontSource = etEnvironment.frontSource;
    updatedCyclone.etSynopticFront = etEnvironment.synopticFront;
    updatedCyclone.etClimatologicalFront = etEnvironment.climatologicalFront;
    updatedCyclone.etShear = totalShear;
    updatedCyclone.etSst = sst;
    const frontalInteraction = diagnoseFrontalCycloneInteraction(
        updatedCyclone,
        pressureSystems,
        totalShear
    );
    advanceFrontalCycloneInteraction(updatedCyclone, pressureSystems,
        frontalInteraction, etEnvironment, totalShear);
    advanceExtratropicalTransition(updatedCyclone, etEnvironment, sst, totalShear);
    const frontalAbsorption = frontalInteraction?.action === 'tc-absorbed'
        ? frontalInteraction : null;

    const oldIntensity = updatedCyclone.intensity;
    const ercStateBeforeIntensity = updatedCyclone.ercState || 'none';
    let intensityPath = 'tropical';
    let thermodynamicMpiDiagnostic = null;
    let structuralMpiDiagnostic = null;
    let baseIntensityChangeDiagnostic = null;
    let sizeShearResistance = 1;
    let shearResilience = 0;
    const terrainElevation = Math.max(
        Number.isFinite(trackLand.meanElevation) ? trackLand.meanElevation : trackLand.maxElevation,
        getElevationAt(updatedCyclone.lon, updatedCyclone.lat) || 0
    );
    const landStatus = getLandStatus(updatedCyclone.lon, updatedCyclone.lat, 0.2);
    // sampleTrackLandInteraction uses the exact vector correction for the
    // endpoint when available. Reusing that decision avoids reintroducing a
    // coarse raster false positive through a second endpoint-only query.
    const isOverLand = trackLand.endpointIsLand;
    const isNearLand = landStatus.isNearLand;
    const landInteraction = trackLand.landFraction > 0;

    updatedCyclone.isLand = isOverLand;
    if (landInteraction || isOverLand || isNearLand) updatedCyclone.riUntil = 0;

    // --- Intensity Change ---
    
    // 1. Land decay. Apply a continuous time tendency proportional to the
    // fraction of this three-hour trajectory spent over land. This resolves
    // islands without turning one terrain sample into a 50–70 kt cliff.
    if (landInteraction || isOverLand) {
        intensityPath = terrainElevation > 70 ? 'terrain' : 'land';
        const sizeResistance = 0.80
            + 0.45 * smoothstep(((updatedCyclone.circulationSize || 300) - 150) / 500);
        const terrainSeverity = smoothstep(terrainElevation / 540);
        const japanRetention = updatedCyclone.lat >= 30 && updatedCyclone.lat <= 40
            && updatedCyclone.lon >= 129 && updatedCyclone.lon <= 140 ? 1.48 : 1;
        const decayTimeHours = clamp(
            (30 - 27 * terrainSeverity) * sizeResistance * japanRetention,
            3,
            36
        );
        const rawExposure = clamp(trackLand.landFraction, 0, 1);
        // A point landing at the end of a three-hour step is not equivalent to
        // three hours over a continental interior. Keep a small floor for a
        // genuine overland endpoint, but let it rise smoothly with the amount
        // of land actually traversed instead of jumping to 35% every time.
        const endpointExposure = isOverLand
            ? 0.15 + 0.34 * smoothstep(rawExposure / 0.45)
            : 0;
        const geometricExposure = Math.max(rawExposure, endpointExposure);
        const fragmentedExposureScale = 0.75
            + 0.25 * smoothstep((rawExposure - 0.12) / 0.38);
        const weakSystemScale = 0.72
            + 0.28 * smoothstep((updatedCyclone.intensity - 25) / 35);
        const effectiveExposure = geometricExposure
            * fragmentedExposureScale
            * weakSystemScale;
        updatedCyclone.landDecayExposure = effectiveExposure;
        const retention = Math.exp(-MODEL_STEP_HOURS * effectiveExposure / decayTimeHours);
        updatedCyclone.intensity *= retention;
        updatedCyclone.speed *= 1 - 0.01 * effectiveExposure;

        if (updatedCyclone.isERCActive) {
            // Landfall destroys the thermodynamic and convective memory of
            // both rings. Keep the geometry briefly for a smooth visual abort,
            // but do not let an old oceanic MPI/outer-ring target reappear as
            // an intensity surge when the centre moves back over water.
            const landWindCap = clamp(updatedCyclone.intensity, 10, MAX_TROPICAL_WIND_KT);
            for (const key of [
                'ercInnerWind',
                'ercEnvironmentalPeak',
                'ercMpiCeiling',
                'ercReplacementWindTarget'
            ]) {
                updatedCyclone[key] = Number.isFinite(updatedCyclone[key])
                    ? Math.min(updatedCyclone[key], landWindCap)
                    : landWindCap;
            }
        }

    } else if (updatedCyclone.isExtratropical) {
        intensityPath = 'extratropical';
        // Translation follows the integrated environmental flow; ET alone
        // is not a source of an extra 1.5 kt of speed every three hours. 
        if (updatedCyclone.extratropicalStage === 'developing') {
            if (updatedCyclone.age >= updatedCyclone.extratropicalDevelopmentEndTime || etEnvironment.support < 0.15) {
                updatedCyclone.extratropicalStage = 'decaying';
                const decayRate = -6 + random() * 6; 
                updatedCyclone.intensity += decayRate;
            } else {
                const divisor = 9 + random() * 5; 
                const target = Math.min(updatedCyclone.extratropicalMaxIntensity, 45 + 50 * etEnvironment.support);
                const intensification = clamp((target - updatedCyclone.intensity) / divisor, -4, 1.5);
                updatedCyclone.intensity += intensification;
            }
        } else { 
            const decayRate = -1 - random() * 2; 
            updatedCyclone.intensity += decayRate;
        }

    } else {
        // MPI Logic
        const thermodynamicMpi = oceanThermodynamicMpi(sst, updatedCyclone.isSubtropical);
        const mpi = adjustMpiForStormStructure(thermodynamicMpi, updatedCyclone);
        thermodynamicMpiDiagnostic = thermodynamicMpi;
        structuralMpiDiagnostic = mpi;

        // Growth Rate Logic
        let latF = (0.4 / Math.max(5, Math.abs(updatedCyclone.lat)) ** 2) * (updatedCyclone.intensity / 50);
        let intensificationRate = Math.max(0, random() * 0.14 * Math.min(1, ((updatedCyclone.intensity - 13) / 65)) - latF);


        if (updatedCyclone.isMonsoonDepression) {
            intensificationRate *= (random() + 0.10) * 0.70; 
        }
        
        let potentialChange = (mpi - updatedCyclone.intensity) * intensificationRate;
        
        let shear = Math.max(0, updatedCyclone.effectiveShear - 8) / 10.0; 
        
        // Latitude and season already enter the three-dimensional environmental field.
        // Do not add a second, hidden climatological shear penalty here.

        // Dry Air Logic
        const humidityEnvironment = sampleEnvironmentalHumidity(
            updatedCyclone,
            pressureSystems,
            month,
            globalTemp,
            options.forecast === true
        );
        const effectiveHumidity = humidityEnvironment.effective;
        updatedCyclone.environmentalHumidity = effectiveHumidity;
        intensificationRate = rapidIntensificationRate(updatedCyclone, mpi, sst, totalShear, effectiveHumidity, intensificationRate, random);
        // Ventilation begins below 75% RH, but remains weak through 60%. The
        // piecewise response below keeps moderate dryness developable while
        // allowing it to interrupt a storm that is locked exactly at MPI.
        const moistureResponse = moistureIntensityResponse(
            effectiveHumidity,
            cyclone.circulationSize
        );
        intensificationRate *= moistureResponse.growthFactor;
        potentialChange = (mpi - updatedCyclone.intensity) * intensificationRate;
        if (updatedCyclone.isRapidIntensifying) potentialChange = Math.min(18, potentialChange);
        if (options.forecast === true && potentialChange > 0) {
            potentialChange *= updatedCyclone.isRapidIntensifying
                ? FORECAST_RI_INTENSIFICATION_RATE_SCALE
                : FORECAST_INTENSIFICATION_RATE_SCALE;
        }
        // A broad circulation is more resistant, not immune. Moderate
        // 60-75% RH carries only the shallow first-slope ventilation loss.
        const dryAirFactor = moistureResponse.dryAirFactor;
        const currentSize = updatedCyclone.circulationSize || 300;
        const clampedSize = Math.max(150, Math.min(500, currentSize));
        // Shear resistance is not identical across all tropical vortices.
        // Broad, vertically coherent circulations retain convection and
        // recover their alignment more effectively than small, shallow
        // disturbances.  Use a smooth scale response rather than a hard
        // category switch: the penalty is about 1.20x for a 150-km system,
        // about 0.95x near 300 km, and bottoms near 0.55x by 500 km.  This
        // reduces vulnerability without pretending that a large storm is
        // immune to a persistent hostile shear vector.
        const sizeMaturity = smoothstep((clampedSize - 150) / (500 - 150));
        shearResilience = calculateShearResilience(
            updatedCyclone,
            currentSize,
            effectiveHumidity
        );
        updatedCyclone.shearResilience = shearResilience;
        // Fold the new structural response into the existing size response
        // instead of stacking a second independent loss term. This preserves
        // the prior broad-storm behaviour while allowing a moist, coherent
        // vortex to resist part of the ventilation loss.
        sizeShearResistance = clamp(
            (1.20 - 0.65 * sizeMaturity) * (1 - 0.75 * shearResilience),
            0.55,
            1.20
        );
        const shearSensitivity = updatedCyclone.isSubtropical ? 0.75 : 1;
        const environmentalLosses = sizeShearResistance * shear * shearSensitivity + dryAirFactor;
        const tropicalChange = potentialChange - environmentalLosses;
        const thermalChange = updatedCyclone.isSubtropical
            ? subtropicalIntensityChange(updatedCyclone.intensity, tropicalChange, sst,
                effectiveHumidity, totalShear, environmentalLosses, etEnvironment.trough)
            : tropicalChange;
        const baseIntensityChange = updatedCyclone.isTransitioning
            ? transitionIntensityChange(updatedCyclone.intensity, thermalChange, etEnvironment.support, updatedCyclone.transitionHours)
            : thermalChange;
        baseIntensityChangeDiagnostic = baseIntensityChange;
        if (updatedCyclone.isTransitioning) intensityPath = 'transitioning';
        else if (updatedCyclone.isERCActive) intensityPath = `erc-${updatedCyclone.ercState || 'active'}`;
        const ercEnvironment = {
            mpi,
            totalShear,
            effectiveHumidity,
            isOverLand,
            baseIntensityChange
        };

        if (updatedCyclone.isERCActive) {
            evolveEyewallReplacement(updatedCyclone, ercEnvironment, true, random);
        } else {
            updatedCyclone.intensity += baseIntensityChange;
            // This call accumulates structural favourability and may seed an
            // outer eyewall; its intensity evolution begins on the next step.
            evolveEyewallReplacement(updatedCyclone, ercEnvironment, false, random);
        }
    }

    // Tropical conversion needs sustained warm-water convection, not simply an age timer.
    if (updatedCyclone.isSubtropical) {
        updatedCyclone.subtropicalWarmHours = Math.max(0, (updatedCyclone.subtropicalWarmHours || 0)
            + (!isOverLand && !updatedCyclone.isTransitioning
                && sst >= TROPICAL_CONVERSION_SST_MIN_C && totalShear < 20
                ? MODEL_STEP_HOURS : -MODEL_STEP_HOURS));
        const requiredWarmHours = Math.max(24, updatedCyclone.subtropicalTransitionTime || 48);
        if (updatedCyclone.subtropicalWarmHours >= requiredWarmHours || updatedCyclone.isExtratropical) {
            updatedCyclone.isSubtropical = false;
        }
    }

    // Land interaction and structural transition disrupt both eyewalls.  Keep
    // a short-lived decaying outer ring over land, but remove the tropical
    // double-eyewall structure immediately after extratropical transition.
    if (updatedCyclone.isERCActive && updatedCyclone.isExtratropical) {
        updatedCyclone.rmw = updatedCyclone.ercInnerRmw;
        clearEyewallStructure(updatedCyclone, 'interrupted');
    } else if (updatedCyclone.isERCActive && (landInteraction || isOverLand || updatedCyclone.isTransitioning)) {
        updatedCyclone.ercState = 'aborting';
        updatedCyclone.ercAdverseHours = Math.max(18, updatedCyclone.ercAdverseHours || 0);
        updatedCyclone.ercInnerWind = Math.min(updatedCyclone.ercInnerWind, updatedCyclone.intensity);
        const structuralExposure = Math.max(updatedCyclone.landDecayExposure, isOverLand ? 0.08 : 0);
        updatedCyclone.ercOuterWindAnomaly *= Math.exp(
            -MODEL_STEP_HOURS * structuralExposure / ERC_ABORT_ADVERSE_DECAY_HOURS
        );
        const disruptedStructure = getEyewallStructure(updatedCyclone);
        // Land can only weaken the scalar maximum on this step. Synchronize
        // both rings to it so the old outer-eyewall state cannot restore a
        // 120 kt maximum immediately after a 64 kt terrain sample.
        updatedCyclone.intensity = Math.min(updatedCyclone.intensity, disruptedStructure.peakWind);
        updatedCyclone.ercInnerWind = Math.min(updatedCyclone.ercInnerWind, updatedCyclone.intensity);
        if (disruptedStructure.outerPeak > updatedCyclone.intensity) {
            updatedCyclone.ercOuterWindAnomaly = Math.max(
                0,
                updatedCyclone.ercOuterWindAnomaly
                    - (disruptedStructure.outerPeak - updatedCyclone.intensity)
            );
        }
        updatedCyclone.ercOuterShare = disruptedStructure.outerShare;
        if (updatedCyclone.ercOuterWindAnomaly < 0.8) {
            updatedCyclone.rmw = updatedCyclone.ercInnerRmw;
            updatedCyclone.ercCooldownUntil = updatedCyclone.age + 12 + random() * 12;
            clearEyewallStructure(updatedCyclone, 'aborted');
        }
    }

    const intensityDiagnostic = {
        modelRevision: '2026-09-10-tutt-audit',
        age: updatedCyclone.age,
        before: oldIntensity,
        after: updatedCyclone.intensity,
        change: updatedCyclone.intensity - oldIntensity,
        path: intensityPath,
        effectiveHumidity: updatedCyclone.environmentalHumidity ?? null,
        totalShear,
        effectiveShear: updatedCyclone.effectiveShear,
        coldSurgeInfluence: updatedCyclone.coldSurgeInfluence,
        coldSurgeCooling: updatedCyclone.coldSurgeCoolingEffect,
        coldSurgeShearBoost: updatedCyclone.coldSurgeShearBoost,
        shearDamage,
        shearResilience,
        sst,
        backgroundSst: oceanUpdate.ocean.backgroundSstC,
        oceanCooling: oceanUpdate.ocean.coolingC,
        oceanHeatContent: oceanUpdate.ocean.ohcKJcm2,
        mixedLayerDepth: oceanUpdate.ocean.mixedLayerDepthM,
        depth26: oceanUpdate.ocean.d26M,
        thermodynamicMpi: thermodynamicMpiDiagnostic,
        structuralMpi: structuralMpiDiagnostic,
        sizeShearResistance,
        landExposure: trackLand.landFraction,
        landDecayExposure: updatedCyclone.landDecayExposure,
        terrainElevation,
        baseIntensityChange: baseIntensityChangeDiagnostic,
        ercStateBefore: ercStateBeforeIntensity,
        ercStateAfter: updatedCyclone.ercState || 'none',
        rmw: updatedCyclone.rmw,
        circulationSize: updatedCyclone.circulationSize,
        riRate: updatedCyclone.riRate ?? null,
        riUntil: updatedCyclone.riUntil ?? null,
        ercInnerWind: updatedCyclone.ercInnerWind ?? null,
        ercOuterWindAnomaly: updatedCyclone.ercOuterWindAnomaly ?? null,
        ercInnerRmw: updatedCyclone.ercInnerRmw ?? null,
        ercOuterRmw: updatedCyclone.ercOuterRmw ?? null,
        ercMpiCeiling: Number.isFinite(updatedCyclone.ercMpiCeiling) ? updatedCyclone.ercMpiCeiling : null
    };
    updatedCyclone.lastIntensityDiagnostic = intensityDiagnostic;
    if (Math.abs(intensityDiagnostic.change) >= 12
        || !Number.isFinite(intensityDiagnostic.after)
        || (Number.isFinite(thermodynamicMpiDiagnostic)
            && intensityDiagnostic.after > thermodynamicMpiDiagnostic
            && intensityDiagnostic.change > 0)) {
        updatedCyclone.intensityEvents = [
            ...(Array.isArray(updatedCyclone.intensityEvents) ? updatedCyclone.intensityEvents.slice(-19) : []),
            intensityDiagnostic
        ];
    }

    const intensityChange = updatedCyclone.intensity - oldIntensity;
    const canPostRelaxSize = !updatedCyclone.isERCActive
        && updatedCyclone.age > (updatedCyclone.ercCompletedAt || 0)
        && updatedCyclone.age <= (updatedCyclone.ercPostSizeRelaxUntil || 0)
        && Number.isFinite(updatedCyclone.ercPostSizeTarget)
        && !isOverLand
        && !updatedCyclone.isTransitioning
        && !updatedCyclone.isExtratropical;
    if (landInteraction || isOverLand) {
        expandRmwOverLand(updatedCyclone, terrainElevation);
        // Decay the broad envelope over hours, preserving residual winds and
        // avoiding both mountain-driven inflation and an instantaneous cutoff.
        const envelopeExposure = Math.max(updatedCyclone.landDecayExposure, isOverLand ? 0.08 : 0);
        updatedCyclone.circulationSize *= Math.exp(
            -MODEL_STEP_HOURS * envelopeExposure / (updatedCyclone.isExtratropical ? 96 : 48)
        );
    } else if (updatedCyclone.isExtratropical || updatedCyclone.isTransitioning) {
        updatedCyclone.circulationSize *= 1.04;
        updatedCyclone.rmw *= 1.03;
    } else if (updatedCyclone.isERCActive || updatedCyclone.ercCompletedAt === updatedCyclone.age) {
        // ERC structure already controls size and RMW for this step.
    } else if (canPostRelaxSize) {
        // The newly dominant outer eyewall contracts faster than the broader
        // wind envelope.  Leave both dimensions to their explicit post-ERC
        // relaxation paths rather than the generic intensity-size tendency.
    } else if (intensityChange > 0.5) {
        updatedCyclone.circulationSize *= 0.99;
        contractRmwDuringIntensification(updatedCyclone);
    } else {
        updatedCyclone.circulationSize *= 1.002;
        updatedCyclone.rmw *= 1.001;
    }

    if (canPostRelaxSize) {
        const relaxationHours = Math.max(24, updatedCyclone.ercPostSizeRelaxHours || 72);
        const relaxationRate = clamp(MODEL_STEP_HOURS / relaxationHours * 3.2, 0.055, 0.14);
        updatedCyclone.circulationSize += (
            updatedCyclone.ercPostSizeTarget - updatedCyclone.circulationSize
        ) * relaxationRate;
    } else if (updatedCyclone.age > (updatedCyclone.ercPostSizeRelaxUntil || 0)) {
        updatedCyclone.ercPostSizeTarget = null;
    }

    const postContractionSupport = postErcContractionSupport(
        updatedCyclone,
        thermodynamicMpiDiagnostic,
        baseIntensityChangeDiagnostic
    );
    const canPostContract = !updatedCyclone.isERCActive
        && updatedCyclone.age > (updatedCyclone.ercCompletedAt || 0)
        && updatedCyclone.age <= (updatedCyclone.ercPostContractionUntil || 0)
        && Number.isFinite(updatedCyclone.ercPostRmwTarget)
        && !isOverLand
        && !updatedCyclone.isTransitioning
        && !updatedCyclone.isExtratropical
        && postContractionSupport > 0;
    if (canPostContract && updatedCyclone.rmw > updatedCyclone.ercPostRmwTarget + 0.5) {
        contractPostErcRmw(updatedCyclone, postContractionSupport);
    } else if (updatedCyclone.age > (updatedCyclone.ercPostContractionUntil || 0)) {
        updatedCyclone.ercPostRmwTarget = null;
    }
    if (!updatedCyclone.isERCActive
        && Number.isFinite(updatedCyclone.radarEyewallMaturity)
        && updatedCyclone.radarEyewallMaturity < 1) {
        updatedCyclone.radarEyewallMaturity = Math.min(1, updatedCyclone.radarEyewallMaturity + 0.08);
    }
    expandRmwFromFrontalInteraction(updatedCyclone);
    updatedCyclone.circulationSize = Math.max(100, Math.min(updatedCyclone.circulationSize, 800));
    updatedCyclone.rmw = clamp(updatedCyclone.rmw, MIN_RMW_KM, 190);
    normalizeCoreRadii(updatedCyclone);
    const finiteIntensityFallback = Number.isFinite(oldIntensity)
        ? oldIntensity
        : Number.isFinite(updatedCyclone.ercInnerWind)
            ? updatedCyclone.ercInnerWind : 10;
    updatedCyclone.intensity = clamp(
        Number.isFinite(updatedCyclone.intensity)
            ? updatedCyclone.intensity : finiteIntensityFallback,
        10,
        MAX_TROPICAL_WIND_KT
    );
    
    // Use the same near-surface environmental pressure as the live panels,
    // station reduction, and product charts. Reading the lower layer here
    // used to create a second pressure datum for the track state.
    const currentEnvPressure = getSurfacePressureAt(
        updatedCyclone.lon,
        updatedCyclone.lat,
        pressureSystems
    );
    const previousCentralPressure = Number.isFinite(cyclone.centralPressure)
        ? cyclone.centralPressure : null;
    const currentCentralPressure = windToPressure(
        updatedCyclone.intensity, 
        updatedCyclone.circulationSize, 
        updatedCyclone.basin, 
        currentEnvPressure
    );
    updatedCyclone.environmentalPressure = currentEnvPressure;
    updatedCyclone.centralPressure = currentCentralPressure;
    updatedCyclone.pressureTendency = previousCentralPressure === null
        ? 0
        : (currentCentralPressure - previousCentralPressure) / MODEL_STEP_HOURS;

    if (!options.deferWindRadii) {
        finalizeCycloneStepDiagnostics(
            updatedCyclone,
            calculateWindRadii(updatedCyclone, pressureSystems, month),
            pressureSystems
        );
    }

    if (frontalAbsorption) {
        // Keep the established terminal status for save/UI compatibility,
        // while retaining an explicit physical cause for history products.
        updatedCyclone.status = 'dissipated';
        updatedCyclone.terminationReason = 'absorbed-by-frontal-cyclone';
        updatedCyclone.absorbedByFrontalLow = frontalAbsorption;
    } else if (updatedCyclone.intensity < 17 || (updatedCyclone.isExtratropical && updatedCyclone.intensity < 24) || updatedCyclone.lat > 70 || updatedCyclone.lat < -70) {
        updatedCyclone.status = 'dissipated';
    }
    
    if (!options.forecast && !updatedCyclone.named && updatedCyclone.intensity >= 34 && !updatedCyclone.isExtratropical) {
        updatedCyclone.named = true;
        updatedCyclone.namedAtAge = updatedCyclone.age;
        const basinKey = updatedCyclone.basin || 'WPAC';
        const list = NAME_LISTS[basinKey] || NAME_LISTS['WPAC'];
        const safeIndex = nameIndex % list.length;
        updatedCyclone.name = list[safeIndex];
        console.log(`System upgraded to Tropical Storm ${updatedCyclone.name} (${basinKey})`);
    }
    
    return updatedCyclone;
}
