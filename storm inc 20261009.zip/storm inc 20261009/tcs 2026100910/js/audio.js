/**
 * Small procedural SFX palette. Shared effects are built once; every source
 * disconnects on completion. Sound variation never consumes model Math.random().
 */
let audioCtx=null, masterGain=null, analyser=null, mix=null;
let reverbNode=null, echoNode=null, noiseBuffer=null, isSFXMuted=false;
let randomState=0;
const voices=new Set(), lastCue=new Map(), lastVariant=new Map();
const MASTER_LEVEL=0.25, MAX_VOICES=48, LANDFALL_SOUND_GAIN=2.5;

function soundRandom(){
    if(!randomState){
        const seed=new Uint32Array(1);
        if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(seed);
        randomState=seed[0] || ((Date.now() ^ 0x6d2b79f5)>>>0);
    }
    randomState^=randomState<<13; randomState^=randomState>>>17; randomState^=randomState<<5;
    return (randomState>>>0)/4294967296;
}
function choose(key,variants){
    const previous=lastVariant.get(key);
    let index=Math.floor(soundRandom()*(previous===undefined?variants.length:variants.length-1));
    if(previous!==undefined && index>=previous)index++;
    lastVariant.set(key,index);
    return variants[index];
}

export function initAudio(){
    if(!audioCtx){
        const Context=globalThis.window?.AudioContext || globalThis.window?.webkitAudioContext;
        if(!Context)return false;
        audioCtx=new Context();
        mix=audioCtx.createGain();
        const compressor=audioCtx.createDynamicsCompressor();
        compressor.threshold.value=-12; compressor.knee.value=12; compressor.ratio.value=4;
        compressor.attack.value=0.004; compressor.release.value=0.12;
        masterGain=audioCtx.createGain(); masterGain.gain.value=isSFXMuted?0:MASTER_LEVEL;
        analyser=audioCtx.createAnalyser(); analyser.fftSize=2048;
        mix.connect(compressor); compressor.connect(masterGain); masterGain.connect(analyser); analyser.connect(audioCtx.destination);

        // Short room and a single filtered echo tap, reused by all cues.
        // The master is AFTER both returns, so mute also silences existing tails.
        const length=Math.ceil(audioCtx.sampleRate*0.65);
        const impulse=audioCtx.createBuffer(2,length,audioCtx.sampleRate);
        for(let channel=0;channel<2;channel++){
            const data=impulse.getChannelData(channel);
            for(let i=0;i<length;i++)data[i]=(soundRandom()*2-1)*(1-i/length)**3*0.45;
        }
        reverbNode=audioCtx.createConvolver();reverbNode.buffer=impulse;reverbNode.connect(mix);
        echoNode=audioCtx.createDelay(0.3);echoNode.delayTime.value=0.13;
        const echoFilter=audioCtx.createBiquadFilter();
        echoFilter.type='lowpass';echoFilter.frequency.value=1800;
        echoNode.connect(echoFilter);echoFilter.connect(mix);

        noiseBuffer=audioCtx.createBuffer(1,Math.ceil(audioCtx.sampleRate*0.5),audioCtx.sampleRate);
        const noise=noiseBuffer.getChannelData(0);
        for(let i=0;i<noise.length;i++)noise[i]=soundRandom()*2-1;
    }
    if(audioCtx.state==='suspended')audioCtx.resume()?.catch?.(()=>{});
    return true;
}
export function toggleSFX(){
    isSFXMuted=!isSFXMuted;
    if(masterGain){
        const t=audioCtx.currentTime;
        masterGain.gain.cancelScheduledValues(t);
        masterGain.gain.setValueAtTime(masterGain.gain.value,t);
        masterGain.gain.linearRampToValueAtTime(isSFXMuted?0:MASTER_LEVEL,t+0.015);
    }
    return isSFXMuted;
}
function begin(key,cooldown=0.08){
    if(isSFXMuted || !initAudio())return null;
    const now=audioCtx.currentTime;
    if(now-(lastCue.get(key)??-Infinity)<cooldown)return null;
    lastCue.set(key,now);
    return now;
}
function envelope(gain,t,duration,peak,attack,release=null,floor=0.0001){
    const rise=Math.min(attack,duration*0.3);
    gain.gain.setValueAtTime(0,t);
    gain.gain.linearRampToValueAtTime(peak,t+rise);
    if(release!==null)gain.gain.setValueAtTime(peak,t+Math.max(rise,duration-release));
    gain.gain.exponentialRampToValueAtTime(floor,t+duration);
}
function connectVoice(source,gain,nodes,room,echo){
    gain.connect(mix);
    for(const [amount,effect] of [[room,reverbNode],[echo,echoNode]]){
        if(amount>0){
            const send=audioCtx.createGain();send.gain.value=amount;
            gain.connect(send);send.connect(effect);nodes.push(send);
        }
    }
    const voice={source,nodes:[source,gain,...nodes]};voices.add(voice);
    source.onended=()=>{
        for(const node of voice.nodes)node.disconnect();
        voices.delete(voice);
    };
}
function tone(frequency,t,duration,{type='sine',peak=0.14,attack=0.008,end=frequency,
    filter=2600,filterEnd=filter,detune=0,room=0.08,echo=0,release=null,floor=0.0001,q=0.65}={}){
    if(voices.size>=MAX_VOICES)return;
    const source=audioCtx.createOscillator(),gain=audioCtx.createGain(),lowpass=audioCtx.createBiquadFilter();
    source.type=type;source.detune.value=detune;source.frequency.setValueAtTime(frequency,t);
    if(end!==frequency)source.frequency.exponentialRampToValueAtTime(end,t+duration);
    lowpass.type='lowpass';lowpass.frequency.value=filter;lowpass.Q.value=q;
    if(filterEnd!==filter){
        lowpass.frequency.setValueAtTime(filter,t);
        lowpass.frequency.exponentialRampToValueAtTime(filterEnd,t+duration);
    }
    envelope(gain,t,duration,peak,attack,release,floor);
    // Always route through the filter, rather than bypassing its unconnected output.
    source.connect(lowpass);lowpass.connect(gain);
    connectVoice(source,gain,[lowpass],room,echo);
    source.start(t);source.stop(t+duration+0.01);
}
function texture(t,duration,{frequency=900,end=frequency,peak=0.08,type='bandpass',q=0.7,room=0}={}){
    if(voices.size>=MAX_VOICES)return;
    const source=audioCtx.createBufferSource(),gain=audioCtx.createGain(),filter=audioCtx.createBiquadFilter();
    source.buffer=noiseBuffer;source.playbackRate.value=0.94+soundRandom()*0.12;
    filter.type=type;filter.frequency.setValueAtTime(frequency,t);
    if(end!==frequency)filter.frequency.exponentialRampToValueAtTime(end,t+duration);
    filter.Q.value=q;envelope(gain,t,duration,peak,0.006);
    source.connect(filter);filter.connect(gain);
    connectVoice(source,gain,[filter],room,0);
    source.start(t,soundRandom()*0.06);source.stop(t+duration+0.01);
}
// Share the landfall palette: low-frequency contact, warm body and a short
// triangular ring. A held body adds weight without raising the global volume.
function contact(t,strength=1,duration=0.11){
    texture(t,duration,{frequency:260,end:90,peak:0.18*strength,q:0.8,room:0.09});
    tone(120,t,duration,{peak:0.12*strength,end:70,filter:400,room:0.08});
}
function weightedNote(frequency,t,duration,peak=0.20){
    tone(frequency,t,duration,{type:'triangle',peak,attack:0.004,
        release:duration*0.55,filter:2200,room:0.10});
    tone(frequency*0.5,t,duration*0.85,{peak:peak*0.6,attack:0.006,
        release:duration*0.5,filter:900,room:0.06});
}
function weightedPhrase(notes,t,{step=0.045,duration=0.095,peak=0.20}={}){
    notes.forEach((frequency,i)=>weightedNote(frequency,t+i*step,duration,
        peak*(i===notes.length-1?1:0.8)));
}

/** A compact weighted tap, not a thin square-wave bleep. */
export function playClick(){
    const t=begin('click',0.045);if(t===null)return;
    const pitch=choose('click',[440,493.88,523.25]);
    weightedNote(pitch,t,0.085,0.17);
    contact(t,0.7,0.075);
}

/** Warm upward/downward movement anchored by the same low contact sound. */
export function playPanelOpen(){
    const t=begin('panel',0.08);if(t===null)return;
    contact(t,0.85,0.12);
    weightedPhrase([330,495],t+0.01,{step:0.055,duration:0.105,peak:0.21});
}
export function playPanelClose(){
    const t=begin('panel',0.08);if(t===null)return;
    contact(t,0.8,0.10);
    weightedPhrase([495,330],t,{step:0.045,duration:0.09,peak:0.19});
}
export function playToggleOn(){
    const t=begin('toggle',0.065);if(t===null)return;
    // Layers slide into view; no contact transient, bass hit or note staircase.
    tone(300,t,0.18,{end:600,peak:0.25,attack:0.02,release:0.10,
        filter:1200,filterEnd:2400,floor:0.001,room:0.07});
}
export function playToggleOff(){
    const t=begin('toggle',0.065);if(t===null)return;
    tone(600,t,0.16,{end:280,peak:0.21,attack:0.02,release:0.09,
        filter:2000,filterEnd:400,q:0.8,floor:0.001,room:0.05});
}

/** Original start cue: C5–E5–G5–C6, with sustained sine/harmonic envelopes. */
export function playStart(){
    const t=begin('start',0.4);if(t===null)return;
    [523.25,659.25,783.99,1046.50].forEach((frequency,i)=>{
        const start=t+i*0.08;
        tone(frequency,start,0.5,{peak:0.2,attack:0.015,release:0.25,
            filter:3500,floor:0.001,room:0.15});
        tone(frequency*2,start,0.35,{peak:0.08,attack:0.03,release:0.2,
            filter:8000,floor:0.001,room:0.15});
    });
}
export function playError(){
    const t=begin('error',0.20);if(t===null)return;
    contact(t,1,0.10);
    weightedPhrase([293.66,196],t,{step:0.09,duration:0.105,peak:0.23});
}

/** A weighty paired signal, without dissonant beating or a siren. */
export function playAlert(){
    const t=begin('alert',0.55);if(t===null)return;
    contact(t,1.1,0.16);
    [0,0.20].forEach(offset=>weightedPhrase([523.25,392],t+offset,{
        step:0.065,duration:0.11,peak:0.24
    }));
}
export function playLandfallSound(){
    const t=begin('landfall',0.6);if(t===null)return;
    texture(t,0.34,{frequency:260,end:90,peak:0.13*LANDFALL_SOUND_GAIN,q:0.8,room:0.09});
    tone(120,t,0.27,{peak:0.055*LANDFALL_SOUND_GAIN,end:65,filter:400,room:0.08});
    [740,1110].forEach((f,i)=>tone(f,t+0.025+i*0.045,0.22,{
        type:'triangle',peak:0.05*LANDFALL_SOUND_GAIN,end:f*0.72,filter:2200,room:0.1
    }));
}

// Restore the original TY/C5 melodies, timing and envelopes, while retaining
// shared output/muting, source cleanup and the existing bounded voice budget.
function typhoonCelebration(t){
    const notes=[523.25,659.25,783.99,987.77];
    [0,0.65].forEach(offset=>notes.forEach((frequency,i)=>{
        const start=t+offset+i*0.10;
        tone(frequency,start,0.45,{peak:0.22,attack:0.01,release:0.2,
            floor:0.001,filter:4000,room:0.15});
        tone(frequency*2,start,0.36,{peak:0.12,attack:0.02,release:0.15,
            floor:0.001,filter:8000,room:0.15});
        tone(frequency*0.5,start,0.225,{peak:0.08,attack:0.015,release:0.1,
            floor:0.001,filter:1000,room:0.15});
    }));
}
function cat5Celebration(t){
    const notes=[523.25,659.25,783.99,987.77,1174.66];
    [0,0.75].forEach(offset=>notes.forEach((frequency,i)=>{
        const start=t+offset+i*0.09;
        tone(frequency,start,0.6,{peak:0.25,attack:0.015,floor:0.001,
            filter:4500,q:0.8,room:0.15});
        tone(frequency*2,start,2.8,{peak:0.15,attack:0.03,floor:0.001,
            filter:8000,room:0.15});
        if(i<3)tone(frequency*0.5,start,0.4,{peak:0.12,attack:0.02,
            floor:0.001,filter:800,room:0.15});
    }));
}

/** TY/C1 and C5 keep their original celebrations; C2–C4 use rising short cues. */
export function playUpgradeSound(category=1){
    if(!Number.isInteger(category)||category<1||category>5)return;
    const t=begin('upgrade',0.12);if(t===null)return;
    if(category===1){typhoonCelebration(t);return;}
    if(category===5){cat5Celebration(t);return;}
    const pitch=[587.33,659.25,783.99][category-2];
    weightedPhrase([pitch*0.75,pitch],t,{step:0.055,duration:0.075,peak:0.24});
    weightedNote(pitch*1.25,t+0.11,0.11,0.27);
    contact(t,1,0.13);
}
export function playCat5Sound(){
    playUpgradeSound(5);
}
/** Paper movement with the same weighted tap/ring as the other controls. */
export function playPageTurn(){
    const t=begin('page',0.075);if(t===null)return;
    contact(t,0.8,0.09);
    weightedPhrase([392,493.88],t,{step:0.045,duration:0.08,peak:0.18});
    texture(t,0.11,{type:'lowpass',frequency:650,peak:0.10});
}
export function getAnalyser(){return analyser;}
