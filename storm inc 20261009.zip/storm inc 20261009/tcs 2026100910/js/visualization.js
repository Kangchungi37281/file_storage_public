/**
 * visualization.js
 * 包含所有 D3.js 绘图函数。
 */
import { getCategory, getWindIntensityColor, windToPressure, directionToCompass, createGeoCircle, unwrapLongitude, calculateHollandPressure, getSST, calculateDistance } from './utils.js';
import { createOceanFieldSampler } from './ocean-thermal.js?v=20261008-forecast-categories1';
import { getWindVectorAt, getGeopotentialHeight500, getGeopotentialHeight500FromWaveFieldSample, createGeopotentialHeight500Sampler, createSurfacePressureSampler, getSurfaceEnvironmentalWind, getSurfacePressureAt, createCycloneHeightAnomalySampler, createCycloneEnvironmentalHeightFeedbackSampler, getCycloneFieldGeometryAt, getSurfaceFrontAnalysis, invalidatePressureSystemCaches } from './cyclone-model.js?v=20261008-forecast-categories1';
import { generatePathForecasts } from './forecast-models.js?v=20261008-forecast-categories1';
import { forecastDisplayLimit } from './forecast-horizon.js';
import { simulationDate } from './simulation-time.js?v=20261008-forecast-categories1';
import { getElevationAt, getLandStatus, getElevationThresholdGeometry } from './terrain-data.js?v=20260911-worker1-raster1';
import { WindWebGPURenderer, canUseWindWebGPU } from './wind-webgpu-renderer.js';
import { Height500BackgroundGpu } from './height500-webgpu.js?v=20261006-column1';
import { historicalCyclonePhase } from './cyclone-history.js?v=20260916-et-structure2';
import { drawStaticCylindricalAtlas, clearStaticAtlas } from './static-atlas.js?v=20261004-history1';
import { DISPLAY_FEATURES } from './display-features.js?v=20260922-shear1';
import { drawShearField, clearShearField } from './shear-layer.js?v=20261008-forecast-categories1';
import { setLegendVisible } from './legend-layout.js?v=20261006-legends-mobile1';
import { drawCycloneMarker } from './cyclone-marker.js?v=20260929-symbol1';
import { ICWC_MAP_STYLE } from './icwc-map-style.js';
import { prepareWarningMapView } from './warning-map-view.js?v=20261008-forecast-categories1';
import { prepareICWCGeography } from './icwc-geography.js';
import { prepareICWCContours } from './icwc-contours.js';
import { synopticCoastline as cachedSynopticCoastline } from './icwc-coastline.js';
import { drawWindRadiiOutlines, WARNING_WIND_RADII } from './wind-radii-outlines.js?v=20261008-forecast-categories1';
import { drawWarningFooter, warningFooterInfo } from './warning-footer.js?v=20261008-forecast-categories1';
import { drawICWCDisclaimer, cycloneNameAt } from './icwc-product-labels.js?v=20261008-forecast-categories1';
import { layoutWarningLeaders } from './warning-label-layout.js?v=20261008-forecast-categories1';
import { ICWC_MAJOR_CITIES } from './track-export.js?v=20261008-forecast-categories1';
export { drawCycloneMarker };

// [新增] 简单的伪随机噪声函数 (用于模拟大尺度湿度波动)
function pseudoNoise(x, y) {
    const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
    return n - Math.floor(n);
}

// [新增] 更加平滑的噪声 (双线性插值)
export function smoothNoise(x, y) {
    const i = Math.floor(x);
    const j = Math.floor(y);
    const u = x - i;
    const v = y - j;
    
    // 平滑插值公式
    const smooth = t => t * t * (3 - 2 * t);
    const uSm = smooth(u);
    const vSm = smooth(v);

    const n00 = pseudoNoise(i, j);
    const n10 = pseudoNoise(i + 1, j);
    const n01 = pseudoNoise(i, j + 1);
    const n11 = pseudoNoise(i + 1, j + 1);

    const x1 = n00 + (n10 - n00) * uSm;
    const x2 = n01 + (n11 - n01) * uSm;
    
    return x1 + (x2 - x1) * vSm;
}

const humiditySmoothstep = value => {
    const bounded = Math.max(0, Math.min(1, value));
    return bounded * bounded * (3 - 2 * bounded);
};
const profileHeight500 = globalThis.location?.search
    ? new URLSearchParams(globalThis.location.search).get('height500-profile') === '1'
    : false;

function reportHeight500Timing(stage, startedAt, details = {}) {
    if (!profileHeight500) return;
    console.info(`[500-hPa timing] ${stage}: ${(performance.now() - startedAt).toFixed(1)} ms ${JSON.stringify(details)}`);
}

let height500GpuPromise = null;
let height500GpuDisabled = false;

function withHeight500GpuTimeout(promise, timeoutMs, operation) {
    let timeoutId;
    return Promise.race([
        promise,
        new Promise((_, reject) => {
            timeoutId = setTimeout(() => reject(new Error(
                `500-hPa WebGPU ${operation} timed out after ${timeoutMs} ms`
            )), timeoutMs);
        })
    ]).finally(() => clearTimeout(timeoutId));
}

async function getHeight500Gpu() {
    if (height500GpuDisabled) return null;
    if (!height500GpuPromise) {
        const creation = Height500BackgroundGpu.create().then(gpu => {
            // Device creation cannot be cancelled. If its deadline already
            // expired, dispose a device that arrives late instead of leaking it.
            if (height500GpuDisabled) {
                gpu?.destroy();
                return null;
            }
            return gpu;
        });
        height500GpuPromise = withHeight500GpuTimeout(creation, 8000, 'initialization').then(gpu => {
            if (!gpu) {
                height500GpuDisabled = true;
                console.info('500-hPa WebGPU is unavailable; using the CPU field renderer.');
            } else {
                console.info('500-hPa background wavefield is running on WebGPU.');
            }
            return gpu;
        }).catch(error => {
            height500GpuDisabled = true;
            console.warn('500-hPa WebGPU initialization failed; using the CPU field renderer.', error);
            return null;
        });
    }
    return height500GpuPromise;
}

function normalizeHeightSystems(pressureSystems) {
    return Array.isArray(pressureSystems)
        ? { upper: pressureSystems }
        : pressureSystems;
}

async function sampleHeight500Grid(points, systems, cyclone, month, cooperative = false) {
    const startedAt = performance.now();
    const background = systems?.upper?.find(cell => cell.role === 'height-background');
    const modern = background?.flowModel === 'qg-barotropic-v1'
        || background?.fieldVersion >= 3;
    if (!modern || points.length === 0) return null;

    let gpu = null;
    try {
        // Ensure the atmospheric state and its zonal profiles are initialized
        // before packing the state for the GPU.
        getGeopotentialHeight500(points[0][0], points[0][1], systems, 500);
        const gpuWaitStartedAt = performance.now();
        gpu = await getHeight500Gpu();
        reportHeight500Timing('WebGPU device ready', gpuWaitStartedAt);
        if (!gpu) return null;
        const computeStartedAt = performance.now();
        const result = await withHeight500GpuTimeout(
            gpu.compute(points, systems, month), 2500, 'field readback'
        );
        reportHeight500Timing('wavefield compute/readback', computeStartedAt, { points: points.length });
        const samples = result?.samples;
        if (!samples || samples.length !== points.length * 2) {
            throw new Error('500-hPa WebGPU returned an incomplete grid');
        }

        const values = new Float32Array(points.length);
        const environmentValues = new Float64Array(points.length);
        const sampleHeight500 = createGeopotentialHeight500Sampler(systems, 500);
        const hasVortex = cyclone?.status === 'active'
            && Number.isFinite(cyclone.lon) && Number.isFinite(cyclone.lat)
            && Number.isFinite(cyclone.intensity);
        const sampleCycloneAnomaly = hasVortex
            ? createCycloneHeightAnomalySampler(cyclone, 500) : null;
        const sampleEnvironmentalFeedback = hasVortex
            ? createCycloneEnvironmentalHeightFeedbackSampler(cyclone, 500, systems)
            : null;
        const environmentStartedAt = performance.now();
        let sliceStart = performance.now();
        for (let index = 0; index < points.length; index++) {
            const [lon, lat] = points[index];
            environmentValues[index] = sampleHeight500(
                lon, lat,
                { height: samples[index * 2], displacement: samples[index * 2 + 1] }
            );
            // Chart-only scheduling: finish every original node in order,
            // but return control to the UI between bounded CPU slices.
            if (cooperative && performance.now() - sliceStart >= 8) {
                await new Promise(resolve => setTimeout(resolve, 0));
                sliceStart = performance.now();
            }
        }
        reportHeight500Timing('CPU environment resolve', environmentStartedAt, {
            points: points.length,
            upperCells: systems?.upper?.length || 0,
            lowerCells: systems?.lower?.length || 0,
            weatherSequence: !!systems?.upper?.find(cell => cell.role === 'height-background')?.weatherSequence
        });
        const resolveStartedAt = performance.now();
        sliceStart = performance.now();
        for (let index = 0; index < points.length; index++) {
            const [lon, lat] = points[index];
            const cycloneAnomaly = hasVortex ? sampleCycloneAnomaly(lon, lat) : 0;
            const environmentalFeedback = hasVortex ? sampleEnvironmentalFeedback(lon, lat) : 0;
            values[index] = environmentValues[index] + cycloneAnomaly + environmentalFeedback;
            if (cooperative && performance.now() - sliceStart >= 8) {
                await new Promise(resolve => setTimeout(resolve, 0));
                sliceStart = performance.now();
            }
        }
        reportHeight500Timing('CPU cyclone-anomaly resolve', resolveStartedAt, { points: points.length });
        reportHeight500Timing('sample total', startedAt, { points: points.length });
        return values;
    } catch (error) {
        height500GpuDisabled = true;
        gpu?.destroy();
        height500GpuPromise = null;
        console.warn('500-hPa WebGPU frame failed or stalled; using the CPU field renderer.', error);
        return null;
    }
}

function makeHeight500MapGrid(mapProjection, width, height, nx = 104) {
    const ny = Math.round(nx * height / width);
    const points = [];
    const pointIndices = [];
    for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
            const coords = mapProjection.invert([i * width / nx, j * height / ny]);
            const index = j * nx + i;
            if (!coords || !Number.isFinite(coords[0]) || !Number.isFinite(coords[1])) continue;
            points.push(coords);
            pointIndices.push(index);
        }
    }
    return { nx, ny, points, pointIndices };
}

// Prepare the exact field grid for one map redraw. The caller waits for this
// frame's GPU result before drawing, so intermediate visual frames are kept.
export async function prepareHeight500MapField(
    mapSvg, mapProjection, pressureSystems, cyclone, month = 8
) {
    const startedAt = performance.now();
    if (!mapSvg || !mapProjection || cyclone?.status !== 'active') return null;
    const systems = normalizeHeightSystems(pressureSystems);
    if (!systems?.upper?.some(cell => cell.role === 'height-background')) return null;
    const { width, height } = mapSvg.node().getBoundingClientRect();
    if (!(width > 0 && height > 0)) return null;

    // Match drawMap's active-cyclone projection without mutating the visible
    // projection while the GPU computes this frame.
    const frameProjection = d3.geoEquirectangular()
        .scale(mapProjection.scale())
        .rotate([-cyclone.lon, 0])
        .center([0, cyclone.lat])
        .translate([width / 2, height / 2]);
    const layout = makeHeight500MapGrid(frameProjection, width, height);
    reportHeight500Timing('project sample grid', startedAt, { points: layout.points.length, nx: layout.nx, ny: layout.ny });
    const sampled = await sampleHeight500Grid(layout.points, systems, cyclone, month);
    if (!sampled) return null;

    const values = new Float32Array(layout.nx * layout.ny);
    values.fill(5800);
    for (let index = 0; index < sampled.length; index++) {
        values[layout.pointIndices[index]] = sampled[index];
    }
    reportHeight500Timing('map field preparation total', startedAt, { points: layout.points.length });
    return { nx: layout.nx, ny: layout.ny, values };
}

// Monthly strength of the observed dry-season 600-hPa humidity anomaly.
// The strongest correction is Jan-Apr, then it relaxes through the monsoon
// and returns gradually with the northeast monsoon.  Values are seasonal
// weights, not humidity percentages.
const NIO_MIDLEVEL_DRY_SEASON_WEIGHT = Object.freeze([
    1.00, 1.00, 1.00, 1.00, 0.55, 0.15, 0.02, 0.02, 0.10, 0.30, 0.55, 0.80
]);

function northIndianOceanMidlevelHumidityAdjustment(lon, lat, month) {
    const longitude = ((lon % 360) + 360) % 360;
    const latitude = Math.abs(lat);
    if (lat <= 0 || latitude < 3 || latitude > 27
        || longitude < 38 || longitude > 103) return 0;

    const monthPosition = Number.isFinite(month)
        ? ((month - 1) % 12 + 12) % 12
        : 7;
    const monthIndex = Math.floor(monthPosition);
    const nextMonthIndex = (monthIndex + 1) % 12;
    const monthFraction = monthPosition - monthIndex;
    const monthWeight = NIO_MIDLEVEL_DRY_SEASON_WEIGHT[monthIndex]
        + (NIO_MIDLEVEL_DRY_SEASON_WEIGHT[nextMonthIndex]
            - NIO_MIDLEVEL_DRY_SEASON_WEIGHT[monthIndex]) * monthFraction;

    // Fade into adjacent basins and outside the main tropical-cyclone belt.
    const basinLatitudeWeight = humiditySmoothstep((latitude - 3) / 3)
        * (1 - humiditySmoothstep((latitude - 20) / 7));
    const arabianSeaWeight = humiditySmoothstep((longitude - 40) / 5)
        * (1 - humiditySmoothstep((longitude - 75) / 5));
    const bayOfBengalWeight = humiditySmoothstep((longitude - 78) / 4)
        * (1 - humiditySmoothstep((longitude - 96) / 4));

    // Duan et al. (2021, Atmosphere 12, 1593) report 600-hPa RH below 30%
    // over the Arabian Sea in Jan-Apr and 35-50% over much of the Bay of
    // Bengal, with wetter flanks.  The existing field is a broader RH proxy;
    // these bounded offsets bring its winter climatology toward those ranges
    // while leaving its transient wave, ridge and storm-relative anomalies.
    const centralBayDryness = Math.exp(-0.5 * (
        ((longitude - 89) / 8) ** 2 + ((latitude - 14) / 7) ** 2
    ));
    const basinAdjustment = -42 * arabianSeaWeight
        - (18 + 9 * centralBayDryness) * bayOfBengalWeight;
    return monthWeight * basinLatitudeWeight * basinAdjustment;
}

// ===================================================
// Humidity
// ===================================================
export function calculateBackgroundHumidity(lon, lat, pressureSystems, currentMonth, cyclone = null, globalTemp = 289, visualSampling = null) {
    const bgTemp = globalTemp;
    const backgroundField = pressureSystems?.upper?.find(
        cell => cell.role === 'height-background'
    );
    const hemisphere = lat < 0 ? -1 : 1;
    const moistureWaves = (backgroundField?.waves || [])
        .filter(wave => wave.hemisphere === hemisphere && wave.k <= 3)
        .sort((a, b) => a.k - b.k);
    // Each atmospheric realization owns its moisture phase. Falling back to
    // month/age keeps archived fields readable, but live simulations no longer
    // replay the same dry tongue at the same longitude and storm age.
    const primaryMoisturePhase = Number.isFinite(moistureWaves[0]?.phase)
        ? moistureWaves[0].phase : currentMonth * 0.41;
    const secondaryMoisturePhase = Number.isFinite(moistureWaves[1]?.phase)
        ? moistureWaves[1].phase : currentMonth * 0.73 + 1.2;
    // 1. 基础反比逻辑：气压越低，湿度越高
    const p = visualSampling
        ? visualSampling.pressure(lon, lat)
        : getSurfacePressureAt(lon, lat, pressureSystems);
    let hum = 79 + (1010 - p) * 1.15 + 3 * (bgTemp - 289);

    // 2. 柏林噪声叠加 (大尺度水汽输送)
    const timeFactor = (cyclone && cyclone.age) ? cyclone.age * 0.02 : 0;
    const scale = 0.06; 
    const noise = smoothNoise(
        lon * scale + timeFactor + primaryMoisturePhase * 0.75,
        lat * scale + secondaryMoisturePhase * 0.45
    );
    hum += (noise - 0.5) * 35;

    // 3. 纬度修正 (赤道湿，两极干)
    const latRad = lat * Math.PI / 180;
    hum *= (0.6 + 0.4 * Math.cos(latRad));

    // Midlevel tropical oceans are not a continuous moist sheet. Advecting
    // dry lobes on the equatorward flank of the subtropical ridge provide the
    // intermittent 500–700 hPa ventilation seen around otherwise oceanic TCs.
    // Two smooth scales avoid pixel noise while allowing narrow intrusions to
    // pass within a few hundred kilometres of a storm.
    const absLat = Math.abs(lat);
    const tropicalFlank = humiditySmoothstep((absLat - 6) / 9)
        * (1 - humiditySmoothstep((absLat - 35) / 11));
    const moistureClock = cyclone?.age || 0;
    const broadDryWave = smoothNoise(
        lon * 0.10 - moistureClock * 0.030 + primaryMoisturePhase * 0.60,
        lat * 0.12 + currentMonth * 0.17 + secondaryMoisturePhase * 0.35
    );
    const filamentWave = smoothNoise(
        lon * 0.18 + moistureClock * 0.050 + secondaryMoisturePhase * 0.70,
        lat * 0.20 - moistureClock * 0.017 - primaryMoisturePhase * 0.30
    );
    const synopticMoistureWave = 0.5 + 0.5 * Math.sin(
        lon * Math.PI / 28
            + lat * Math.PI / 18
            - moistureClock * 2 * Math.PI / 84
            + primaryMoisturePhase
            + 0.45 * secondaryMoisturePhase
    );
    const dryLobe = humiditySmoothstep(
        (0.66 - (0.45 * broadDryWave
            + 0.25 * filamentWave
            + 0.30 * synopticMoistureWave)) / 0.34
    );
    const height500 = getGeopotentialHeight500(lon, lat, pressureSystems, 500);
    const ridgeSubsidence = Number.isFinite(height500)
        ? humiditySmoothstep((height500 - 5860) / 100)
        : 0.35;
    // The moisture wave controls when a dry tongue reaches the storm, but its
    // amplitude is anchored to the resolved subtropical ridge. This prevents
    // an independent humidity texture from painting equally strong dry air
    // beneath a low-height tropical environment.
    const ridgeDryLobe = tropicalFlank * dryLobe
        * (3 + 7 * ridgeSubsidence);
    const synopticDryPulse = humiditySmoothstep(
        (0.40 - synopticMoistureWave) / 0.22
    );
    const transientDryPulse = tropicalFlank * synopticDryPulse
        * (2 + 3 * ridgeSubsidence);
    // Ridge subsidence and an arriving dry tongue are not two independent
    // reservoirs of dry air. Bound their combined tropical anomaly so a TC
    // on the ridge's oceanic southern flank is not forced into a permanently
    // hostile 40-50% RH environment in every realization.
    hum -= 3.5 * tropicalFlank * ridgeSubsidence;
    hum -= Math.min(10, ridgeDryLobe + 0.45 * transientDryPulse);

    // Upper cold vortices entrain dry midlevel air around their circulation.
    // Diagnose that footprint from the same prognostic cold-low objects that
    // bend the 500/200-hPa height field, including their smooth lifecycle.
    let coldVortexDrySupport = 0;
    for (const low of backgroundField?.synoptic?.coldLows || []) {
        if (!Number.isFinite(low.lon) || !Number.isFinite(low.lat)) continue;
        const life = Math.sin(Math.PI * humiditySmoothstep(
            (low.age || 0) / Math.max(1, low.life || 1)
        )) ** 2;
        const dx = ((lon - low.lon + 540) % 360) - 180;
        const longitudeScale = Math.max(0.35, Math.cos(low.lat * Math.PI / 180));
        const radius = Math.max(4, low.radius || 5);
        const distanceSquared = (dx * longitudeScale / (radius * 1.8)) ** 2
            + ((lat - low.lat) / (radius * 1.35)) ** 2;
        const strength = humiditySmoothstep(((low.amplitude || 24) - 18) / 24);
        coldVortexDrySupport = Math.max(
            coldVortexDrySupport,
            life * strength * Math.exp(-0.5 * distanceSquared)
        );
    }
    hum -= 14 * coldVortexDrySupport;

    const isNorth = lat > 0;
    let baseDryLat = isNorth ? 46 : -46;
    const systemsList = Array.isArray(pressureSystems) ? pressureSystems : (pressureSystems?.lower || []);
    if (systemsList.length > 0) {
        const subpolarLow = systemsList.find(s => 
            s.baseSigmaX > 200 && 
            s.strength < -15 &&   
            (isNorth ? s.y > 30 : s.y < -30)
        );

        if (subpolarLow) {
            const offset = isNorth ? 5 : -8;
            baseDryLat = subpolarLow.y + offset;
        }
    }

    // B. [新增] 计算罗斯贝波 (Rossby Wave) 偏移
    // 引入经度(lon)作为变量，使急流产生弯曲
    
    // 波数：环绕地球一圈有几个波 (通常 3-6 个)
    const waveNumber = 5.0;
    const phaseSpeed = (cyclone ? cyclone.age : 0) * 0.02;
    
    // 振幅：波动的南北幅度 (度)
    const waveAmplitude = 6.0; 

    // 计算正弦波偏移
    const rossbyOffset = Math.sin((lon * Math.PI / 180) * waveNumber + phaseSpeed) * waveAmplitude;

    // C. [新增] 叠加急流噪声 (Jet Stream Turbulence)
    // 让线条不那么平滑，增加随机扰动
    // timeFactor 已经在函数前面定义了
    const jetNoise = (smoothNoise(lon * 0.08, timeFactor) - 0.5) * 8.0;

    // D. 合成最终的目标干燥纬度
    // Target = 基础位置 + 长波摆动 + 短波噪声
    const targetDryLat = baseDryLat + rossbyOffset + jetNoise;

    // E. 应用高斯分布扣减
    // 在 targetDryLat 附近形成干燥区
    const dryBandWidth = 200; // 影响宽度 (sigma^2)
    const westerliesDryFactor = Math.exp(-Math.pow(lat - targetDryLat, 2) / dryBandWidth);
    // Westerlies are not an everywhere-dry wall. Dry intrusions are localized
    // and evolve with the same wave field; moist trough sectors remain possible.
    const field = backgroundField;
    let intrusion = .35;
    if (field?.waves) {
        const hemisphere = lat < 0 ? -1 : 1;
        const waves = field.waves.filter(w => w.hemisphere === hemisphere && w.k <= 4);
        const phase = waves.reduce((sum,w) => sum + Math.sin(w.k*lon*Math.PI/180+w.phase),0) / Math.max(1,waves.length);
        intrusion = .25 + .75 * Math.max(0,phase);
    }
    hum -= westerliesDryFactor * (field?.waves ? 32 * intrusion : 100);

    // 4. 地形与焚风效应 (Foehn Effect)
    const elevation = getElevationAt(lon, lat);
    
    if (elevation > 0) {
        hum -= (elevation / 200) * 15;
    }

    // B. 焚风效应 (升级版：逆风回溯拖尾)
    if (cyclone) {
        const vec = getWindVectorAt(lon, lat, currentMonth, cyclone, pressureSystems,
            visualSampling?.windOptions);
        const len = Math.sqrt(vec.u * vec.u + vec.v * vec.v);
        // 只有风速足够大才产生显著拖尾 (>10kt)
        let windWeight = (len - 15.0) / (30.0 - 15.0);
        windWeight = Math.max(0, Math.min(1, windWeight)); // Clamp 到 0~1

        // 只有当有权重时才计算，节省性能
        if (windWeight > 0.01) {
            const dirU = vec.u / len;
            const dirV = vec.v / len;

            // --- 配置参数 ---
            const traceSteps = 30;      // 回溯步数 (步数越多拖尾越精细，但性能开销大)
            const stepSize = 0.1;      // 每步步长 (度)，0.1度 ≈ 10km
            const decayFactor = 0.2;   // 距离衰减系数 (越小拖尾越长)
            
            let maxDryImpact = 0;      // 记录路径上最大的干燥影响

            // 开始回溯循环
            for (let i = 1; i <= traceSteps; i++) {
                // 当前回溯距离
                const dist = i * stepSize;
                
                // 计算上风点坐标
                const upLon = lon - (dirU * dist);
                const upLat = lat - (dirV * dist);
                
                // 获取上风点海拔
                const upElevation = getElevationAt(upLon, upLat);
                const elevationDiff = upElevation - elevation;

                // 只有当上风处比当前处高出一定阈值 (500m) 才视为阻挡
                if (elevationDiff > 30) {
                    // 1. 基础强度：落差越大，越干
                    let impact = elevationDiff / 30;
                    
                    // 2. 风速加成：风越大，焚风穿透力越强
                    // 限制最大加成倍数，防止数值爆炸
                    const windFactor = (vec.magnitude - 22);
                    impact *= windFactor;

                    // 3. [关键] 距离衰减：距离越远，影响越小
                    // 使用指数衰减公式：Impact * e^(-dist * decay)
                    // 当 dist=0.4时 衰减很少，当 dist=2.0时 衰减很多
                    impact *= Math.exp(-dist * decayFactor);

                    // 保留路径上发现的最强阻挡效果
                    if (impact > maxDryImpact) {
                        maxDryImpact = impact;
                    }
                }
            }

            // [安全钳制] 焚风最强让湿度下降 80%
            maxDryImpact = Math.min(maxDryImpact, 80);
            hum -= maxDryImpact;
        }
    }

    // Apply the regional winter midlevel climatology after transient dry-air,
    // circulation and storm-relative terms, preserving their local structure.
    hum += northIndianOceanMidlevelHumidityAdjustment(lon, lat, currentMonth);

    // 钳制背景湿度 (0% - 100%)
    return Math.max(5, Math.min(100, hum));
}

export function calculateTotalHumidity(lon, lat, pressureSystems, cyclone, globalTemp, visualSampling = null) {
    const currentMonth = (cyclone && cyclone.currentMonth) ? cyclone.currentMonth : 8;
    
    // 1. 获取基础背景湿度
    let hum = calculateBackgroundHumidity(lon, lat, pressureSystems, currentMonth, cyclone, globalTemp, visualSampling);

    // 2. 叠加气旋水汽 (核心 CDO + 螺旋雨带)
    // 逻辑复用自之前的 drawHumidityField
    if (cyclone && cyclone.status === 'active') {
        const dx = lon - cyclone.lon;
        const dy = lat - cyclone.lat;
        const dist = Math.sqrt(dx*dx + dy*dy);
        
        // A. 气旋核心强制加湿 (CDO)
        // 核心范围约为 环流大小 * 0.01 (度)
        if (dist < cyclone.circulationSize * 0.01) { 
            const stormHumBoost = 50 * (1 - dist/(cyclone.circulationSize * 0.01)); 
            hum += Math.max(0, stormHumBoost);
        }

        // B. 螺旋雨带 (简单的正弦波模拟)
        if (dist < cyclone.circulationSize * 0.02) {
            const angle = Math.atan2(dy, dx);
            const age = cyclone.age || 0;
            // 简单的螺旋纹理
            const spiral = Math.sin(angle * 3 + dist * 2 - age * 0.1);
            if (spiral > 0.5) hum += 10;
        }
    }

    // 钳制在 0-99 之间
    return Math.max(10, Math.min(99, hum));
}

// This context belongs to one synchronous visual grid only. The model and
// forecast point APIs keep their original path; no cross-frame state is held.
export function createVisualHumiditySampler(pressureSystems, cyclone, globalTemp) {
    const visualSampling = {
        pressure: createSurfacePressureSampler(pressureSystems, { includeTerrain: true }),
        windOptions: { pressureSampler: createSurfacePressureSampler(pressureSystems) }
    };
    return (lon, lat) => calculateTotalHumidity(
        lon, lat, pressureSystems, cyclone, globalTemp, visualSampling
    );
}

// [修改] 绘制 850hPa 湿度场 (现在调用分离的逻辑)
export function drawHumidityField(container, mapProjection, pressureSystems, cyclone, globalTemp) {
    const profile = globalThis.location?.search
        && new URLSearchParams(globalThis.location.search).get('humidity-field-profile') === '1';
    const startedAt = profile ? performance.now() : 0;
    const svgNode = container.node().closest('svg'); 
    const { width, height } = svgNode.getBoundingClientRect();
    
    const nx = 56, ny = Math.round(nx * height / width);
    const grid = [];

    const sampleHumidity = createVisualHumiditySampler(pressureSystems, cyclone, globalTemp);

    for (let j = 0; j < ny; ++j) {
        for (let i = 0; i < nx; ++i) {
            const coords = mapProjection.invert([i * width / nx, j * height / ny]);
            if (!coords || !isFinite(coords[0]) || !isFinite(coords[1])) {
                grid.push(0); continue;
            }
            
            const finalHum = sampleHumidity(coords[0], coords[1]);
            grid.push(Math.max(10, Math.min(99, finalHum)));
        }
    }

    const sampledAt = profile ? performance.now() : 0;
    // 生成等值线
    const contours = d3.contours().size([nx, ny]).thresholds([10,20,30,40,50,60,70,80,90]);
    const transform = d3.geoTransform({ point: function(x, y) { this.stream.point(x * width / nx, y * height / ny); } });
    const pathGenerator = d3.geoPath().projection(transform);

    // 绘制
    container.selectAll("path")
        .data(contours(grid))
        .enter().append("path")
        .attr("d", pathGenerator)
        .attr("class", d => {
            if (d.value >= 90) return "isohume-high"; // 高湿区 (深绿/填充)
            if (d.value >= 60) return "isohume-med"; // 中湿区 (浅绿)
            if (d.value >= 30) return "isohume"; // 低湿区 (浅黄)
            return "isohume-low"; // 干线 (浅橙)
        });
    if (profile) console.info(`[humidity-field-profile] ${JSON.stringify({
        nodes: nx * ny,
        samplingMs: sampledAt - startedAt,
        contourAndSubmitMs: performance.now() - sampledAt,
        totalMs: performance.now() - startedAt
    })}`);
}

// ===================================================
// Wind Field
// ===================================================
function drawWindRadii(container, pathGenerator, cyclone) {
    if (!cyclone || cyclone.intensity < 34) return;
    const windData = [
        { threshold: 64, color: "#c0392b", trackIndex: 9 },
        { threshold: 50, color: "#e67e22", trackIndex: 8 },
        { threshold: 34, color: "#f1c40f", trackIndex: 7 }
    ];
    const latestTrackPoint = cyclone.track?.at(-1);
    const drawArcStep = 5;

    // 辅助：计算坐标
    const getPointAt = (centerLon, centerLat, angleRad, distKm) => {
        const distDeg = distKm / 111.32; 
        const lonScale = 1.0 / Math.max(0.1, Math.cos(centerLat * Math.PI / 180));
        const lon = centerLon + distDeg * Math.cos(angleRad) * lonScale;
        const lat = centerLat + distDeg * Math.sin(angleRad);
        return [lon, lat];
    };

    windData.forEach(level => {
        if (cyclone.intensity < level.threshold) return;
        let radiiKm = Array.isArray(cyclone.radiiState?.[level.threshold])
            ? cyclone.radiiState[level.threshold]
            : null;
        if (!radiiKm && Array.isArray(latestTrackPoint?.[level.trackIndex])) {
            radiiKm = latestTrackPoint[level.trackIndex].map(radius => radius * 111.32);
        }
        if (!radiiKm || radiiKm.every(radius => radius <= 0)) return;

        // The operational display is deliberately four-quadrant: NE, SE,
        // SW and NW each use one diagnosed radius.  The finer angular state
        // remains available to the physics layer, but must not leak into the
        // standard wind-radii graphic.
        const quadrants = [
            { dataIndex: 0, start: 0, end: 90 },
            { dataIndex: 3, start: 90, end: 180 },
            { dataIndex: 2, start: 180, end: 270 },
            { dataIndex: 1, start: 270, end: 360 }
        ];
        const polyPoints = [];
        quadrants.forEach(quad => {
            const radius = radiiKm[quad.dataIndex] || 0;
            if (radius <= 0) {
                polyPoints.push([cyclone.lon, cyclone.lat]);
                return;
            }

            for (let angle = quad.start; angle <= quad.end; angle += drawArcStep) {
                const angleRad = angle * (Math.PI / 180);
                const [pLon, pLat] = getPointAt(cyclone.lon, cyclone.lat, angleRad, radius);
                polyPoints.push([pLon, pLat]);
            }
        });

        if (polyPoints.length > 2) {
            polyPoints.push(polyPoints[0]);
            if (d3.polygonArea(polyPoints) < 0) polyPoints.reverse();

            const polygonGeoJSON = { type: "Polygon", coordinates: [polyPoints] };
            
            container.append("path")
                .datum(polygonGeoJSON)
                .attr("class", "wind-radii")
                .style("fill", level.color)
                .style("fill-rule", "evenodd")
                .style("stroke", d3.color(level.color).darker(0.5))
                .style("stroke-width", 0.8)
                .style("opacity", 0.4)
                .attr("d", pathGenerator);

            container.append("path")
                .datum(polygonGeoJSON)
                .attr("class", "wind-radii-edge")
                .style("fill", "none")
                .style("stroke", d3.color(level.color).brighter(1.35))
                .style("stroke-width", 1.15)
                .style("opacity", 0.9)
                .attr("d", pathGenerator);
        }
    });
}

export function triggerLandfallEffect(mapSvg, mapProjection, lon, lat, event = {}) {
  if (!mapSvg || !mapProjection || !Number.isFinite(lon) || !Number.isFinite(lat)) return;

  const layer = mapSvg.select('.layer-effects');
  if (layer.empty()) return;

  const effect = layer.append('g')
    .datum([lon, lat])
    .attr('class', 'landfall-effect')
    .style('color', getCategory(event.intensity || 0, event.isTransitioning,
        event.isExtratropical, event.isSubtropical).color);

  effect.append('circle')
    .attr('class', 'landfall-ring landfall-ring-a')
    .attr('r', 5);

  effect.append('circle')
    .attr('class', 'landfall-ring landfall-ring-b')
    .attr('r', 5);

  effect.append('path')
    .attr('class', 'landfall-diamond')
    .attr('d', 'M0,-11 L11,0 L0,11 L-11,0 Z');

  const position = mapProjection([lon, lat]);

  if (position) {
    effect.attr(
      'transform',
      `translate(${position[0]},${position[1]})`
    );
  }

  setTimeout(() => effect.remove(), 2050);
}

let landCanvas = null;      // 陆地检测用的离屏 Canvas
let landCtx = null;
let windCanvasLayer = null; // 风场显示的 Canvas DOM 元素
let windCtx = null;         // 风场显示的绘图上下文
let windGpuCanvasLayer = null;
let windGpuRenderer = null;
let windGpuInitPromise = null;
let windGpuDisabled = false;
let lastWindGpuFrame = null;
let windFieldVisible = false;
let landGrid = null;
let landGridWidth = 0;
let landGridHeight = 0;
let landGridSourceWorld = null;

function windFieldRenderSignature(mapProjection, cyclone, pressureSystems, world,
  width, height, dpr) {
  const center = mapProjection([cyclone.lon, cyclone.lat]) || [];
  const east = mapProjection([cyclone.lon + 1, cyclone.lat]) || [];
  const north = mapProjection([cyclone.lon, cyclone.lat + 1]) || [];
  const cycloneValues = [
    'age', 'lon', 'lat', 'intensity', 'rmw', 'centralPressure',
    'speed', 'direction', 'circulationSize', 'outerWindBroadness',
    'isERCActive', 'ercInnerRmw', 'ercInnerWind', 'ercOuterRmw',
    'ercOuterWindAnomaly', 'ercOuterOrganization', 'ercOuterShare',
    'ercInnerIntegrity', 'ercOuterWidth'
  ].map(key => cyclone[key]).join('|');
  const cellValues = [
    ...(pressureSystems?.upper || []), ...(pressureSystems?.lower || [])
  ].map(cell => [
    cell.role, cell.x, cell.y, cell.strength, cell.sigmaX, cell.sigmaY,
    cell.age, cell.fieldEnvelope, cell.ridgeHeightAnomalyM,
    cell.ridgeWeatherId, cell.ridgeWeatherColumn
  ].join(',')).join(';');
  const background = pressureSystems?.upper?.find(
    cell => cell.role === 'height-background'
  );
  return [
    width, height, dpr, world,
    center[0], center[1], east[0], east[1], north[0], north[1],
    cycloneValues, background?.elapsedHours, background?.calendarMonth,
    cellValues
  ].join('|');
}

// Detailed wind-layer timings are opt-in so the normal render loop pays no
// profiling overhead. The model module reads this short-lived object while a
// draw is active and records its cache hits/misses.
const profileWindField = globalThis.location?.search
    ? new URLSearchParams(globalThis.location.search).get('wind-field-profile') === '1'
    : false;

// The surface-pressure stencil is regular for the wind lattice. Build its
// four samples in a compact typed array before the vector loop, then let each
// arrow read those values through the existing exact surface-wind evaluator.
// The pressure arithmetic and stencil offsets stay unchanged; this only moves
// pressure sampling out of the arrow-driven call stack.
function buildWindFieldPressureGrid(points, pressureSampler) {
    const delta = 0.25;
    const values = new Float64Array(points.length * 4);
    for (let index = 0; index < points.length; index++) {
        const point = points[index];
        const offset = index * 4;
        values[offset] = pressureSampler(point.lon + delta, point.lat);
        values[offset + 1] = pressureSampler(point.lon - delta, point.lat);
        values[offset + 2] = pressureSampler(point.lon, point.lat + delta);
        values[offset + 3] = pressureSampler(point.lon, point.lat - delta);
    }
    return values;
}

function createWindFieldGridEnvironmentSampler(pressureValues, systems) {
    let currentIndex = -1;
    let pressureOffset = 0;
    const sampledPressure = () => pressureValues[currentIndex * 4 + pressureOffset++];
    return {
        setIndex(index) {
            currentIndex = index;
            pressureOffset = 0;
        },
        sample(lon, lat, applyTerrainFriction, terrainInfo) {
            pressureOffset = 0;
            return getSurfaceEnvironmentalWind(
                lon,
                lat,
                systems,
                applyTerrainFriction,
                sampledPressure,
                terrainInfo,
                false
            );
        }
    };
}

function beginWindFieldProfile() {
    if (!profileWindField) return null;
    const profile = {
        active: true,
        startedAt: performance.now(),
        backend: windGpuRenderer ? 'webgpu' : 'canvas',
        gridCandidates: 0,
        projected: 0,
        visible: 0,
        arrows: 0,
        vectorCalls: 0,
        vectorMs: 0,
        environmentMs: 0,
        surfaceWindCalls: 0,
        surfaceWindCacheHits: 0,
        surfaceWindCacheMisses: 0,
        surfacePressureCalls: 0,
        surfacePressureCacheHits: 0,
        surfacePressureCacheMisses: 0,
        surfacePressureSamplerCalls: 0,
        surfacePressureSamplerMs: 0,
        pressureGridPoints: 0,
        pressureGridMs: 0,
        surfacePressureUniqueSamples: 0,
        surfacePressureDuplicateSamples: 0,
        surfacePressureSampleKeys: new Set(),
        heightUniqueSamples: 0,
        heightDuplicateSamples: 0,
        heightSampleKeys: new Set(),
        heightSamplerMs: 0,
        waveFieldMs: 0,
        surfacePressureSamplerCacheHits: 0,
        surfacePressureSamplerCacheMisses: 0,
        heightTransientMs: 0,
        heightTransientCalls: 0,
        heightCellAnomalyMs: 0,
        heightSurgeMs: 0,
        heightScaleMs: 0,
        setupMs: 0,
        loopMs: 0,
        canvasMs: 0,
        gpuMs: 0
    };
    globalThis.__windFieldProfile = profile;
    return profile;
}

function finishWindFieldProfile(profile, extra = {}) {
    if (!profile) return;
    profile.active = false;
    profile.totalMs = performance.now() - profile.startedAt;
    console.info(`[wind-field-profile] ${JSON.stringify({
        ...profile,
        startedAt: undefined,
        ...extra,
        totalMs: Math.round(profile.totalMs * 10) / 10,
        setupMs: Math.round(profile.setupMs * 10) / 10,
        loopMs: Math.round(profile.loopMs * 10) / 10,
        vectorMs: Math.round(profile.vectorMs * 10) / 10,
        environmentMs: Math.round(profile.environmentMs * 10) / 10,
        surfacePressureSamplerMs: Math.round(profile.surfacePressureSamplerMs * 10) / 10,
        pressureGridMs: Math.round(profile.pressureGridMs * 10) / 10,
        surfacePressureDuplicateRatio: Math.round(
            profile.surfacePressureDuplicateSamples
            / Math.max(1, profile.surfacePressureSamplerCalls) * 1000
        ) / 1000,
        heightDuplicateRatio: Math.round(
            profile.heightDuplicateSamples
            / Math.max(1, profile.heightUniqueSamples + profile.heightDuplicateSamples) * 1000
        ) / 1000,
        surfacePressureSampleKeys: undefined,
        heightSampleKeys: undefined,
        heightSamplerMs: Math.round(profile.heightSamplerMs * 10) / 10,
        waveFieldMs: Math.round(profile.waveFieldMs * 10) / 10,
        canvasMs: Math.round(profile.canvasMs * 10) / 10,
        gpuMs: Math.round(profile.gpuMs * 10) / 10
    })}`);
    if (globalThis.__windFieldProfile === profile) globalThis.__windFieldProfile = null;
}

// The wind overlay keeps the full arrow lattice, but reuses its typed-array
// storage between frames. Reusing these buffers avoids several thousand small
// array allocations whenever the field is redrawn.
const windRenderPool = {
    gpu: new Float32Array(0),
    low: new Float32Array(0),
    high: new Float32Array(0),
    extreme: new Float32Array(0)
};

function ensureWindPoolBuffer(name, requiredFloats) {
    const required = Math.max(8, Math.ceil(requiredFloats));
    const current = windRenderPool[name] || new Float32Array(0);
    if (current.length >= required) return current;
    let capacity = Math.max(1024, current.length || 0);
    while (capacity < required) capacity *= 2;
    windRenderPool[name] = new Float32Array(capacity);
    return windRenderPool[name];
}

function wrappedWindLongitudeDelta(lon, origin) {
    let delta = lon - origin;
    while (delta > 180) delta -= 360;
    while (delta < -180) delta += 360;
    return delta;
}

function visibleWindGridBounds(mapProjection, cyclone, width, height, step, range = 20) {
    const fallback = {
        startLon: -range,
        endLon: range,
        startLat: -range * 0.5,
        endLat: range * 0.5
    };
    if (!mapProjection?.invert || !Number.isFinite(cyclone?.lon) || !Number.isFinite(cyclone?.lat)) {
        return fallback;
    }

    const corners = [[0, 0], [width, 0], [0, height], [width, height]];
    const deltas = [];
    const latitudes = [];
    for (const corner of corners) {
        const point = mapProjection.invert(corner);
        if (!point || !Number.isFinite(point[0]) || !Number.isFinite(point[1])) return fallback;
        deltas.push(wrappedWindLongitudeDelta(point[0], cyclone.lon));
        latitudes.push(point[1]);
    }
    const minDelta = Math.min(...deltas);
    const maxDelta = Math.max(...deltas);
    const minLat = Math.max(-90, Math.min(...latitudes));
    const maxLat = Math.min(90, Math.max(...latitudes));
    // A normal viewport around the active centre is narrower than a
    // hemisphere. If a different projection returns a wrapped globe, keep
    // the conservative local range instead of iterating across 360 degrees.
    if (!Number.isFinite(minDelta) || !Number.isFinite(maxDelta)
        || maxDelta - minDelta > 170 || maxLat - minLat > 150) {
        return fallback;
    }
    const pad = step * 1.5;
    return {
        // Union the visible bounds with the original local envelope. A
        // narrow viewport can therefore never reduce the arrow count.
        startLon: Math.min(
            -range,
            Math.floor((minDelta - pad) / step) * step
        ),
        endLon: Math.max(
            range,
            Math.ceil((maxDelta + pad) / step) * step
        ),
        startLat: Math.max(
            -90,
            Math.min(-range * 0.5, Math.floor((minLat - pad) / step) * step)
        ),
        endLat: Math.min(
            90,
            Math.max(range * 0.5, Math.ceil((maxLat + pad) / step) * step)
        )
    };
}

function createWindProjectionBasis(mapProjection, cyclone) {
    if (!mapProjection || !Number.isFinite(cyclone?.lon) || !Number.isFinite(cyclone?.lat)) return null;
    const baseLon = cyclone.lon;
    const baseLat = cyclone.lat;
    const origin = mapProjection([baseLon, baseLat]);
    if (!origin || !Number.isFinite(origin[0]) || !Number.isFinite(origin[1])) return null;

    const lonDirection = Math.abs(baseLon) > 179 ? -1 : 1;
    const latDirection = Math.abs(baseLat) > 89 ? -1 : 1;
    const lonProbe = mapProjection([baseLon + lonDirection, baseLat]);
    const latProbe = mapProjection([baseLon, baseLat + latDirection]);
    if (!lonProbe || !latProbe) return null;

    const dx = (lonProbe[0] - origin[0]) / lonDirection;
    const dy = (latProbe[1] - origin[1]) / latDirection;
    if (!Number.isFinite(dx) || !Number.isFinite(dy)) return null;
    return { x: origin[0], y: origin[1], dx, dy };
}

function initLandGrid(world) {
    if (!world) return;
    
    // 网格精度：每度 8 个点 (0.125度精度)，足够风场使用了
    const resolution = 8; 
    landGridWidth = 360 * resolution;
    landGridHeight = 180 * resolution;
    
    // 创建离屏 Canvas 来通过绘图快速生成网格
    const canvas = document.createElement('canvas');
    canvas.width = landGridWidth;
    canvas.height = landGridHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    // 使用等距圆柱投影将世界地图铺满 Canvas
    // x: -180~180 => 0~width
    // y: 90~-90   => 0~height
    const projection = d3.geoEquirectangular()
        .fitSize([landGridWidth, landGridHeight], world);
    const path = d3.geoPath().projection(projection).context(ctx);
    
    // 绘制陆地 (红色)
    ctx.fillStyle = '#FF0000';
    ctx.beginPath();
    path(world);
    ctx.fill();
    
    // 获取像素数据并保存为轻量级数组
    const imgData = ctx.getImageData(0, 0, landGridWidth, landGridHeight).data;
    landGrid = new Uint8Array(landGridWidth * landGridHeight);
    
    for (let i = 0; i < landGrid.length; i++) {
        // 如果像素有红色分量，标记为陆地 (1)
        // imgData 是 r,g,b,a 排列，红色是 index*4
        if (imgData[i * 4] > 100) {
            landGrid[i] = 1;
        }
    }
    
    console.log("Land grid initialized for high-performance wind rendering.");
}

// 辅助：快速查询某经纬度是否在陆地上
function checkLandFast(lon, lat) {
    if (!landGrid && landGridSourceWorld) initLandGrid(landGridSourceWorld);
    if (!landGrid) return false;
    
    // 经纬度映射到网格索引
    // lon: -180 ~ 180 -> 0 ~ 360
    // lat: 90 ~ -90   -> 0 ~ 180 (注意 Canvas y轴向下)
    let x = Math.floor((lon + 180) * (landGridWidth / 360));
    let y = Math.floor((90 - lat) * (landGridHeight / 180));
    
    // 边界保护
    x = Math.max(0, Math.min(x, landGridWidth - 1));
    y = Math.max(0, Math.min(y, landGridHeight - 1));
    
    return landGrid[y * landGridWidth + x] === 1;
}

// Wind arrows follow the same 5 kt colour steps as the product legend:
// calm grey → cyan → blue → green → yellow → orange → red → brown → purple.
// Keep the pre-normalised RGBA values here so both WebGPU and Canvas2D use
// exactly the same ramp without allocating a colour object per arrow.
const WIND_FIELD_PALETTE = Object.freeze([
    { css: 'rgba(48, 48, 48, 0.72)', rgba: [48 / 255, 48 / 255, 48 / 255, 0.72] },
    { css: 'rgba(0, 220, 240, 0.80)', rgba: [0, 220 / 255, 240 / 255, 0.80] },
    { css: 'rgba(12, 48, 245, 0.82)', rgba: [12 / 255, 48 / 255, 245 / 255, 0.82] },
    { css: 'rgba(0, 220, 42, 0.82)', rgba: [0, 220 / 255, 42 / 255, 0.82] },
    { css: 'rgba(255, 235, 0, 0.84)', rgba: [1, 235 / 255, 0, 0.84] },
    { css: 'rgba(255, 150, 0, 0.84)', rgba: [1, 150 / 255, 0, 0.84] },
    { css: 'rgba(255, 60, 20, 0.86)', rgba: [1, 60 / 255, 20 / 255, 0.86] },
    { css: 'rgba(240, 20, 40, 0.86)', rgba: [240 / 255, 20 / 255, 40 / 255, 0.86] },
    { css: 'rgba(130, 50, 30, 0.86)', rgba: [130 / 255, 50 / 255, 30 / 255, 0.86] },
    { css: 'rgba(220, 0, 220, 0.86)', rgba: [220 / 255, 0, 220 / 255, 0.86] },
    { css: 'rgba(100, 0, 150, 0.86)', rgba: [100 / 255, 0, 150 / 255, 0.86] }
]);

function windFieldPaletteIndex(magnitude) {
    const speed = Number.isFinite(magnitude) ? Math.max(0, magnitude) : 0;
    return speed >= 50
        ? WIND_FIELD_PALETTE.length - 1
        : Math.min(WIND_FIELD_PALETTE.length - 1, Math.floor(speed / 5));
}

function ensureWindGpuLayer(container) {
    if (windGpuDisabled || windGpuRenderer || windGpuInitPromise || !canUseWindWebGPU()) return;

    windGpuCanvasLayer = document.createElement('canvas');
    windGpuCanvasLayer.id = 'wind-webgpu-canvas-layer';
    windGpuCanvasLayer.style.position = 'absolute';
    windGpuCanvasLayer.style.top = '0';
    windGpuCanvasLayer.style.left = '0';
    windGpuCanvasLayer.style.pointerEvents = 'none';
    windGpuCanvasLayer.style.zIndex = '11';
    windGpuCanvasLayer.style.display = 'none';
    container.appendChild(windGpuCanvasLayer);

    windGpuInitPromise = WindWebGPURenderer.create(windGpuCanvasLayer)
        .then(renderer => {
            if (!renderer) {
                windGpuDisabled = true;
                windGpuCanvasLayer.style.display = 'none';
                return null;
            }

            windGpuRenderer = renderer;
            if (windFieldVisible && lastWindGpuFrame && windCanvasLayer) {
                windCanvasLayer.style.display = 'none';
                renderer.render(
                    lastWindGpuFrame.data,
                    lastWindGpuFrame.width,
                    lastWindGpuFrame.height,
                    lastWindGpuFrame.dpr
                );
                windGpuCanvasLayer.style.display = 'block';
            } else {
                if (windCanvasLayer) windCanvasLayer.style.display = 'none';
                windGpuCanvasLayer.style.display = 'none';
            }
            console.info('[wind-field] WebGPU arrow renderer enabled.');
            return renderer;
        })
        .catch(error => {
            windGpuDisabled = true;
            windGpuCanvasLayer.style.display = 'none';
            if (windFieldVisible && windCanvasLayer) windCanvasLayer.style.display = 'block';
            console.warn('[wind-field] WebGPU unavailable; using Canvas 2D fallback.', error);
            return null;
        });
}

function renderWindGpuFrame(data, width, height, dpr) {
    if (!windGpuRenderer) return false;
    try {
        const rendered = windGpuRenderer.render(data, width, height, dpr);
        if (!rendered) return false;
        windCanvasLayer.style.display = 'none';
        windGpuCanvasLayer.style.display = 'block';
        return true;
    } catch (error) {
        console.warn('[wind-field] WebGPU render failed; returning to Canvas 2D.', error);
        windGpuRenderer.destroy();
        windGpuRenderer = null;
        windGpuDisabled = true;
        if (windGpuCanvasLayer) windGpuCanvasLayer.style.display = 'none';
        windCanvasLayer.style.display = 'block';
        return false;
    }
}

function clearWindFieldLayers() {
    windFieldVisible = false;
    setLegendVisible('wind-field-legend', false);
    if (windCtx && windCanvasLayer) {
        windCtx.clearRect(0, 0, windCanvasLayer.width, windCanvasLayer.height);
        windCanvasLayer.style.display = 'none';
    }
    if (windGpuRenderer && windGpuCanvasLayer) {
        try {
            // Hidden canvas client sizes are zero, while canvas.width/height
            // are physical pixels. Passing those back as logical dimensions
            // multiplies the backing store by DPR on every redraw.
            if (windGpuRenderer.width > 0 && windGpuRenderer.height > 0) {
                windGpuRenderer.clear(
                    windGpuRenderer.width,
                    windGpuRenderer.height,
                    windGpuRenderer.dpr
                );
            }
        } catch (error) {
            console.warn('[wind-field] WebGPU clear failed.', error);
        }
        windGpuCanvasLayer.style.display = 'none';
    }
    lastWindGpuFrame = null;
}

export function drawWindField(mapSvg, mapProjection, cyclone, pressureSystems, world) {
    windFieldVisible = true;
    const legend = document.getElementById('wind-field-legend');
    if (legend) {
        // Use the renderer's palette, including opacity and its 50 kt cap.
        // Build once; no extra environmental sampling or per-frame DOM churn.
        const scale = legend.querySelector('.wind-field-scale');
        if (scale && !scale.childElementCount) {
            for (let i = WIND_FIELD_PALETTE.length - 1; i >= 0; i--) {
                const row = document.createElement('div');
                row.className = 'wind-field-bin';
                const swatch = document.createElement('i');
                swatch.style.backgroundColor = WIND_FIELD_PALETTE[i].css;
                swatch.setAttribute('aria-hidden', 'true');
                const label = document.createElement('span');
                label.textContent = i === WIND_FIELD_PALETTE.length - 1 ? '50+' : `${i * 5}–${(i + 1) * 5}`;
                row.append(swatch, label);
                scale.append(row);
            }
        }
        setLegendVisible('wind-field-legend', true);
    }
    const profile = beginWindFieldProfile();
    const currentMonth = cyclone.currentMonth || 6;
    const { width, height } = mapSvg.node().getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    // --- 1. Canvas 初始化 (保持不变) ---
    if (!windCanvasLayer) {
        const container = mapSvg.node().parentNode;
        windCanvasLayer = document.createElement('canvas');
        windCanvasLayer.id = 'wind-canvas-layer';
        windCanvasLayer.style.position = 'absolute';
        windCanvasLayer.style.top = '0';
        windCanvasLayer.style.left = '0';
        windCanvasLayer.style.pointerEvents = 'none';
        windCanvasLayer.style.zIndex = '10';
        container.appendChild(windCanvasLayer);
        windCtx = windCanvasLayer.getContext('2d', {
            alpha: true,
            // Allow the compositor to present the completed arrow batch
            // without waiting for an extra main-thread synchronization point.
            desynchronized: true
        });
    }
    const container = mapSvg.node().parentNode;
    ensureWindGpuLayer(container);
    windCanvasLayer.style.display = windGpuRenderer ? 'none' : 'block';

    const logicalWidth = windCanvasLayer.width / dpr;
    const logicalHeight = windCanvasLayer.height / dpr;

    if (logicalWidth !== width || logicalHeight !== height) {
        windCanvasLayer.width = width * dpr;
        windCanvasLayer.height = height * dpr;
        windCanvasLayer.style.width = `${width}px`;
        windCanvasLayer.style.height = `${height}px`;
        windCtx.scale(dpr, dpr);
    }
    
    windCtx.clearRect(0, 0, width, height);

    if (!world || !cyclone || cyclone.status !== 'active') {
        clearWindFieldLayers();
        finishWindFieldProfile(profile, { reason: 'inactive' });
        return;
    }

    const renderSignature = windFieldRenderSignature(
        mapProjection, cyclone, pressureSystems, world, width, height, dpr
    );
    if (windGpuRenderer && lastWindGpuFrame
        && lastWindGpuFrame.signature === renderSignature) {
        const gpuStartedAt = profile ? performance.now() : 0;
        const rendered = renderWindGpuFrame(
            lastWindGpuFrame.data,
            lastWindGpuFrame.width,
            lastWindGpuFrame.height,
            lastWindGpuFrame.dpr
        );
        if (profile) {
            profile.gpuMs = performance.now() - gpuStartedAt;
            finishWindFieldProfile(profile, {
                backend: rendered ? 'webgpu' : 'canvas',
                gpuData: lastWindGpuFrame.data.length / 8,
                cached: true
            });
        }
        if (rendered) return;
    }

    // --- 3. 准备批量数组 ---
    // 保持原有 0.4° 箭头晶格；只复用 typed-array 存储，避免每次重绘
    // 产生几千个临时数组。GPU 可用时也不再同时构造 Canvas 2D 几何。
    const GEO_RANGE = 20;
    const GEO_STEP = 0.4;
    const arrowScale = 0.75;
    const headLen = 5;

    // Derive the lattice from the visible projection instead of a fixed
    // ±20° box. Wide viewports previously left an unpainted strip at the
    // sides; the small one-cell pad guarantees the edge arrows cover it.
    const setupStartedAt = profile ? performance.now() : 0;
    const bounds = visibleWindGridBounds(
        mapProjection, cyclone, width, height, GEO_STEP, GEO_RANGE
    );
    const startLat = bounds.startLat;
    const endLat = bounds.endLat;
    const startLonDelta = bounds.startLon;
    const endLonDelta = bounds.endLon;
    const projectionBasis = createWindProjectionBasis(mapProjection, cyclone);
    const estimatedRows = Math.ceil((endLat - startLat) / GEO_STEP) + 1;
    const estimatedCols = Math.ceil((endLonDelta - startLonDelta) / GEO_STEP) + 1;
    const estimatedFloats = Math.max(8, estimatedRows * estimatedCols * 8);
    const useGpuGeometry = Boolean(windGpuRenderer);
    // Keep a GPU snapshot while the device is still being warmed up; when
    // WebGPU is unavailable this allocation is skipped entirely.
    const shouldBuildGpuData = useGpuGeometry
        || (!windGpuDisabled && canUseWindWebGPU());
    const gpuBuffer = shouldBuildGpuData
        ? ensureWindPoolBuffer('gpu', estimatedFloats) : null;
    const canvasBatches = useGpuGeometry ? null : WIND_FIELD_PALETTE.map((_, index) => ({
        data: ensureWindPoolBuffer(`palette${index}`, estimatedFloats), count: 0
    }));
    // Compile the invariant pressure-field closure once for this immutable
    // atmosphere snapshot. It evaluates the exact same four-point stencil as
    // getSurfaceEnvironmentalWind, but avoids rediscovering the background,
    // circulation profiles and lower-layer sampler for every arrow.
    const pressureSampler = createSurfacePressureSampler(
        pressureSystems,
        { cache: false }
    );
    let gpuCount = 0;
    const windPoints = [];
    if (profile) profile.setupMs = performance.now() - setupStartedAt;

    // --- 4. 先建立可见箭头的规则压力网格 ---
    // Projection and visibility are kept as a separate pass so every pressure
    // stencil is materialized before any arrow asks for its environmental wind.
    for (let lat = startLat; lat <= endLat + 1e-6; lat += GEO_STEP) {
        if (lat < -90 || lat > 90) continue;

        for (let lonDelta = startLonDelta; lonDelta <= endLonDelta + 1e-6; lonDelta += GEO_STEP) {
            if (profile) profile.gridCandidates++;
            const lon = cyclone.lon + lonDelta;
            // The active map uses an equirectangular projection. Project its
            // affine basis once per frame rather than calling D3 for every
            // arrow; the fallback keeps compatibility with other projections.
            let x;
            let y;
            if (projectionBasis) {
                x = projectionBasis.x + wrappedWindLongitudeDelta(lon, cyclone.lon) * projectionBasis.dx;
                y = projectionBasis.y + (lat - cyclone.lat) * projectionBasis.dy;
            } else {
                const proj = mapProjection([lon, lat]);
                if (!proj || isNaN(proj[0]) || isNaN(proj[1])) continue;
                x = proj[0];
                y = proj[1];
            }

            // 屏幕剔除
            if (x < -20 || x > width + 20 || y < -20 || y > height + 20) continue;
            if (profile) profile.projected++;

            if (profile) profile.visible++;
            windPoints.push({ lon, lat, x, y });
        }
    }

    const pressureGridStartedAt = profile ? performance.now() : 0;
    const pressureValues = buildWindFieldPressureGrid(windPoints, pressureSampler);
    const windFieldEnvironmentSampler = createWindFieldGridEnvironmentSampler(
        pressureValues,
        pressureSystems
    );
    if (profile) {
        profile.pressureGridPoints = windPoints.length;
        profile.pressureGridMs = performance.now() - pressureGridStartedAt;
    }

    // --- 5. 箭头循环 (只计算，不绘图) ---
    const loopStartedAt = profile ? performance.now() : 0;
    for (let pointIndex = 0; pointIndex < windPoints.length; pointIndex++) {
        const point = windPoints[pointIndex];
        windFieldEnvironmentSampler.setIndex(pointIndex);
        const { lon, lat, x, y } = point;

        // 物理计算
        const vectorStartedAt = profile ? performance.now() : 0;
        let vec = getWindVectorAt(
            lon,
            lat,
            currentMonth,
            cyclone,
            pressureSystems,
            {
                pressureSampler,
                environmentSampler: windFieldEnvironmentSampler,
                skipEnvironmentCache: true
            }
        );
        if (profile) profile.vectorMs += performance.now() - vectorStartedAt;

        if (vec.magnitude <= 0) continue;

        // The WebGPU vertex shader expands the shaft and arrow head. Do
        // not also build and stroke the hidden Canvas2D copy on the CPU.
        const angle = Math.atan2(-vec.v, vec.u); 
        const len = Math.min(20, vec.magnitude * arrowScale);

        const paletteIndex = windFieldPaletteIndex(vec.magnitude);
        const color = WIND_FIELD_PALETTE[paletteIndex].rgba;
        // x, y, screen angle, length, rgba. The GPU expands these into
        // three thick line segments per arrow.
        if (shouldBuildGpuData) {
            const gpuOffset = gpuCount * 8;
            gpuBuffer[gpuOffset] = x;
            gpuBuffer[gpuOffset + 1] = y;
            gpuBuffer[gpuOffset + 2] = angle;
            gpuBuffer[gpuOffset + 3] = len;
            gpuBuffer[gpuOffset + 4] = color[0];
            gpuBuffer[gpuOffset + 5] = color[1];
            gpuBuffer[gpuOffset + 6] = color[2];
            gpuBuffer[gpuOffset + 7] = color[3];
            gpuCount++;
        }
        if (profile) profile.arrows++;

        if (useGpuGeometry) continue;

        const halfLen = len / 2;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        const dx = halfLen * cos;
        const dy = halfLen * sin;
        const p1x = x - dx; const p1y = y - dy;
        const p2x = x + dx; const p2y = y + dy;
        const angleBack1 = angle + Math.PI * 0.85;
        const angleBack2 = angle - Math.PI * 0.85;
        let h1x = p2x, h1y = p2y, h2x = p2x, h2y = p2y;
        if (len > 6) {
            h1x = p2x + headLen * Math.cos(angleBack1);
            h1y = p2y + headLen * Math.sin(angleBack1);
            h2x = p2x + headLen * Math.cos(angleBack2);
            h2y = p2y + headLen * Math.sin(angleBack2);
        }

        const targetBatch = canvasBatches[paletteIndex];
        const batchOffset = targetBatch.count * 8;
        targetBatch.data[batchOffset] = p1x;
        targetBatch.data[batchOffset + 1] = p1y;
        targetBatch.data[batchOffset + 2] = p2x;
        targetBatch.data[batchOffset + 3] = p2y;
        targetBatch.data[batchOffset + 4] = h1x;
        targetBatch.data[batchOffset + 5] = h1y;
        targetBatch.data[batchOffset + 6] = h2x;
        targetBatch.data[batchOffset + 7] = h2y;
        targetBatch.count++;
    }
    if (profile) profile.loopMs = performance.now() - loopStartedAt;

    // --- 5. 批量绘制 ---
    windCtx.lineWidth = 1.5; // 稍微调细一点，因为现在线条多了
    windCtx.lineCap = 'round';
    windCtx.lineJoin = 'round';

    const drawBatch = (batch, color) => {
        if (!batch || batch.count === 0) return;
        windCtx.beginPath();
        windCtx.strokeStyle = color;
        // 每个箭头占 8 个浮点数：两端点 + 两个箭头头部端点。
        const data = batch.data;
        const floatCount = batch.count * 8;
        for (let i = 0; i < floatCount; i += 8) {
            // 画主干
            windCtx.moveTo(data[i], data[i+1]);   // p1
            windCtx.lineTo(data[i+2], data[i+3]); // p2 (尖端)
            // 画箭头 V 字
            windCtx.moveTo(data[i+4], data[i+5]); // h1
            windCtx.lineTo(data[i+2], data[i+3]); // 回到 p2
            windCtx.lineTo(data[i+6], data[i+7]); // h2
        }
        windCtx.stroke();
    }

    if (!windGpuRenderer) {
        const canvasStartedAt = profile ? performance.now() : 0;
        canvasBatches.forEach((batch, index) => {
            drawBatch(batch, WIND_FIELD_PALETTE[index].css);
        });
        if (profile) profile.canvasMs = performance.now() - canvasStartedAt;
    }

    if (!shouldBuildGpuData) {
        lastWindGpuFrame = null;
        finishWindFieldProfile(profile, { backend: 'canvas', gpuData: 0 });
        return;
    }
    const gpuData = gpuBuffer.subarray(0, gpuCount * 8);
    lastWindGpuFrame = {
        data: gpuData, width, height, dpr, signature: renderSignature
    };
    const gpuWasActive = Boolean(windGpuRenderer);
    const gpuStartedAt = profile ? performance.now() : 0;
    const rendered = renderWindGpuFrame(gpuData, width, height, dpr);
    if (profile) {
        profile.gpuMs = performance.now() - gpuStartedAt;
        finishWindFieldProfile(profile, {
            backend: rendered ? 'webgpu' : 'canvas',
            gpuData: gpuCount
        });
    }
    if (!rendered && gpuWasActive && windGpuDisabled && windFieldVisible) {
        // The CPU batches were intentionally skipped while the GPU backend
        // was active. Recompute this single frame after disabling the backend
        // so a device loss falls back to visible Canvas2D arrows immediately.
        requestAnimationFrame(() => {
            if (windFieldVisible) drawWindField(mapSvg, mapProjection, cyclone, pressureSystems, world);
        });
    }
}

function getUnwrappedPath(track) {
    if (!track || track.length === 0) return [];
    let lastLon = track[0][0];
    return track.map(point => {
        const p = [...point];
        p[0] = unwrapLongitude(p[0], lastLon); // 调用 utils 里的统一逻辑
        lastLon = p[0];
        return p;
    });
}

// ===================================================
// Forecast Cone
// ===================================================
function forecastConeBridge(a, b) {
    // Each pair owns its tangents. Using the next leg's normal at a shared
    // vertex can reverse/self-intersect the preceding polygon on a turn.
    const midpoint = d3.geoInterpolate(a.center, b.center)(0.5);
    const local = d3.geoAzimuthalEquidistant()
        .rotate([-midpoint[0], -midpoint[1]]).scale(180 / Math.PI).translate([0, 0]);
    const pa = local(a.center), pb = local(b.center);
    const tangent = getConeTangentPolygon(
        {x: pa[0], y: pa[1], r: a.radiusDeg},
        {x: pb[0], y: pb[1], r: b.radiusDeg}
    );
    if (!tangent) return null; // Contained/coincident disks need no bridge.
    const ring = tangent.map(p => local.invert(p));
    ring.push(ring[0]);
    const polygon = {type: 'Polygon', coordinates: [ring]};
    // D3's spherical convention chooses the complementary globe for a
    // reversed exterior ring. Forecast bridges always occupy the small side.
    if (d3.geoArea(polygon) > 2 * Math.PI) ring.reverse();
    return polygon;
}

const forecastRenderStates = new WeakMap();
let forecastShapeId = 0;

function forecastPointLetter(intensity) {
    // Weak lows share D; stronger fixes use the simulator's existing
    // category thresholds rather than a second, separate intensity scale.
    if (intensity < 34) return 'D';
    if (intensity < 64) return 'S';
    return getCategory(intensity).shortName.slice(-1);
}

const FORECAST_POINT_DESIGN = Object.freeze({ radius: 9, fontSize: 11, strokeWidth: 1.2 });
const FORECAST_POINT_PAINT = Object.freeze({
    regular: Object.freeze({ fill: '#0a1019', stroke: '#f2f5f7', text: '#ffffff' }),
    major: Object.freeze({ fill: '#ffffff', stroke: '#080d12', text: '#080d12' })
});
function forecastPointPaint(intensity) {
    return FORECAST_POINT_PAINT[Number(forecastPointLetter(intensity)) >= 3 ? 'major' : 'regular'];
}

// The ICWC artwork is exported at 2x display resolution. Its badges use
// 85% of the live layer's size, with identical proportions and colors.
const WARNING_FORECAST_POINT_SCALE = 2 * 0.85;
function drawWarningForecastPoint(ctx, pos, intensity, scale = WARNING_FORECAST_POINT_SCALE) {
    const paint = forecastPointPaint(intensity);
    const fontSize = FORECAST_POINT_DESIGN.fontSize * scale;
    ctx.save();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.arc(pos[0], pos[1], FORECAST_POINT_DESIGN.radius * scale, 0, Math.PI * 2);
    ctx.fillStyle = paint.fill;
    ctx.strokeStyle = paint.stroke;
    ctx.lineWidth = FORECAST_POINT_DESIGN.strokeWidth * scale;
    ctx.fill();
    ctx.stroke();
    ctx.font = `bold ${fontSize}px Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = paint.text;
    // Match the live SVG's dy=0.35em instead of relying on font-dependent
    // canvas middle alignment.
    ctx.fillText(forecastPointLetter(intensity), pos[0], pos[1] + fontSize * 0.35);
    ctx.restore();
}

function forecastTracksMatch(snapshot, forecasts) {
    return snapshot?.length === forecasts.length && forecasts.every((f, i) =>
        snapshot[i].length === f.track.length && f.track.every((point, j) => {
            const old = snapshot[i][j];
            return Array.isArray(point) ? Array.isArray(old)
                && old.length === Math.min(point.length, 5)
                && old.every((value, k) => Object.is(value, point[k])) : Object.is(old, point);
        }));
}

function forecastProjectionState(projection) {
    // Clipping/resampling settings also invalidate cached projected paths.
    const state = [projection];
    for (const key of ['scale', 'translate', 'center', 'rotate', 'angle',
        'reflectX', 'reflectY', 'precision', 'clipAngle', 'clipExtent',
        'parallels', 'preclip', 'postclip']) {
        if (typeof projection[key] === 'function') {
            const value = projection[key]();
            state.push(key, ...(Array.isArray(value) ? value.flat() : [value]));
        }
    }
    return state;
}

function buildForecastConeGeometry(pathForecasts) {
    const validPoint = p => Array.isArray(p) && Number.isFinite(p[0])
        && Number.isFinite(p[1]) && Math.abs(p[1]) <= 90 && Number.isFinite(p[2]);
    
    const coneSegments = []; 
    const meanTrackCoordinates = []; // 用于构建 GeoJSON LineString
    const forecastLabels = [];
    let lastStepData = null;

    const unwrapLon = (lon, refLon) => {
        const diff = ((lon - refLon) % 360 + 540) % 360 - 180;
        return refLon + diff;
    };
    // The live layer has no 36/60h endpoints; Warning Graphic does.
    const quantizedLimit = forecastDisplayLimit(pathForecasts);
    const keyframes = quantizedLimit === 4 ? [4] : [8, 16, 24];

    let refLon = pathForecasts.map(f => f.track[0]).find(validPoint)?.[0] ?? 0;

    for (let i = 0; i <= quantizedLimit; i++) {
        const pointsAtStep = [];
        pathForecasts.forEach(f => {
            if (validPoint(f.track[i])) pointsAtStep.push(f.track[i]);
        });
        if (pointsAtStep.length === 0) break;

        // 1. [核心修复] 解包经度并计算平均值
        // 将所有点的经度转换为相对于 refLon 连续的值
        const unwrappedPoints = pointsAtStep.map(p => {
            const uLon = unwrapLon(p[0], refLon);
            return [uLon, p[1]]; // [lon, lat]
        });

        const avgLonUnwrapped = d3.mean(unwrappedPoints, p => p[0]);
        const avgLat = d3.mean(pointsAtStep, p => p[1]);

        // 更新下一轮的参考经度
        refLon = avgLonUnwrapped;

        // 规范化 avgLon 回 -180~180 用于存储 GeoJSON (虽然 D3 通常能处理越界，但规范化更安全)
        const avgLonNorm = ((avgLonUnwrapped % 360) + 540) % 360 - 180;

        // 收集中心线点 (使用规范化坐标)
        meanTrackCoordinates.push([avgLonNorm, avgLat]);
        if (keyframes.includes(i)) {
            // Mark exactly the consensus vertex, not model zero's offset
            // track. Its letter must describe the same ensemble consensus.
            forecastLabels.push({hour: i * 3,
                point: [avgLonNorm, avgLat, d3.mean(pointsAtStep, p => p[2])]});
        }

        // 2. 动态半径 (使用解包后的坐标计算距离，避免日界线处距离突变)
        const stdDev = d3.deviation(unwrappedPoints, p => Math.hypot(p[0] - avgLonUnwrapped, p[1] - avgLat)) || 0;
        const radiusDeg = (0.25 + i * 0.14) + (stdDev * 0.6);
        const currentStep = {center: [avgLonNorm, avgLat], radiusDeg};
        if (lastStepData) {
            const bridge = forecastConeBridge(lastStepData, currentStep);
            if (bridge) coneSegments.push({type: "Feature", geometry: bridge});
        }
        // A LineString filled by SVG closes across the projection seam. Use
        // a spherical polygon so D3 can clip a disk at the date line/pole.
        const nodeCircle = d3.geoCircle().center(currentStep.center)
            .radius(radiusDeg).precision(5)();
        coneSegments.push({type: "Feature", geometry: nodeCircle});

        lastStepData = currentStep;
    }

    return {
        coneSegments,
        centerLine: {type: 'Feature', geometry: {type: 'LineString', coordinates: meanTrackCoordinates}},
        labels: forecastLabels
    };
}

export function drawForecastCone(container, mapProjection, pathForecasts) {
    const node = container.node();
    if (!node) return;
    // Historical/model annotations belong to the previous display, not to
    // the retained cone. Preserve the live callers' former clear semantics.
    container.selectAll('.forecast-track, .forecast-point-label').remove();
    const forecasts = (pathForecasts || []).filter(f => Array.isArray(f?.track));
    if (!forecasts.length || forecastDisplayLimit(forecasts) === 0) {
        container.selectAll('.forecast-cone-container, .forecast-center-line, .forecast-labels').remove();
        forecastRenderStates.delete(node);
        return;
    }
    let state = forecastRenderStates.get(node);
    const dataChanged = !forecastTracksMatch(state?.tracks, forecasts);
    if (dataChanged) {
        state = {...state, geometry: buildForecastConeGeometry(forecasts),
            tracks: forecasts.map(f => f.track.map(p => Array.isArray(p) ? p.slice(0, 5) : p)),
            projectionState: null};
        forecastRenderStates.set(node, state);
    }
    const projectionState = forecastProjectionState(mapProjection);
    const viewChanged = !state.projectionState || projectionState.length !== state.projectionState.length
        || projectionState.some((value, i) => !Object.is(value, state.projectionState[i]));
    const mounted = state.shape?.node().parentNode && node.contains(state.shape.node());
    if (!dataChanged && !viewChanged && mounted) return;

    if (viewChanged) {
        const geoPath = d3.geoPath().projection(mapProjection);
        // Preserve every spherical primitive and D3 clipping/resampling.
        // Nonzero fill of identically oriented rings gives their union.
        state.conePath = state.geometry.coneSegments.map(segment => geoPath(segment) || '').join('');
        state.centerPath = state.geometry.centerLine.geometry.coordinates.length > 1
            ? geoPath(state.geometry.centerLine) : null;
        state.labels = state.geometry.labels.map(label => ({...label,
            xy: mapProjection(label.point.slice(0, 2))})).filter(label => label.xy?.every(Number.isFinite));
        state.projectionState = projectionState;
    }

    if (!mounted) {
        container.selectAll('.forecast-cone-container, .forecast-center-line, .forecast-labels').remove();
        const id = `forecast-cone-shape-${++forecastShapeId}`;
        const cone = container.append('g').attr('class', 'forecast-cone-container').style('pointer-events', 'none');
        const defs = cone.append('defs');
        state.shape = defs.append('path').attr('id', id);
        const mask = defs.append('mask').attr('id', `${id}-edge`)
            .attr('x', '-10%').attr('y', '-10%').attr('width', '120%').attr('height', '120%')
            .attr('mask-type', 'luminance');
        mask.append('use').attr('href', `#${id}`).attr('fill', 'none')
            .attr('stroke', 'white').attr('stroke-width', 2);
        // Subtract the filled union so only the one-pixel outer edge remains.
        // Interior circle/bridge seams need no blur/morphology SVG filter.
        mask.append('use').attr('href', `#${id}`).attr('fill', 'black');
        cone.append('use').attr('href', `#${id}`).attr('class', 'forecast-cone-fill')
            .attr('fill', 'rgb(85, 105, 160)').attr('fill-rule', 'nonzero').attr('opacity', 0.15);
        cone.append('use').attr('href', `#${id}`).attr('class', 'forecast-cone-edge')
            .attr('fill', 'none').attr('stroke', '#98eaf2').attr('stroke-width', 2)
            .attr('stroke-opacity', 0.65).attr('mask', `url(#${id}-edge)`);
        state.center = container.append('path').attr('class', 'forecast-center-line')
            .style('fill', 'none').style('stroke', 'cyan').style('stroke-width', 2)
            .style('stroke-dasharray', '4, 3').style('opacity', 0.8).style('pointer-events', 'none');
        state.labelGroup = container.append('g').attr('class', 'forecast-labels');
    }
    state.shape.datum(state.geometry.coneSegments).attr('d', state.conePath);
    state.center.datum(state.geometry.centerLine).attr('d', state.centerPath);
    const labels = state.labelGroup.selectAll('g').data(state.labels, label => label.hour).join(enter => {
        const group = enter.append('g').attr('class', 'forecast-point');
        group.append('circle').attr('r', FORECAST_POINT_DESIGN.radius).attr('fill', '#0a1019')
            .attr('stroke', '#f2f5f7').attr('stroke-width', FORECAST_POINT_DESIGN.strokeWidth)
            .append('title');
        group.append('text').attr('class', 'forecast-point-category')
            .attr('text-anchor', 'middle').attr('dy', '0.35em')
            .style('font-size', `${FORECAST_POINT_DESIGN.fontSize}px`).style('font-weight', '700').style('font-family', 'Arial, sans-serif')
            .style('fill', '#ffffff').style('pointer-events', 'none');
        group.append('text').attr('class', 'forecast-point-time').attr('text-anchor', 'middle').attr('y', -15)
            .style('font-size', '10px').style('font-family', 'Monospace').style('fill', 'white')
            .style('paint-order', 'stroke').style('stroke', '#101827').style('stroke-width', 2.5)
            .style('stroke-linejoin', 'round').style('pointer-events', 'none');
        return group;
    });
    labels.attr('transform', label => `translate(${label.xy[0]},${label.xy[1]})`);
    labels.select('circle')
        .attr('fill', label => forecastPointPaint(label.point[2]).fill)
        .attr('stroke', label => forecastPointPaint(label.point[2]).stroke);
    labels.select('.forecast-point-category')
        .style('fill', label => forecastPointPaint(label.point[2]).text)
        .text(label => forecastPointLetter(label.point[2]));
    labels.select('title').text(label => `+${label.hour}h · ${forecastPointLetter(label.point[2])}`);
    labels.select('.forecast-point-time').text(label => `+${label.hour}h`);
}

function drawSSTField(container, mapProjection, month, globalTemp, cyclone) {
    const svgNode = container.node().closest('svg');
    const { width, height } =
        svgNode.getBoundingClientRect();

    /*
     * SST 的空间变化比气压平滑，
     * 第一版不需要特别高的网格分辨率。
     */
    const nx = 90;
    const ny = Math.max(
        30,
        Math.round(nx * height / width)
    );

    const grid = [];
    const sampleOcean = createOceanFieldSampler(month, globalTemp,
        cyclone?.oceanHeatDistribution ?? 50, cyclone);

    for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
            const coords = mapProjection.invert([
                (i + 0.5) * width / nx,
                (j + 0.5) * height / ny
            ]);

            if (
                !coords ||
                !Number.isFinite(coords[0]) ||
                !Number.isFinite(coords[1])
            ) {
                grid.push(0);
                continue;
            }

            const lon = coords[0];
            const lat = coords[1];

            grid.push(
                sampleOcean(lat, lon).sstC
            );
        }
    }

    const thresholds = [
        -2, 0, 5, 10, 15, 20, 22, 24,
        26, 27, 28, 29, 30, 31, 32
    ];

    const contours = d3.contours()
        .size([nx, ny])
        .thresholds(thresholds)(grid);

    const transform = d3.geoTransform({
        point(x, y) {
            this.stream.point(
                x * width / nx,
                y * height / ny
            );
        }
    });

    const pathGenerator =
        d3.geoPath().projection(transform);

    const color = d3.scaleLinear()
        .domain([
            10, 15, 20, 24,
            26, 28, 30, 32
        ])
        .range([
            '#312e81',
            '#2563eb',
            '#0891b2',
            '#10b981',
            '#84cc16',
            '#facc15',
            '#f97316',
            '#dc2626'
        ])
        .clamp(true);

    container
        .selectAll('path')
        .data(contours)
        .join('path')
        .attr('d', pathGenerator)
        .attr('fill', d => color(d.value))
        .attr('stroke', 'none')
        .attr('opacity', 0.58)
        .style('pointer-events', 'none');
}

// ===================================================
// 500-hPa Geopotential-Height Field
// ===================================================
// The map control formerly labelled "Steering Flow" rendered MSLP contours.
// That was physically and visually misleading: the steering diagnostic is
// based on the mid-tropospheric field, while MSLP belongs in the surface
// synoptic products. Keep this layer tied to the native 500-hPa field.
function drawHeight500Field(
    container, mapProjection, pressureSystemsObj, cyclone = null, precomputedGrid = null
) {
    const startedAt = performance.now();
    const svgNode = container.node().closest('svg'); 
    const { width, height } = svgNode.getBoundingClientRect();
    const nx = precomputedGrid?.nx || 104;
    const ny = precomputedGrid?.ny || Math.round(nx * height / width);
    const grid = precomputedGrid ? Array.from(precomputedGrid.values) : [];
    const systems = normalizeHeightSystems(pressureSystemsObj);
    const hasHeightBackground = systems?.upper?.some(c => c.role === 'height-background');
    if (!hasHeightBackground) return;

    const hasVortex = cyclone?.status === 'active'
        && Number.isFinite(cyclone.lon) && Number.isFinite(cyclone.lat)
        && Number.isFinite(cyclone.intensity);
    const sampleCycloneAnomaly = hasVortex
        ? createCycloneHeightAnomalySampler(cyclone, 500) : null;
    const sampleEnvironmentalFeedback = hasVortex
        ? createCycloneEnvironmentalHeightFeedbackSampler(cyclone, 500, systems)
        : null;

    if (!precomputedGrid) {
        for (let j = 0; j < ny; ++j) {
            for (let i = 0; i < nx; ++i) {
                const coords = mapProjection.invert([i * width / nx, j * height / ny]);
                if (!coords || !isFinite(coords[0]) || !isFinite(coords[1])) {
                    grid.push(5800); continue;
                }

                const [lon, lat] = coords;
                const environment = getGeopotentialHeight500(lon, lat, systems, 500);
                const cycloneAnomaly = hasVortex
                    ? sampleCycloneAnomaly(lon, lat)
                    : 0;
                const environmentalFeedback = hasVortex
                    ? sampleEnvironmentalFeedback(lon, lat)
                    : 0;
                grid.push(environment + cycloneAnomaly + environmentalFeedback);
            }
        }
    }

    const minHeight = Math.min(...grid);
    const maxHeight = Math.max(...grid);
    if (!Number.isFinite(minHeight) || !Number.isFinite(maxHeight)) return;

    // 20-m spacing is the standard synoptic interval for a compact 500-hPa
    // chart. Every fourth contour is drawn heavier and labelled as Z500.
    const firstContour = Math.floor(minHeight / 20) * 20;
    const lastContour = Math.ceil(maxHeight / 20) * 20;
    const contours = d3.contours()
        .size([nx, ny])
        .thresholds(d3.range(firstContour, lastContour + 20, 20))(grid);
    const transform = d3.geoTransform({ point: function(x, y) { this.stream.point(x * width / nx, y * height / ny); } });
    const pathGenerator = d3.geoPath().projection(transform);

    const contourGroup = container.append("g").attr("class", "height500-contours");
    contourGroup.selectAll("path").data(contours).enter().append("path")
        .attr("class", d => (Math.round(d.value) % 80 === 0)
            ? "isohypse isohypse-major"
            : "isohypse")
        .attr("d", pathGenerator);

    const majorContours = contours.filter(d => Math.round(d.value) % 80 === 0);
    contourGroup.append("g").attr("class", "height500-labels")
        .selectAll("text").data(majorContours).enter().append("text")
        .attr("class", "isohypse-label")
        .attr("x", d => pathGenerator.centroid(d)[0])
        .attr("y", d => pathGenerator.centroid(d)[1])
        .text(d => `Z${Math.round(d.value)}`);
    reportHeight500Timing('contour generation + SVG paths', startedAt, {
        gridPoints: grid.length,
        contourCount: contours.length,
        labeledContours: majorContours.length
    });
}

export function drawMap(mapSvg, mapProjection, world, cyclone, options = {}) {
    if (!world || !mapSvg) return;
    if (landGridSourceWorld !== world) {
        landGridSourceWorld = world;
        landGrid = null;
    }
    const fullDrawStartedAt = performance.now();

    // 1. 使用对象解构并设置默认值，消除长参数列表带来的维护麻烦
    const {
        pathForecasts = [],
        pressureSystems = [],
        showPressureField = false,
        showHumidityField = false,
        showSSTField = false,
        showShearField = false,
        showPathForecast = false,
        showWindRadii = false,
        showPathPoints = false,
        showWindField = false,
        siteName = null,
        siteLon = null,
        siteLat = null,
        siteData = null,
        siteHistory = [],
        onSiteClick = null,
        isPaused = false,
        month = 8,
        globalTemp = 289,
        globalShear = 100,
        precomputedHeight500Grid = null,
        interactivePressureSystems = pressureSystems
    } = options;

    // 2. 初始化图层结构 (逻辑保持不变，但结构更清晰)
    const layerNames = [
        "layer-sst",
        "layer-static",       // 背景：经纬网、陆地
        "layer-humidity",     // 等湿度线
        "layer-shear",        // 环境 200–850 hPa 风切变
        "layer-pressure",     // 500 hPa 高度线（保留旧选择器兼容性）
        "layer-forecast",     // 预测路径/锥
        "layer-track-lines",  // 历史路径线
        "layer-track-points", // 历史路径点
        "layer-wind-radii",   // 风圈
        "layer-cyclone",      // 当前气旋图标
        "layer-effects",      // 登陆等短时地图事件
        "layer-pressure-handles",   // 压力系统控制手柄层
        "track-interaction-layer",
        "layer-ui"            // 站点标记、悬浮框等
    ];

    layerNames.forEach(name => {
        const className = `${name}`;
        if (mapSvg.select(`.${className}`).empty()) {
            mapSvg.append("g").attr("class", className);
        }
    });
    const sstLayer = mapSvg.select(".layer-sst");
    const staticLayer = mapSvg.select(".layer-static");
    const pressureLayer = mapSvg.select(".layer-pressure");
    const humidityLayer = mapSvg.select(".layer-humidity");
    const shearLayer = mapSvg.select('.layer-shear');
    const forecastLayer = mapSvg.select(".layer-forecast");
    const trackLineLayer = mapSvg.select(".layer-track-lines");
    const trackPointLayer = mapSvg.select(".layer-track-points");
    const windRadiiLayer = mapSvg.select(".layer-wind-radii");
    const cycloneLayer = mapSvg.select(".layer-cyclone");
    const effectsLayer = mapSvg.select(".layer-effects");
    const uiLayer = mapSvg.select(".layer-ui");
    const pressureHandlesLayer = mapSvg.select(".layer-pressure-handles");

    const { width, height } = mapSvg.node().getBoundingClientRect();
    const pathGenerator = d3.geoPath().projection(mapProjection);

    // Start WebGPU device setup while the map is being drawn so enabling the
    // wind layer later does not pay the adapter/pipeline creation cost.
    ensureWindGpuLayer(mapSvg.node().parentNode);

    // 3. 气旋中心定位逻辑 (仅在 active 状态且有坐标时执行)
    if (cyclone && cyclone.status === 'active' && isFinite(cyclone.lon)) {
         mapProjection.rotate([-cyclone.lon, 0]).center([0, cyclone.lat]).translate([width / 2, height / 2]);
    }
    
    const highlandGeometry = getElevationThresholdGeometry(200);
    const usedStaticAtlas = drawStaticCylindricalAtlas(
        staticLayer, mapProjection, world, highlandGeometry, width
    );
    if (!usedStaticAtlas) clearStaticAtlas(staticLayer);
    // A. 初始化：如果陆地不存在，则创建 DOM (仅执行一次)
    if (!usedStaticAtlas) {
        if (staticLayer.select(".land").empty()) {
            // 绘制经纬网容器
            staticLayer.append("path")
                .datum(d3.geoGraticule().step([10, 10]))
                .attr("class", "graticule");

            // 绘制陆地容器
            staticLayer.append("g")
                .attr("class", "land-group") //以此 Group 为容器
                .selectAll("path")
                .data(world.features)
                .enter().append("path")
                .attr("class", "land")
                .style("stroke", "none");
        }

        if (staticLayer.select('.highland').empty()) {
            if (highlandGeometry) {
                staticLayer.append('path')
                    .datum(highlandGeometry)
                    .attr('class', 'highland');
            }
        }
    }

    // B. 更新：每一帧都需要根据新的 Projection 更新坐标
    sstLayer.selectAll("*").remove();

    if (DISPLAY_FEATURES.sst && showSSTField) {
        drawSSTField(sstLayer, mapProjection, month, globalTemp, cyclone);
    }
    if (!usedStaticAtlas) {
        staticLayer.select(".graticule").attr("d", pathGenerator);
        staticLayer.select(".land-group").selectAll(".land").attr("d", pathGenerator);
        staticLayer.select('.highland').attr('d', pathGenerator);
    }
    effectsLayer.selectAll('.landfall-effect').attr('transform', d => {
        const position = mapProjection(d);
        return position ? `translate(${position[0]},${position[1]})` : null;
    });

    // ============================================================

    // 4. 风场：WebGPU 优先，Canvas 2D 自动回退
    if (showWindField && cyclone && cyclone.status === 'active') {
        drawWindField(mapSvg, mapProjection, cyclone, pressureSystems, world);
    } else {
        clearWindFieldLayers();
    }

    // 5. 500 hPa 高度场 (Steering Flow) 和湿度场 (Humidity)
    pressureLayer.selectAll("*").remove(); 
    if (showPressureField && cyclone && cyclone.status === 'active') {
        drawHeight500Field(
            pressureLayer, mapProjection, pressureSystems, cyclone, precomputedHeight500Grid
        );
    }

    humidityLayer.selectAll("*").remove();
    if (showHumidityField && cyclone && cyclone.status === 'active') {
        drawHumidityField(humidityLayer, mapProjection, pressureSystems, cyclone);
    }
    const shearVisible = DISPLAY_FEATURES.shear && showShearField && cyclone?.status === 'active';
    setLegendVisible('shear-legend', shearVisible);
    if (shearVisible) {
        drawShearField(shearLayer, mapProjection, pressureSystems, globalShear).catch(error => {
            console.error('[shear-layer] Failed to render environmental shear', error);
        });
    } else {
        clearShearField(shearLayer);
    }

    // 6. 风圈 (Wind Radii)
    windRadiiLayer.selectAll("*").remove(); 
    if (showWindRadii && cyclone && cyclone.status === 'active') {
        drawWindRadii(windRadiiLayer, pathGenerator, cyclone, pressureSystems, isPaused);
    }

    // 7. 预测路径 (Forecast)
    if (showPathForecast && pathForecasts && pathForecasts.length > 0) {
        drawForecastCone(forecastLayer, mapProjection, pathForecasts);
    } else {
        forecastLayer.selectAll('*').remove();
    }

    trackLineLayer.selectAll('.history-track').remove();
    trackPointLayer.selectAll('.history-track').remove();
    drawTrackGeometry(trackLineLayer, trackPointLayer, mapProjection, cyclone, showPathPoints);

    // 9. 当前气旋图标 (Icon)
    drawCycloneMarker(cycloneLayer, mapProjection, cyclone);

    const activeSystemsList = Array.isArray(interactivePressureSystems)
        ? interactivePressureSystems
        : (interactivePressureSystems.upper || []);

    if (showPressureField && cyclone && cyclone.status === 'active' && activeSystemsList.length > 0) {
        // 过滤出强度显著的系统用于显示手柄
        const significantSystems = activeSystemsList.filter(s => Math.abs(s.strength) > 5);
        
        // 第3个参数传过滤后的列表，第4个参数传完整的 pressureSystems 对象(用于同步拖动)
        drawInteractivePressureSystems(
            pressureHandlesLayer,
            mapProjection,
            significantSystems,
            interactivePressureSystems,
            cyclone,
            options.onSystemRemove,
            options.onSystemChange,
            options.onSystemDrag
        );
    } else {
        pressureHandlesLayer.selectAll("*").remove();
    }

    // 10. UI 层
    uiLayer.selectAll("*").remove();
    if (siteLon != null && siteLat != null && isFinite(siteLon) && isFinite(siteLat)) {
        drawSiteMarker(uiLayer, mapProjection, siteName, siteLon, siteLat, siteData, siteHistory, onSiteClick);
    }
    if (showPressureField) {
        reportHeight500Timing('full map draw', fullDrawStartedAt, {
            trackPoints: cyclone?.track?.length || 0,
            pressureHandleCount: activeSystemsList.length
        });
    }
}

// ===================================================
// Site Marker
// ===================================================
function drawSiteMarker(container, projection, name, lon, lat, data, history, onClick) {
    const proj = projection([lon, lat]);
    if (!proj) return;
    const [siteX, siteY] = proj;
    const isSelected = data ? data.isSelected : false;
    
    // 选中时稍微亮一点，但不弹出东西
    const markerColor = isSelected ? "rgba(255, 255, 255, 0.8)" : "rgba(17, 24, 39, 0.5)";

    // 1. 绘制站点方块
    container.append("rect")
        .attr("x", siteX - 5).attr("y", siteY - 5)
        .attr("width", 10).attr("height", 10)
        .attr("fill", markerColor)
        .attr("stroke", "white").attr("stroke-width", 1.5)
        .style("cursor", "pointer")
        .style("pointer-events", "all") 
        .on('mouseover', function() { 
            d3.select(this).attr('fill', "rgba(255, 255, 255, 1.0)");
            // 隐藏其他图层的干扰
            d3.select(".tooltip").style("opacity", 0);
            d3.selectAll(".track-interaction-layer circle").style("opacity", 0);
        })
        .on('mousemove', (e) => e.stopPropagation()) 
        .on('mouseout', function() { d3.select(this).attr('fill', markerColor) })
        .on("click", (e) => { e.stopPropagation(); if (onClick) onClick(); });

    // 2. 绘制站点名称
    if (name) {
        container.append("text")
            .attr("x", siteX).attr("y", siteY + 16)
            .attr("class", "site-label-name")
            .style("fill", "white").style("font-weight", "bold").style("font-size", "11px")
            .style("text-anchor", "middle").style("stroke", "black").style("stroke-width", "2px")
            .style("paint-order", "stroke").text(name);
    }

    // 3. 绘制基础风速标签 (常驻显示)
    if (data && data.label) {
        let windColor = "#22d3ee"; 
        const spd = data.displaySpeed || 0;

        if (spd >= 64) { windColor = "#ff80ab"; } 
        else if (spd >= 48) { windColor = "#d500f9"; } 
        else if (spd >= 34) { windColor = "#ef4444"; } 
        else if (spd >= 22) { windColor = "#facc15"; }

        container.append("foreignObject")
            .attr("x", siteX - 60) 
            .attr("y", siteY - 22) 
            .attr("width", 120)
            .attr("height", 20)
            .style("pointer-events", "none") 
            .append("xhtml:div")
            .style("width", "100%")
            .style("height", "100%")
            .style("display", "flex")
            .style("align-items", "center")
            .style("justify-content", "center")
            .style("text-align", "center")
            .style("font-family", "Monospace")
            .style("font-size", "10px")
            .style("font-weight", "bold")
            .style("color", windColor)
            .style("text-shadow", "0 0 2px black, 0 0 4px black") 
            .html(data.label);
    }

    // [已删除] 旧的气压显示逻辑
    // [已删除] 旧的折线图绘制逻辑 (drawSiteChart 调用)
}

export function drawFinalPath(mapSvg, mapProjection, cyclone, world, tooltip, siteName, siteLon, siteLat, showPathPoints = false, finalStats = null, basin = 'WPAC', pressureSystems = [], showWindField = false, month = 8, siteHistory = [], siteData = null, onSiteClick = null, displayLayers = {}) {
    // 1. 基础安全检查
    if (!cyclone || !cyclone.track || cyclone.track.length < 2) return;
    
    // [修复 A] 清理 "SHOW ALL" 模式留下的残留线条 (.history-segment)
    mapSvg.select(".layer-track-lines").selectAll(".history-segment").remove();

    const { width, height } = mapSvg.node().getBoundingClientRect();

    // 2. 经度解包 (处理日界线)
    const unwrappedTrackForCentering = [];
    let lastLon_center = NaN;
    cyclone.track.forEach(pointData => {
        const point = [...pointData];
        let lon = point[0];
        if (!isNaN(lastLon_center)) {
            if (Math.abs(lon - lastLon_center) > 180) {
                lon += (lon < lastLon_center) ? 360 : -360;
            }
        }
        point[0] = lon;
        lastLon_center = lon;
        unwrappedTrackForCentering.push(point);
    });

    // 3. 计算中心并旋转地球
    const avgLon = d3.mean(unwrappedTrackForCentering, p => p[0]);
    const avgLat = d3.mean(unwrappedTrackForCentering, p => p[1]);

    if (isFinite(avgLon) && isFinite(avgLat)) {
        // 将视角旋转到路径中心
        mapProjection.rotate([-avgLon, 0]).center([0, avgLat]);
    }

    // 4. 计算缩放 (Fit Extent)
    const coords = cyclone.track.map(p => [p[0], p[1]]);
    const fullTrackGeoJSON = { type: "LineString", coordinates: coords };

    // [修复 B] 动态计算边距，防止硬编码数值在小屏幕上导致负数
    // 左侧留出 360px 给左侧面板 (如果有显示)，上下留出 50px
    const leftPad = width > 600 ? 360 : 100; 
    
    // 自动缩放地图以适应完整路径
    mapProjection.fitExtent([[leftPad, 100], [width - 100, height - 100]], fullTrackGeoJSON);
    
    // [修复 C - 核心] 创建副本并强制修改状态为 'history'
    // 这防止 drawMap() 内部检测到 'active' 状态后强制重置地图中心，覆盖上面的 fitExtent
    const cycloneForDisplay = { ...cyclone, status: 'history' };

    // 5. 绘制地图
    drawMap(mapSvg, mapProjection, world, cycloneForDisplay, {
    pathForecasts: [],
    pressureSystems: pressureSystems,
    showPressureField: false,
    showHumidityField: false,
    showShearField: false,
    showSSTField: displayLayers.showSSTField === true,
    showPathForecast: false,
    showWindRadii: false,
    siteName,
    siteLon,
    siteLat,
    showPathPoints,
    showWindField,
    month,
    siteHistory,
    siteData,
    onSiteClick
    });

    // 6. 更新信息显示
    if (finalStats) {
        const infoBox = document.getElementById('map-info-box');
        const timeEl = document.getElementById('map-info-time');
        const intensityEl = document.getElementById('map-info-intensity');
        const movementEl = document.getElementById('map-info-movement');

        if (infoBox && timeEl && intensityEl && movementEl) {
            timeEl.textContent = finalStats.number; 
            intensityEl.textContent = `${finalStats.peakWind}kt / ${finalStats.minPressure}hPa`;
            intensityEl.style.color = getCategory(Number(finalStats.peakWind)).color;
            movementEl.textContent = `ACE: ${finalStats.ace}`;
            infoBox.classList.remove('hidden');
        }
    } else {
         document.getElementById('map-info-box').classList.add('hidden');
    }

// 7. 交互层 (Interaction Layer) - 鼠标悬停查看详情 + 点击查看历史预测
    let interactionLayer = mapSvg.select(".track-interaction-layer");
    let forecastLayer = mapSvg.select(".layer-forecast"); // 确保获取到预测层

    // 如果预测层不存在，创建一个（通常 drawMap 会创建，为了保险起见）
    if (forecastLayer.empty()) {
        forecastLayer = mapSvg.insert("g", ".layer-ui").attr("class", "layer-forecast");
    }
    
    if (interactionLayer.empty()) {
        const uiLayer = mapSvg.select(".layer-ui");
        if (!uiLayer.empty()) {
            interactionLayer = mapSvg.insert("g", ".layer-ui").attr("class", "track-interaction-layer");
        } else {
            interactionLayer = mapSvg.append("g").attr("class", "track-interaction-layer");
        }
    }

    // 重建遮罩
    interactionLayer.selectAll("*").remove();

    interactionLayer.append("rect")
        .attr("class", "interaction-overlay")
        .attr("width", width)
        .attr("height", height)
        .style("fill", "transparent") // 关键：必须是 transparent 用于接收鼠标事件
        .style("cursor", "crosshair");

    // 悬停时的高亮圆圈
    const highlightCircle = interactionLayer.append("circle")
        .attr("class", "highlight-circle")
        .attr("r", 9)
        .style("fill", "none")
        .style("stroke", "white")
        .style("stroke-width", "2px")
        .style("pointer-events", "none")
        .style("opacity", 0);

    // 点击锁定时的圆圈 (新增：用于标记当前选中的点)
    const selectedCircle = interactionLayer.append("circle")
        .attr("class", "selected-circle")
        .attr("r", 7)
        .style("fill", "cyan") // 选中点用青色实心
        .style("fill-opacity", 0.6)
        .style("stroke", "none")
        .style("pointer-events", "none")
        .style("opacity", 0);

    // 辅助函数：寻找最近点
    function findClosestPoint(mouseX, mouseY) {
        let closest = null;
        let minDist = Infinity;

        cyclone.track.forEach((pointData, idx) => {
            const proj = mapProjection(pointData.slice(0, 2));
            if (!proj) return;
            const [projX, projY] = proj;
            const dist = Math.sqrt((mouseX - projX) ** 2 + (mouseY - projY) ** 2);
            if (dist < minDist) {
                minDist = dist;
                closest = { data: pointData, index: idx };
            }
        });
        
        // 阈值判断 (50px)
        if (minDist < 50) return closest;
        return null;
    }

    // 绑定事件
    interactionLayer.select(".interaction-overlay")
        .on("mousemove", function(event) {
            const [mouseX, mouseY] = d3.pointer(event);
            const closestPoint = findClosestPoint(mouseX, mouseY);

            if (closestPoint) {
                const { data, index } = closestPoint;
                const [lon, lat, intensity, isT, isE, circulationSize, isS, r34, r50, r64, storedPressure] = data;
                
                // --- Tooltip 显示逻辑 ---
                const category = getCategory(intensity, isT, isE, isS);
                let pressure;
                if (storedPressure !== undefined && storedPressure !== null) {
                    pressure = storedPressure;
                } else {
                    const validSize = (typeof circulationSize === 'number') ? circulationSize : 250;
                    const centerEnvP = getSurfacePressureAt(lon, lat, pressureSystems);
                    pressure = windToPressure(intensity, validSize, basin, centerEnvP);
                }

                const latStr = `${Math.abs(lat).toFixed(1)}°${lat >= 0 ? 'N' : 'S'}`;
                const lonValue = lon > 180 ? lon - 360 : (lon < -180 ? lon + 360 : lon);
                const lonStr = `${Math.abs(lonValue).toFixed(1)}°${lonValue >= 0 ? 'E' : 'W'}`;
                
                tooltip.transition().duration(50).style("opacity", .9);
                tooltip.html(
                    `<div style="text-align: center; font-family: 'JetBrains Mono', monospace; font-size: 11px;">
                        <strong style="color: #94a3b8;">T+${index * 3}h</strong><br/>
                        <span style="color: #cbd5e1;">${latStr} ${lonStr}</span><br/>
                        <span style="color:${category.color}; font-size:1.1em; font-weight:bold;">
                        ${intensity.toFixed(0)}KT / ${pressure}hPa
                        </span><br/>
                        <span style="color: #64748b; font-size: 10px; text-transform: uppercase;">${category.shortName}</span>
                    </div>`
                )
                .style("left", (event.pageX + 15) + "px")
                .style("top", (event.pageY - 28) + "px");
                
                // --- 高亮圆圈位置更新 ---
                const proj = mapProjection(data.slice(0, 2));
                if (proj) {
                    highlightCircle
                        .attr("cx", proj[0])
                        .attr("cy", proj[1])
                        .style("fill", category.color) // 使用当前等级颜色
                        .style("opacity", 1);
                }
            } else {
                tooltip.style("opacity", 0);
                highlightCircle.style("opacity", 0);
            }
        })
        .on("click", function(event) {
            // [核心修改] 点击事件：处理历史预测的显示与隐藏
            const [mouseX, mouseY] = d3.pointer(event);
            const closestPoint = findClosestPoint(mouseX, mouseY);

            // 1. 无论点没点中，先清空旧的预测线和选中圆圈
            forecastLayer.selectAll("*").remove();
            selectedCircle.style("opacity", 0);

            if (closestPoint) {
                const { data, index } = closestPoint;
                
                // 标记选中的点
                const proj = mapProjection(data.slice(0, 2));
                selectedCircle
                    .attr("cx", proj[0])
                    .attr("cy", proj[1])
                    .style("opacity", 1);

                // 2. 获取对应的历史时刻
                // 假设每步是3小时，气象预报通常每6小时存储一次
                const currentAge = index * 3; 
                const snapAge = Math.floor(currentAge / 6) * 6; // 向下取整到最近的6小时节点

                // 3. 查找并绘制预测
                if (cyclone.forecastLogs && cyclone.forecastLogs[snapAge]) {
                    const historicalForecast = cyclone.forecastLogs[snapAge];
                    
                    console.log(`Displaying forecast for T+${snapAge}h`); // 调试用

                    // 绘制预测锥 (使用现有的 drawForecastCone 函数)
                    if (typeof drawForecastCone === 'function') {
                        drawForecastCone(forecastLayer, mapProjection, historicalForecast);
                    }

                    // 绘制预测中心线
                    // drawForecastCone 已经负责绘制预测锥和共识中心线。
                    // 这里仅补充各模型的终点标签，不能再次调用 drawForecastCone：
                    // drawForecastCone 会先清空旧预测层，第二次调用 cyclone.pathForecasts
                    // 会把刚刚绘制的历史预测（historicalForecast）清掉。
                    historicalForecast.forEach((forecast, i) => {
                        // 可选：添加模型名称标签
                        if (forecast.track.length > 0) {
                             const lastPoint = forecast.track[forecast.track.length - 1];
                             const projPos = mapProjection(lastPoint);
                             if (projPos) {
                                 forecastLayer.append("text")
                                    .attr("x", projPos[0] + 5)
                                    .attr("y", projPos[1])
                                    .text(forecast.modelName || "")
                                    .attr("class", "forecast-point-label")
                                    .style("opacity", 0.7);
                             }
                        }
                    });
                } else {
                    // 如果该时刻没有预测数据，可以稍微提示一下或者不做操作
                    console.log(`No forecast data for T+${snapAge}h`);
                }
                const trackClickEvent = new CustomEvent('cycloneTrackClick', { 
                    detail: { index: index } 
                });
                window.dispatchEvent(trackClickEvent);
            } else {
                const deselectEvent = new CustomEvent('cycloneTrackDeselect');
                window.dispatchEvent(deselectEvent);
            }
        })
        .on("mouseleave", function() {
            tooltip.style("opacity", 0);
            highlightCircle.style("opacity", 0);
        });
}

export function drawHistoricalIntensityChart(
    chartContainer,
    cycloneTrack,
    tooltip,
    mode = 'kt',
    basin = 'WPAC'
) {
    chartContainer.selectAll("*").remove();

    if (!cycloneTrack || cycloneTrack.length < 2) return;

    const { width, height } = chartContainer.node().getBoundingClientRect();
    if (width === 0 || height === 0) return;

    const margin = {
        top: 22,
        right: 22,
        bottom: 34,
        left: 54
    };

    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    /* =========================================================
       SVG
    ========================================================= */

    const svg = chartContainer
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", `0 0 ${width} ${height}`)
        .style("overflow", "visible");

    const defs = svg.append("defs");

    // 曲线柔光
    const glow = defs
        .append("filter")
        .attr("id", "intensity-line-glow")
        .attr("x", "-50%")
        .attr("y", "-50%")
        .attr("width", "200%")
        .attr("height", "200%");

    glow.append("feGaussianBlur")
        .attr("stdDeviation", 3)
        .attr("result", "blur");

    const merge = glow.append("feMerge");

    merge.append("feMergeNode")
        .attr("in", "blur");

    merge.append("feMergeNode")
        .attr("in", "SourceGraphic");

    // 曲线下方渐变
    const areaGradient = defs
        .append("linearGradient")
        .attr("id", "intensity-area-gradient")
        .attr("x1", "0")
        .attr("y1", "0")
        .attr("x2", "0")
        .attr("y2", "1");

    areaGradient.append("stop")
        .attr("offset", "0%")
        .attr("stop-color", "#dbeafe")
        .attr("stop-opacity", 0.12);

    areaGradient.append("stop")
        .attr("offset", "70%")
        .attr("stop-color", "#93c5fd")
        .attr("stop-opacity", 0.025);

    areaGradient.append("stop")
        .attr("offset", "100%")
        .attr("stop-color", "#93c5fd")
        .attr("stop-opacity", 0);

    const chartSvg = svg
        .append("g")
        .attr(
            "transform",
            `translate(${margin.left},${margin.top})`
        );

    /* =========================================================
       DATA
    ========================================================= */

    const intensityData = cycloneTrack.map((point, index) => {
        const intensity = Math.round(point[2]);

        let pressure;

        if (point[10] !== undefined && point[10] !== null) {
            pressure = point[10];
        } else {
            const size = point[5] || 300;

            pressure = Math.round(
                windToPressure(
                    intensity,
                    size,
                    basin
                )
            );
        }

        return {
            hour: index * 3,
            wind: intensity,
            pressure,
            val: mode === "kt" ? intensity : pressure,
            isT: point[3],
            isE: point[4],
            isS: point[6],
            color: point[4] ? '#c084fc' : getWindIntensityColor(point[2])
        };
    });

    const maxHour =
        intensityData[intensityData.length - 1].hour;

    /* =========================================================
       SCALES
    ========================================================= */

    const x = d3
        .scaleLinear()
        .domain([0, maxHour])
        .range([0, innerWidth]);

    let y;

    if (mode === "kt") {
        const maxIntensity =
            d3.max(intensityData, d => d.val);

        const upperLimit =
            Math.max(
                40,
                Math.ceil((maxIntensity + 12) / 10) * 10
            );

        y = d3
            .scaleLinear()
            .domain([0, upperLimit])
            .range([innerHeight, 0]);
    } else {
        const minP =
            d3.min(intensityData, d => d.val);

        const lower =
            Math.floor((minP - 8) / 10) * 10;

        y = d3
            .scaleLinear()
            .domain([
                Math.min(1000, lower),
                1020
            ])
            .range([innerHeight, 0]);
    }

    /* =========================================================
       BACKGROUND
    ========================================================= */

    chartSvg
        .append("rect")
        .attr("width", innerWidth)
        .attr("height", innerHeight)
        .attr("fill", "#05080d");

    /* =========================================================
       CATEGORY BANDS
       大幅降低存在感
    ========================================================= */

    if (mode === "kt") {
        const bands = [
            {
                min: 0,
                max: 34,
                color: "#64748b"
            },
            {
                min: 34,
                max: 64,
                color: "#38bdf8"
            },
            {
                min: 64,
                max: 83,
                color: "#22c55e"
            },
            {
                min: 83,
                max: 96,
                color: "#eab308"
            },
            {
                min: 96,
                max: 113,
                color: "#f59e0b"
            },
            {
                min: 113,
                max: 137,
                color: "#f97316"
            },
            {
                min: 137,
                max: 180,
                color: "#ef4444"
            }
        ];

        bands.forEach(band => {
            const yTop = y(
                Math.min(
                    band.max,
                    y.domain()[1]
                )
            );

            const yBottom = y(
                Math.max(
                    band.min,
                    y.domain()[0]
                )
            );

            if (yBottom <= yTop) return;

            chartSvg
                .append("rect")
                .attr("x", 0)
                .attr("y", yTop)
                .attr("width", innerWidth)
                .attr(
                    "height",
                    yBottom - yTop
                )
                .attr("fill", band.color)
                .attr("opacity", 0.055);
        });
    }

    /* =========================================================
       GRID
    ========================================================= */

    const yTicks =
        mode === "kt"
            ? y.ticks(5)
            : y.ticks(5);

    chartSvg
        .append("g")
        .selectAll("line")
        .data(yTicks)
        .join("line")
        .attr("x1", 0)
        .attr("x2", innerWidth)
        .attr("y1", d => y(d))
        .attr("y2", d => y(d))
        .attr("stroke", "#94a3b8")
        .attr("stroke-opacity", 0.12)
        .attr("stroke-width", 1);

    /* =========================================================
       AXES
    ========================================================= */

    const xAxis = d3
        .axisBottom(x)
        .ticks(
            Math.min(
                5,
                Math.ceil(maxHour / 36)
            )
        )
        .tickSize(6)
        .tickPadding(10)
        .tickFormat(d => `${d}h`);

    const yAxis = d3
        .axisLeft(y)
        .ticks(5)
        .tickSize(0)
        .tickPadding(12)
        .tickFormat(d =>
            mode === "kt"
                ? `${d}kt`
                : `${d}`
        );

    const gx = chartSvg
        .append("g")
        .attr(
            "transform",
            `translate(0,${innerHeight})`
        )
        .call(xAxis);

    const gy = chartSvg
        .append("g")
        .call(yAxis);

    // 坐标轴统一设计
    [gx, gy].forEach(axis => {
        axis.selectAll("text")
            .attr("fill", "#94a3b8")
            .style("font-size", "12px")
            .style("font-weight", "500");

        axis.selectAll(".domain")
            .attr("stroke", "#475569")
            .attr("stroke-opacity", 0.55);

        axis.selectAll("line")
            .attr("stroke", "#64748b")
            .attr("stroke-opacity", 0.45);
    });

    // Y 轴单位
    chartSvg
        .append("text")
        .attr("x", 0)
        .attr("y", -9)
        .attr("fill", "#64748b")
        .style("font-size", "10px")
        .style("font-weight", "600")
        .style("letter-spacing", "0.08em")
        .text(
            mode === "kt"
                ? "WIND SPEED"
                : "PRESSURE · HPA"
        );

    /* =========================================================
       LINE
    ========================================================= */

    const lineGen = d3
        .line()
        .x(d => x(d.hour))
        .y(d => y(d.val))
        .curve(d3.curveMonotoneX);

    const areaGen = d3
        .area()
        .x(d => x(d.hour))
        .y0(innerHeight)
        .y1(d => y(d.val))
        .curve(d3.curveMonotoneX);

    // 曲线下方非常淡的面积
    chartSvg
        .append("path")
        .datum(intensityData)
        .attr("d", areaGen)
        .attr(
            "fill",
            "url(#intensity-area-gradient)"
        );

    // Color follows historical intensity in BOTH KT and HPA views. ET is
    // still intensity-colored; only completed EX changes to fixed purple.
    const lineGradient=defs.append('linearGradient')
        .attr('id','intensity-line-colors').attr('gradientUnits','userSpaceOnUse')
        .attr('x1',0).attr('x2',innerWidth).attr('y1',0).attr('y2',0);
    intensityData.forEach((d,i)=>{
        const offset=`${d.hour/maxHour*100}%`;
        const previous=intensityData[i-1];
        if(previous && Boolean(previous.isE)!==Boolean(d.isE)) {
            lineGradient.append('stop').attr('offset',offset).attr('stop-color',previous.color);
        }
        lineGradient.append('stop').attr('offset',offset).attr('stop-color',d.color);
    });

    // glow
    chartSvg
        .append("path")
        .datum(intensityData)
        .attr("d", lineGen)
        .attr("fill", "none")
        .attr("stroke", "url(#intensity-line-colors)")
        .attr("stroke-opacity", 0.22)
        .attr("stroke-width", 6)
        .attr("filter", "url(#intensity-line-glow)");

    // 主线
    chartSvg
        .append("path")
        .datum(intensityData)
        .attr("d", lineGen)
        .attr("fill", "none")
        .attr("stroke", "url(#intensity-line-colors)")
        .attr("stroke-width", 2.5)
        .attr("stroke-linecap", "round")
        .attr("stroke-linejoin", "round");

    /* =========================================================
       LAST POINT
    ========================================================= */

    const latest =
        intensityData[intensityData.length - 1];

    const latestGroup =
        chartSvg.append("g");

    latestGroup
        .append("circle")
        .attr("cx", x(latest.hour))
        .attr("cy", y(latest.val))
        .attr("r", 7)
        .attr("fill", latest.color)
        .attr("opacity", 0.08);

    latestGroup
        .append("circle")
        .attr("cx", x(latest.hour))
        .attr("cy", y(latest.val))
        .attr("r", 3)
        .attr("fill", latest.color);

    /* =========================================================
       TOOLTIP
    ========================================================= */

    const focus =
        chartSvg
            .append("g")
            .style("display", "none");

    focus
        .append("line")
        .attr("class", "focus-line")
        .attr("y1", 0)
        .attr("y2", innerHeight)
        .attr("stroke", "#cbd5e1")
        .attr("stroke-width", 1)
        .attr("stroke-opacity", 0.25)
        .attr("stroke-dasharray", "3 5");

    focus
        .append("circle")
        .attr("class", "focus-ring")
        .attr("r", 7)
        .attr("fill", "#020617")
        .attr("stroke", "#f8fafc")
        .attr("stroke-width", 1.5);

    focus
        .append("circle")
        .attr("class", "focus-dot")
        .attr("r", 2.5)
        .attr("fill", "#f8fafc");

    const bisect =
        d3.bisector(d => d.hour).center;

    chartSvg
        .append("rect")
        .attr("width", innerWidth)
        .attr("height", innerHeight)
        .attr("fill", "transparent")
        .style("pointer-events", "all")

        .on("mouseenter", () => {
            focus.style("display", null);

            tooltip
                .style("opacity", 1);
        })

        .on("mouseleave", () => {
            focus.style("display", "none");

            tooltip
                .style("opacity", 0);
        })

        .on("mousemove", function(event) {
            const [mouseX] =
                d3.pointer(event, this);

            const hour =
                x.invert(mouseX);

            const index =
                bisect(
                    intensityData,
                    hour
                );

            const d =
                intensityData[index];

            if (!d) return;

            focus.select(".focus-line")
                .attr(
                    "transform",
                    `translate(${x(d.hour)},0)`
                );

            focus.select(".focus-ring")
                .attr("stroke", d.color)
                .attr("cx", x(d.hour))
                .attr("cy", y(d.val));

            focus.select(".focus-dot")
                .attr("fill", d.color)
                .attr("cx", x(d.hour))
                .attr("cy", y(d.val));

            const category =
                getCategory(
                    d.wind,
                    d.isT,
                    d.isE,
                    d.isS
                );

            const unit =
                mode === "kt"
                    ? "KT"
                    : "hPa";

            tooltip
                .html(`
                    <div style="
                        min-width:90px;
                        text-align:left;
                        padding:3px 2px;
                    ">
                        <div style="
                            color:#64748b;
                            font-size:10px;
                            font-weight:600;
                            letter-spacing:.06em;
                            margin-bottom:4px;
                        ">
                            T+${d.hour}H
                        </div>

                        <div style="
                            color:#f8fafc;
                            font-size:17px;
                            line-height:1.1;
                            font-weight:700;
                        ">
                            ${d.val}
                            <span style="
                                color:#94a3b8;
                                font-size:10px;
                                font-weight:600;
                            ">
                                ${unit}
                            </span>
                        </div>

                        <div style="
                            color:${category.color};
                            font-size:10px;
                            font-weight:700;
                            margin-top:5px;
                        ">
                            ${category.shortName}
                        </div>
                    </div>
                `)
                .style(
                    "left",
                    `${event.pageX + 14}px`
                )
                .style(
                    "top",
                    `${event.pageY - 34}px`
                );
        });
}

// Shared by live, single-history, and all-history views. Keep colors,
// marker cadence, and the .storm-track CSS contract in one place.
function drawTrackGeometry(trackLineLayer, trackPointLayer, mapProjection, cyclone, showPathPoints) {
    const pathGenerator = d3.geoPath().projection(mapProjection);
    // 8. 历史路径 (Track) - 增量更新模式
    if (cyclone && cyclone.track && cyclone.track.length > 1) {
        // 数据解包
        const unwrappedTrack = [];
        let lastLon = NaN;
        cyclone.track.forEach(pointData => {
            const point = [...pointData];
            let lon = point[0];
            if (!isNaN(lastLon)) {
                if (Math.abs(lon - lastLon) > 180) {
                    lon += (lon < lastLon) ? 360 : -360;
                }
            }
            point[0] = lon;
            lastLon = lon;
            unwrappedTrack.push(point);
        });

        const segmentData = [];
        for (let i = 0; i < unwrappedTrack.length - 1; i++) {
            segmentData.push({
                type: "LineString",
                coordinates: [unwrappedTrack[i].slice(0, 2), unwrappedTrack[i+1].slice(0, 2)],
                intensity: unwrappedTrack[i+1][2],
                isT: unwrappedTrack[i+1][3],
                isE: unwrappedTrack[i+1][4],
                isS: unwrappedTrack[i+1][6]
            });
        }

        // 绘制线段
        trackLineLayer.selectAll(".storm-track")
            .data(segmentData)
            .join(
                // Enter: 创建新元素时设置颜色
                enter => enter.append("path")
                    .attr("class", "storm-track")
                    .attr("d", pathGenerator)
                    .style("stroke", d => getCategory(d.intensity, d.isT, d.isE, d.isS).color),
                
                // Update: [核心修复] 更新现有元素时，必须同时更新形状 AND 颜色
                // 否则复用的 DOM 会保留上一次模拟的颜色
                update => update
                    .attr("d", pathGenerator)
                    .style("stroke", d => getCategory(d.intensity, d.isT, d.isE, d.isS).color)
            );

        // 绘制节点 (同理，更新 update 逻辑)
        if (showPathPoints) {
            const pointDisplayData = unwrappedTrack.filter((_, i) => i % 2 === 0);
            trackPointLayer.selectAll("circle")
                .data(pointDisplayData)
                .join(
                    enter => enter.append("circle")
                        .attr("r", 4.5)
                        .attr("stroke", "#222222")
                        .attr("stroke-width", 1)
                        .attr("cx", d => mapProjection(d.slice(0, 2))[0])
                        .attr("cy", d => mapProjection(d.slice(0, 2))[1])
                        .style("fill", d => getCategory(d[2], d[3], d[4], d[6]).color),
                    
                    // [核心修复] Update 时也要更新位置 AND 颜色
                    update => update
                        .attr("cx", d => mapProjection(d.slice(0, 2))[0])
                        .attr("cy", d => mapProjection(d.slice(0, 2))[1])
                        .style("fill", d => getCategory(d[2], d[3], d[4], d[6]).color)
                );
        } else {
            trackPointLayer.selectAll("*").remove();
        }
    } else {
        trackLineLayer.selectAll("*").remove();
        trackPointLayer.selectAll("*").remove();
    }

}

export function drawAllHistoryTracks(mapSvg, mapProjection, historyList, world, { showPathPoints = false } = {}) {
    const histories = (historyList || []).filter(item => item.cycloneData?.track?.length > 1);
    if (!histories.length) return;
    const referenceLon = histories[0].cycloneData.track[0][0];
    let minLon = Infinity, maxLon = -Infinity, minLat = Infinity, maxLat = -Infinity;
    for (const item of histories) {
        let previous = referenceLon;
        for (const p of item.cycloneData.track) {
            const lon = p[0] + Math.round((previous - p[0]) / 360) * 360;
            previous = lon;
            minLon = Math.min(minLon, lon); maxLon = Math.max(maxLon, lon);
            minLat = Math.min(minLat, p[1]); maxLat = Math.max(maxLat, p[1]);
        }
    }
    const { width, height } = mapSvg.node().getBoundingClientRect();
    mapProjection.rotate([-(minLon + maxLon) / 2, 0]).center([0, (minLat + maxLat) / 2]);
    // Fit the full point collection, not a diagonal whose great-circle arc
    // can take the short way around the globe and omit intermediate tracks.
    mapProjection.fitExtent([[50, 50], [width - 50, height - 50]], {
        type: 'MultiPoint',
        coordinates: histories.flatMap(item => item.cycloneData.track.map(p => p.slice(0, 2)))
    });
    mapSvg.selectAll('.track-interaction-layer').remove();
    drawMap(mapSvg, mapProjection, world, { status: 'history_all', track: [] }, {
        pathForecasts: [], pressureSystems: [],
        showPressureField: false, showHumidityField: false, showShearField: false,
        showPathForecast: false, showWindRadii: false, showWindField: false,
        siteName: null, siteLon: null, siteLat: null
    });
    const lines = mapSvg.select('.layer-track-lines');
    const points = mapSvg.select('.layer-track-points');
    lines.selectAll('*').remove();
    points.selectAll('*').remove();
    for (const item of histories) {
        const trackLines = lines.append('g').attr('class', 'history-track');
        const trackPoints = points.append('g').attr('class', 'history-track');
        drawTrackGeometry(trackLines, trackPoints, mapProjection, item.cycloneData, showPathPoints);
        // Native SVG titles preserve the intensity colors and avoid a second
        // hover style that disagrees with the single-history view.
        trackLines.selectAll('.storm-track').append('title')
            .text(d => `${item.name} · ${Math.round(d.intensity)} KT`);
    }
}

function drawInteractivePressureSystems(
    container, mapProjection, renderableSystems, allPressureSystems, cyclone,
    onRemove, onSystemChange, onSystemDrag
) {
    renderableSystems = renderableSystems.filter(c => c.role !== "height-background");
    
    const masterList = Array.isArray(allPressureSystems) ? allPressureSystems : (allPressureSystems.upper || []);
    const lowerList = Array.isArray(allPressureSystems) ? null : (allPressureSystems.lower || []);
    // 1. 获取当前视口的“视觉中心经度” (处理日界线)
    let viewCenterLon = mapProjection.center()[0];
    const rotation = mapProjection.rotate();
    if (Math.abs(rotation[0]) > 0.1) {
        viewCenterLon = -rotation[0];
    }

    // 2. 智能经度标准化函数
    const getVisualLon = (dataLon) => {
        let diff = dataLon - viewCenterLon;
        while (diff < -180) diff += 360;
        while (diff > 180) diff -= 360;
        return viewCenterLon + diff;
    };

    // 绑定数据
    const handles = container.selectAll(".pressure-handle")
        .data(renderableSystems);

    // Enter
    const enterHandles = handles.enter().append("g")
        .attr("class", "pressure-handle")
        .style("cursor", "grab");

    // 绘制光晕
    enterHandles.append("circle")
        .attr("class", "halo")
        .attr("r", 20)
        .attr("fill", "none")
        .attr("stroke", d => d.strength > 0 ? "#2980b9" : "#c0392b")
        .attr("stroke-width", 1)
        .attr("opacity", 0.3)
        .style("pointer-events", "none");

    // 绘制核心圆
    enterHandles.append("circle")
        .attr("class", "core")
        .attr("r", 12)
        .attr("stroke", "white")
        .attr("stroke-width", 1.5)
        .attr("fill-opacity", 0.8);

    // 绘制文字
    enterHandles.append("text")
        .attr("dy", "0.35em")
        .attr("text-anchor", "middle")
        .style("font-family", "Arial, sans-serif")
        .style("font-weight", "bold")
        .style("font-size", "11px")
        .style("fill", "white")
        .style("pointer-events", "none");

    // Merge
    const allHandles = enterHandles.merge(handles);

    // [新增] 双击 H 标记删除该系统 (如果是手动生成的)
    allHandles.on("dblclick", (event, d) => {
        event.stopPropagation(); // 阻止事件冒泡到地图
        event.preventDefault();
        
        if (d.isManual && onRemove) {
            // 调用 main.js 传进来的回调函数进行删除
            onRemove(d); 
        }
    });

    // Update 位置 (初始化渲染)
    allHandles
        .attr("transform", d => {
            const visualLon = getVisualLon(d.x);
            const coords = mapProjection([visualLon, d.y]);
            if (!coords || isNaN(coords[0]) || isNaN(coords[1])) {
                return "translate(-9999, -9999)";
            }
            return `translate(${coords[0]}, ${coords[1]})`;
        });

    // Update 样式
    allHandles.select(".core").attr("fill", d => d.strength > 0 ? "#2980b9" : "#c0392b");
    allHandles.select(".halo").attr("stroke", d => d.strength > 0 ? "#2980b9" : "#c0392b");
    allHandles.select("text").text(d => d.strength > 0 ? "H" : "L");

    // Drag Behavior
const dragBehavior = d3.drag()
        .subject(function(event, d) {
            const visualLon = getVisualLon(d.x);
            const [px, py] = mapProjection([visualLon, d.y]);
            return { x: px, y: py };
        })
        .on("start", function(event, d) {
            d3.select(this).style("cursor", "grabbing");
            d3.select(this).select(".core").attr("stroke", "#f1c40f").attr("stroke-width", 3);
        })
        .on("drag", function(event, d) {
            // 1. 视觉跟随
            d3.select(this).attr("transform", `translate(${event.x}, ${event.y})`);

            // 2. 数据更新
            const coords = mapProjection.invert([event.x, event.y]);
            if (coords) {
                // 计算位移量 (用于同步 Lower 层)
                const dx = coords[0] - d.x;
                const dy = coords[1] - d.y;

                // Keep manual ridge relocation as the centre of subsequent weather variability.
                if(d.synopticAnchor){
                    d.synopticAnchor.x += ((dx+180)%360+360)%360-180;
                    d.synopticAnchor.y += dy;
                }
                // A. 更新当前层 (Upper)
                d.x = coords[0];
                d.y = coords[1];

                if (d.role === 'wave-handle') {
                    const field=masterList.find(c => c.role === 'height-background');
                    const wave=field?.waves?.find(w => `${w.hemisphere}:${w.k}` === d.waveKey);
                    if(wave){wave.phase=Math.PI-wave.k*d.x*Math.PI/180;wave.latitude=Math.max(22,Math.min(65,Math.abs(d.y)));}
                    invalidatePressureSystemCaches(allPressureSystems);
                    onSystemDrag?.(allPressureSystems, d);
                    return;
                }
                // Pair layers by identity; layer arrays can differ after cold surges/deletion.
                if (lowerList) {
                    const linked = d.fieldId ? lowerList.find(c => c.fieldId === d.fieldId)
                        : d.isManual ? lowerList.find(c => c.isManual)
                        : !masterList.some(c => c.role === 'height-background') ? lowerList[masterList.indexOf(d)] : null;
                    if (linked) {
                        linked.x += ((dx + 180) % 360 + 360) % 360 - 180;
                        linked.y += dy;
                    }
                }
                onSystemDrag?.(allPressureSystems, d);
            }
        })
        .on("end", function(event, d) {
            d3.select(this).style("cursor", "grab");
            d3.select(this).select(".core").attr("stroke", "white").attr("stroke-width", 1.5);
            invalidatePressureSystemCaches(allPressureSystems);

            // The frame being displayed was computed from an immutable GPU
            // snapshot. Let the owner schedule a fresh full redraw so the
            // edited live systems become the next frame's inputs. This avoids
            // a synchronous CPU field rebuild (and forecast rebuild) inside
            // the pointer event handler.
            if (onSystemChange) {
                onSystemChange(allPressureSystems, d);
                return;
            }
            
            // 强制刷新
            const svg = d3.select(this.closest("svg"));
            
            // 1. 重绘 500 hPa 高度场 (传入完整的 obj)
            const pressureLayer = svg.select(".layer-pressure");
            if (!pressureLayer.empty()) {
                pressureLayer.selectAll("*").remove();
                    drawHeight500Field(pressureLayer, mapProjection, allPressureSystems, cyclone);
            }

            // 2. 重绘预测路径
            if (cyclone && cyclone.status === 'active') {
                const forecastLayer = svg.select(".layer-forecast");
                if (!forecastLayer.empty()) {
                    forecastLayer.selectAll("*").remove();
                    
                    const newForecasts = generatePathForecasts(cyclone, allPressureSystems, checkLandFast);
                    drawForecastCone(forecastLayer, mapProjection, newForecasts);
                    
                    const colors = d3.scaleOrdinal(d3.schemeCategory10);
                    const pathGenerator = d3.geoPath().projection(mapProjection);
                    
                    newForecasts.forEach((forecast, i) => {
                        const forecastGeoJSON = { type: "LineString", coordinates: forecast.track };
                        forecastLayer.append("path")
                            .datum(forecastGeoJSON)
                            .attr("class", "forecast-track")
                            .style("stroke", colors(i))
                            .attr("d", pathGenerator);
                    });
                }
            }
        });

    allHandles.call(dragBehavior);
    handles.exit().remove();
}

// ===================================================
// ICWC FORECAST PRODUCTS
// ===================================================

// Return the common external-tangent quadrilateral between two uncertainty
// circles. If one circle contains the other, no bridge is necessary because
// the raster union of the circles already covers the whole transition.
function getConeTangentPolygon(a, b) {
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const distance = Math.hypot(dx, dy);

    if (!Number.isFinite(distance) || distance <= Math.abs(a.r - b.r)) {
        return null;
    }

    const vx = dx / distance;
    const vy = dy / distance;
    const radiusRatio = (a.r - b.r) / distance;
    const tangentScale = Math.sqrt(Math.max(0, 1 - radiusRatio * radiusRatio));
    const n1 = {
        x: vx * radiusRatio - vy * tangentScale,
        y: vy * radiusRatio + vx * tangentScale
    };
    const n2 = {
        x: vx * radiusRatio + vy * tangentScale,
        y: vy * radiusRatio - vx * tangentScale
    };

    return [
        [a.x + n1.x * a.r, a.y + n1.y * a.r],
        [b.x + n1.x * b.r, b.y + n1.y * b.r],
        [b.x + n2.x * b.r, b.y + n2.y * b.r],
        [a.x + n2.x * a.r, a.y + n2.y * a.r]
    ];
}

/*
 * Build the cone as a true union of forecast-time circles and the tangent
 * bridges between them. A left/right ribbon polygon is topologically invalid
 * when the forecast doubles back: its two ordered sides cross even when every
 * individual radius is valid. Rasterising the primitives first and tracing
 * their outer contour makes loops and nearly coincident points harmless.
 */
function buildConeUnionContour(points, width, height) {
    if (!points || points.length < 2) return null;

    const mask = new Uint8Array(width * height);

    const markCircle = circle => {
        if (!circle || !Number.isFinite(circle.r) || circle.r <= 0.5) return;

        const minX = Math.max(0, Math.floor(circle.x - circle.r));
        const maxX = Math.min(width - 1, Math.ceil(circle.x + circle.r));
        const minY = Math.max(0, Math.floor(circle.y - circle.r));
        const maxY = Math.min(height - 1, Math.ceil(circle.y + circle.r));
        const radiusSquared = circle.r * circle.r;

        for (let y = minY; y <= maxY; y++) {
            const dySquared = (y + 0.5 - circle.y) ** 2;
            for (let x = minX; x <= maxX; x++) {
                const dx = x + 0.5 - circle.x;
                if (dx * dx + dySquared <= radiusSquared) {
                    mask[y * width + x] = 1;
                }
            }
        }
    };

    const markPolygon = polygon => {
        if (!polygon) return;

        const minX = Math.max(0, Math.floor(d3.min(polygon, p => p[0])));
        const maxX = Math.min(width - 1, Math.ceil(d3.max(polygon, p => p[0])));
        const minY = Math.max(0, Math.floor(d3.min(polygon, p => p[1])));
        const maxY = Math.min(height - 1, Math.ceil(d3.max(polygon, p => p[1])));

        for (let y = minY; y <= maxY; y++) {
            for (let x = minX; x <= maxX; x++) {
                if (d3.polygonContains(polygon, [x + 0.5, y + 0.5])) {
                    mask[y * width + x] = 1;
                }
            }
        }
    };

    points.forEach(markCircle);
    for (let i = 0; i < points.length - 1; i++) {
        markPolygon(getConeTangentPolygon(points[i], points[i + 1]));
    }

    return d3.contours()
        .size([width, height])
        .smooth(true)
        .thresholds([0.5])(mask)[0] || null;
}

export async function renderJTWCStyleAsync(cyclone, timeIndex, worldData, pressureSystems = { lower: [], upper: []}, options = {}) {
    const view = prepareWarningMapView(cyclone, timeIndex, options);
    const geography = await prepareICWCGeography(worldData, view.projection);
    return renderJTWCStyle(cyclone, timeIndex, worldData, pressureSystems, geography, options, view);
}

export function renderJTWCStyle(cyclone, timeIndex, worldData, pressureSystems = { lower: [], upper: []}, geography = null, options = {}, view = prepareWarningMapView(cyclone, timeIndex, options)) {
    const coneFill = 'rgba(255, 255, 255, 0.24)';
    const coneBorder = '#ffffff';
    const oceanFill = '#9bc2da'; // Lighter warning-map backdrop; probability palette stays unchanged.
    // 1. 设置高分辨率画布
    const width = 1600;
    const height = 1200;
    const footerHeight = 80;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height + footerHeight + 36;
    const ctx = canvas.getContext('2d');

    const { projection, centerLon, centerLat, currentPoint, pastTrack, currentAge,
        snapAge, forecastModels, rawSteps, meanTrack, maxSteps, quantizedLimit,
        mapCenterLon, mapCenterLat, windBands: warningWindBands } = view;
    const historicalName = cycloneNameAt(cyclone, timeIndex).toUpperCase();

    const pathGenerator = d3.geoPath().projection(projection).context(ctx);

    // --- 绘图开始 ---

    // A. 背景
    ctx.fillStyle = oceanFill;
    ctx.fillRect(0, 0, width, height);

    // B. 陆地（经纬网覆盖海陆，与概率产品一致）
    ctx.beginPath();
    ctx.fillStyle = ICWC_MAP_STYLE.land;
    ctx.strokeStyle = ICWC_MAP_STYLE.coast;
    ctx.lineWidth = 1.1;
    if (geography) { ctx.fill(geography.land); ctx.stroke(geography.land); }
    else { pathGenerator(worldData); ctx.fill(); ctx.stroke(); }

    // C. 经纬网
    ctx.beginPath();
    ctx.strokeStyle = ICWC_MAP_STYLE.grid;
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    const gridStep = ICWC_MAP_STYLE.gridStep;
    const graticule = d3.geoGraticule().step([gridStep, gridStep]);
    pathGenerator(graticule());
    ctx.stroke();
    ctx.setLineDash([]);

    // Latitude at the left edge, longitude along the bottom; keep clear of
    // the title and footer. Unwrap before iterating the dateline.
    ctx.save();
    ctx.fillStyle = '#080808';
    ctx.font = '22px Arial, sans-serif';
    ctx.textBaseline = 'middle';
    const pixelsPerDegree = projection.scale() * Math.PI / 180;
    const west = mapCenterLon - width / 2 / pixelsPerDegree;
    const east = mapCenterLon + width / 2 / pixelsPerDegree;
    const south = Math.max(-90, mapCenterLat - height / 2 / pixelsPerDegree);
    const north = Math.min(90, mapCenterLat + height / 2 / pixelsPerDegree);
    ctx.textAlign = 'left';
    for (let lat = Math.ceil(south / gridStep) * gridStep; lat < north; lat += gridStep) {
        const [, y] = projection([centerLon, lat]);
        if (y < 75 || y > height - 85) continue;
        ctx.fillText(`${Math.abs(lat)}°${lat < 0 ? 'S' : 'N'}`, 9, y + 4);
    }
    ctx.textAlign = 'center';
    for (let lon = Math.ceil(west / gridStep) * gridStep; lon < east; lon += gridStep) {
        const [x] = projection([lon, centerLat]);
        if (x < 65 || x > width - 65) continue;
        const wrapped = ((lon + 180) % 360 + 360) % 360 - 180;
        ctx.fillText(`${Math.abs(wrapped)}°${wrapped < 0 ? 'W' : 'E'}`, x, height - 55);
    }
    ctx.restore();

    const majorCities = ICWC_MAJOR_CITIES;

    ctx.save();
    ctx.fillStyle = "black";
    ctx.font = "bold 11px Arial"; // JTWC 风格通常字号较小且清晰
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";

    // 辅助函数：大圆距离 (Haversine) - 如果外部已有 calculateDistance 可直接替换
    const getDist = (lat1, lon1, lat2, lon2) => {
        const R = 6371; // km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    };

const pressureLayer = pressureSystems;

function getCityPressure(cityLon, cityLat) {
    // 1. 城市所在地的背景气压
    const backgroundPressure = getSurfacePressureAt(
        cityLon,
        cityLat,
        pressureLayer
    );

    // 2. 当前历史时刻的气旋参数
    const stormLon = currentPoint[0];
    const stormLat = currentPoint[1];
    const stormWind = currentPoint[2] || 0;
    const circulationSize =
        currentPoint[5] ||
        cyclone.circulationSize ||
        300;

    // 3. 气旋中心环境气压
    const centerEnvPressure = getSurfacePressureAt(
        stormLon,
        stormLat,
        pressureLayer
    );

    // 4. 优先读取历史轨迹中保存的中心气压
    const centerPressure =
        currentPoint[10] != null
            ? currentPoint[10]
            : windToPressure(
                stormWind,
                circulationSize,
                cyclone.basin || "WPAC",
                centerEnvPressure
            );

    // 5. 城市与气旋中心距离
    const distanceKm = getDist(
        stormLat,
        stormLon,
        cityLat,
        cityLon
    );

    // 6. 与主程序一致的压力半径
    const rmwKm =
        10 +
        circulationSize * 0.25;

    // 7. 叠加气旋气压扰动
    const cityPressure =
        centerPressure +
        (backgroundPressure - centerPressure) *
        Math.exp(
            -rmwKm / Math.max(1, distanceKm)
        );

    return cityPressure;
}
majorCities.forEach(city => {
    const pos = projection([city.lon, city.lat]);

    if (
        !pos ||
        pos[0] <= 10 ||
        pos[0] >= width - 10 ||
        pos[1] <= 10 ||
        pos[1] >= height - 10
    ) {
        return;
    }

    const pressure = Math.round(
        getCityPressure(
            city.lon,
            city.lat,
        )
    );

    // 城市标记
    ctx.fillStyle = "black";
    ctx.fillRect(
        pos[0] - 2,
        pos[1] - 2,
        4,
        4
    );

    const labelX =
        pos[0] > width - 120
            ? pos[0] - 6
            : pos[0] + 6;

    ctx.textAlign =
        pos[0] > width - 120
            ? "right"
            : "left";

    // 城市名
    ctx.font = "bold 12px Arial";
    ctx.fillStyle = "black";
    ctx.fillText(
        city.name,
        labelX,
        pos[1] - 6
    );

    // 气压值
    ctx.font = "11px 'JetBrains Mono', monospace";
    ctx.fillStyle = "#222222";
    ctx.fillText(
        `${pressure} hPa`,
        labelX,
        pos[1] + 7
    );
});
    ctx.restore();

    // D. 预测锥 (Forecast Cone)
    if (forecastModels.length > 0 && forecastModels[0].track.length > 1) {
        const coneDisks = rawSteps.map((step, index) => {
            const center = projection([step.lon, step.lat]);
            const radiusPoint = projection([step.lon, step.lat + step.r]);
            if (!center || !radiusPoint) return null;

            return {
                x: center[0],
                y: center[1],
                // The first forecast point remains the cone apex.
                r: index === 0
                    ? 0
                    : Math.hypot(radiusPoint[0] - center[0], radiusPoint[1] - center[1])
            };
        }).filter(Boolean);

        const coneContour = buildConeUnionContour(coneDisks, width, height);
        const conePath = d3.geoPath()
            .projection(d3.geoIdentity())
            .context(ctx);

        if (coneContour) {
            ctx.save();
            ctx.beginPath();
            conePath(coneContour);
            ctx.fillStyle = coneFill;
            ctx.fill();
            ctx.strokeStyle = coneBorder;
            ctx.lineWidth = 2;
            ctx.setLineDash([]);
            ctx.stroke();
            ctx.restore();
        }

        // --- 4. 绘制中心线 ---
        if (meanTrack.length > 0) {
            ctx.beginPath();
            ctx.strokeStyle = "#282888"; ctx.lineWidth = 2;
            const lineFeature = { type: "LineString", coordinates: meanTrack };
            pathGenerator(lineFeature);
            ctx.stroke(); ctx.setLineDash([]);
        }
        
        // --- 5. 预测点标签 (修改版) ---
        const targetHours = [12, 24, 36, 48, 60, 72]; 
        const forecastLabels = [];

        targetHours.forEach(h => {
            const idx = h / 3; 
            if (idx > quantizedLimit) return;

            // 1. 获取集合平均位置 (当前点)
            const points = [];
            forecastModels.forEach(m => { if(m.track[idx]) points.push(m.track[idx]); });
            if (points.length === 0) return;
            
            const p = [d3.mean(points, v=>v[0]), d3.mean(points, v=>v[1])];
            const pos = projection(p); // 屏幕坐标 [x, y]
            if (!pos) return;

            const avgIntensity = d3.mean(points, v => v[2]);
            const roundedIntensity = Math.round(avgIntensity / 5) * 5;

            // 2. 获取前后点以计算切线方向
            let nextP = null;
            let prevP = null;

            // 找 next
            const nextPoints = [];
            if (idx + 1 < maxSteps) {
                forecastModels.forEach(m => { if(m.track[idx+1]) nextPoints.push(m.track[idx+1]); });
                if (nextPoints.length > 0) {
                    const np = [d3.mean(nextPoints, v=>v[0]), d3.mean(nextPoints, v=>v[1])];
                    nextP = projection(np);
                }
            }
            // 找 prev
            const prevPoints = [];
            if (idx - 1 >= 0) {
                forecastModels.forEach(m => { if(m.track[idx-1]) prevPoints.push(m.track[idx-1]); });
                if (prevPoints.length > 0) {
                    const pp = [d3.mean(prevPoints, v=>v[0]), d3.mean(prevPoints, v=>v[1])];
                    prevP = projection(pp);
                }
            }

            // 3. 计算路径切线角度
            let tangentAngle = 0;
            if (nextP && prevP) {
                tangentAngle = Math.atan2(nextP[1] - prevP[1], nextP[0] - prevP[0]);
            } else if (nextP) {
                tangentAngle = Math.atan2(nextP[1] - pos[1], nextP[0] - pos[0]);
            } else if (prevP) {
                tangentAngle = Math.atan2(pos[1] - prevP[1], pos[0] - prevP[0]);
            }

            forecastLabels.push({h, pos, avgIntensity, roundedIntensity,
                normalAngle:tangentAngle + Math.PI / 2});
        });

        // Resolve all leaders before drawing: any crossing can reverse one
        // side by 180 degrees without repainting or moving a forecast fix.
        for (const {h, pos, avgIntensity, roundedIntensity, labelX, labelY} of layoutWarningLeaders(forecastLabels)) {

            // Draw the leader first, so it cannot cross the badge's letter.
            ctx.beginPath();
            ctx.strokeStyle = "black";
            ctx.lineWidth = 1;
            ctx.moveTo(pos[0], pos[1]);
            ctx.lineTo(labelX, labelY);
            ctx.stroke();

            drawWarningForecastPoint(ctx, pos, avgIntensity);

            // 7. 绘制文字 (智能对齐)
            ctx.fillStyle = "black";
            ctx.font = "bold 20px 'JetBrains Mono', monospace";
            ctx.textBaseline = "middle";

            // [新增] 现场计算并规整时间 (Round to nearest 6H)
            // Use this simulation's saved origin plus forecast-relative hours.
            const calcDate = simulationDate(cyclone, currentAge + h);
            
            // 3. 执行 6小时 四舍五入 (Round)
            let resultH = calcDate.getUTCHours();
            const rem = resultH % 6;
            if (rem > 3) {
                resultH += (6 - rem); // >=3小时则进位
            } else {
                resultH -= rem;       // <3小时则舍去
            }
            calcDate.setUTCHours(resultH, 0, 0, 0); // 应用规整后的时间

            // 4. 格式化字符串 (DD/HHZ)
            const dateStr = `${String(calcDate.getUTCDate()).padStart(2,'0')}/${String(calcDate.getUTCHours()).padStart(2,'0')}Z`;

            // 根据 labelX 相对于 pos[0] 的位置决定文字对齐方向
            if (labelX > pos[0]) {
                ctx.textAlign = "left";
                ctx.fillText(`  ${dateStr}, ${roundedIntensity}KT`, labelX, labelY);
            } else {
                ctx.textAlign = "right";
                ctx.fillText(`${dateStr}, ${roundedIntensity}KT  `, labelX, labelY);
            }
        }
    }

    // --- 辅助函数：日期格式化 ---
    function calculateDateStr(currentAge, forecastHour, cyclone) {
        const totalSimHours = currentAge + forecastHour;
        const dateObj = simulationDate(cyclone, totalSimHours);
        
        const dd = String(dateObj.getUTCDate()).padStart(2, '0');
        const hh = String(dateObj.getUTCHours()).padStart(2, '0');
        return `${dd}/${hh}Z`; 
    }

    // E. 历史路径
    if (pastTrack.length > 0) {
        ctx.beginPath();
        ctx.strokeStyle = "black";
        ctx.lineWidth = 3;
        ctx.lineJoin = "round";
        ctx.setLineDash([4, 2]);
        const trackFeature = {
            type: "LineString",
            coordinates: pastTrack.map(p => [p[0], p[1]])
        };
        pathGenerator(trackFeature);
        ctx.stroke();
    }

    // F. 历史点 (Optimized Icons)
    // 预设置字体：必须匹配 CSS 中引入的版本 (Font Awesome 6 Free Solid)
    ctx.font = '900 16px "Font Awesome 6 Free"';
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const hurricaneIcon = '\uf751'; // fa-hurricane 的 Unicode 编码

    pastTrack.forEach((p, i) => {
        // 保持每 6 小时一个点的稀疏度 (假设每步3小时)
        if (i % 2 !== 0) return;
        
        const pos = projection(p);
        if (!pos) return;

        const intensity = p[2]; // 获取强度

        if (intensity >= 64) {
            // [>= 64 KT] 实心台风图标 (TY)
            // 1. 先画一个白色背景圆，遮挡住底下的路径线，防止线条穿过图标
            ctx.beginPath();
            ctx.fillStyle = "white"; 
            ctx.arc(pos[0], pos[1], 5, 0, Math.PI * 2);
            ctx.fill();

            // 2. 绘制实心图标
            ctx.fillStyle = "black";
            ctx.fillText(hurricaneIcon, pos[0], pos[1]);

        } else if (intensity >= 34) {
            ctx.setLineDash([]);
            ctx.beginPath();
            ctx.fillStyle = "white";
            ctx.strokeStyle = "black";
            ctx.lineWidth = 1.5;
            ctx.arc(pos[0], pos[1], 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

        } else {
            // [< 34 KT] 原样：空心圆点 (TD)
            ctx.beginPath();
            ctx.strokeStyle = "black";
            ctx.lineWidth = 1.5;
            ctx.arc(pos[0], pos[1], 5, 0, Math.PI * 2);
            ctx.stroke();
        }
    });

    // G. 当前位置 & 风圈
    const intensity = currentPoint[2]; 
    const windRadiiConfig = WARNING_WIND_RADII;

    // 辅助函数：构建非对称风圈路径
    const createAsymmetricCircle = (center, radii) => {
        radii = Array.from({length:4}, (_,q) => Number.isFinite(radii[q]) ? Math.max(0,radii[q]) : 0);
        if (radii.every(r => r <= 0)) return;
        
        const c = projection(center); // 中心点屏幕坐标 [x, y]
        if (!c) return;
        const cx = c[0];
        const cy = c[1];

        const path = new Path2D();

        // 辅助函数：计算该纬度下的像素半径 (X轴和Y轴分开计算)
        // degRadius: 物理半径(度)
        const getEllipseRadii = (degRadius) => {
            if (degRadius <= 0) return { rx: 0, ry: 0 };
            
            // Y轴 (纬度) 像素半径：直接计算向北的投影距离
            const pNorth = projection([center[0], center[1] + degRadius]);
            const ry = Math.abs(pNorth[1] - cy);

            // X轴 (经度) 像素半径：计算向东的投影距离
            // 注意：在高纬度，同样经度差的物理距离变短，投影会将其拉伸以保持矩形网格
            const lonRadius = degRadius / Math.max(0.1, Math.cos(center[1] * Math.PI / 180));
            const pEast = projection([center[0] + lonRadius, center[1]]);
            const rx = Math.abs(pEast[0] - cx);

            return { rx, ry };
        };

        // 四个象限的半径数据 (NE, SE, SW, NW)
        const rads = [
            getEllipseRadii(radii[0]), // NE
            getEllipseRadii(radii[1]), // SE
            getEllipseRadii(radii[2]), // SW
            getEllipseRadii(radii[3])  // NW
        ];

        // 绘制四段椭圆弧
        // Canvas ellipse 参数: (x, y, radiusX, radiusY, rotation, startAngle, endAngle)
        
        // 1. NE Quadrant (上 -> 右)
        // 使用 NE 的 rx 和 ry
        if (rads[0].rx > 0) {
            path.ellipse(cx, cy, rads[0].rx, rads[0].ry, 0, -Math.PI/2, 0);
        } else {
            path.moveTo(cx, cy);
        }

        // 2. SE Quadrant (右 -> 下)
        if (rads[1].rx > 0) {
            // 需要连线到起点吗？ellipse 会自动连线，但为了保险
            path.ellipse(cx, cy, rads[1].rx, rads[1].ry, 0, 0, Math.PI/2);
        } else {
            path.lineTo(cx, cy);
        }

        // 3. SW Quadrant (下 -> 左)
        if (rads[2].rx > 0) {
            path.ellipse(cx, cy, rads[2].rx, rads[2].ry, 0, Math.PI/2, Math.PI);
        } else {
            path.lineTo(cx, cy);
        }

        // 4. NW Quadrant (左 -> 上)
        if (rads[3].rx > 0) {
            path.ellipse(cx, cy, rads[3].rx, rads[3].ry, 0, Math.PI, -Math.PI/2);
        } else {
            path.lineTo(cx, cy);
        }

        path.closePath(); // 闭合路径

        return path;
    };
    // Only threshold outlines; preserve the chart underneath each radius.
    const windBands = warningWindBands.map(band => ({...band,
        path:createAsymmetricCircle([currentPoint[0], currentPoint[1]], band.radii)}));
    drawWindRadiiOutlines(ctx, windBands);

    // G. 当前位置
    const currPos = projection(currentPoint);
    if (currPos) {
        ctx.beginPath();
        ctx.fillStyle = "#ff0000"; 
        ctx.strokeStyle = "black";
        ctx.lineWidth = 2;
        ctx.arc(currPos[0], currPos[1], 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        ctx.fillStyle = "black";
        ctx.font = "bold 20px Arial"; // 保持原字体，或者换成 'JetBrains Mono' 也可以
        ctx.textAlign = "left";
        
        // [新增] 获取强度并取整到最近的 5KT
        // currentPoint 结构通常是 [lon, lat, intensity, ...]
        const rawIntensity = currentPoint[2]; 
        const roundedIntensity = Math.round(rawIntensity / 5) * 5;
        
        // 显示名字 + 强度
        const currentLabel = `${historicalName || 'TD'}, ${roundedIntensity}KT`;
        if (currPos[0] > width * 0.72) {
            ctx.textAlign = "right";
            ctx.fillText(
                currentLabel,
                currPos[0] - 20,
                currPos[1] + 10
            );
        } else {
            ctx.textAlign = "left";
            ctx.fillText(
                currentLabel,
                currPos[0] + 20,
                currPos[1] + 10
            );
        }
    }

    // H. 装饰
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, width, 50);
    ctx.fillStyle = "white";
    ctx.font = "bold 20px Arial";
    ctx.textAlign = "left";
    const reportNum = timeIndex + 1;
    ctx.fillText(`PROGNOSTIC REASONING: ${historicalName || 'TD'} #${reportNum}`, 20, 32);
    ctx.textAlign = "right";
    ctx.fillText("INDEPENDENT CYCLONE WARNING CENTER", width - 20, 32);

    // I. 绘制图例 (Legend)
    // ============================================================
    const legendW = 260;
    const legendH = 210;
    const legendX = width - legendW - 20; // 右对齐，留出20px边距
    const legendY = 60; // 标题栏下方

    ctx.save();
    
    // 1. 图例背景框 (白底黑边)
    ctx.fillStyle = "white";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 1;
    ctx.fillRect(legendX, legendY, legendW, legendH);
    ctx.strokeRect(legendX, legendY, legendW, legendH);

    // 2. 图例内容配置
    const lineHeight = 25;
    const startX = legendX + 20;
    const startY = legendY + 25;
    const iconX = startX + 10; // 图标中心X
    
    ctx.font = "bold 12px Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "black";

    // --- Item 1: LESS THAN 34 KT (空心圆) ---
    let currentY = startY;
    ctx.setLineDash([4,2]);
    ctx.beginPath();
    ctx.strokeStyle = "black";
    ctx.lineWidth = 1.5;
    ctx.arc(iconX, currentY, 5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillText("LESS THAN 34 KT", startX + 30, currentY);

    // --- Item 2: 34-63 KT (白底黑圈) ---
    currentY += lineHeight;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 1.5;
    ctx.arc(iconX, currentY, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "black"; // 恢复文字颜色
    ctx.fillText("34-63 KT", startX + 30, currentY);

    // --- Item 3: MORE THAN 63 KT (台风图标) ---
    currentY += lineHeight;
    // 先画白底遮挡
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.arc(iconX, currentY, 5, 0, Math.PI * 2);
    ctx.fill();
    // 画图标
    ctx.fillStyle = "black";
    ctx.font = '900 12px "Font Awesome 6 Free"'; // 确保字体一致
    ctx.textAlign = "center";
    const faHurricane = '\uf751';
    ctx.fillText(faHurricane, iconX, currentY);
    // 恢复文字设置
    ctx.font = "bold 12px Arial";
    ctx.textAlign = "left";
    ctx.fillText("MORE THAN 63 KT", startX + 30, currentY);

    // --- Item 4: PAST CYCLONE TRACK (实线) ---
    currentY += lineHeight;
    ctx.beginPath();
    ctx.strokeStyle = "black";
    ctx.lineWidth = 3;
    ctx.moveTo(startX - 5, currentY);
    ctx.lineTo(startX + 25, currentY);
    ctx.stroke();
    ctx.fillStyle = "black";
    ctx.fillText("PAST CYCLONE TRACK", startX + 30, currentY);

    // --- Item 5: FORECAST CYCLONE TRACK (虚线) ---
    currentY += lineHeight;
    ctx.beginPath();
    ctx.strokeStyle = "black";
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 4]);
    ctx.moveTo(startX - 5, currentY);
    ctx.lineTo(startX + 25, currentY);
    ctx.stroke();
    ctx.setLineDash([]); // 重置
    ctx.fillStyle = "black";
    ctx.fillText("FORECAST CYCLONE TRACK", startX + 30, currentY);

    // --- Item 6: UNCERTAINTY CONE AREA (plain translucent fill) ---
    currentY += lineHeight;
    // 画矩形示例
    ctx.save();
    ctx.strokeStyle = coneBorder;
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    const rectX = startX - 5;
    const rectY = currentY - 6;
    // Show the white edge against the same ocean backdrop as the map.
    ctx.fillStyle = oceanFill;
    ctx.fillRect(rectX, rectY, 30, 12);
    ctx.fillStyle = coneFill;
    ctx.fillRect(rectX, rectY, 30, 12);
    ctx.strokeRect(rectX, rectY, 30, 12);
    ctx.restore();

    ctx.fillStyle = "black";
    ctx.fillText("UNCERTAINTY CONE AREA", startX + 30, currentY);

    ctx.restore();

    //Item 7: Wind Radii Legend ---
    currentY += lineHeight + 8; // 多留一点空隙给双行文字
    
    // 绘制同心圆图标
    drawWindRadiiOutlines(ctx, windRadiiConfig.map((cfg,index)=>{
        const path=new Path2D();
        path.arc(iconX,currentY,[14,9,5][index],0,Math.PI*2);
        return {...cfg,width:1.5,path};
    }));

    // 绘制双行文字
    ctx.fillStyle = "black";
    ctx.font = "bold 12px Arial"; // 稍微缩小字体以适应两行
    ctx.textAlign = "left";
    ctx.fillText("34/50/64 KNOT WIND RADII", startX + 30, currentY - 6);
    ctx.fillText("(VALID OVER OPEN OCEAN ONLY)", startX + 30, currentY + 6);

    ctx.restore();

    // Preserve the existing city-metric path (the complete first model),
    // independent of the displayed cone's dissipation cutoff and camera.
    let forecastPath = [];
    if (forecastModels.length > 0) {
        forecastPath = forecastModels[0].track;
    }

    // 3. 计算指标
    const cityMetrics = majorCities.map(city => {
        // A. 当前距离
        const currentDist = getDist(currentPoint[1], currentPoint[0], city.lat, city.lon);
        
        // B. CPA 插值计算 (点到线段的最短距离)
        let minCpa = currentDist; // 初始值为当前距离
        
        if (forecastPath.length > 1) {
            for (let i = 0; i < forecastPath.length - 1; i++) {
                const p1 = forecastPath[i];   // [lon, lat]
                const p2 = forecastPath[i+1]; // [lon, lat]
                
                // 将经纬度投影到局部平面进行几何计算 (纬度校正)
                const latMid = (p1[1] + p2[1]) / 2 * (Math.PI / 180);
                const cosLat = Math.cos(latMid);
                
                // 向量 P1->P2
                const dx = (p2[0] - p1[0]) * cosLat;
                const dy = p2[1] - p1[1];
                // 向量 P1->City
                const cx = (city.lon - p1[0]) * cosLat;
                const cy = city.lat - p1[1];
                
                // 投影因子 t
                const lenSq = dx*dx + dy*dy;
                let t = (lenSq > 0) ? (cx*dx + cy*dy) / lenSq : 0;
                t = Math.max(0, Math.min(1, t)); // 限制在线段内
                
                // 找到最近点坐标
                const closestLon = p1[0] + t * (p2[0] - p1[0]);
                const closestLat = p1[1] + t * (p2[1] - p1[1]);
                
                // 计算实际距离
                const segDist = getDist(city.lat, city.lon, closestLat, closestLon);
                if (segDist < minCpa) minCpa = segDist;
            }
        }
        
        return { name: city.name, curr: currentDist, cpa: minCpa };
    });

    // 4. 排序并筛选 (按当前距离最近的 Top 3)
    cityMetrics.sort((a, b) => a.curr - b.curr);
    const topCities = cityMetrics.slice(0, 3);

    // 5. 绘制列表框
    // 位置：图例下方，X轴与图例对齐
    // legendX, legendY, legendH 是前面定义的变量
    const listX = legendX; 
    const listY = legendY + legendH + 10; // 紧贴图例下方
    const listW = legendW;
    const listH = 65; // 高度

    ctx.save();
    
    // 背景
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 1;
    ctx.setLineDash([]); // 确保是实线
    ctx.fillRect(listX, listY, listW, listH);
    ctx.strokeRect(listX, listY, listW, listH);

    // 标题
    ctx.fillStyle = "black";
    ctx.font = "bold 10px Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillText("CLOSEST CITIES / CPA (INTERPOLATED)", listX + 5, listY + 5);

    // 列表内容 (使用等宽字体对齐)
    ctx.font = "10px 'JetBrains Mono', 'Courier New', monospace";
    
    topCities.forEach((c, i) => {
        const y = listY + 20 + i * 14;
        
        // 格式化数据: "NAHA       866KM CPA 339KM"
        const nameStr = c.name.padEnd(11, " "); // 城市名占11格
        const currStr = `${Math.round(c.curr)}KM    `.padStart(5, " "); // 距离占5格右对齐
        const cpaStr = `CPA ${Math.round(c.cpa)}KM`.padStart(4, " "); // CPA占9格右对齐
        
        ctx.fillText(`${nameStr} ${currStr} ${cpaStr}`, listX + 5, y);
    });

    ctx.restore();

    // Keep the original map extent; append a compact, white information strip.
    drawWarningFooter(ctx, warningFooterInfo(cyclone, timeIndex), width, height, footerHeight);
    drawICWCDisclaimer(ctx, width, height + footerHeight);

    return canvas;
}

export { renderProbabilitiesStyle } from './wind-probability-chart.js?v=20261008-forecast-categories1';

// --- [新增] 站点历史数据绘图函数 (折线 + 风羽 + 交互) ---
export function drawStationGraph(containerId, historyData, type = 'wind') {
    const container = d3.select(containerId);
    container.selectAll("*").remove(); // 清空旧图表

    if (!historyData || historyData.length === 0) return;

    // 1. 设置尺寸与边距
    const rect = container.node().getBoundingClientRect();
    const margin = { top: 40, right: 30, bottom: 30, left: 40 }; 
    // Hidden/collapsed panels can briefly report only a few pixels of width.
    // Do not pass a negative plot area to SVG rects and D3 scales.
    if (rect.width <= margin.left + margin.right || rect.height <= margin.top + margin.bottom) return;
    const width = rect.width - margin.left - margin.right;
    const height = rect.height - margin.top - margin.bottom;

    const svg = container.append("svg")
        .attr("width", "100%")
        .attr("height", "100%")
        .attr("viewBox", `0 0 ${rect.width} ${rect.height}`)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // 2. X轴 (时间)
    const x = d3.scaleLinear()
        .domain(d3.extent(historyData, d => d.hour))
        .range([0, width]);

    svg.append("g")
        .attr("transform", `translate(0,${height})`)
        .attr("color", "#94a3b8") 
        .call(d3.axisBottom(x).ticks(5).tickFormat(d => `+${d}h`));

    // 3. Y轴与折线 (根据类型)
    let y, color, unit;
    if (type === 'wind') {
        const maxWind = d3.max(historyData, d => d.wind) || 10;
        y = d3.scaleLinear()
            .domain([0, Math.max(30, maxWind * 1.1)])
            .range([height, 0]);
        color = "#22d3ee"; // Cyan
        unit = "KT";
    } else {
        const minP = d3.min(historyData, d => d.pressure);
        const maxP = d3.max(historyData, d => d.pressure);
        // 稍微放宽一点上下限，让图表不至于贴边
        y = d3.scaleLinear()
            .domain([minP - 2, maxP + 2])
            .range([height, 0]);
        color = "#facc15"; // Yellow
        unit = "hPa";
    }

    svg.append("g")
        .attr("color", "#94a3b8")
        .call(d3.axisLeft(y).ticks(5));

    // 4. 绘制折线 (硬朗风格)
    const line = d3.line()
        .x(d => x(d.hour))
        .y(d => y(type === 'wind' ? d.wind : d.pressure))
        .curve(d3.curveLinear); // [修改] 使用线性插值 (取消平滑)

    // 绘制线条背景阴影 (可选，增加一点层次感)
    svg.append("path")
        .datum(historyData)
        .attr("fill", "none")
        .attr("stroke", color)
        .attr("stroke-width", 4)
        .attr("stroke-opacity", 0.1)
        .attr("d", line);

    // 绘制主线条
    svg.append("path")
        .datum(historyData)
        .attr("fill", "none")
        .attr("stroke", color)
        .attr("stroke-width", 2)
        .attr("d", line);

    // 5. 绘制风羽 (仅 Wind 模式)
    if (type === 'wind') {
        const step = Math.max(1, Math.floor(historyData.length / (width / 40)));
        const barbData = historyData.filter((d, i) => i % step === 0);
        const barbGroup = svg.append("g").attr("class", "wind-barbs");

        barbData.forEach(d => {
            const angleRad = Math.atan2(-d.v, d.u);
            const angleDeg = angleRad * (180 / Math.PI); 
            const bx = x(d.hour);
            const by = -15;
            const speed = d.wind;
            const scale = 0.8; 

            const g = barbGroup.append("g")
                .attr("transform", `translate(${bx}, ${by}) rotate(${angleDeg}) scale(${scale})`);

            g.append("line")
                .attr("x1", 0).attr("y1", 0).attr("x2", -20).attr("y2", 0)
                .attr("stroke", "#64748b").attr("stroke-width", 1.5);

            let rem = Math.round(speed / 5) * 5; 
            let pos = -20; 

            while (rem >= 50) {
                g.append("path").attr("d", `M${pos},0 L${pos+5},-10 L${pos+10},0`).attr("fill", "#64748b");
                pos += 12; rem -= 50;
            }
            while (rem >= 10) {
                g.append("line").attr("x1", pos).attr("y1", 0).attr("x2", pos + 3).attr("y2", -8).attr("stroke", "#64748b").attr("stroke-width", 1.5);
                pos += 5; rem -= 10;
            }
            if (rem >= 5) {
                g.append("line").attr("x1", pos).attr("y1", 0).attr("x2", pos + 1.5).attr("y2", -4).attr("stroke", "#64748b").attr("stroke-width", 1.5);
            }
        });
    }

    // --- [新增] 交互层 (Interaction) ---
    
    // 创建交互用的 Focus Group
    const focus = svg.append("g")
        .attr("class", "focus")
        .style("display", "none");

    // 垂直辅助线
    focus.append("line")
        .attr("class", "hover-line")
        .attr("y1", 0)
        .attr("y2", height)
        .style("stroke", "#94a3b8")
        .style("stroke-width", 1)
        .style("stroke-dasharray", "3,3")
        .style("opacity", 0.7);

    // 数据点圆圈
    focus.append("circle")
        .attr("r", 4)
        .style("fill", "#1e293b") // Slate-800 背景
        .style("stroke", color)
        .style("stroke-width", 2);

    // 文本标签背景
    focus.append("rect")
        .attr("class", "tooltip-bg")
        .attr("width", 70)
        .attr("height", 20)
        .attr("rx", 3)
        .attr("ry", 3)
        .style("fill", "rgba(0,0,0,0.7)")
        .style("pointer-events", "none"); // 防止遮挡鼠标

    // 文本标签
    const focusText = focus.append("text")
        .attr("x", 0)
        .attr("y", -10)
        .style("fill", "white")
        .style("font-size", "10px")
        .style("font-family", "Monospace")
        .style("font-weight", "bold")
        .style("text-anchor", "middle");

    // 透明矩形用于捕获鼠标事件
    svg.append("rect")
        .attr("class", "overlay")
        .attr("width", width)
        .attr("height", height)
        .style("fill", "none")
        .style("pointer-events", "all")
        .on("mouseover", () => focus.style("display", null))
        .on("mouseout", () => focus.style("display", "none"))
        .on("mousemove", mousemove);

    // 二分查找器
    const bisect = d3.bisector(d => d.hour).left;

    function mousemove(event) {
        // 1. 获取鼠标对应的 X 轴数值 (时间)
        const x0 = x.invert(d3.pointer(event)[0]);
        
        // 2. 在数组中查找最近的数据点
        const i = bisect(historyData, x0, 1);
        const d0 = historyData[i - 1];
        const d1 = historyData[i];
        
        // 边界处理
        let d = d0;
        if (d1 && d0) {
            d = x0 - d0.hour > d1.hour - x0 ? d1 : d0;
        } else if (d1) {
            d = d1;
        }

        if (!d) return;

        // 3. 移动 Focus 元素
        const posX = x(d.hour);
        const val = type === 'wind' ? d.wind : d.pressure;
        const posY = y(val);

        focus.attr("transform", `translate(${posX},${posY})`);
        
        // 更新垂直线位置 (因为 transform 移动了整个 group，垂直线需要反向修正 Y)
        focus.select(".hover-line")
            .attr("y1", -posY) // 延伸到顶部
            .attr("y2", height - posY); // 延伸到底部

        // 更新文本
        focusText.text(`T+${d.hour}h: ${Math.round(val)}${unit}`);
        
        // 动态调整 Tooltip 位置，防止超出右边界
        const textWidth = 80;
        if (posX + textWidth/2 > width) {
            focus.select("rect").attr("x", -textWidth);
            focusText.attr("x", -textWidth/2);
        } else {
            focus.select("rect").attr("x", 5);
            focusText.attr("x", 40); // 居中
        }
        // 垂直位置微调
        focus.select("rect").attr("y", -25);
        focusText.attr("y", -11);
    }
}

function addNoise(val, magnitude, seed) {
    return val + (Math.sin(seed * 12.9898) * magnitude);
}

// [核心] 渲染气旋相空间图 (Cyclone Phase Space - CPS)
export function renderPhaseSpace(cyclone, globalTemp = 289, timeIndex = null) { // <--- 支持按6小时产品翻页
    const width = 800;
    const height = 600;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // --- 1. 背景 ---
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);

    const chartX = 60;
    const chartY = 40;
    const chartW = width - chartX - 180;
    const chartH = height - chartY - 50;

    // --- 2. 物理参数反演 ---
    const safeIndex = Number.isInteger(timeIndex)
        ? Math.max(0, Math.min(timeIndex, cyclone.track.length - 1))
        : null;
    const track = safeIndex === null
        ? cyclone.track
        : cyclone.track.slice(0, safeIndex + 1);
    const dataPoints = [];
    const rawPoints = [];
    const month = cyclone.currentMonth || 8;
    const phaseEntries = track
        .map((p, index) => ({ p, index, phase: p?.[11]?.phase }))
        .filter(entry => entry.phase
            && entry.phase.source === 'resolved-height-proxy'
            && Number.isFinite(entry.phase.b)
            && Number.isFinite(entry.phase.vtLower));
    const useResolvedDiagnostics = phaseEntries.length > 0;
    const entries = useResolvedDiagnostics
        ? phaseEntries
        : track.map((p, index) => ({ p, index, phase: null }));
    // Keep the resolved diagnostic values untouched.  Phase-space products
    // present -V_T on a ×10 scale; applying that conversion here keeps this
    // a presentation-only change and does not affect forecast dynamics.
    const phaseVtDisplayScale = 10;

    entries.forEach(({ p, index, phase }) => {
        const lat = p[1];
        const lon = p[0];
        const intensity = p[2];
        const isExtra = Boolean(p[4]);
        const isSub = Boolean(p[6]);
        const ageHours = index * 3;

        if (phase) {
            const vtLower = phase.vtLower * phaseVtDisplayScale;
            const vtUpper = Number.isFinite(phase.vtUpper)
                ? phase.vtUpper * phaseVtDisplayScale
                : vtLower;
            rawPoints.push({
                x: phase.b,
                y: vtLower,
                vtUpper,
                isExtra,
                isSub,
                isTransitioning: Boolean(p[3]),
                intensity,
                hour: ageHours,
                source: phase.source,
                phaseSampleCount: phase.sampleCount
            });
            return;
        }

        // Legacy records do not carry a resolved pressure snapshot. Keep a
        // deterministic estimate so opening the product cannot change its
        // values, while labelling the result as an archived fallback below.
        const sst = getSST(lat, lon, month, globalTemp);
        let B = 35.0 - sst;
        if (!isExtra) {
            const isNH = lat >= 0;
            let seasonPhase = Math.cos((month - 1) / 12 * 2 * Math.PI);
            if (!isNH) seasonPhase *= -1;
            const jetStrength = 1.0 + seasonPhase * 0.3;
            const effectiveLat = Math.max(0, Math.abs(lat) - 15);
            let latForcing = (Math.pow(effectiveLat, 1.8) / 26.0) * jetStrength;
            const ageFactor = ageHours < 48 ? Math.pow(ageHours / 48, 1.5) : 1;
            latForcing *= ageFactor;
            B += latForcing;
            if (isSub) B = Math.max(B, 17.5 + addNoise(0, 2.5, index + 11));
        } else {
            const frontSeasonality = 1.0
                + Math.cos((month - 1) / 12 * 2 * Math.PI)
                * (lat >= 0 ? 1 : -1) * 0.2;
            B = 20 + 30 * Math.tanh((Math.abs(lat) - 20) / 15) * frontSeasonality;
        }
        B = Math.max(0, Math.min(60, addNoise(B, 1.5, index)));

        let Vt;
        if (!isExtra) {
            let sstFactor = Math.max(0.3, Math.min(1.1, (sst - 18) / 16));
            if (isSub) sstFactor *= 0.8;
            Vt = (intensity * 1.4) - (28 - sst) * 10.0;
            Vt *= sstFactor;
        } else {
            const coldAdvection = (Math.abs(lat)
                - 20 * 0.6 * (1 + Math.sin((month - 2) / 12 * 2 * Math.PI))) * 4.0;
            Vt = intensity - coldAdvection - Math.max(0, (26 - sst) * 2.0);
            Vt = Math.max(-150, Vt);
        }
        Vt = addNoise(Vt, 3.0, index * 2);
        rawPoints.push({
            x: B,
            y: Vt,
            vtUpper: Vt,
            isExtra,
            isSub,
            isTransitioning: Boolean(p[3]),
            intensity,
            hour: ageHours,
            source: 'estimated-legacy'
        });
    });

    if (useResolvedDiagnostics) {
        dataPoints.push(...rawPoints);
    } else {
        // Preserve the old smoothing only for legacy records. Resolved phase
        // points are already ring-averaged and should not be blurred again.
        for (let i = 0; i < rawPoints.length; i++) {
            let sumX = 0, sumY = 0, count = 0;
            for (let j = -1; j <= 1; j++) {
                if (rawPoints[i + j]) {
                    sumX += rawPoints[i + j].x;
                    sumY += rawPoints[i + j].y;
                    count++;
                }
            }
            dataPoints.push({ ...rawPoints[i], x: sumX / count, y: sumY / count });
        }
    }

    const currentData = dataPoints[dataPoints.length - 1] || {
        x: 0, y: 0, vtUpper: 0, source: 'estimated-legacy',
        isExtra: false, isSub: false, isTransitioning: false, intensity: 0, hour: 0
    };
    // --- 3. 绘图 (坐标系 & 网格) ---
    const minB = -10, maxB = 60;
    const minVt = -150, maxVt = 250; 

    const scaleX = val => chartX + ((val - minB) / (maxB - minB)) * chartW;
    const scaleY = val => chartY + chartH - ((val - minVt) / (maxVt - minVt)) * chartH;

    // 背景色块
    ctx.fillStyle = "#fff1f2"; // Deep Warm
    ctx.fillRect(scaleX(minB), scaleY(maxVt), scaleX(10) - scaleX(minB), scaleY(0) - scaleY(maxVt));
    ctx.fillStyle = "#fffbeb"; // Shallow/Hybrid
    ctx.fillRect(scaleX(10), scaleY(maxVt), scaleX(maxB) - scaleX(10), scaleY(0) - scaleY(maxVt));
    ctx.fillStyle = "#f0f9ff"; // Cold
    ctx.fillRect(scaleX(minB), scaleY(0), scaleX(maxB) - scaleX(minB), scaleY(minVt) - scaleY(0));

    // 网格线
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#e2e8f0";
    ctx.font = "10px Arial";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";

    for (let v = -150; v <= 250; v += 50) {
        let y = scaleY(v);
        ctx.beginPath(); ctx.moveTo(chartX, y); ctx.lineTo(chartX + chartW, y); ctx.stroke();
        ctx.fillStyle = "#64748b"; ctx.fillText(v, chartX - 5, y);
    }

    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    for (let b = 0; b <= 60; b += 10) {
        let x = scaleX(b);
        ctx.beginPath(); ctx.moveTo(x, chartY); ctx.lineTo(x, chartY + chartH); ctx.stroke();
        ctx.fillStyle = "#64748b"; ctx.fillText(b, x, chartY + chartH + 5);
    }

    // 主轴
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(scaleX(10), chartY); ctx.lineTo(scaleX(10), chartY + chartH); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(chartX, scaleY(0)); ctx.lineTo(chartX + chartW, scaleY(0)); ctx.stroke();

    // 标签
    ctx.font = "bold 12px Arial";
    ctx.textAlign = "left";
    ctx.fillStyle = "#be123c"; ctx.fillText("DEEP WARM CORE", chartX + 10, chartY + 15);
    ctx.textAlign = "right";
    ctx.fillStyle = "#b45309"; ctx.fillText("SHALLOW WARM / HYBRID", chartX + chartW - 10, chartY + 15);
    ctx.fillStyle = "#0369a1"; ctx.fillText("COLD CORE (EXTRATROPICAL)", chartX + chartW - 10, chartY + chartH - 15);

    ctx.save();
    ctx.translate(15, chartY + chartH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillStyle = "#000";
    ctx.fillText("Parameter -V_T ×10 : 850–500 hPa proxy", 0, 0);
    ctx.restore();
    ctx.textAlign = "center";
    ctx.fillText("Parameter B : 850–500 hPa thermal asymmetry proxy", chartX + chartW / 2, height - 10);

    // --- 4. 绘制轨迹 ---
    // Keep both CPS legs inside the plotting rectangle. Upper-level tropical
    // values can legitimately exceed the displayed ×10 range; they should be
    // clipped at the frame edge rather than leaking into the title area.
    ctx.save();
    ctx.beginPath();
    ctx.rect(chartX, chartY, chartW, chartH);
    ctx.clip();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = 3;

    for (let i = 0; i < dataPoints.length - 1; i++) {
        const p1 = dataPoints[i];
        const p2 = dataPoints[i+1];
        
        ctx.beginPath();
        ctx.moveTo(scaleX(p1.x), scaleY(p1.y));
        ctx.lineTo(scaleX(p2.x), scaleY(p2.y));

        if (p2.isExtra) ctx.strokeStyle = "#2563eb";
        else if (p2.isTransitioning) ctx.strokeStyle = "#8b5cf6";
        else if (p2.isSub) ctx.strokeStyle = "#d97706";
        else ctx.strokeStyle = "#dc2626";

        ctx.stroke();

        // The upper-tropospheric thermal wind is shown as a dashed companion
        // trajectory when the resolved diagnostic is available. Keeping both
        // legs visible follows the CPS convention without inventing a second
        // axis or changing the historical fallback product.
        if (useResolvedDiagnostics
            && Number.isFinite(p1.vtUpper)
            && Number.isFinite(p2.vtUpper)) {
            ctx.save();
            ctx.setLineDash([5, 4]);
            ctx.lineWidth = 1.8;
            ctx.strokeStyle = "#475569";
            ctx.beginPath();
            ctx.moveTo(scaleX(p1.x), scaleY(p1.vtUpper));
            ctx.lineTo(scaleX(p2.x), scaleY(p2.vtUpper));
            ctx.stroke();
            ctx.restore();
        }
        
        if (i > 0 && p1.hour % 24 === 0) {
            const mx = scaleX(p1.x);
            const my = scaleY(p1.y);
            ctx.fillStyle = "#000";
            ctx.beginPath(); ctx.arc(mx, my, 2.5, 0, Math.PI*2); ctx.fill();
            const d = Math.floor(p1.hour / 24);
            ctx.font = "9px Arial";
            ctx.fillText(`D${d}`, mx + 6, my - 6);
        }
    }

    // A/Z
    if (dataPoints.length > 0) {
        ctx.fillStyle = "#000";
        ctx.font = "bold 16px Arial";
        ctx.fillText("A", scaleX(dataPoints[0].x), scaleY(dataPoints[0].y));
        
        const lastP = dataPoints[dataPoints.length - 1];
        ctx.shadowBlur = 5; ctx.shadowColor = "rgba(255,255,255,1)";
        ctx.beginPath(); ctx.arc(scaleX(lastP.x), scaleY(lastP.y), 6, 0, Math.PI*2); ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#fff";
        ctx.font = "bold 10px Arial";
        ctx.textBaseline = "middle";
        ctx.fillText("Z", scaleX(lastP.x), scaleY(lastP.y));
    }
    ctx.restore();

    // --- 5. 右侧状态栏 ---
    const infoX = chartX + chartW + 20;
    const infoY = chartY;
    
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    
    ctx.fillStyle = "#64748b";
    ctx.font = "bold 12px 'JetBrains Mono'";
    ctx.fillText("CURRENT STATUS", infoX, infoY);

    let phaseName = "TROPICAL";
    let phaseColor = "#dc2626";
    if (currentData.isExtra) {
        phaseName = "EXTRATROPICAL";
        phaseColor = "#2563eb";
    } else if (currentData.isTransitioning) {
        phaseName = "TRANSITIONING";
        phaseColor = "#8b5cf6";
    } else if (currentData.isSub) {
        phaseName = "SUBTROPICAL";
        phaseColor = "#d97706";
    }

    ctx.fillStyle = phaseColor;
    ctx.fillRect(infoX, infoY + 20, 4, 35);
    
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 20px 'JetBrains Mono'";
    ctx.fillText(phaseName, infoX + 10, infoY + 20);
    
    ctx.fillStyle = "#64748b";
    ctx.font = "11px 'JetBrains Mono'";
    ctx.fillText(`B (Asym): ${currentData.x.toFixed(1)}`, infoX + 10, infoY + 45);
    ctx.fillText(`-V_T lower ×10: ${currentData.y.toFixed(1)}`, infoX + 10, infoY + 60);
    ctx.fillText(`-V_T upper ×10: ${(Number.isFinite(currentData.vtUpper)
        ? currentData.vtUpper : currentData.y).toFixed(1)}`, infoX + 10, infoY + 75);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "9px 'JetBrains Mono'";
    ctx.fillText(currentData.source === 'resolved-height-proxy'
        ? "RESOLVED HEIGHT PROXY" : "ESTIMATED LEGACY RECORD", infoX + 10, infoY + 95);
    if (useResolvedDiagnostics) {
        ctx.fillStyle = "#475569";
        ctx.fillText("solid: lower  /  dashed: upper", infoX + 10, infoY + 110);
    }
    
    // 版权标
    ctx.textAlign = "right";
    ctx.fillStyle = "#cbd5e1";
    ctx.fillText("STORM_INC®", width - 10, height - 10);

    return canvas;
}

function renderNewsBackground(ctx, projection, width, height, worldData) {
    const pathGenerator = d3.geoPath().projection(projection).context(ctx);

    // 1. 海洋
    ctx.fillStyle = "#0f3460";
    ctx.fillRect(0, 0, width, height);

    // 2. 陆地（Canvas 模式下必须逐个 feature 调用 beginPath，否则 fill/stroke 无效）
    if (worldData && worldData.objects) {
        const topoKey = worldData.objects.countries ? 'countries' : 'land';
        const geoFeature = topojson.feature(worldData, worldData.objects[topoKey]);
        // 填充：整体一次 beginPath（D3 geoPath 对 FeatureCollection 会合并路径）
        ctx.beginPath();
        pathGenerator(geoFeature);
        ctx.fillStyle = "#16213e";
        ctx.fill();
        // 边界线：用 topojson.mesh 只画国家边界，比逐个 feature 快得多
        const topoObj = worldData.objects[topoKey];
        if (topojson.mesh) {
            const meshLine = topojson.mesh(worldData, topoObj, (a, b) => a !== b);
            ctx.beginPath();
            pathGenerator(meshLine);
            ctx.strokeStyle = "#4ecca3";
            ctx.lineWidth = 0.8;
            ctx.stroke();
        }
    }

    // 3. 经纬网
    const graticule = d3.geoGraticule().step([5, 5]);
    ctx.beginPath();
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 1;
    graticule.lines().forEach(l => {
        pathGenerator(l);
        ctx.stroke();
        ctx.beginPath();
    });

    // 4. 边缘标签
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.font = "12px 'JetBrains Mono'";
    ctx.textBaseline = "middle";

    const tl = projection.invert([0, 0]) || [-180, 90];
    const br = projection.invert([width, height]) || [180, -90];

    // 纬度标签 (左边缘)
    const startLat = Math.floor(Math.min(tl[1], br[1]) / 5) * 5;
    const endLat = Math.ceil(Math.max(tl[1], br[1]) / 5) * 5;
    const refLonLeft = tl[0]; 

    ctx.textAlign = "left";
    for (let lat = startLat; lat <= endLat; lat += 5) {
        const p = projection([refLonLeft, lat]);
        if (p && p[1] > 20 && p[1] < height - 20) {
            ctx.fillText(`${lat}°N`, 10, p[1]);
        }
    }

    // 经度标签 (下边缘)
    const centerLon = (tl[0] + br[0]) / 2;
    const spanEstimate = 360 / (projection.scale() / 100); 
    const scanStart = Math.floor((centerLon - spanEstimate) / 5) * 5;
    const scanEnd = Math.ceil((centerLon + spanEstimate) / 5) * 5;
    const refLatBot = br[1];

    ctx.textAlign = "center";
    for (let lon = scanStart; lon <= scanEnd; lon += 5) {
        const p = projection([lon, refLatBot]);
        if (p && p[0] > 50 && p[0] < width - 50) {
            let displayLon = lon;
            while (displayLon > 180) displayLon -= 360;
            while (displayLon < -180) displayLon += 360;
            const suffix = displayLon >= 0 ? 'E' : 'W';
            ctx.fillText(`${Math.abs(displayLon)}°${suffix}`, p[0], height - 25);
        }
    }
}

export function startNewsAnimation(canvas, worldData, cyclone, pathForecasts, basin, simulationCount, pressureSystems, currentMonth, globalTemp, globalShear) {
    const container = canvas.parentElement; // 假设外层有个 relative 的 div
    
    const introOverlay = document.createElement('div');
    // 设置为绝对定位铺满，并加入 transition 用于 10 秒后的淡出
    introOverlay.className = "absolute inset-0 z-50 transition-opacity duration-1000";
    introOverlay.style.background = "#1c62be"; // 使用 test.html 的深海蓝背景
    container.appendChild(introOverlay);

    // --- 2. 注入 test.html 的原版代码 ---
    // 【重要】请将您 test.html 中 <script> 里的 D3 绘图代码，
    // 比如 drawUIComponents()、路径绘制、专属 Icon 加载等，全部放进下面这个函数中执行。
    renderExactTestHtml(introOverlay, worldData, cyclone, pathForecasts);

    // --- 3. 后台静默初始化原来的粒子流场 ---
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    // --- 1. 数据解包 ---
    const unwrapLon = (lon, refLon) => {
        let diff = lon - refLon;
        while (diff > 180) diff -= 360;
        while (diff < -180) diff += 360;
        return refLon + diff;
    };

    if (!cyclone.track || cyclone.track.length === 0) return null;

    const refLon = cyclone.track[0][0];
    const fullTrackUnwrapped = cyclone.track.map(p => [unwrapLon(p[0], refLon), p[1], p[2]]);

    let forecastModels = [];
    if (pathForecasts && pathForecasts.length > 0) {
        forecastModels = pathForecasts.map(model => {
            return {
                ...model,
                track: model.track.map(p => [unwrapLon(p[0], refLon), p[1], p[2]])
            };
        });
    }

    // --- 2. 统一投影计算 ---
    // 我们直接以气旋当前位置为中心，采用较高的缩放倍率，
    // 这样 JTWC 画面和 流场 画面将完美重合，无需缩放过渡。
    const lastTrackPoint = fullTrackUnwrapped[fullTrackUnwrapped.length - 1];
    const finalCenterLon = lastTrackPoint[0];
    const finalCenterLat = lastTrackPoint[1];
    
    // [终极修复] 必须使用与 test.html SVG 层完全相同的墨卡托投影 (Mercator) 
    // 以及完全相同的缩放比例 (2500)
    // 这样流场不仅能正确画出陆地，而且 10 秒切换时地图绝对不会产生跳变错位
    const projection = d3.geoMercator()
        .center([finalCenterLon, finalCenterLat])
        .scale(2500)
        .translate([width / 2, height / 2]);

    // --- 3. 预渲染 Phase 1: JTWC 静态背景 (test.html 风格) ---
    const jtwcBgCanvas = document.createElement('canvas');
    jtwcBgCanvas.width = width; jtwcBgCanvas.height = height;
    const jCtx = jtwcBgCanvas.getContext('2d');

    // 海洋 (经典警告蓝)
    jCtx.fillStyle = '#1c62be';
    jCtx.fillRect(0, 0, width, height);

    // 陆地
    if (worldData && worldData.objects && worldData.objects.land) {
        const path = d3.geoPath(projection, jCtx);
        jCtx.beginPath();
        path(topojson.feature(worldData, worldData.objects.land));
        jCtx.fillStyle = '#1a1a1a'; jCtx.fill();
        jCtx.strokeStyle = '#333333'; jCtx.lineWidth = 1.5; jCtx.stroke();
    }

    // 预测误差锥 (Forecast Cone)
    if (forecastModels.length > 0) {
        jCtx.fillStyle = "rgba(255, 255, 255, 0.15)";
        jCtx.strokeStyle = "rgba(255, 255, 255, 0.3)";
        jCtx.setLineDash([4, 4]);
        
        forecastModels[0].track.forEach((p, i) => {
            const pos = projection(p);
            if (pos) {
                jCtx.beginPath();
                jCtx.arc(pos[0], pos[1], 20 + i * 5, 0, Math.PI * 2); // 模拟锥体扩散
                jCtx.fill(); jCtx.stroke();
            }
        });
        jCtx.setLineDash([]);
    }

    // 历史路径
    jCtx.beginPath();
    jCtx.strokeStyle = "rgba(255,255,255,0.9)";
    jCtx.lineWidth = 3;
    fullTrackUnwrapped.forEach((p, i) => {
        const pos = projection(p);
        if (pos) { i === 0 ? jCtx.moveTo(pos[0], pos[1]) : jCtx.lineTo(pos[0], pos[1]); }
    });
    jCtx.stroke();

    // 历史节点
    jCtx.fillStyle = "#f39c12"; jCtx.strokeStyle = "black"; jCtx.lineWidth = 1;
    fullTrackUnwrapped.forEach(p => {
        const pos = projection(p);
        if (pos) {
            jCtx.beginPath();
            jCtx.arc(pos[0], pos[1], 4, 0, Math.PI * 2);
            jCtx.fill(); jCtx.stroke();
        }
    });

    // JTWC 头部 UI
    jCtx.fillStyle = "#111"; jCtx.strokeStyle = "white"; jCtx.lineWidth = 2;
    jCtx.fillRect(50, 50, 500, 80); jCtx.strokeRect(50, 50, 500, 80);
    jCtx.fillStyle = "white"; jCtx.font = "bold 24px Arial"; 
    jCtx.textAlign = "center"; jCtx.textBaseline = "middle";
    jCtx.fillText("JTWC TROPICAL CYCLONE WARNING", 300, 75);
    jCtx.fillStyle = "#e74c3c"; jCtx.font = "bold 16px monospace";
    jCtx.fillText(">> ACTIVE TRACKING IN PROGRESS <<", 300, 105);

    // --- 预渲染流场静态背景 (终极修复版) ---
    const streamlineBgCanvas = document.createElement('canvas');
    streamlineBgCanvas.width = width; 
    streamlineBgCanvas.height = height;
    const sCtx = streamlineBgCanvas.getContext('2d');
    
    // 1. 画海洋底色
    sCtx.fillStyle = '#0f172a'; // 深蓝色海洋
    sCtx.fillRect(0, 0, width, height);

    // 2. 强制创建一个专属 Canvas 的路径生成器 (极其关键)
    const canvasPathGenerator = d3.geoPath().projection(projection).context(sCtx);

    // 3. 先画一层经纬网 (只要你能看到白色网格，说明投影和 Canvas 绘制绝对没问题！)
    sCtx.beginPath();
    canvasPathGenerator(d3.geoGraticule().step([10, 10])());
    sCtx.strokeStyle = 'rgba(255, 255, 255, 0.15)'; // 半透明白色网格
    sCtx.lineWidth = 1;
    sCtx.stroke();

    // 4. 绝对防御版：画陆地
    if (worldData) {
        let geoJsonData = null;

        // 情况 A: 数据是 TopoJSON
        if (worldData.type === 'Topology' && worldData.objects) {
            const keys = Object.keys(worldData.objects);
            if (keys.length > 0) {
                // 智能寻找包含 'land' 或 'countr' 的键，找不到就直接用第一个
                let targetKey = keys.find(k => k.toLowerCase().includes('land') || k.toLowerCase().includes('countr')) || keys[0];
                geoJsonData = topojson.feature(worldData, worldData.objects[targetKey]);
            }
        } 
        // 情况 B: 数据已经被转换成了 GeoJSON (FeatureCollection)
        else if (worldData.type === 'FeatureCollection' || worldData.type === 'Feature') {
            geoJsonData = worldData;
        }

        // 开始渲染
        if (geoJsonData) {
            sCtx.fillStyle = '#2a4365'; 
            sCtx.strokeStyle = '#64748b'; 
            sCtx.lineWidth = 1.5;

            // [关键防御] 如果是 FeatureCollection，必须拆开逐个国家/板块绘制
            // 防止高倍率缩放时单一巨大 Path 导致 Canvas 内存截断或渲染崩溃
            if (geoJsonData.features && Array.isArray(geoJsonData.features)) {
                geoJsonData.features.forEach(feature => {
                    sCtx.beginPath(); 
                    canvasPathGenerator(feature);
                    sCtx.fill();
                    sCtx.stroke();
                });
            } else {
                // 兜底：作为单一对象绘制
                sCtx.beginPath(); 
                canvasPathGenerator(geoJsonData); 
                sCtx.fill();
                sCtx.stroke();
            }
        } else {
            console.error("STORM_INC: worldData 存在，但无法提取出有效的地理几何体", worldData);
        }
    }
    // 流场粒子初始化
    const NUM_PARTICLES = 1500;
    const particles = [];
    const initParticle = (p) => {
        p.x = Math.random() * width; p.y = Math.random() * height;
        p.age = Math.random() * 50; p.maxAge = 60 + Math.random() * 60; 
        return p;
    };
    for(let k=0; k<NUM_PARTICLES; k++) particles.push(initParticle({}));

    // --- 5. 动画状态控制与渲染循环 ---
    const basinMap = { 'WPAC': 'WP', 'EPAC': 'EP', 'NATL': 'AL', 'NIO': 'IO', 'SHEM': 'SH', 'SIO': 'SH', 'SATL': 'SL' };
    const basinCode = basinMap[basin] || 'XX';
    const cycloneNumStr = String(simulationCount).padStart(2, '0');
    const rotationDir = cyclone.lat < 0 ? 1 : -1; 
    let animationId = null;

    // 时间常量配置 (毫秒)
    const JTWC_DURATION = 10000; // 播报警告界面 10 秒
    const FADE_DURATION = 1000;  // 溶解切换 1 秒

    let startTime = null;

    const render = (timestamp) => {
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;

        ctx.clearRect(0, 0, width, height);

        // 获取当前气旋屏幕坐标
        const cPos = projection(lastTrackPoint);

        if (elapsed < JTWC_DURATION) {
            // ==========================================
            // 阶段一：JTWC 静态播报 + 仅呼吸闪烁标签
            // ==========================================
            ctx.drawImage(jtwcBgCanvas, 0, 0);

            if (cPos) {
                // 计算呼吸闪烁 (周期 1 秒)
                const blinkTime = (elapsed % 1000) / 1000;
                let opacity = 1; let scale = 1;
                if (blinkTime < 0.5) { // 膨胀变淡
                    opacity = 1 - blinkTime * 1.6; 
                    scale = 1 + blinkTime * 0.8;   
                } else { // 恢复
                    opacity = 0.2 + (blinkTime - 0.5) * 1.6;
                    scale = 1.4 - (blinkTime - 0.5) * 0.8;
                }

                ctx.save();
                ctx.translate(cPos[0], cPos[1]);

                // 闪烁红圈
                ctx.beginPath(); ctx.arc(0, 0, 25 * scale, 0, Math.PI*2);
                ctx.fillStyle = `rgba(255, 0, 0, ${opacity * 0.2})`; ctx.fill();
                ctx.strokeStyle = `rgba(255, 51, 51, ${opacity})`; ctx.lineWidth = 3; ctx.stroke();

                // 中心靶点
                ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI*2);
                ctx.fillStyle = "#e74c3c"; ctx.fill();
                ctx.strokeStyle = "white"; ctx.lineWidth = 2; ctx.stroke();

                // 闪烁文字
                ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
                ctx.font = "bold 20px Arial"; ctx.textAlign = "left"; ctx.textBaseline = "middle";
                ctx.shadowColor = "black"; ctx.shadowBlur = 4; ctx.shadowOffsetX = 2; ctx.shadowOffsetY = 2;
                ctx.fillText(`SYS: ${Math.round(cyclone.intensity)}kt / ${Math.round(cyclone.pressure)}hPa`, 35, 0);

                ctx.restore();
            }

        } else {
            // ==========================================
            // 阶段二：流场动画 (包含 1秒 淡入过渡)
            // ==========================================
            const alpha = Math.min(1, (elapsed - JTWC_DURATION) / FADE_DURATION);

            // 1. 画底层暗黑流场背景
            ctx.drawImage(streamlineBgCanvas, 0, 0);

            // 2. 推进并绘制粒子
            ctx.lineWidth = 1.2; ctx.lineCap = "round";
            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                const geo = projection.invert([p.x, p.y]);
                if (!geo) { initParticle(p); continue; }
                const [lon, lat] = geo;

                const vec = getWindVectorAt(lon, lat, currentMonth, cyclone, pressureSystems, globalTemp, globalShear);
                const speedScale = 0.2; 
                p.x += vec.u * speedScale;
                p.y -= vec.v * speedScale; 
                p.age++;

                const speed = vec.magnitude;
                let pAlpha = 0.5;
                if (p.age < 15) pAlpha = p.age / 15;
                if (p.age > p.maxAge - 15) pAlpha = (p.maxAge - p.age) / 15;
                
                // 全局透明度渐变控制
                pAlpha *= alpha;

                ctx.beginPath();
                const trailLen = 3.0; 
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(p.x - vec.u * speedScale * trailLen, p.y + vec.v * speedScale * trailLen);
                
                if (speed > 48) ctx.strokeStyle = `rgba(255, 80, 80, ${pAlpha})`; 
                else if (speed > 23) ctx.strokeStyle = `rgba(255, 220, 100, ${pAlpha})`; 
                else ctx.strokeStyle = `rgba(200, 255, 255, ${pAlpha * 0.4})`; 
                ctx.stroke();

                if (p.age >= p.maxAge || p.x < 0 || p.x > width || p.y < 0 || p.y > height) initParticle(p);
            }

            // 3. 气旋风眼 Icon
            if (cPos) {
                ctx.globalAlpha = alpha;
                ctx.font = '900 32px "Font Awesome 6 Free"';
                ctx.fillStyle = "white"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
                ctx.save();
                ctx.translate(cPos[0], cPos[1]);
                ctx.rotate((elapsed / 1000) * rotationDir); 
                ctx.fillText('\uf751', 0, 0); 
                ctx.restore();
            }
            
            // 4. 右下角 UI 浮窗
            ctx.fillStyle = `rgba(0,0,0,${0.8 * alpha})`;
            ctx.fillRect(width - 260, 80, 240, 40);
            ctx.fillStyle = `rgba(74,222,128,${alpha})`; // #4ade80
            ctx.font = "bold 16px 'JetBrains Mono'";
            ctx.textAlign = "right";
            ctx.fillText("● LIVE WIND FIELD", width - 40, 105);

            // 5. 过渡期间，在最顶层叠加残余的 JTWC 画面 (渐渐消失)
            if (alpha < 1) {
                ctx.globalAlpha = 1 - alpha;
                ctx.drawImage(jtwcBgCanvas, 0, 0);
                ctx.globalAlpha = 1; // 恢复
            }
        }

        animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    setTimeout(() => {
        introOverlay.style.transition = 'opacity 1000ms ease';
        introOverlay.style.opacity = '0';
        setTimeout(() => {
            if (introOverlay.parentNode) introOverlay.parentNode.removeChild(introOverlay);
        }, 1100);
    }, JTWC_DURATION);

    return () => {
        if (animationId) cancelAnimationFrame(animationId);
    };
}

function synopticCoastline(world) {
    return cachedSynopticCoastline(world);
}

function projectedFrontSegments(projection, points) {
    const projected = (points || []).map(point => projection(point));
    const segments = [];
    let segment = [];
    for (const point of projected) {
        if (point && Number.isFinite(point[0]) && Number.isFinite(point[1])) {
            segment.push(point);
        } else if (segment.length) {
            segments.push(segment);
            segment = [];
        }
    }
    if (segment.length) segments.push(segment);
    return segments.filter(pointsInSegment => pointsInSegment.length >= 2);
}

function frontStyle(type) {
    if (type === 'warm') return { color: '#d7333f', label: 'WARM FRONT' };
    if (type === 'occluded') return { color: '#8a42a5', label: 'OCCLUDED' };
    return { color: '#2478c4', label: 'COLD FRONT' };
}

function drawFrontSymbol(ctx, type, x, y, angle, side, color, scale = 1) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    const bulge = -Math.sign(side || 1);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 2.2 * scale;
    if (type === 'warm') {
        ctx.beginPath();
        ctx.moveTo(-14 * scale, 0);
        ctx.bezierCurveTo(
            -14 * scale, bulge * 24 * scale,
            14 * scale, bulge * 24 * scale,
            16 * scale, 0
        );
        ctx.lineTo(-9 * scale, 0);
        ctx.closePath();
        ctx.fill();
    } else {
        ctx.beginPath();
        ctx.moveTo(-14 * scale, 0);
        ctx.lineTo(14 * scale, 0);
        ctx.lineTo(0, bulge * 24 * scale);
        ctx.closePath();
        ctx.fill();
    }
    ctx.restore();
}

function drawFrontSegment(ctx, segment, front, scale = 1) {
    const style = frontStyle(front.type);
    ctx.save();
    ctx.globalAlpha = .52 + .48 * Math.max(0, Math.min(1, front.strength || 0));
    ctx.strokeStyle = style.color;
    ctx.lineWidth = (3.4 + 1.3 * (front.strength || 0)) * scale;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    if ((front.strength || 0) < .32) ctx.setLineDash([13 * scale, 8 * scale]);
    ctx.beginPath();
    segment.forEach((point, index) => index
        ? ctx.lineTo(point[0], point[1]) : ctx.moveTo(point[0], point[1]));
    ctx.stroke();
    ctx.setLineDash([]);

    const cumulative = [0];
    for (let index = 1; index < segment.length; index++) {
        cumulative.push(cumulative[index - 1] + Math.hypot(
            segment[index][0] - segment[index - 1][0],
            segment[index][1] - segment[index - 1][1]
        ));
    }
    const total = cumulative[cumulative.length - 1];
    const spacing = 72 * scale;
    let symbolIndex = 0;
    for (let distance = spacing * .72; distance < total - spacing * .25; distance += spacing) {
        while (symbolIndex + 1 < cumulative.length && cumulative[symbolIndex + 1] < distance) {
            symbolIndex++;
        }
        if (symbolIndex + 1 >= segment.length) break;
        const span = Math.max(1, cumulative[symbolIndex + 1] - cumulative[symbolIndex]);
        const t = (distance - cumulative[symbolIndex]) / span;
        const a = segment[symbolIndex], b = segment[symbolIndex + 1];
        const x = a[0] + (b[0] - a[0]) * t;
        const y = a[1] + (b[1] - a[1]) * t;
        const type = front.type === 'occluded'
            ? (Math.round(distance / spacing) % 2 ? 'warm' : 'cold')
            : front.type;
        drawFrontSymbol(ctx, type, x, y, Math.atan2(b[1] - a[1], b[0] - a[0]),
            front.symbolSide, style.color, scale);
    }
    ctx.restore();
}

function drawSurfaceFrontAnalysis(ctx, projection, fronts, pressureSystems) {
    for (const front of fronts) {
        for (const segment of projectedFrontSegments(projection, front.points)) {
            drawFrontSegment(ctx, segment, front);
        }
    }

    const synopticCenters = new Map();
    for (const front of fronts.filter(item => item.ownerType === 'synoptic')) {
        if (!synopticCenters.has(front.ownerId)) synopticCenters.set(front.ownerId, front);
    }
    for (const feature of synopticCenters.values()) {
        if (feature.showCenterLabel === false) continue;
        const center = feature.center;
        const pixel = projection(center);
        if (!pixel || pixel[0] < 35 || pixel[0] > ctx.canvas.width - 35
            || pixel[1] < 70 || pixel[1] > ctx.canvas.height - 45) continue;
        const pressure = Math.round(Number.isFinite(feature.centerPressure)
            ? feature.centerPressure
            : getSurfacePressureAt(center[0], center[1], pressureSystems));
        ctx.save();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
        ctx.font = 'bold 34px Arial'; ctx.strokeStyle = 'rgba(255,255,255,.92)'; ctx.lineWidth = 5;
        ctx.strokeText('L', pixel[0], pixel[1]);
        ctx.fillStyle = '#a83e37'; ctx.fillText('L', pixel[0], pixel[1]);
        ctx.font = 'bold 15px Arial'; ctx.strokeText(`${pressure}`, pixel[0], pixel[1] + 28);
        ctx.fillStyle = '#253b43'; ctx.fillText(`${pressure}`, pixel[0], pixel[1] + 28);
        ctx.restore();
    }

    if (!fronts.length) return;
    const legendY = ctx.canvas.height - 35;
    const entries = ['cold', 'warm', 'occluded'];
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.86)';
    ctx.fillRect(18, legendY - 25, 430, 43);
    entries.forEach((type, index) => {
        const x = 36 + index * 140;
        const style = frontStyle(type);
        ctx.strokeStyle = style.color; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x, legendY); ctx.lineTo(x + 44, legendY); ctx.stroke();
        drawFrontSymbol(ctx, type === 'occluded' ? 'cold' : type,
            x + 22, legendY, 0, 1, style.color, .72);
        ctx.fillStyle = '#263943'; ctx.font = 'bold 11px Arial';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(style.label, x + 50, legendY);
    });
    ctx.restore();
}

export async function renderStationSynopticChartAsync(cyclone, timeIndex, worldData, pressureSystems, stationLon, stationLat, stationName) {
    const safeIndex = (timeIndex >= 0 && timeIndex < cyclone.track.length)
        ? timeIndex : cyclone.track.length - 1;
    const point = cyclone.track[safeIndex];
    const projection = d3.geoEquirectangular()
        .rotate([-(stationLon ?? point[0]), 0])
        .center([0, stationLat ?? point[1]])
        .scale(4000).translate([800, 600]);
    const geography = await prepareICWCGeography(worldData, projection, true);
    const size = point[5] || cyclone.circulationSize || 300;
    const chartCyclone = {
        ...cyclone, lon: point[0], lat: point[1], intensity: point[2],
        circulationSize: size,
        r34: Array.isArray(point[7]) ? point[7] : cyclone.r34,
        ...historicalCyclonePhase(cyclone, safeIndex)
    };
    // Use the existing exact evaluator with one immutable-frame context.
    // Terrain remains enabled, matching getSurfacePressureAt's default.
    const samplePressure = createSurfacePressureSampler(pressureSystems, { includeTerrain: true });
    const centerEnvP = samplePressure(point[0], point[1]);
    const Pc = windToPressure(point[2], size, cyclone.basin || 'WPAC', centerEnvP);
    const Rmw = 10 + size * 0.25;
    const nx = 200, ny = 150, grid = new Float32Array(nx * ny);
    let sliceStart = performance.now();
    for (let j = 0; j < ny; ++j) for (let i = 0; i < nx; ++i) {
        const coords = projection.invert([i * 1600 / nx, j * 1200 / ny]);
        if (!coords) { grid[j * nx + i] = 1012; continue; }
        const [lon, lat] = coords;
        const P_env = samplePressure(lon, lat);
        const distKm = getCycloneFieldGeometryAt(lon, lat, chartCyclone).effectiveRadiusKm;
        grid[j * nx + i] = calculateHollandPressure(distKm, Rmw, Pc, P_env);
        if (performance.now() - sliceStart >= 8) {
            await new Promise(resolve => setTimeout(resolve, 0));
            sliceStart = performance.now();
        }
    }
    const contours = await prepareICWCContours(grid, nx, ny, d3.range(780, 1060, 2));
    return renderStationSynopticChart(cyclone, timeIndex, worldData, pressureSystems,
        stationLon, stationLat, stationName, geography, grid, contours);
}

export function renderStationSynopticChart(cyclone, timeIndex, worldData, pressureSystems, stationLon, stationLat, stationName, geography = null, precomputedGrid = null, precomputedContours = null) {
    const width = 1600;
    const height = 1200;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // 1. 数据准备
    // 获取当时的气旋状态
    const safeIndex = (timeIndex >= 0 && timeIndex < cyclone.track.length) ? timeIndex : cyclone.track.length - 1;
    const currentPoint = cyclone.track[safeIndex];
    const cycLon = currentPoint[0];
    const cycLat = currentPoint[1];
    const intensity = currentPoint[2];
    const size = currentPoint[5] || cyclone.circulationSize || 300;
    const basin = cyclone.basin || 'WPAC';
    const chartCyclone = {
        ...cyclone,
        lon: cycLon,
        lat: cycLat,
        intensity,
        circulationSize: size,
        // Use the radii saved with this historical point. Falling back to the
        // live cyclone radii can make a past chart protect the wrong footprint.
        r34: Array.isArray(currentPoint[7]) ? currentPoint[7] : cyclone.r34,
        ...historicalCyclonePhase(cyclone, safeIndex)
    };

    // 2. 投影设置 (以站点为中心)
    // 如果没有站点坐标，兜底使用气旋中心
    const centerLon = (stationLon != null) ? stationLon : cycLon;
    const centerLat = (stationLat != null) ? stationLat : cycLat;

    // 使用球极平面投影 (Stereographic) 或 等距方位投影，适合局部天气图
    // 这里为了兼容性继续使用 Equirectangular，但放大倍数较高
    const projection = d3.geoEquirectangular()
        .rotate([-centerLon, 0])
        .center([0, centerLat])
        .scale(4000) // 局部放大，约显示 10-15 度范围
        .translate([width / 2, height / 2]);

    const pathGenerator = d3.geoPath().projection(projection).context(ctx);

    // 3. 背景绘制 (海洋/陆地)
    ctx.fillStyle = "#aed6f1"; // 浅蓝海洋
    ctx.fillRect(0, 0, width, height);

    ctx.beginPath();
    ctx.fillStyle = "#a8efaf"; // 鲜绿色陆地
    ctx.strokeStyle = "#999";
    ctx.lineWidth = 1;
    if (geography) {
        ctx.fill(geography.land);
        ctx.stroke(geography.land);
    } else {
        pathGenerator(worldData);
        ctx.fill();
        ctx.stroke();
    }

    // Retain the original national borders; darken only unshared coastline edges.
    ctx.beginPath();
    ctx.strokeStyle = '#778a82';
    ctx.lineWidth = 1;
    if (geography) ctx.stroke(geography.coast);
    else {
        pathGenerator(synopticCoastline(worldData));
        ctx.stroke();
    }

    // 4. 绘制经纬网
    ctx.beginPath();
    ctx.strokeStyle = "rgba(0,0,0,0.2)";
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    pathGenerator(d3.geoGraticule().step([1, 1])()); // 1度网格
    ctx.stroke();
    ctx.setLineDash([]);

    // --- 5. [核心] 计算合成气压场 ---
    const nx = 200, ny = 150; // 网格分辨率
    const gridValues = precomputedGrid || new Float32Array(nx * ny);
    const centerEnvP = getSurfacePressureAt(cycLon, cycLat, pressureSystems);
    // 气旋参数预计算
    const Pc = windToPressure(intensity, size, basin, centerEnvP); // 中心气压
    const Rmw = 10 + size * 0.25; 

    for (let j = 0; !precomputedGrid && j < ny; ++j) {
        for (let i = 0; i < nx; ++i) {
            // 反投影获取经纬度
            const coords = projection.invert([i * width / nx, j * height / ny]);
            if (!coords) { gridValues[j * nx + i] = 1012; continue; }
            
            const [lon, lat] = coords;

            // A. 计算环境气压 (Synoptic Background)
            const P_env = getSurfacePressureAt(lon, lat, pressureSystems);

            // B. 计算气旋气压 (Vortex Field)
            const distKm = getCycloneFieldGeometryAt(
                lon,
                lat,
                chartCyclone
            ).effectiveRadiusKm;
            // Holland 公式：P(r)
            const P_total = calculateHollandPressure(distKm, Rmw, Pc, P_env);
            gridValues[j * nx + i] = P_total;
        }
    }

    // --- 6. 绘制等压线 (Isobars) ---
    const thresholds = d3.range(780, 1060, 2); // 每 2hPa 一根
    const contours = precomputedContours || d3.contours().size([nx, ny]).thresholds(thresholds)(gridValues);
    
    // 坐标变换器
    const transform = d3.geoTransform({
        point: function(x, y) {
            this.stream.point(x * (width / nx), y * (height / ny));
        }
    });
    const isobarCanvas = document.createElement('canvas');
    isobarCanvas.width = width; isobarCanvas.height = height;
    const lineCtx = isobarCanvas.getContext('2d');
    const contourPath = d3.geoPath().projection(transform).context(lineCtx);

    contours.forEach(c => {
        const val = c.value;
        lineCtx.beginPath();
        contourPath(c);
        
        // 样式逻辑
        if (val % 10 === 0) {
            // 主曲线 (1000, 1010...)
            lineCtx.lineWidth = 2.5;
            lineCtx.strokeStyle = "#344b58";
        } else if (val % 4 === 0) {
            // 次级曲线
            lineCtx.lineWidth = 1.25;
            lineCtx.strokeStyle = "rgba(52,75,88,0.72)";
        } else {
            // 细线
            lineCtx.lineWidth = 0.85;
            lineCtx.strokeStyle = "rgba(52,75,88,0.48)";
        }
        
        lineCtx.stroke();
    });

    // One label per 10 hPa main contour, on a long, gently curved visible section.
    // Cut gaps in the isobar layer only, preserving the underlying grid and borders.
    const centerPixel = projection([cycLon, cycLat]);
    const stationPixel = stationLon != null && stationLat != null ? projection([stationLon, stationLat]) : null;
    const labels = [];
    lineCtx.font = 'bold 18px Arial';
    for (const contour of contours.filter(c => c.value % 10 === 0)) {
        let best = null;
        for (const polygon of contour.coordinates) for (const ring of polygon) {
            for (let i = 8; i < ring.length - 8; i += 4) {
                const p = [ring[i][0] * width / nx, ring[i][1] * height / ny];
                if (p[0] < 65 || p[0] > width - 65 || p[1] < 105 || p[1] > height - 80) continue;
                if (centerPixel && Math.hypot(p[0] - centerPixel[0], p[1] - centerPixel[1]) < 115) continue;
                if (stationPixel && p[0] > stationPixel[0] - 35 && p[0] < stationPixel[0] + 250 && Math.abs(p[1] - stationPixel[1]) < 65) continue;
                if (labels.some(l => Math.hypot(l.x - p[0], l.y - p[1]) < 140)) continue;
                const before = ring[i - 8], after = ring[i + 8];
                const dx = (after[0] - before[0]) * width / nx, dy = (after[1] - before[1]) * height / ny;
                const length = Math.hypot(dx, dy);
                if (length < 65) continue;
                const bend = Math.abs(dx * (p[1] - before[1] * height / ny) - dy * (p[0] - before[0] * width / nx)) / length;
                if (bend > 7) continue;
                const score = length - bend * 8 - Math.abs(dy) * 0.3;
                if (!best || score > best.score) {
                    let angle = Math.atan2(dy, dx);
                    if (angle > Math.PI / 2) angle -= Math.PI;
                    if (angle < -Math.PI / 2) angle += Math.PI;
                    best = { x: p[0], y: p[1], angle, score, value: String(contour.value) };
                }
            }
        }
        if (best) labels.push(best);
    }
    for (const label of labels) {
        lineCtx.save(); lineCtx.translate(label.x, label.y); lineCtx.rotate(label.angle);
        const labelWidth = lineCtx.measureText(label.value).width;
        lineCtx.globalCompositeOperation = 'destination-out';
        lineCtx.fillRect(-labelWidth / 2 - 7, -13, labelWidth + 14, 26);
        lineCtx.globalCompositeOperation = 'source-over';
        lineCtx.fillStyle = '#344b58'; lineCtx.textAlign = 'center'; lineCtx.textBaseline = 'middle';
        lineCtx.fillText(label.value, 0, 0);
        lineCtx.restore();
    }
    ctx.drawImage(isobarCanvas, 0, 0);
    isobarCanvas.width = 1; isobarCanvas.height = 1;

    // --- 7. 绘制关键要素 ---

    // Fronts belong above the isobars but below station and cyclone labels.
    // This includes both resolved background frontal lows and a tracked TC
    // after it has completed extratropical transition.
    const surfaceFronts = getSurfaceFrontAnalysis(chartCyclone, pressureSystems);
    drawSurfaceFrontAnalysis(ctx, projection, surfaceFronts, pressureSystems);

    // A. 站点标记
    if (stationLon != null && stationLat != null) {
        const sPos = projection([stationLon, stationLat]);
        if (sPos) {
            // 靶心图标
            ctx.beginPath(); ctx.arc(sPos[0], sPos[1], 8, 0, Math.PI*2);
            ctx.fillStyle = "red"; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle="white"; ctx.stroke();
            
            // 站点名称
            ctx.fillStyle = "black";
            ctx.font = "bold 24px Arial";
            ctx.textAlign = "left";
            ctx.fillText((stationName || "STATION").toUpperCase(), sPos[0] + 15, sPos[1] + 8);
            
            // 当前气压值
            // 重新计算一下该点的气压用于显示
            const P_env = getSurfacePressureAt(stationLon, stationLat, pressureSystems);
            const dist = getCycloneFieldGeometryAt(
                stationLon,
                stationLat,
                chartCyclone
            ).effectiveRadiusKm;
            const P_local = Math.round(calculateHollandPressure(dist, Rmw, Pc, P_env));
            
            ctx.fillStyle = "blue";
            ctx.font = "bold 20px Monospace";
            ctx.fillText(`${P_local} hPa`, sPos[0] + 15, sPos[1] + 32);
        }
    }

    // B. 气旋中心
    const cPos = projection([cycLon, cycLat]);
    if (cPos) {
        ctx.save();
        ctx.translate(cPos[0], cPos[1]);
        ctx.font = 'bold 38px Arial';
        ctx.fillStyle = "#a83e37";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.lineJoin = 'round'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,255,255,0.88)';
        ctx.strokeText('L', 0, 0); ctx.fillText('L', 0, 0);
        ctx.font = 'bold 20px Arial';
        ctx.fillStyle = '#253b43'; ctx.lineWidth = 3;
        const pressureLabel = `${Math.round(Pc)} hPa`;
        ctx.strokeText(pressureLabel, 0, 34); ctx.fillText(pressureLabel, 0, 34);
        ctx.restore();
    }

    // --- 8. 图表装饰 ---
    // 标题栏
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, width, 60);
    ctx.strokeStyle = "black";
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, width, 60);

    ctx.fillStyle = "black";
    ctx.textAlign = "left";
    ctx.font = "bold 24px Arial";
    ctx.textBaseline = "middle";
    ctx.fillText("LOCAL SYNOPTIC ANALYSIS (MSLP)", 20, 30);

    // 时间戳
    const currentAge = timeIndex * 3;
    const simDate = simulationDate(cyclone, currentAge);
    const dateStr = simDate.toISOString().replace("T", " ").substring(0, 16) + "Z";

    ctx.textAlign = "right";
    ctx.fillText(`VALID: ${dateStr}`, width - 20, 30);

    // 底部水印
    ctx.font = "900 32px 'Inter', sans-serif"; 
    ctx.fillStyle = "rgba(0, 0, 0, 0.15)";
    ctx.textAlign = "right";
    ctx.textBaseline = "bottom";
    ctx.fillText("STORM_INC®", width - 20, height - 10);

    return canvas;
}

export async function renderTestHtmlIntro(container, cyclone, state) {
    const width = 1920;
    const height = 1080;
    
    // 创建 SVG 容器
    const svg = d3.select(container).append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('width', '100%')
        .style('height', '100%')
        .style('background', '#1c62be'); // test.html 的海洋蓝

    // 注入 CSS 动画 (核心：闪烁的热带气旋标签)
    svg.append('style').text(`
        @keyframes alert-flash {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.2; transform: scale(1.4); }
            100% { opacity: 1; transform: scale(1); }
        }
        .flashing-icon { 
            animation: alert-flash 1s infinite cubic-bezier(0.4, 0, 0.6, 1); 
            transform-origin: center;
        }
        .track-line { fill: none; stroke: rgba(255,255,255,0.9); stroke-width: 3px; }
    `);

    // 设置投影 (居中于气旋)
    const projection = d3.geoMercator()
        .center([cyclone.lon, cyclone.lat])
        .scale(1800)
        .translate([width / 2, height / 2]);
    const path = d3.geoPath().projection(projection);

    // 1. 绘制地图底层 (经纬网与陆地)
    try {
        const worldData = await d3.json("https://unpkg.com/world-atlas@2.0.2/countries-50m.json");
        const land = topojson.feature(worldData, worldData.objects.land);
        
        // 经纬网
        svg.append("path").datum(d3.geoGraticule())
            .attr("d", path).style("fill", "none").style("stroke", "rgba(255,255,255,0.15)");
        
        // 陆地
        svg.append("path").datum(land)
            .attr("d", path).style("fill", "#1a1a1a").style("stroke", "#333333").style("stroke-width", "1.5px");
    } catch(e) { console.error("Map load failed:", e); }

    // 2. 绘制预测锥 (Cone of Uncertainty)
    // 假设您已经 import 了 generatePathForecasts
    const forecasts = generatePathForecasts(cyclone, state.pressureSystems, state.GlobalTemp);
    if (forecasts && forecasts.length > 0) {
        const coneGroup = svg.append("g").attr("class", "forecast-cone");
        forecasts.forEach(f => {
            const p = projection([f.lon, f.lat]);
            if (p) {
                // 利用多圆叠加模拟误差锥
                coneGroup.append("circle")
                    .attr("cx", p[0])
                    .attr("cy", p[1])
                    .attr("r", f.errorRadius * (1800 / 111) * 0.4) // 粗略的公里到像素换算
                    .style("fill", "rgba(255, 255, 255, 0.15)")
                    .style("stroke", "rgba(255, 255, 255, 0.3)")
                    .style("stroke-dasharray", "4,4");
            }
        });
    }

    // 3. 绘制历史路径
    const historyLine = d3.line()
        .x(d => projection([d.lon, d.lat])[0])
        .y(d => projection([d.lon, d.lat])[1])
        .curve(d3.curveMonotoneX);
        
    svg.append("path")
        .datum(cyclone.history)
        .attr("class", "track-line")
        .attr("d", historyLine);

    // 绘制历史节点
    cyclone.history.forEach(h => {
        const p = projection([h.lon, h.lat]);
        if (p) {
            svg.append("circle")
                .attr("cx", p[0]).attr("cy", p[1]).attr("r", 4)
                .style("fill", "#f39c12").style("stroke", "black");
        }
    });

    // 4. [动态] 绘制闪烁的当前气旋位置
    const cPos = projection([cyclone.lon, cyclone.lat]);
    if (cPos) {
        const currentMark = svg.append("g")
            .attr("transform", `translate(${cPos[0]}, ${cPos[1]})`);
            
        // 闪烁的雷达圈
        currentMark.append("circle")
            .attr("class", "flashing-icon")
            .attr("r", 25)
            .style("fill", "rgba(255, 0, 0, 0.2)")
            .style("stroke", "#ff3333")
            .style("stroke-width", 3);
            
        // 中心风眼标签
        currentMark.append("circle")
            .attr("r", 8)
            .style("fill", "#e74c3c")
            .style("stroke", "white")
            .style("stroke-width", 2);

        // 旁边的文字标签
        currentMark.append("text")
            .attr("x", 35)
            .attr("y", 5)
            .attr("class", "flashing-icon") // 文字也一起闪烁
            .style("fill", "white")
            .style("font-family", "Arial")
            .style("font-weight", "bold")
            .style("font-size", "20px")
            .style("text-shadow", "2px 2px 4px black")
            .text(`SYS: ${Math.round(cyclone.intensity)}kt / ${Math.round(cyclone.pressure)}hPa`);
    }

    // 5. 绘制 test.html 风格的 UI 装饰框 (JTWC Header)
    svg.append("rect")
        .attr("x", 50).attr("y", 50).attr("width", 500).attr("height", 80)
        .style("fill", "#111").style("stroke", "white").style("stroke-width", 2);
        
    svg.append("text")
        .attr("x", 300).attr("y", 85)
        .attr("text-anchor", "middle")
        .style("fill", "white").style("font-family", "Arial")
        .style("font-size", "24px").style("font-weight", "bold")
        .text("JTWC TROPICAL CYCLONE WARNING");
        
    svg.append("text")
        .attr("x", 300).attr("y", 115)
        .attr("text-anchor", "middle")
        .style("fill", "#e74c3c").style("font-family", "monospace")
        .style("font-size", "16px").style("font-weight", "bold")
        .text(">> ACTIVE TRACKING IN PROGRESS <<");
}

export async function renderExactTestHtml(container, worldData, cyclone, pathForecasts, options = {}) {
    // ================= 从 cyclone 对象中提取 historyData / forecastData =================
    // cyclone.track 格式: [[lon, lat, intensity], ...]  每步 3 小时
    // pathForecasts 格式: [{ track: [[lon, lat, intensity], ...], ... }, ...]  每步 3 小时

    // ---- 时间工具：将模拟小时数转换为 CST (UTC+8) 中文日期标签 ----
    // currentAge = cyclone.track.length * 3（小时），即当前模拟时刻
    // Calendar labels share the saved simulation origin with ICWC products.
    function simHoursToCST(totalUTCHours) {
        const d = simulationDate(cyclone, totalUTCHours + 8); // +8 转 CST
        const day  = d.getUTCDate();
        const hour = d.getUTCHours();
        return `${day}日 ${String(hour).padStart(2, '0')}时`;
    }

    // 当前模拟已过去的小时数（track 每步 3 小时）
    const rawTrack = (cyclone && cyclone.track) ? cyclone.track : [];
    const currentSimAge = rawTrack.length * 3; // 单位：小时

    // 历史路径：使用 cyclone.track 全部节点（每 3 小时一点，绘图用，不需要标签）
    const historyData = rawTrack.map((p, i) => ({
        lon:       p[0],
        lat:       p[1],
        intensity: p[2] || cyclone.intensity || 20,
        radius:    0,
        date:      simHoursToCST((i - rawTrack.length) * 3 + currentSimAge)
    }));

    // 预报路径：取第一个预报模型（主模式）作为中心线，每 3 小时一点
    // 用所有模型的散布计算每步误差半径（km），驱动误差锥绘制
    // 只对每 8 步（=24 小时）的整点打标签，显示 CST 日期
    let forecastData = [];
    let quantizedLimit = 8; // 默认至少24h，在下方预报数据块中更新
    if (pathForecasts && pathForecasts.length > 0 && pathForecasts[0].track) {
        const fTrack = pathForecasts[0].track;

        // 预计算每步的误差半径（km）：基于多模型散布 + 时间增长项
        // 与 drawForecastCone 公式一致：radius_deg = (0.25 + i*0.14) + stdDev*0.6
        const unwrapLon = (lon, ref) => { let d = lon - ref; while(d>180)d-=360; while(d<-180)d+=360; return ref+d; };
        const errorRadiiKm = fTrack.map((_, i) => {
            let stdDev = 0;
            if (pathForecasts.length > 1) {
                const refLon0 = pathForecasts[0].track[0][0];
                const pts = pathForecasts.map(f => f.track[i]).filter(Boolean);
                const uPts = pts.map(p => [unwrapLon(p[0], refLon0), p[1]]);
                const avgLon = uPts.reduce((s,p)=>s+p[0],0)/uPts.length;
                const avgLat = uPts.reduce((s,p)=>s+p[1],0)/uPts.length;
                const dists = uPts.map(p => Math.hypot(p[0]-avgLon, p[1]-avgLat));
                const mean = dists.reduce((s,v)=>s+v,0)/dists.length;
                stdDev = Math.sqrt(dists.reduce((s,v)=>s+Math.pow(v-mean,2),0)/dists.length);
            }
            const radiusDeg = (0.25 + i * 0.14) + stdDev * 0.6;
            return radiusDeg * 111.32; // 度 → km
        });

        quantizedLimit = forecastDisplayLimit(pathForecasts);
        const validTrack = quantizedLimit ? fTrack.slice(0, quantizedLimit + 1) : [];

        forecastData = validTrack.map((p, i) => {
            const forecastUTCHours = currentSimAge + i * 3;
            const isDailyTick = (i > 0) && (i % 8 === 0);
            return {
                lon:       p[0],
                lat:       p[1],
                intensity: Number.isFinite(p[2]) ? p[2] : cyclone.intensity || 20,
                radius:    i === 0 ? 0 : errorRadiiKm[i], // 起报点radius=0，之后线性增长
                date:      simHoursToCST(forecastUTCHours),
                label:     isDailyTick ? simHoursToCST(forecastUTCHours) : null
            };
        });
    } else {
        forecastData = [{
            lon:       cyclone.lon,
            lat:       cyclone.lat,
            intensity: cyclone.intensity || 20,
            radius:    0,
            date:      simHoursToCST(currentSimAge),
            label:     null
        }];
    }

    // 若 historyData 为空则将当前位置作为唯一历史点
    if (historyData.length === 0) {
        historyData.push({
            lon: cyclone.lon, lat: cyclone.lat,
            intensity: cyclone.intensity || 20, radius: 0,
            date: simHoursToCST(currentSimAge)
        });
    }

    // ================= 数据配置 (与 test.html 完全一致) =================
    const exportWidth  = options.exportWidth  || 1920;
    const exportHeight = options.exportHeight || 1080;
    const baseWidth    = options.baseWidth    || 960;
    const baseHeight   = options.baseHeight   || 540;
    const refPoint     = options.refPoint     || { lat: 22.4, lon: 114.0 };
    // systemName: 优先 options > cyclone.name > cyclone.id > 默认
    const systemName   = options.systemName   || cyclone.name || cyclone.id || "TD";

    const COLORS = {
        ocean:      "#093454",
        land:       "#5a9e56",
        landStroke: "#3a7538",
        grid:       "rgba(255, 255, 255, 0.4)",
        trackWhite: "#ffffff",
        uiBlue:     "#003366"
    };

    const INTENSITY_CONFIG = {
        "DB":      { name: "低压区",     color: "#666666", min: 0 },
        "TD":      { name: "热带低压",   color: "#aaaaaa", min: 23 },
        "TS":      { name: "热带风暴",   color: "#00ffcc", min: 34 },
        "STS":     { name: "强热带风暴", color: "#ffff00", min: 48 },
        "TY":      { name: "台风",       color: "#ff9900", min: 64 },
        "STY":     { name: "强台风",     color: "#ff66ff", min: 83 },
        "SuperTY": { name: "超强台风",   color: "#ff0044", min: 113 }
    };

    function getCat(wind) {
        if (wind >= 113) return "SuperTY";
        if (wind >= 83)  return "STY";
        if (wind >= 64)  return "TY";
        if (wind >= 48)  return "STS";
        if (wind >= 34)  return "TS";
        if (wind >= 23)  return "TD";
        return "DB";
    }

    // ================= 概率计算（v3：方向性风圈 + 多模型误差锥加权）=================
    // 物理逻辑：
    //   1. 起报点取实测 r34/r64（四象限，度→km）作为基准风圈
    //   2. 预报时刻 t 的风圈：r(t) = r_base × (intensity(t) / base_intensity)^0.75
    //      指数 0.75 反映风圈扩张慢于强度增长的物理现实
    //   3. 方向性修正：计算参考点相对于台风中心的方位角，
    //      插值对应象限的半径而非取平均，使 NE/SW 不对称风圈正确影响结果
    //   4. 距离评分：
    //      - dist < r_dir（风圈内）：score = 1 - (dist/r_dir)²，平方使边缘衰减更快
    //      - dist >= r_dir（风圈外）：score = exp(-k × (dist - r_dir))，指数衰减
    //        k 由风圈外扩展性决定（强度越高，向外延伸越远）
    //   5. 时间衰减：每小时衰减 0.7%（0.993^h），与预报时效不确定性匹配
    //   6. 多模型误差锥：若有多个 pathForecasts，对各模型单独计算概率后取加权平均
    //      （模型数量越多，集合离散度越高，概率越低）
    function calculateProbabilities() {
        // --- 辅助：从方位角 + 四象限半径插值该方向的半径 ---
        // bearing: 气象方位角（0=北，顺时针）, radii: [NE, SE, SW, NW] (km)
        function directionalRadius(bearing, radii) {
            const b = ((bearing % 360) + 360) % 360;
            // 四象限边界：NE 0-90, SE 90-180, SW 180-270, NW 270-360
            let r;
            if (b < 90) {
                // NE 象限内，在 NE(0)→SE(90) 之间按方位角插值
                const frac = b / 90;
                r = radii[0] * (1 - frac) + radii[1] * frac;
            } else if (b < 180) {
                const frac = (b - 90) / 90;
                r = radii[1] * (1 - frac) + radii[2] * frac;
            } else if (b < 270) {
                const frac = (b - 180) / 90;
                r = radii[2] * (1 - frac) + radii[3] * frac;
            } else {
                const frac = (b - 270) / 90;
                r = radii[3] * (1 - frac) + radii[0] * frac;
            }
            return Math.max(0, r);
        }

        // --- 辅助：计算参考点相对于台风中心的气象方位角（0=北，顺时针）---
        function bearingTo(fromLat, fromLon, toLat, toLon) {
            const dLon = (toLon - fromLon) * Math.PI / 180;
            const lat1 = fromLat * Math.PI / 180;
            const lat2 = toLat   * Math.PI / 180;
            const y = Math.sin(dLon) * Math.cos(lat2);
            const x = Math.cos(lat1) * Math.sin(lat2)
                    - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
            return ((Math.atan2(y, x) * 180 / Math.PI) + 360) % 360;
        }

        // --- 提取起报点实测风圈基准 ---
        const basePoint = rawTrack[rawTrack.length - 1];
        const baseIntensity = Math.max(1, (basePoint && basePoint[2]) || cyclone.intensity || 20);
        // r34/r64: [NE, SE, SW, NW]，单位：度 → km
        const r34baseDeg = (basePoint && Array.isArray(basePoint[7])) ? basePoint[7] : null;
        const r64baseDeg = (basePoint && Array.isArray(basePoint[9])) ? basePoint[9] : null;
        // 无实测时按强度粗估（34kt 对应约 200km，线性推算）
        const r34baseKm = r34baseDeg
            ? r34baseDeg.map(v => v * 111.32)
            : [1,1,1,1].map(() => Math.max(0, (baseIntensity - 20) * 5.5));
        const r64baseKm = r64baseDeg
            ? r64baseDeg.map(v => v * 111.32)
            : r34baseKm.map(v => v * 0.42);

        // --- 单模型概率计算（对一条预报路径） ---
        function calcForTrack(fData) {
            let maxT1 = 0, maxT2 = 0;
            const hoursPerStep = 3;
            const samples = 8;

            for (let i = 0; i < fData.length - 1; i++) {
                const p1 = fData[i], p2 = fData[i + 1];
                for (let s = 0; s <= samples; s++) {
                    const t = s / samples;
                    const cInten = p1.intensity + t * (p2.intensity - p1.intensity);
                    const cLat   = p1.lat       + t * (p2.lat - p1.lat);
                    const cLon   = p1.lon       + t * (p2.lon - p1.lon);

                    if (cInten < 34) continue; // 低于八号信号阈值，跳过

                    const leadHours  = (i + t) * hoursPerStep;
                    const timeDecay  = Math.pow(0.993, leadHours);

                    // 强度驱动的风圈缩放（指数 0.75，风圈扩张慢于强度）
                    const intensityScale = Math.pow(cInten / baseIntensity, 0.75);
                    const r34km = r34baseKm.map(v => v * intensityScale);
                    const r64km = r64baseKm.map(v => v * intensityScale);

                    // 参考点到台风中心的距离和方位
                    const dist    = calculateDistance(cLat, cLon, refPoint.lat, refPoint.lon);
                    const bearing = bearingTo(cLat, cLon, refPoint.lat, refPoint.lon);

                    // T8（34kt）概率
                    const r34dir = directionalRadius(bearing, r34km);
                    let t1 = 0;
                    if (r34dir > 0) {
                        // 设置“擦边”时的保底概率，85% 代表只要碰到了风圈边缘，概率极高
                        const grazeProb = 0.85; 

                        if (dist <= r34dir) {
                            // 风圈内：平缓衰减。中心是 100%，边缘是 85%
                            // 公式：1.0 - 0.15 * (距离/半径)^2
                            t1 = (1.0 - (1.0 - grazeProb) * Math.pow(dist / r34dir, 2)) * timeDecay;
                        } else {
                            // 风圈外：指数衰减，从 85% 开始往外降
                            // 减小了分子(1.0)，增大了分母(80, r34dir*0.5)，使衰减变得更慢（更宽松）
                            const k34 = 1.0 / Math.max(80, r34dir * 0.5);
                            t1 = grazeProb * Math.exp(-k34 * (dist - r34dir)) * timeDecay;
                        }
                    }
                    maxT1 = Math.max(maxT1, Math.min(1, Math.max(0, t1)));

                    // T10（64kt）概率
                    if (maxT1 >= 0.9) {
                        const r64dir = directionalRadius(bearing, r64km);
                        let t2 = 0;
                        if (r64dir > 0) {
                            const grazeProb = 0.85; 
                            if (dist <= r64dir) {
                                t2 = (1.0 - (1.0 - grazeProb) * Math.pow(dist / r64dir, 2)) * timeDecay;
                            } else {
                                const k64 = 2.0 / Math.max(30, r64dir * 0.3);
                                t2 = Math.exp(-k64 * (dist - r64dir)) * 0.85 * timeDecay;
                            }
                        }
                        maxT2 = Math.max(maxT2, Math.min(1, Math.max(0, t2)));
                    }
                }
            }
            return { t8: maxT1, t10: maxT2 };
        }
        // --- 多模型集合：对所有 pathForecasts 分别计算，加权平均 ---
        // 模型数量越多，集合离散度通常越大，用模型数适当压低置信度
        const allModels = (pathForecasts && pathForecasts.length > 0)
            ? pathForecasts.map(m => {
                // 将 m.track 转换为 forecastData 格式
                const cutIdx = (() => {
                    let idx = m.track.length - 1;
                    for (let k = m.track.length - 1; k >= 0; k--) {
                        if ((m.track[k][2] || 0) >= 15) { idx = k; break; }
                    }
                    return idx;
                })();
                return m.track.slice(0, cutIdx + 1).map((p, i) => ({
                    lon: p[0], lat: p[1],
                    intensity: p[2] || cyclone.intensity || 20
                }));
              })
            : [forecastData]; // 无多模型时退化为主模式

        const results = allModels.map(calcForTrack);
        // 集合平均，并用 sqrt(n)/n 适当压低（模型越多不确定性越大）
        const n = results.length;
        const ensembleWeight = n > 1 ? 1 / Math.sqrt(n) * 1.2 : 1.0;
        const t8  = Math.min(1, results.reduce((s, r) => s + r.t8,  0) / n * ensembleWeight);
        const t10 = Math.min(1, results.reduce((s, r) => s + r.t10, 0) / n * ensembleWeight);

        return { t8, t10 };
    }
    const probResult = calculateProbabilities();

    // ================= 1. 初始化 SVG 图层 =================
    d3.select(container).html("");

    const svg = d3.select(container)
        .append("svg")
        .attr("width", exportWidth)
        .attr("height", exportHeight)
        .attr("viewBox", `0 0 ${baseWidth} ${baseHeight}`)
        .style("max-width", "100%")
        .style("height", "auto")
        .attr("xmlns", "http://www.w3.org/2000/svg");

    const defs = svg.append("defs");

    // 科幻发光滤镜
    const glowFilter = defs.append("filter")
        .attr("id", "neonGlow_exact")
        .attr("x", "-30%").attr("y", "-30%")
        .attr("width", "160%").attr("height", "160%");
    glowFilter.append("feGaussianBlur").attr("stdDeviation", "3.5").attr("result", "blur");
    const feMerge = glowFilter.append("feMerge");
    feMerge.append("feMergeNode").attr("in", "blur");
    feMerge.append("feMergeNode").attr("in", "SourceGraphic");

    // 标题栏渐变
    const headerGradient = defs.append("linearGradient")
        .attr("id", "headerGrad_exact")
        .attr("x1", "0%").attr("y1", "0%")
        .attr("x2", "100%").attr("y2", "0%");
    headerGradient.append("stop").attr("offset", "0%").attr("stop-color", "#0b162c");
    headerGradient.append("stop").attr("offset", "100%").attr("stop-color", "#1a365d");

    // 海洋底色
    svg.append("rect").attr("width", baseWidth).attr("height", baseHeight).attr("fill", COLORS.ocean);

    const gGrid     = svg.append("g");
    const gMap      = svg.append("g");
    const gWarning  = svg.append("g");
    const gConeFill = svg.append("g");
    const gWindRadii = svg.append("g");
    const gTrack    = svg.append("g");
    const gHeader   = svg.append("g");
    const gUI       = svg.append("g");

    // ================= 2. 投影计算 =================
    const allData = [...historyData, ...forecastData];
    const centerLon = d3.mean(forecastData, d => d.lon);
    const centerLat = d3.mean(forecastData, d => d.lat);

    const projection = d3.geoConicConformal()
        .center([0, centerLat])
        .rotate([-centerLon, 0])
        .parallels([10, 60]);

    const minLon = Math.min(...forecastData.map(d => d.lon)) - 4;
    const maxLon = Math.max(...forecastData.map(d => d.lon)) + 4;
    const minLat = Math.min(...forecastData.map(d => d.lat)) - 6;
    const maxLat = Math.max(...forecastData.map(d => d.lat)) + 4;

    projection.fitExtent([[0, 60], [baseWidth, baseHeight + 80]], {
        type: "FeatureCollection",
        features: [
            { type: "Feature", geometry: { type: "Point", coordinates: [minLon, minLat] } },
            { type: "Feature", geometry: { type: "Point", coordinates: [maxLon, maxLat] } }
        ]
    });

    const pathGenerator = d3.geoPath().projection(projection);

    // ================= 3. 经纬网与地图 =================
    const graticule = d3.geoGraticule().step([10, 10]);
    gGrid.selectAll("path.grid")
        .data(graticule.lines())
        .enter().append("path")
        .attr("class", "grid")
        .attr("d", pathGenerator)
        .attr("fill", "none")
        .attr("stroke", COLORS.grid)
        .attr("stroke-width", 0.8);

    // 优先使用调用方已传入的 worldData，否则回退到网络加载
    try {
        let geoData = worldData;
        if (!geoData || !geoData.objects) {
            geoData = await d3.json("https://unpkg.com/world-atlas@2.0.2/countries-50m.json");
        }
        const topoKey = geoData.objects.countries ? 'countries' : 'land';
        const geoFeature = topojson.feature(geoData, geoData.objects[topoKey]);
        gMap.selectAll("path")
            .data(geoFeature.features)
            .enter().append("path")
            .attr("d", pathGenerator)
            .attr("fill", COLORS.land)
            .attr("stroke", COLORS.landStroke)
            .attr("stroke-width", 0.5);
    } catch(e) { console.warn("地图数据加载失败:", e); }

    // ================= 香港 400km 警戒圈 =================
    const circleGenerator = d3.geoCircle().center([refPoint.lon, refPoint.lat]).radius(400 / 111.32);
    gWarning.append("path")
        .datum(circleGenerator())
        .attr("d", pathGenerator)
        .attr("fill", "none")
        .attr("stroke", "rgba(255,255,255,0.4)")
        .attr("stroke-width", 1.5)
        .attr("stroke-dasharray", "8,5");

    const edgePoint = projection([refPoint.lon, refPoint.lat + (400 / 111.32)]);
    gWarning.append("text")
        .attr("x", edgePoint[0]).attr("y", edgePoint[1] - 5)
        .attr("fill", "rgba(255,255,255,0.6)").attr("font-size", "12px").attr("text-anchor", "middle")
        .text("400km");

    // ================= 4. 坐标转换 =================
    const centerP    = projection([centerLon, centerLat]);
    const centerP_up = projection([centerLon, centerLat + 0.1]);
    const pxPerDegLat = Math.sqrt(
        Math.pow(centerP_up[0] - centerP[0], 2) +
        Math.pow(centerP_up[1] - centerP[1], 2)
    ) * 10;

    const pixels = allData.map(d => {
        const [x, y] = projection([d.lon, d.lat]);
        const rPx = (d.radius || 0) / 111.32 * pxPerDegLat;
        return { x, y, r: rPx, label: d.label, intensity: d.intensity };
    });

    // ================= 5. 不确定性圆锥 =================
    const coneGroup = gConeFill.append("g")
        .attr("fill", "white").attr("opacity", "0.15").attr("stroke", "none");

    for (let i = historyData.length; i < pixels.length - 1; i++) {
        const c1 = pixels[i], c2 = pixels[i+1];
        if (c2.r > 0) {
            coneGroup.append("circle").attr("cx", c2.x).attr("cy", c2.y).attr("r", c2.r);
            const dx = c2.x - c1.x, dy = c2.y - c1.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            const angle = Math.atan2(dy, dx);
            if (c1.r < 1) {
                const angleOffset = Math.asin(Math.min(1, c2.r / dist));
                const t1_x = c2.x + c2.r * Math.cos(angle - angleOffset - Math.PI/2);
                const t1_y = c2.y + c2.r * Math.sin(angle - angleOffset - Math.PI/2);
                const t2_x = c2.x + c2.r * Math.cos(angle + angleOffset + Math.PI/2);
                const t2_y = c2.y + c2.r * Math.sin(angle + angleOffset + Math.PI/2);
                coneGroup.append("polygon").attr("points", `${c1.x},${c1.y} ${t1_x},${t1_y} ${t2_x},${t2_y}`);
            } else {
                const diff = c1.r - c2.r;
                const safeDist = Math.max(dist, Math.abs(diff) + 0.1);
                const beta = Math.acos(diff / safeDist);
                const x1_l = c1.x + c1.r * Math.cos(angle + beta), y1_l = c1.y + c1.r * Math.sin(angle + beta);
                const x2_l = c2.x + c2.r * Math.cos(angle + beta), y2_l = c2.y + c2.r * Math.sin(angle + beta);
                const x1_r = c1.x + c1.r * Math.cos(angle - beta), y1_r = c1.y + c1.r * Math.sin(angle - beta);
                const x2_r = c2.x + c2.r * Math.cos(angle - beta), y2_r = c2.y + c2.r * Math.sin(angle - beta);
                coneGroup.append("polygon").attr("points", `${x1_l},${y1_l} ${x2_l},${y2_l} ${x2_r},${y2_r} ${x1_r},${y1_r}`);
            }
        }
    }

    // ================= 5.5 四象限风圈（从 cyclone.track 读取真实风圈数据）=================
    // track 格式: [lon, lat, intensity, isT, isE, circulationSize, isS, r34, r50, r64, ...]
    // r34/r64 均为 [NE, SE, SW, NW]，单位：度
    const currentP = pixels[historyData.length];
    const currentTrackPoint = rawTrack[rawTrack.length - 1];
    if (currentP && currentTrackPoint) {
        const cLon = currentTrackPoint[0];
        const cLat = currentTrackPoint[1];
        const r34deg = Array.isArray(currentTrackPoint[7]) ? currentTrackPoint[7] : [0,0,0,0];
        const r50deg = Array.isArray(currentTrackPoint[8]) ? currentTrackPoint[8] : [0,0,0,0];
        const r64deg = Array.isArray(currentTrackPoint[9]) ? currentTrackPoint[9] : [0,0,0,0];

        // 用地理坐标密集采样 + 投影绘制风圈
        // 关键：象限半径为 0 时，该象限退化为"回到中心"，
        //       用中心点代替弧线，形成正确的扇形/饼图轮廓
        const WIND_STEPS = 30;
        const cosLat = Math.cos(cLat * Math.PI / 180);
        const centerPx = projection([cLon, cLat]); // 台风中心屏幕坐标
        const drawWindRing = (rDeg, strokeColor, fillColor, fillOpacity) => {
            if (!rDeg || rDeg.every(v => v <= 0)) return;
            const quadrants = [
                { r: rDeg[0], start: 0,   end: 90  }, // NE
                { r: rDeg[1], start: 90,  end: 180 }, // SE
                { r: rDeg[2], start: 180, end: 270 }, // SW
                { r: rDeg[3], start: 270, end: 360 }, // NW
            ];

            // 构建路径段列表：每段是一组屏幕坐标点
            // 零半径象限插入中心点，使路径正确收拢而不是乱连
            const pathPts = [];
            let prevWasZero = false;

            quadrants.forEach(({ r, start, end }, qi) => {
                if (r <= 0) {
                    // 缺失象限：插入中心点（仅插一次，避免重复）
                    if (!prevWasZero && centerPx) pathPts.push(centerPx);
                    prevWasZero = true;
                } else {
                    // 若前一象限是零（刚从中心出发），先插中心点作为起点
                    if (prevWasZero && centerPx) pathPts.push(centerPx);
                    prevWasZero = false;
                    for (let s = 0; s <= WIND_STEPS; s++) {
                        const bearingDeg = start + (end - start) * s / WIND_STEPS;
                        const bearingRad = bearingDeg * Math.PI / 180;
                        const dLat = r * Math.cos(bearingRad);
                        const dLon = r * Math.sin(bearingRad) / cosLat;
                        const pt = projection([cLon + dLon, cLat + dLat]);
                        if (pt) pathPts.push(pt);
                    }
                }
            });

            if (pathPts.length < 3) return;
            const d = pathPts.map((p, i) =>
                `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(2)},${p[1].toFixed(2)}`
            ).join(' ') + ' Z';
            gWindRadii.append("path")
                .attr("d", d)
                .attr("fill", fillColor).attr("fill-opacity", fillOpacity)
                .attr("stroke", strokeColor).attr("stroke-width", 1.5);
        };

        drawWindRing(r34deg, "#ffcc00", "#ffcc00", 0.12); // 七级风（34kt）黄圈
        drawWindRing(r50deg, "#ff9900", "#ff9900", 0.15); // 十级风（50kt）橙圈
        drawWindRing(r64deg, "#ff0044", "#ff0044", 0.25); // 十二级风（64kt）红圈
    }

    // ================= 6. 路径线 =================
    const lineGen = d3.line().x(d => d.x).y(d => d.y);

    const historyPixels  = pixels.slice(0, historyData.length + 1);
    const forecastPixels = pixels.slice(historyData.length);

    gTrack.append("path")
        .attr("d", lineGen(historyPixels))
        .attr("fill", "none").attr("stroke", COLORS.trackWhite).attr("stroke-width", 2);

    gTrack.append("path")
        .attr("d", lineGen(forecastPixels))
        .attr("fill", "none").attr("stroke", COLORS.trackWhite)
        .attr("stroke-width", 1.5).attr("stroke-dasharray", "6, 4");

    // 预报锥不画描边切线，仅保留各显示点上的虚线圆（在 pixels.forEach 中处理）


    // ================= 7. 分级点位图标 =================
    function drawPointMarker(group, x, y, intensity) {
        const cat   = getCat(intensity);
        const color = INTENSITY_CONFIG[cat].color;
        const g = group.append("g").attr("transform", `translate(${x}, ${y})`);
        if (cat === "STY" || cat === "SuperTY") g.attr("filter", "url(#neonGlow_exact)");

        if (cat === "TD") {
            g.append("circle").attr("r", 4.5).attr("fill", "none").attr("stroke", color).attr("stroke-width", 1.5).attr("stroke-dasharray", "2,2");
            g.append("circle").attr("r", 1.5).attr("fill", color);
        } else if (cat === "TS") {
            g.append("circle").attr("r", 4.5).attr("fill", color);
            g.append("circle").attr("r", 2).attr("fill", "#222");
            g.append("circle").attr("r", 7).attr("fill", "none").attr("stroke", color).attr("stroke-width", 1).attr("opacity", 0.7);
        } else if (cat === "STS") {
            g.append("circle").attr("r", 4.5).attr("fill", color);
            g.append("circle").attr("r", 1.5).attr("fill", "#222");
            g.append("path").attr("d", "M -7.5,0 A 7.5,7.5 0 0,1 0,-7.5").attr("fill", "none").attr("stroke", color).attr("stroke-width", 1.5);
            g.append("path").attr("d", "M 7.5,0 A 7.5,7.5 0 0,1 0,7.5").attr("fill", "none").attr("stroke", color).attr("stroke-width", 1.5);
        } else if (cat === "TY") {
            g.append("circle").attr("r", 4.5).attr("fill", "none").attr("stroke", color).attr("stroke-width", 2);
            g.append("circle").attr("r", 1.5).attr("fill", color);
            g.append("path").attr("d", "M -4.5,0 C -9,0 -10,-2 -11,-6").attr("fill", "none").attr("stroke", color).attr("stroke-width", 2).attr("stroke-linecap", "round");
            g.append("path").attr("d", "M 4.5,0 C 9,0 10,2 11,6").attr("fill", "none").attr("stroke", color).attr("stroke-width", 2).attr("stroke-linecap", "round");
        } else if (cat === "STY") {
            g.append("circle").attr("r", 5).attr("fill", "none").attr("stroke", color).attr("stroke-width", 2.5);
            g.append("circle").attr("r", 2).attr("fill", color);
            g.append("path").attr("d", "M -5,0 C -10,0 -11,-3 -12,-8").attr("fill", "none").attr("stroke", color).attr("stroke-width", 2.5).attr("stroke-linecap", "round");
            g.append("path").attr("d", "M 5,0 C 10,0 11,3 12,8").attr("fill", "none").attr("stroke", color).attr("stroke-width", 2.5).attr("stroke-linecap", "round");
            g.append("circle").attr("r", 11).attr("fill", "none").attr("stroke", color).attr("stroke-width", 1.5).attr("opacity", 0.6);
        } else if (cat === "SuperTY") {
            g.append("circle").attr("r", 6).attr("fill", "none").attr("stroke", color).attr("stroke-width", 3);
            g.append("circle").attr("r", 2.5).attr("fill", color);
            g.append("path").attr("d", "M -6,0 C -12,0 -14,-4 -15,-10").attr("fill", "none").attr("stroke", color).attr("stroke-width", 3).attr("stroke-linecap", "round");
            g.append("path").attr("d", "M 6,0 C 12,0 14,4 15,10").attr("fill", "none").attr("stroke", color).attr("stroke-width", 3).attr("stroke-linecap", "round");
            g.append("circle").attr("r", 13).attr("fill", "none").attr("stroke", color).attr("stroke-width", 2).attr("opacity", 0.8);
            g.append("circle").attr("r", 17).attr("fill", "none").attr("stroke", color).attr("stroke-width", 1).attr("stroke-dasharray", "4,3").attr("opacity", 0.6);
        } else {
            // DB
            g.append("circle").attr("r", 4).attr("fill", color).attr("opacity", 0.8);
        }
    }

    // 强度取整到5的倍数
    function roundToFive(v) { return Math.round(v / 5) * 5; }

    pixels.forEach((p, i) => {
        // 判断是否是预报区域的点（i >= historyData.length 为预报点）
        const isForecastPoint = i >= historyData.length;
        // 预报点的索引（从0开始，0是起报点）
        const forecastIdx = i - historyData.length;
        // 历史点：每 2 步（=6 小时）显示一个图标
        // 预报点：起报点(forecastIdx=0) + 每 8 步（=24 小时）
        const shouldDrawMarker = !isForecastPoint
            ? (i % 2 === 0)
            : (forecastIdx === 0 || forecastIdx % 8 === 0);

        // 虚线预报圈：仅在需要绘制图标的点上显示（与图标频率同步）
        if (p.r > 1 && shouldDrawMarker) {
            gTrack.append("circle")
                .attr("cx", p.x).attr("cy", p.y).attr("r", p.r)
                .attr("fill", "none").attr("stroke", "rgba(255,255,255,0.7)")
                .attr("stroke-width", 1.5).attr("stroke-dasharray", "6, 4");
        }

        if (shouldDrawMarker) {
            drawPointMarker(gTrack, p.x, p.y, p.intensity);
        }

        if (p.label) {
            gTrack.append("text")
                .attr("x", p.x + 16).attr("y", p.y - 12).attr("dy", "0.3em")
                .text(p.label)
                .attr("font-size", "15px").attr("font-family", "sans-serif")
                .attr("font-weight", "bold").attr("fill", "white")
                .attr("stroke", COLORS.ocean).attr("stroke-width", 3.5)
                .attr("stroke-linejoin", "round").attr("paint-order", "stroke");
        }

        // 当前位置底座（起报点）
        if (i === historyData.length) {
            const roundedIntensity = roundToFive(p.intensity);
            const cat = getCat(roundedIntensity);
            const sysIntensity = INTENSITY_CONFIG[cat];
            const currentName = `${systemName} ${roundedIntensity}KT`;
            const textWidth = 110;
            gTrack.append("rect")
                .attr("x", p.x - textWidth / 2).attr("y", p.y + 16)
                .attr("width", textWidth).attr("height", 30)
                .attr("rx", 15).attr("ry", 15)
                .attr("fill", "#2c3e50").attr("stroke", sysIntensity.color)
                .attr("stroke-width", 1.5).attr("filter", "url(#neonGlow_exact)");
            gTrack.append("text")
                .attr("x", p.x).attr("y", p.y + 31).attr("dy", "0.35em")
                .attr("text-anchor", "middle").text(currentName)
                .attr("font-size", "15px").attr("font-family", "sans-serif")
                .attr("font-weight", "bold").attr("fill", "white");
        }
    });

    // ================= 8. 标题栏 =================
    function drawHeader() {
        const hHeight = 55;
        gHeader.append("rect").attr("width", baseWidth).attr("height", hHeight).attr("fill", "url(#headerGrad_exact)");
        gHeader.append("line")
            .attr("x1", 0).attr("y1", hHeight).attr("x2", baseWidth).attr("y2", hHeight)
            .attr("stroke", "rgba(255,255,255,0.4)").attr("stroke-width", 1);

        // 气旋 ICON
        const gIcon = gHeader.append("g").attr("transform", "translate(34, 28) scale(1.2) rotate(90)");
        const iconColor = "#fffff6";
        const sw = 3.6;
        gIcon.append("path").attr("d", "M -3,0 C -7,0 -9,-2 -10,-6")
            .attr("fill", "none").attr("stroke", iconColor).attr("stroke-width", sw).attr("stroke-linecap", "round");
        gIcon.append("path").attr("d", "M 3,0 C 7,0 9,2 10,6")
            .attr("fill", "none").attr("stroke", iconColor).attr("stroke-width", sw).attr("stroke-linecap", "round");
        gIcon.append("circle").attr("cx", 0).attr("cy", 0).attr("r", 4.5)
            .attr("fill", "none").attr("stroke", iconColor).attr("stroke-width", sw);
        gIcon.append("circle").attr("cx", 0).attr("cy", 0).attr("r", 2.7).attr("fill", "#0b162c");

        // 标题文字
        const startCat = getCat(forecastData[0].intensity);
        const sysIntensity = INTENSITY_CONFIG[startCat];
        const titleText = gHeader.append("text").attr("x", 60).attr("y", 34)
            .attr("font-size", "24px").attr("font-weight", "900")
            .attr("fill", "white").style("text-shadow", "0 2px 4px rgba(0,0,0,0.5)");
        titleText.append("tspan").attr("fill", sysIntensity.color).text(`${sysIntensity.name} ${systemName}`);
        titleText.append("tspan").attr("fill", "white").text(` 未来${quantizedLimit * 3}小时路径预报图(ENAI)`);

        const currentYear = simulationDate(cyclone, currentSimAge).getUTCFullYear();
        gHeader.append("text")
            .attr("x", baseWidth - 25).attr("y", 34)
            .attr("text-anchor", "end")
            .attr("fill", "rgba(255,255,255,0.6)").attr("font-size", "12px")
            .style("font-family", "'Montserrat', 'Segoe UI', 'PingFang SC', sans-serif")
            .style("font-weight", "300").style("letter-spacing", "2px")
            .text(`制图 @ICWCWNP / ${currentYear} / ${simHoursToCST(currentSimAge)}`);
    }
    drawHeader();

    // ================= 信号概率挂件 =================
    function drawSignalWidget() {
        const showT10 = probResult.t10 > 0;
        const finalProb = Math.round((showT10 ? probResult.t10 : probResult.t8) * 100);
        const gWidget = gUI.append("g").attr("transform", "translate(20, 75)");
        gWidget.append("rect").attr("width", 260).attr("height", 42).attr("rx", 6)
            .attr("fill", "rgba(0,10,25,0.8)").attr("stroke", "rgba(255,255,255,0.2)");

        const gIcon = gWidget.append("g").attr("transform", "translate(24, 21)");
        if (showT10) {
            gIcon.append("path").attr("d", "M -8,-2.5 H -2.5 V -8 H 2.5 V -2.5 H 8 V 2.5 H 2.5 V 8 H -2.5 V 2.5 H -8 Z").attr("fill", "#fff");
            gIcon.append("text").attr("x", 12).attr("y", 2).attr("fill", "#ff3333").attr("font-size", "32px").attr("font-family", "Impact").attr("dominant-baseline", "middle").text("10");
        } else {
            const tri = "M -8,3 L 0,-6 L 8,3 Z";
            gIcon.append("path").attr("d", tri).attr("transform", "translate(-2, -6)").attr("fill", "#cceeff");
            gIcon.append("path").attr("d", tri).attr("transform", "translate(-2, 4)").attr("fill", "#cceeff");
            gIcon.append("text").attr("x", 12).attr("y", 2).attr("fill", "#cceeff").attr("font-size", "34px").attr("font-family", "Impact").attr("dominant-baseline", "middle").text("8");
        }
        gWidget.append("text").attr("x", 68).attr("y", 21).attr("dominant-baseline", "middle")
            .attr("fill", "white").attr("font-size", "15px").attr("font-weight", "bold")
            .text(`${showT10 ? '十' : '八'}号信号发出概率：`)
            .append("tspan").attr("fill", "#00ffcc").text(` ${finalProb}%`);
    }
    drawSignalWidget();

    // ================= 9. UI 装饰组件 =================
    function drawUIComponents() {
        // 左下角图例
        const gLegendLeft = gUI.append("g").attr("transform", `translate(20, ${baseHeight - 145})`);
        gLegendLeft.append("rect")
            .attr("width", 180).attr("height", 130).attr("rx", 6).attr("ry", 6)
            .attr("fill", "rgba(0, 20, 40, 0.65)").attr("stroke", "rgba(255,255,255,0.2)").attr("stroke-width", 1);

        // 预报圈图例
        gLegendLeft.append("circle").attr("cx", 25).attr("cy", 22).attr("r", 9)
            .attr("fill", "rgba(255,255,255,0.2)").attr("stroke", COLORS.trackWhite)
            .attr("stroke-width", 1.5).attr("stroke-dasharray", "4, 3");
        gLegendLeft.append("text").attr("x", 45).attr("y", 27).attr("fill", "white").attr("font-size", "14px").attr("font-family", "sans-serif").text("70% 概率预报圈");

        // 七级风圈图例
        gLegendLeft.append("circle").attr("cx", 25).attr("cy", 52).attr("r", 9)
            .attr("fill", "#ffcc00").attr("fill-opacity", 0.4).attr("stroke", "#ffcc00").attr("stroke-width", 1.5);
        gLegendLeft.append("text").attr("x", 45).attr("y", 57).attr("fill", "white").attr("font-size", "14px").attr("font-family", "sans-serif").text("七级风圈 (大风)");

        // 十级风圈图例
        gLegendLeft.append("circle").attr("cx", 25).attr("cy", 82).attr("r", 9)
            .attr("fill", "#ffaa42").attr("fill-opacity", 0.4).attr("stroke", "#ffaa42").attr("stroke-width", 1.5);
        gLegendLeft.append("text").attr("x", 45).attr("y", 87).attr("fill", "white").attr("font-size", "14px").attr("font-family", "sans-serif").text("十级风圈 (暴风)");

        // 十二级风圈图例
        gLegendLeft.append("circle").attr("cx", 25).attr("cy", 112).attr("r", 9)
            .attr("fill", "#ff0044").attr("fill-opacity", 0.5).attr("stroke", "#ff0044").attr("stroke-width", 1.5);
        gLegendLeft.append("text").attr("x", 45).attr("y", 117).attr("fill", "white").attr("font-size", "14px").attr("font-family", "sans-serif").text("十二级风圈 (飓风)");

        // 右下角强度图例
        const gIntLegend = gUI.append("g").attr("transform", `translate(${baseWidth - 170}, ${baseHeight - 480})`);
        gIntLegend.append("rect")
            .attr("width", 165).attr("height", 240).attr("rx", 6).attr("ry", 6)
            .attr("fill", "rgba(0, 20, 40, 0.75)").attr("stroke", "rgba(255,255,255,0.2)").attr("stroke-width", 1);

        gIntLegend.append("text").attr("x", 82.5).attr("y", 25).attr("text-anchor", "middle")
            .attr("fill", "white").attr("font-size", "15px").attr("font-weight", "bold").attr("letter-spacing", "1px").text("台风强度");

        gIntLegend.append("line")
            .attr("x1", 15).attr("y1", 35).attr("x2", 150).attr("y2", 35)
            .attr("stroke", "rgba(255,255,255,0.3)").attr("stroke-width", 1);

        const legendItems = [
            { wind: 115, label: "超强台风" },
            { wind: 85,  label: "强台风" },
            { wind: 70,  label: "台风" },
            { wind: 55,  label: "强热带风暴" },
            { wind: 40,  label: "热带风暴" },
            { wind: 28,  label: "热带低气压" },
        ];
        legendItems.forEach((item, i) => {
            const yPos = 62 + i * 31;
            drawPointMarker(gIntLegend, 35, yPos, item.wind);
            gIntLegend.append("text")
                .attr("x", 65).attr("y", yPos + 5)
                .attr("fill", "white").attr("font-size", "14px").attr("font-family", "sans-serif")
                .text(item.label);
        });
    }
    drawUIComponents();
// ================= 10. 导出图像按钮 (纯 SVG 内置版) =================
    // 将按钮直接作为 <g> 元素画进 UI 图层，确保它被包含在 return svg.node() 中
    const btnGroup = gUI.append("g")
        .attr("transform", `translate(${baseWidth - 140}, 20)`)
        .style("cursor", "pointer")
        .attr("id", "export-btn-group");

    const btnRect = btnGroup.append("rect")
        .attr("width", 120)
        .attr("height", 36)
        .attr("rx", 4)
        .attr("fill", "rgba(0, 51, 102, 0.8)")
        .attr("stroke", "#00ffcc")
        .attr("stroke-width", 1);

    const btnText = btnGroup.append("text")
        .attr("x", 60)
        .attr("y", 23)
        .attr("text-anchor", "middle")
        .attr("fill", "#00ffcc")
        .attr("font-size", "14px")
        .attr("font-weight", "bold")
        .text("⬇ 导出为 PNG");

    // 模拟 Hover 交互效果
    btnGroup.on("mouseover", function() {
        btnRect.attr("fill", "#00ffcc");
        btnText.attr("fill", "#0b162c");
    }).on("mouseout", function() {
        btnRect.attr("fill", "rgba(0, 51, 102, 0.8)");
        btnText.attr("fill", "#00ffcc");
    });

    // 点击事件
    btnGroup.on("click", function() {
        // 1. 截图前先隐藏按钮组，避免按钮出现在导出的气象图中
        btnGroup.attr("display", "none");

        // 2. 给一点微小的延迟，确保 DOM 隐藏渲染完毕后再抽数据
        setTimeout(() => {
            const svgNode = svg.node();
            const serializer = new XMLSerializer();
            let svgString = serializer.serializeToString(svgNode);

            // 补充命名空间
            if (!svgString.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)) {
                svgString = svgString.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
            }

            const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
            const url = URL.createObjectURL(svgBlob);

            const canvas = document.createElement("canvas");
            canvas.width = exportWidth;
            canvas.height = exportHeight;
            const ctx = canvas.getContext("2d");

            const img = new Image();
            img.onload = function() {
                // 绘制深海背景色兜底
                ctx.fillStyle = COLORS.ocean;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制 SVG 到 Canvas
                ctx.drawImage(img, 0, 0, exportWidth, exportHeight);
                URL.revokeObjectURL(url);

                // 导出为 PNG
                const imgURL = canvas.toDataURL("image/png");
                const a = document.createElement("a");
                a.download = `${systemName}_路径预报_${simHoursToCST(currentSimAge)}.png`;
                a.href = imgURL;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);

                // 3. 导出流程结束后，恢复显示按钮
                btnGroup.attr("display", "block");
            };
            img.src = url;
        }, 50);
    });
    // 返回 SVG 节点，方便外部保存
    return svg.node();
}


export function height500Bounds(lon, lat) {
    // Keep the 40°-tall chart inside the model's ±85° valid latitude range.
    // A ±70° center would otherwise request latitudes beyond 85° near the poles.
    const centerLat = Math.max(-65, Math.min(65, lat));
    // 经度跨度 60° (±30°)，纬度跨度 40° (±20°)，完美匹配 1500:1000 (3:2) 画布比例
    return { west: lon - 30, east: lon + 30, south: centerLat - 20, north: centerLat + 20, centerLat };
}

function renderHeightChart(
    cyclone, timeIndex, worldData, systems, level = 500, precomputedGrid = null, geography = null
) {
    const point = cyclone.track[timeIndex];
    if (!point || !systems?.upper?.length) throw new Error('No height field at this time');
    const [lon, lat] = point;
    const chartCyclone = {
        ...cyclone,
        lon,
        lat,
        intensity: Number.isFinite(point[2]) ? point[2] : cyclone.intensity,
        ...historicalCyclonePhase(cyclone, timeIndex),
        circulationSize: point[5] || cyclone.circulationSize,
        isSubtropical: point[6] ?? cyclone.isSubtropical,
        status: 'active'
    };
    const bounds = height500Bounds(lon, lat);
    
    const canvas = document.createElement('canvas');
    canvas.width = 1650; canvas.height = 1240;
    const ctx = canvas.getContext('2d');
    
    // 设置画布内框：宽 1500px，高 1000px
    const left = 80, top = 135, width = 1500, height = 1000;
    
    ctx.fillStyle = '#f7f8f6'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#203746'; ctx.textBaseline = 'middle'; ctx.font = 'bold 30px Arial';
    const contourStep = level === 200 ? 60 : 20;
    const majorContourStep = level === 200 ? 240 : 80;
    const contourReference = level === 200 ? 12000 : 5880;
    ctx.fillText(`${level} hPa GEOPOTENTIAL HEIGHT`, left, 42);
    const date = simulationDate(cyclone, timeIndex * 3);
    ctx.font = '18px Arial';
    ctx.fillText(`VALID ${date.toISOString().slice(0,16).replace('T',' ')}Z`, left, 82);
    ctx.textAlign = 'right'; ctx.fillText(`CONTOURS ${contourStep} m`, left + width, 82);
    
    ctx.save(); ctx.beginPath(); ctx.rect(left, top, width, height); ctx.clip();
    ctx.fillStyle = '#aed6f1'; ctx.fillRect(left, top, width, height);

    // 投影适配 60 度经度跨度和 1500px 宽度
    const projection = d3.geoEquirectangular().rotate([-lon, 0]).center([0, bounds.centerLat])
        .scale(width / (60 * Math.PI / 180)).translate([left + width / 2, top + height / 2])
        .clipExtent([[left, top], [left + width, top + height]]);

    const geoPath = d3.geoPath(projection, ctx);
    if (worldData) {
        ctx.fillStyle = '#a8efaf'; ctx.strokeStyle = '#999'; ctx.lineWidth = 1;
        if (geography) { ctx.fill(geography.land); ctx.stroke(geography.land); }
        else { ctx.beginPath(); geoPath(worldData); ctx.fill(); ctx.stroke(); }
        ctx.strokeStyle = '#778a82';
        if (geography) ctx.stroke(geography.coast);
        else { ctx.beginPath(); geoPath(synopticCoastline(worldData)); ctx.stroke(); }
    }
    
    // 虚线网格绘制
    ctx.strokeStyle = 'rgba(0,0,0,0.20)'; ctx.lineWidth = 1; ctx.setLineDash([4,5]);
    for(let i = 0; i <= 24; i++) {
        const xOffset = i * width / 24;
        ctx.beginPath(); ctx.moveTo(left + xOffset, top); ctx.lineTo(left + xOffset, top + height); ctx.stroke();
    }
    for(let i = 0; i <= 16; i++) {
        const yOffset = i * height / 16;
        ctx.beginPath(); ctx.moveTo(left, top + yOffset); ctx.lineTo(left + width, top + yOffset); ctx.stroke();
    }
    ctx.setLineDash([]);

    // 采样等高线网格 (根据 1500x1000 按比例采样)
    const nx = 150, ny = 100;
    const values = precomputedGrid ? Array.from(precomputedGrid) : [];
    const lonStep = 60 / (nx - 1);
    const latStep = 40 / (ny - 1);
    const sampleCycloneAnomaly = createCycloneHeightAnomalySampler(chartCyclone, level);
    const sampleEnvironmentalFeedback = createCycloneEnvironmentalHeightFeedbackSampler(
        chartCyclone, level, systems
    );

    if (!precomputedGrid) {
        for(let y = 0; y < ny; y++) {
            for(let x = 0; x < nx; x++) {
                const sampleLon = bounds.west + x * lonStep;
                const sampleLat = bounds.north - y * latStep;
                const environmentalHeight = getGeopotentialHeight500(sampleLon, sampleLat, systems, level);
                const cycloneHeight = sampleCycloneAnomaly(sampleLon, sampleLat);
                const environmentalFeedback = sampleEnvironmentalFeedback(sampleLon, sampleLat);
                values.push(environmentalHeight + cycloneHeight + environmentalFeedback);
            }
        }
    }

    const min = Math.min(...values), max = Math.max(...values);

    // 等高线精准坐标变换映射
    // The contour grid is already the chart's rectangular coordinate system.
    // Re-projecting each point and silently dropping null points lets a
    // dateline/clip boundary join two unrelated segments.  A direct affine
    // mapping keeps every contour line continuous, including wrapped windows.
    const contourTransform = d3.geoTransform({
        point(x, y) {
            this.stream.point(
                left + x * width / (nx - 1),
                top + y * height / (ny - 1)
            );
        }
    });

    const contourPath = d3.geoPath(contourTransform, ctx);
    const contours = d3.contours().size([nx, ny]).thresholds(
        d3.range(Math.ceil(min / contourStep) * contourStep, max + 1, contourStep)
    )(values);
    const labels = [];

    for(const contour of contours) {
        ctx.beginPath(); contourPath(contour);
        ctx.strokeStyle = '#344b58';
        ctx.lineWidth = (contour.value - contourReference) % majorContourStep === 0 ? 2.5 : 1.3;
        ctx.stroke();
        if((contour.value - contourReference) % majorContourStep !== 0) continue;

        const candidates = contour.coordinates.flatMap(p => p.flat()).map(([gx, gy]) => [
            left + gx * width / (nx - 1),
            top + gy * height / (ny - 1)
        ]);

        const candidate = candidates.find(([x, y]) => x > left + 90 && x < left + width - 90 && y > top + 70 && y < top + height - 70 && labels.every(l => Math.hypot(x - l.x, y - l.y) > 150));
        if(candidate) labels.push({x: candidate[0], y: candidate[1], value: contour.value});
    }

    ctx.font = 'bold 19px Arial'; ctx.textAlign = 'center'; ctx.lineJoin = 'round';
    for(const label of labels) {
        ctx.strokeStyle = '#e0e7df'; ctx.lineWidth = 7; ctx.strokeText(String(label.value), label.x, label.y);
        ctx.fillStyle = '#263f4f'; ctx.fillText(String(label.value), label.x, label.y);
    }

    const center = projection([lon, lat]);
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(center[0], center[1], 9, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#ab4238'; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.font = 'bold 20px Arial'; ctx.strokeStyle = '#f7f8f6'; ctx.lineWidth = 5;
    ctx.strokeText('TC', center[0], Math.max(top + 16, center[1] - 25)); 
    ctx.fillStyle = '#ab4238'; ctx.fillText('TC', center[0], Math.max(top + 16, center[1] - 25));
    ctx.restore();

    ctx.strokeStyle = '#344b58'; ctx.lineWidth = 2; ctx.strokeRect(left, top, width, height);

    // 刻度标注：经度 60°（按 15° 递增）、纬度 40°（按 10° 递增）
    const longitudeLabel = x => { const v = ((x + 180) % 360 + 360) % 360 - 180; return `${Math.abs(v).toFixed(1)}°${v < 0 ? 'W' : 'E'}`; };
    ctx.fillStyle = '#526773'; ctx.font = '16px Arial'; ctx.textAlign = 'center';
    
    // 底部经度标注 (5个标注：-30°, -15°, 0°, +15°, +30°)
    for(let i = 0; i <= 4; i++) {
        ctx.fillText(longitudeLabel(bounds.west + i * 15), left + i * width / 4, top + height + 27);
    }
    // 左侧纬度标注 (5个标注：+20°, +10°, 0°, -10°, -20°)
    for(let i = 0; i <= 4; i++) {
        const value = bounds.north - i * 10;
        ctx.save(); ctx.translate(left - 29, top + i * height / 4); ctx.rotate(-Math.PI / 2);
        ctx.fillText(`${Math.abs(value).toFixed(1)}°${value < 0 ? 'S' : 'N'}`, 0, 0); ctx.restore();
    }

    ctx.font = 'bold 16px Arial'; ctx.fillText('GENERATED BY STORM_INC GAME', canvas.width / 2, 1210);
    return canvas;
}

export function renderHeight500Chart(cyclone, timeIndex, worldData, systems) {
    return renderHeightChart(cyclone, timeIndex, worldData, systems, 500);
}

function prepareHeightChartGeography(worldData, lon, lat) {
    const bounds = height500Bounds(lon, lat);
    const projection = d3.geoEquirectangular().rotate([-lon, 0]).center([0, bounds.centerLat])
        .scale(1500 / (60 * Math.PI / 180)).translate([830, 635])
        .clipExtent([[80, 135], [1580, 1135]]);
    return prepareICWCGeography(worldData, projection, true);
}

export async function renderHeight500ChartAsync(cyclone, timeIndex, worldData, systems) {
    const point = cyclone?.track?.[timeIndex];
    if (!point || !systems?.upper?.length) throw new Error('No height field at this time');
    const [lon, lat] = point;
    const geography = await prepareHeightChartGeography(worldData, lon, lat);
    const bounds = height500Bounds(lon, lat);
    const nx = 150, ny = 100;
    const points = new Array(nx * ny);
    let index = 0;
    for (let y = 0; y < ny; y++) {
        const sampleLat = bounds.north - y * 40 / (ny - 1);
        for (let x = 0; x < nx; x++) {
            points[index++] = [bounds.west + x * 60 / (nx - 1), sampleLat];
        }
    }
    const chartCyclone = {
        ...cyclone,
        lon,
        lat,
        intensity: Number.isFinite(point[2]) ? point[2] : cyclone.intensity,
        ...historicalCyclonePhase(cyclone, timeIndex),
        circulationSize: point[5] || cyclone.circulationSize,
        isSubtropical: point[6] ?? cyclone.isSubtropical,
        status: 'active'
    };
    const normalizedSystems = normalizeHeightSystems(systems);
    let grid = await sampleHeight500Grid(points, normalizedSystems, chartCyclone, cyclone.currentMonth || 8, true);
    if (!grid) {
        // Unsupported/lost GPUs must still load historical charts. Yield the
        // 15,000-cell CPU fallback in small UI slices instead of blocking the
        // page inside the synchronous chart renderer for the entire grid.
        grid = new Float32Array(points.length);
        const sampleCycloneAnomaly = createCycloneHeightAnomalySampler(chartCyclone, 500);
        const sampleEnvironmentalFeedback = createCycloneEnvironmentalHeightFeedbackSampler(
            chartCyclone, 500, normalizedSystems
        );
        let sliceStart = performance.now();
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            grid[i] = getGeopotentialHeight500(x, y, normalizedSystems, 500)
                + sampleCycloneAnomaly(x, y)
                + sampleEnvironmentalFeedback(x, y);
            if (performance.now() - sliceStart >= 8) { // half a 60-Hz frame budget
                await new Promise(resolve => setTimeout(resolve, 0));
                sliceStart = performance.now();
            }
        }
    }
    return renderHeightChart(cyclone, timeIndex, worldData, systems, 500, grid, geography);
}

export function renderHeight200Chart(cyclone, timeIndex, worldData, systems) {
    return renderHeightChart(cyclone, timeIndex, worldData, systems, 200);
}

export async function renderHeight200ChartAsync(cyclone, timeIndex, worldData, systems) {
    const point = cyclone?.track?.[timeIndex];
    if (!point || !systems?.upper?.length) throw new Error('No height field at this time');
    const [lon, lat] = point;
    const geography = await prepareHeightChartGeography(worldData, lon, lat);
    const bounds = height500Bounds(lon, lat);
    const chartCyclone = {
        ...cyclone, lon, lat,
        intensity: Number.isFinite(point[2]) ? point[2] : cyclone.intensity,
        ...historicalCyclonePhase(cyclone, timeIndex),
        circulationSize: point[5] || cyclone.circulationSize,
        isSubtropical: point[6] ?? cyclone.isSubtropical,
        status: 'active'
    };
    const nx = 150, ny = 100, grid = new Float64Array(nx * ny);
    const lonStep = 60 / (nx - 1), latStep = 40 / (ny - 1);
    const sampleAnomaly = createCycloneHeightAnomalySampler(chartCyclone, 200);
    const sampleFeedback = createCycloneEnvironmentalHeightFeedbackSampler(chartCyclone, 200, systems);
    let sliceStart = performance.now();
    for (let y = 0; y < ny; y++) for (let x = 0; x < nx; x++) {
        const sampleLon = bounds.west + x * lonStep, sampleLat = bounds.north - y * latStep;
        // Preserve the original sampler, double precision, node order and
        // arithmetic; only yield between completed nodes on a cold grid.
        grid[y * nx + x] = getGeopotentialHeight500(sampleLon, sampleLat, systems, 200)
            + sampleAnomaly(sampleLon, sampleLat) + sampleFeedback(sampleLon, sampleLat);
        if (performance.now() - sliceStart >= 8) {
            await new Promise(resolve => setTimeout(resolve, 0));
            sliceStart = performance.now();
        }
    }
    return renderHeightChart(cyclone, timeIndex, worldData, systems, 200, grid, geography);
}
