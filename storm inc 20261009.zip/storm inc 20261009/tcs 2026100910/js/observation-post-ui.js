import { simulationDate } from './simulation-time.js?v=20261008-forecast-categories1';
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const copy = {
    EN: {
        source:'STORM_INC / 72H OUTLOOK', title:'OBSERVATION POST', issued:'Issued',
        refresh:'Refresh forecast', close:'Close forecast', open:'Observation Post · 72-hour outlook',
        subtitle:'OBSERVATION POST · TROPICAL CYCLONE', distance:'CURRENT DISTANCE',
        level:rank=>'Level '+rank+' of 3', day:i=>'DAY '+i, weather:'WEATHER CONDITION',
        temperature:'TEMPERATURE', gust:'WIND GUST', forecast:'Three-day forecast', notes:'Forecast notes',
        conditions:{Fair:'Fair',Cloudy:'Cloudy',Rain:'Rain','Heavy rain':'Heavy rain',Thunderstorms:'Thunderstorms'},
        unavailable:'Unavailable', noDistance:'Current distance unavailable',
        gauge:(distance,range)=>'Cyclone distance '+distance+' km. Scale 0 to '+range+' km; the white tick marks 400 km.',
        loading:'Preparing the three-day station outlook…', error:'Forecast unavailable. Please retry.',
        noSite:'Set an Observation Post latitude and longitude first.', configure:'Configure post',
        inactive:'Start a simulation to view the three-day outlook. Ended simulations do not issue new forecasts.',
        noTrack:'No complete tropical forecast: uncovered periods use environmental weather only. This does not rule out cyclone impacts.',
        explanation:'Three successive 24-hour outlooks: weather, temperature range and peak gust. Temperature uses in-game SST, land/sea thermal inertia, coastal moderation and elevation, with frontal, sustained cold-air transport, recovery and cloud effects. Cold-surge cooling follows air masses and environmental winds, not a direct conversion from station pressure. No real-world temperature dataset is used. Gusts use surface-wind diagnostics. Not observations or official warnings. Refresh to update the issue time.',
        alerts:{
            none:{rank:0,title:'NO TROPICAL CYCLONE ALERT',rule:'No tropical cyclone alert for this post.'},
            watch:{rank:1,title:'TROPICAL CYCLONE WATCH',rule:'FORECAST WITHIN 72H <b>≤ 400 km</b> · OUTLOOK FOR <b>THIS POST</b>'},
            warning:{rank:2,title:'TROPICAL CYCLONE WARNING',threshold:34},
            special:{rank:3,title:'SPECIAL TROPICAL CYCLONE WARNING',threshold:64}
        },
        probability:(threshold,hours)=>hours+'h '+threshold+' kt SUSTAINED-WIND PROBABILITY AT THIS POST <b>&gt; 70%</b>'
    },
    CN: {
        source:'STORM_INC / 72小时天气展望', title:'观测站', issued:'发布',
        refresh:'刷新天气预报', close:'关闭天气预报', open:'观测站 · 72小时天气展望',
        subtitle:'观测站 · 热带气旋', distance:'当前距离',
        level:rank=>'预警'+rank+'级，共3级', day:i=>'第'+i+'天', weather:'天气状况',
        temperature:'气温', gust:'阵风', forecast:'未来三天预报', notes:'预报说明',
        conditions:{Fair:'晴好',Cloudy:'多云',Rain:'有雨','Heavy rain':'大雨',Thunderstorms:'雷雨'},
        unavailable:'暂无数据', noDistance:'暂无当前距离',
        gauge:(distance,range)=>'气旋当前距离'+distance+' km；刻度为0至'+range+' km，白色刻度标出400 km。',
        loading:'正在推算观测站未来三天天气…', error:'预报暂不可用，请重试。',
        noSite:'请先在设置中填写观测站的经纬度。', configure:'设置观测站',
        inactive:'请启动模拟后查看三天天气预报。模拟结束后不继续发布旧场预报。',
        noTrack:'无完整热带气旋预测：未覆盖时段仅显示环境天气估算，不能据此排除气旋影响。',
        explanation:'未来三个24小时窗口的天气概况、温度范围和最大阵风。温度以游戏内海温为热力背景，根据陆海热惯性和海岸距离估算季节、昼夜响应，再考虑海拔、锋面、持续冷空气输送、回暖与云雨影响。寒潮降温取决于气团及环境风，不由本站气压直接换算。未接入真实温度数据；阵风为地面风诊断估算。非实况或正式预警。刷新可获取当前模拟时刻的新预报。',
        alerts:{
            none:{rank:0,title:'无热带气旋预警',rule:'本站未触发热带气旋预警。'},
            watch:{rank:1,title:'热带气旋注意',rule:'未来72小时预报距离 <b>≤ 400 km</b> · <b>本站天气展望</b>'},
            warning:{rank:2,title:'热带气旋警报',threshold:34},
            special:{rank:3,title:'热带气旋特别警报',threshold:64}
        },
        probability:(threshold,hours)=>'本站'+hours+'小时内'+threshold+' kt持续风累计概率 <b>&gt; 70%</b>'
    }
};
const shapes = [
    '<circle cx="28" cy="28" r="21"/>',
    '<path d="M28 5 51 28 28 51 5 28Z"/>',
    '<path d="M28 5 51 47H5Z"/>',
    '<path d="m28 4 21 12v24L28 52 7 40V16Z"/>'
];
const weatherPaths = {
    Fair:'<circle cx="32" cy="32" r="10"/><path d="M32 6v8m0 36v8M6 32h8m36 0h8M14 14l6 6m24 24 6 6m0-36-6 6M20 44l-6 6"/>',
    Cloudy:'<path d="M16 43a11 11 0 0 1 2-22 15 15 0 0 1 28 3 10 10 0 0 1 4 19Z"/>',
    Rain:'<path d="M16 36a11 11 0 0 1 2-22 15 15 0 0 1 28 3 10 10 0 0 1 4 19Z"/><path d="m22 44-3 9m14-9-3 9m14-9-3 9"/>',
    'Heavy rain':'<path d="M16 32a11 11 0 0 1 2-22 15 15 0 0 1 28 3 10 10 0 0 1 4 19Z"/><path d="m19 39-4 13m16-13-4 13m16-13-4 13m16-13-4 13"/>',
    Thunderstorms:'<path d="M16 32a11 11 0 0 1 2-22 15 15 0 0 1 28 3 10 10 0 0 1 4 19Z"/><path d="m34 35-10 14h10l-7 12M17 40l-3 9m34-9-3 9"/>'
};
function windBarb(kph) {
    // Standard 5 kt visual increments, but the displayed gust stays in kph.
    // This symbol indicates magnitude only, not an invented wind direction.
    const count=Number.isFinite(kph)?Math.round(Math.max(0,kph)/1.852/5):0;
    let remaining=count, x=10, path='M62 38H10', flags='';
    while(remaining>=10){flags+='<path d="M'+x+' 38l7-20 7 20Z" fill="currentColor"/>';x+=16;remaining-=10;}
    while(remaining>=2){path+='M'+x+' 38l7-20';x+=9;remaining-=2;}
    if(remaining)path+='M'+(x===10?18:x)+' 38l4-10';
    return '<svg class="post-wind-barb" viewBox="0 0 72 50" aria-hidden="true"><circle cx="62" cy="38" r="3"/>'+flags+'<path d="'+path+'"/></svg>';
}
function distanceGauge(value, text) {
    if(!Number.isFinite(value) || value<0)
        return '<div class="post-distance"><p class="post-distance-label">'+text.distance+'</p><p class="post-distance-value" aria-label="'+text.noDistance+'">—<small>km</small></p></div>';
    const distance=Math.round(value),range=Math.max(500,Math.ceil(distance/500)*500);
    const angle=d=>Math.PI*(1-d/range),point=(a,r)=>[127.5+r*Math.cos(a),126-r*Math.sin(a)];
    const p=point(angle(distance),100),a=angle(400),t0=point(a,91),t1=point(a,109),label=point(a,122);
    const active=distance===0?'':'M27.5 126A100 100 0 0 1 '+p.join(' ');
    return '<div class="post-distance"><p class="post-distance-label">'+text.distance+'</p>'
        +'<svg class="post-distance-gauge" viewBox="0 -14 255 165" role="img" aria-label="'+escape(text.gauge(distance,range))+'">'
        +'<path class="post-gauge-base" d="M27.5 126A100 100 0 0 1 227.5 126"/><path class="post-gauge-active" d="'+active+'"/>'
        +'<path d="M'+t0.join(' ')+'L'+t1.join(' ')+'" stroke="var(--post-ink)" stroke-width="2"/>'
        +'<text x="'+Math.max(16,Math.min(239,label[0]))+'" y="'+(label[1]-4)+'" text-anchor="middle">400</text><text x="17" y="146" text-anchor="middle">0</text>'
        +'<text x="234" y="146" text-anchor="middle">'+range+'</text><circle cx="'+p[0]+'" cy="'+p[1]+'" r="6" fill="var(--post-panel)" stroke="var(--post-accent)" stroke-width="2"/></svg>'
        +'<p class="post-distance-value">'+distance+'<small>km</small></p></div>';
}
function renderPostAlert(result, text) {
    const key=text.alerts[result.alert]?result.alert:'none',level=text.alerts[key];
    const hours=Number.isFinite(result.windProbability?.hours)?result.windProbability.hours:72;
    const rule=level.threshold?text.probability(level.threshold,hours):level.rule;
    return '<section class="post-alert post-alert-'+key+'" data-level="'+level.rank+'" '+(level.rank?'role="alert"':'role="region"')+' aria-label="'+escape(level.title)+'">'
        +'<div><span class="post-sr-only">'+text.level(level.rank)+'</span><div class="post-alert-heading">'
        +'<svg class="post-alert-symbol" viewBox="0 0 56 56" aria-hidden="true">'+shapes[level.rank]+'<circle cx="28" cy="28" r="3" fill="var(--post-accent)" stroke="none"/></svg>'
        +'<div><h3>'+level.title+'</h3><p class="post-alert-subtitle">'+text.subtitle+'</p></div></div><p class="post-alert-rule">'+rule+'</p></div>'
        +distanceGauge(result.currentDistance,text)+'</section>';
}

export function renderPostForecast(result, input, cn = false) {
    const text=copy[cn?'CN':'EN'];
    const date = simulationDate({...input.cyclone,
        currentMonth:input.cyclone?.currentMonth || input.month}, result.age);
    const stamp = date.toISOString().slice(0,16).replace('T',' ') + ' UTC';
    const number=value=>Number.isFinite(value)?escape(value):'—';
    return '<p class="post-location">'+escape(input.site.names?.[cn?'CN':'EN'] || input.site.name || text.title)+' · '+Math.abs(input.site.lat).toFixed(2)+'°'+(input.site.lat<0?'S':'N')+' '+Math.abs(input.site.lon).toFixed(2)+'°'+(input.site.lon<0?'W':'E')+'</p>'
        +'<p class="post-issued">'+text.issued+' <time datetime="'+date.toISOString()+'">'+stamp+'</time> · T+'+number(result.age)+'h</p>'
        +renderPostAlert(result,text)
        +'<section class="post-days" aria-label="'+text.forecast+'">'+result.days.map((day,i)=>
            '<article class="post-day'+(i===0?' post-day-primary':'')+'"><header><span>'+text.day(i+1)+'</span><span>+'+number(day.from)+'–'+number(day.to)+'h</span></header>'
            +'<svg class="post-weather-icon" viewBox="0 0 64 64" aria-hidden="true">'+(weatherPaths[day.condition]||weatherPaths.Cloudy)+'</svg>'
            +'<div class="post-weather-block"><p class="post-key">'+text.weather+'</p><p class="post-value post-condition'+(day.condition==='Thunderstorms'?' post-condition-long':'')+'">'+escape(text.conditions[day.condition]||text.unavailable)+'</p></div>'
            +'<div class="post-temperature-block"><p class="post-key">'+text.temperature+'</p><p class="post-value">'+number(day.min)+'–'+number(day.max)+'<small>°C</small></p></div>'
            +'<div class="post-gust-block"><p class="post-key">'+text.gust+'</p><div class="post-gust-row"><p class="post-value">'+number(day.gustKph)+'<small>kph</small></p>'+windBarb(day.gustKph)+'</div></div></article>'
        ).join('')+'</section>'
        +(!result.hasTrack?'<p class="post-track-note" role="note">'+text.noTrack+'</p>':'')
        +'<footer class="post-footer"><span>STORM_INC / ICWC</span><details class="post-notes"><summary>'+text.notes+'</summary><p>'+text.explanation+'</p></details></footer>';
}

export function mountObservationPost({ modal, openButton, closeButton, readInput, generate, configure, onOpen=()=>{}, onClose=()=>{} }) {
    const content = modal.querySelector('#postForecastContent');
    const refresh = modal.querySelector('#refreshPostForecast');
    const panel = modal.querySelector('.post-panel');
    let revision = 0, busy = false, previousFocus = null, previousOverflow = '', view = {kind:'idle'};
    const cn = () => {
        try{return (window.getUserLanguage?.() || localStorage.getItem('userLanguage'))==='CN';}
        catch{return false;}
    };
    const text = () => copy[cn()?'CN':'EN'];
    function render() {
        const words=text();
        panel.lang=cn()?'zh-CN':'en';
        modal.querySelector('#postForecastTitle').textContent=words.title;
        modal.querySelector('#postForecastSource').textContent=words.source;
        for(const [button,label] of [[refresh,words.refresh],[closeButton,words.close],[openButton,words.open]]) {
            button.setAttribute('aria-label',label);button.title=label;
        }
        if(view.kind==='result') {
            const oldNotes=content.querySelector('.post-notes');
            const notesOpen=oldNotes?.open;
            const notesFocused=oldNotes && document.activeElement===oldNotes.querySelector('summary');
            content.innerHTML=renderPostForecast(view.result,view.input,cn());
            const notes=content.querySelector('.post-notes');
            notes.open=Boolean(notesOpen);
            if(notesFocused)notes.querySelector('summary').focus();
            panel.dataset.level=String((words.alerts[view.result.alert]||words.alerts.none).rank);
        } else if(view.kind!=='idle') {
            panel.dataset.level='0';
            content.innerHTML='<p class="post-empty" role="status">'+words[view.kind]+'</p>'
                +(view.kind==='noSite'?'<button type="button" class="post-action post-configure" id="configurePost">'+words.configure+'</button>':'');
            const button=modal.querySelector('#configurePost');
            if(button)button.onclick=()=>{close();configure();};
        }
    }
    async function load() {
        if (busy) return;
        const input = readInput();
        if (!input.site || !Number.isFinite(input.site.lat) || Math.abs(input.site.lat)>90 || !Number.isFinite(input.site.lon)) {
            view={kind:'noSite'};render();return;
        }
        if (!input.cyclone || input.cyclone.status !== 'active') {
            view={kind:'inactive'};render();return;
        }
        const request = ++revision;
        const restoreRefreshFocus=document.activeElement===refresh;
        busy = true; refresh.disabled = true; content.setAttribute('aria-busy','true');
        view={kind:'loading'};render();
        try {
            const result = await generate(input);
            if(request===revision){
                // Keep only immutable presentation inputs, not the live physics state.
                view={kind:'result',result,input:{month:input.month,site:{...input.site}}};
                render();
            }
        } catch (error) {
            if(request===revision){view={kind:'error'};render();}
            console.error('[observation-post]',error);
        } finally {
            busy=false;refresh.disabled=false;content.removeAttribute('aria-busy');
            if(restoreRefreshFocus && request===revision && !modal.classList.contains('hidden') && document.activeElement===document.body)refresh.focus();
            if(request!==revision && !modal.classList.contains('hidden'))load();
        }
    }
    function close() {
        if(modal.classList.contains('hidden'))return;
        revision++;modal.classList.add('hidden');document.body.style.overflow=previousOverflow;
        onClose();
        previousFocus?.focus();
    }
    openButton.addEventListener('click',()=>{
        previousFocus=document.activeElement;previousOverflow=document.body.style.overflow;
        document.body.style.overflow='hidden';modal.classList.remove('hidden');render();closeButton.focus();load();
        onOpen();
    });
    closeButton.addEventListener('click',close);
    refresh.addEventListener('click',load);
    modal.addEventListener('click',event=>{if(event.target===modal)close();});
    // Relocalize cached results, including error/loading states, without running the worker again.
    window.addEventListener('uiLanguageChanged',render);
    window.addEventListener('storage',event=>{if(event.key==='userLanguage')render();});
    modal.addEventListener('keydown',event=>{
        event.stopPropagation();
        if(event.key==='Escape'){event.preventDefault();close();}
        if(event.key==='Tab'){
            const focusable=[...modal.querySelectorAll('button:not(:disabled), summary')].filter(node=>node.getClientRects().length);
            const first=focusable[0],last=focusable.at(-1);
            if(event.shiftKey && document.activeElement===first){event.preventDefault();last?.focus();}
            else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first?.focus();}
        }
    });
    render();
}
