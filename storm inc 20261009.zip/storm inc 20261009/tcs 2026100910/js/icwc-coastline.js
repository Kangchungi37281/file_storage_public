// Remove shared country borders; retain the original ordered coastline runs.
const cache = new WeakMap();
export function synopticCoastline(world) {
    if (cache.has(world)) return cache.get(world);
    const rings = [];
    const visit = geometry => {
        if (!geometry) return;
        if (geometry.type === 'FeatureCollection') geometry.features.forEach(visit);
        else if (geometry.type === 'Feature') visit(geometry.geometry);
        else if (geometry.type === 'GeometryCollection') geometry.geometries.forEach(visit);
        else if (geometry.type === 'Polygon') rings.push(...geometry.coordinates);
        else if (geometry.type === 'MultiPolygon') geometry.coordinates.forEach(p => rings.push(...p));
    };
    visit(world);
    const pointKey = p => `${p[0].toFixed(6)},${p[1].toFixed(6)}`;
    const key = (a, b) => { const x = pointKey(a), y = pointKey(b); return x < y ? `${x}|${y}` : `${y}|${x}`; };
    const counts = new Map();
    for (const ring of rings) for (let i = 1; i < ring.length; i++) {
        const edge = key(ring[i - 1], ring[i]); counts.set(edge, (counts.get(edge) || 0) + 1);
    }
    const coordinates = [];
    for (const ring of rings) {
        let run = [];
        for (let i = 1; i < ring.length; i++) {
            if (counts.get(key(ring[i - 1], ring[i])) === 1) {
                if (!run.length) run.push(ring[i - 1]);
                run.push(ring[i]);
            } else if (run.length) { coordinates.push(run); run = []; }
        }
        if (run.length) coordinates.push(run);
    }
    const coast = { type: 'MultiLineString', coordinates };
    cache.set(world, coast);
    return coast;
}
