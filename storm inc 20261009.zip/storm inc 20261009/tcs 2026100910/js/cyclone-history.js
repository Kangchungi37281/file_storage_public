// Historical field products must not borrow the live storm's ET clock or
// steering. Older tracks lack the clock; approximate only from preceding
// contiguous 3-hour records, never from the eventual outcome of the storm.
export function historicalCyclonePhase(cyclone, index) {
    const track = cyclone.track;
    const point = track[index];
    const metadata = point[11] || {};
    const previous = track[Math.max(0, index - 1)] || point;
    let transitionHours = metadata.transitionHours;
    if (!Number.isFinite(transitionHours)) {
        transitionHours = point[4] ? 24 : 0;
        for (let i = index; point[3] && i >= 0 && track[i][3]; i--) {
            transitionHours = Math.min(24, transitionHours + 3);
        }
    }
    let transitionElapsedHours = metadata.transitionElapsedHours;
    if (!Number.isFinite(transitionElapsedHours)) {
        // Older tracks did not persist a separate wall-clock ET dwell. Their
        // exposure clock is the only available proxy, so preserve it exactly.
        transitionElapsedHours = transitionHours;
    }
    let extratropicalAgeHours = metadata.extratropicalAgeHours;
    if (!Number.isFinite(extratropicalAgeHours)) {
        extratropicalAgeHours = 0;
        for (let i = index; i > 0 && track[i][4] && track[i - 1][4]; i--) {
            extratropicalAgeHours += 3;
        }
    }
    const dLon = ((point[0] - previous[0] + 540) % 360) - 180;
    return {
        isTransitioning: Boolean(point[3]),
        isExtratropical: Boolean(point[4]),
        transitionHours,
        transitionElapsedHours,
        extratropicalAgeHours,
        extratropicalStage: metadata.extratropicalStage || (point[4] ? 'developing' : 'none'),
        steeringU: dLon * 111.32 * Math.cos((point[1] + previous[1]) * Math.PI / 360) / 3 / 3.6,
        steeringV: (point[1] - previous[1]) * 111.32 / 3 / 3.6
    };
}
