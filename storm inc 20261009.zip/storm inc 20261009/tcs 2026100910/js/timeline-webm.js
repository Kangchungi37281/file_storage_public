// One VP9 video track, fixed 10 fps. Only compressed packets enter the container.
// EBML sizes and block timestamps follow RFC 8794 / Matroska SimpleBlock.
const text = value => new TextEncoder().encode(value);
const bytes = value => {
    let n = BigInt(value), result = [];
    do { result.unshift(Number(n & 255n)); n >>= 8n; } while (n);
    return Uint8Array.from(result);
};
const size = value => {
    const n = BigInt(value);
    let length = 1;
    while (n >= (1n << BigInt(length * 7)) - 1n) length++;
    const result = new Uint8Array(length);
    let encoded = n | (1n << BigInt(length * 7));
    for (let i = length - 1; i >= 0; i--) { result[i] = Number(encoded & 255n); encoded >>= 8n; }
    return result;
};
const join = parts => {
    const result = new Uint8Array(parts.reduce((n, part) => n + part.length, 0));
    let offset = 0;
    for (const part of parts) { result.set(part, offset); offset += part.length; }
    return result;
};
const element = (id, payload) => join([bytes(id), size(payload.length), payload]);
const master = (id, children) => element(id, join(children));
const uint = (id, value) => element(id, bytes(value));
const string = (id, value) => element(id, text(value));
const float = (id, value) => {
    const result = new Uint8Array(8); new DataView(result.buffer).setFloat64(0, value);
    return element(id, result);
};

export function makeTimelineCluster(timestampMs, packets) {
    const time = uint(0xE7, timestampMs), parts = [time];
    for (const packet of packets) {
        const relative = Math.round(packet.timestamp / 1000) - timestampMs;
        if (relative < 0 || relative > 32767) throw new Error('Invalid WebM block timestamp');
        const blockHeader = Uint8Array.of(0x81, relative >> 8, relative & 255, packet.key ? 0x80 : 0);
        parts.push(bytes(0xA3), size(blockHeader.length + packet.data.length), blockHeader, packet.data);
    }
    const length = parts.reduce((n, part) => n + part.length, 0);
    return new Blob([bytes(0x1F43B675), size(length), ...parts]);
}

export function finishTimelineWebM(clusters, width, height) {
    const ebml = master(0x1A45DFA3, [uint(0x4286, 1), uint(0x42F7, 1), uint(0x42F2, 4), uint(0x42F3, 8),
        string(0x4282, 'webm'), uint(0x4287, 4), uint(0x4285, 2)]);
    const info = master(0x1549A966, [uint(0x2AD7B1, 1000000), float(0x4489, clusters.length * 400),
        string(0x4D80, 'STORM_INC / ICWC'), string(0x5741, 'STORM_INC / ICWC')]);
    const tracks = master(0x1654AE6B, [master(0xAE, [uint(0xD7, 1), uint(0x73C5, 1), uint(0x83, 1),
        uint(0x9C, 0), string(0x86, 'V_VP9'), uint(0x23E383, 100000000),
        master(0xE0, [uint(0xB0, width), uint(0xBA, height)])])]);
    // Every chart starts with a keyframe, so keep seek points without raw frames.
    let offset = info.length + tracks.length;
    const cues = master(0x1C53BB6B, clusters.map((cluster, i) => {
        const cue = master(0xBB, [uint(0xB3, i * 400), master(0xB7, [uint(0xF7, 1), uint(0xF1, offset)])]);
        offset += cluster.size;
        return cue;
    }));
    const segmentSize = info.length + tracks.length + cues.length + clusters.reduce((n, cluster) => n + cluster.size, 0);
    return new Blob([ebml, bytes(0x18538067), size(segmentSize), info, tracks, ...clusters, cues], { type: 'video/webm' });
}
