export const ICWC_DISCLAIMER = 'SIMULATION ONLY LOL · STORM_INC / ICWC';

// Canonical history fixes are three hours apart. A name belongs to the
// naming event, not every earlier fix or only the current TS-strength fixes.
export function cycloneNameAt(cyclone, timeIndex) {
    if (!cyclone.name || cyclone.named === false) return '';
    if (Number.isFinite(cyclone.namedAtAge) && cyclone.namedAtAge >= 0) {
        return timeIndex * 3 >= cyclone.namedAtAge ? cyclone.name : '';
    }
    // Older saves predate the timestamp. Reconstruct the same non-EX
    // 34-kt naming condition from actual history, never the forecast track.
    const namedIndex = (cyclone.track || []).findIndex(point => point[2] >= 34 && !point[4]);
    return namedIndex >= 0 && timeIndex >= namedIndex ? cyclone.name : '';
}

export function cycloneProductName(cyclone, point, timeIndex) {
    let prefix;
    if (point[4]) prefix = 'Extratropical Cyclone';
    else if (getCategory(point[2]).shortName === 'LPA') prefix = 'Low Pressure';
    else if (point[2] < 34) prefix = 'Tropical Depression';
    else if (point[2] < 64) prefix = 'Tropical Storm';
    else if (cyclone.basin === 'WPAC') prefix = 'Typhoon';
    else if (['NATL', 'EPAC', 'CPAC'].includes(cyclone.basin)) prefix = 'Hurricane';
    else prefix = 'Cyclone';
    const name = timeIndex === undefined ? cyclone.name || 'UNNAMED' : cycloneNameAt(cyclone, timeIndex);
    return name ? `${prefix} ${name}` : prefix;
}

export function drawICWCDisclaimer(ctx, width, top, height = 36) {
    ctx.save();
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, top, width, height);
    ctx.fillStyle = '#333';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 18px Arial, sans-serif';
    ctx.fillText(ICWC_DISCLAIMER, width / 2, top + height / 2, width - 40);
    ctx.restore();
}
import { getCategory } from './utils.js';
