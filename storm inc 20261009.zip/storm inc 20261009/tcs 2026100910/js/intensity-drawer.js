// The same open state is used by the desktop handle and mobile quickbar.
export function mountIntensityDrawer(section, onOpen) {
    const toggle=section.querySelector('#intensity-chart-toggle');
    const body=section.querySelector('#intensity-chart-body');
    let wasOpen=false, frame=0, drag=null, suppressClick=false;
    // Stay docked to the right edge, but allow the handle to move vertically.
    const place=top=>{
        const height=Math.max(section.offsetHeight,toggle.offsetHeight);
        section.style.top=`${Math.max(8,Math.min(top,window.innerHeight-height-8))}px`;
    };
    const keepVisible=()=>{
        if(!section.style.top||!section.isConnected||section.classList.contains('hidden')||!window.innerHeight) return;
        place(section.getBoundingClientRect().top);
    };
    const sync=()=>{
        const open=section.classList.contains('mobile-open')&&!section.classList.contains('hidden');
        toggle.setAttribute('aria-expanded',String(open));
        body.inert=!open;
        body.setAttribute('aria-hidden',String(!open));
        if(!open&&body.contains(document.activeElement)) toggle.focus({preventScroll:true});
        document.getElementById('mobileChartBtn')?.classList.toggle('active',open);
        keepVisible();
        if(open!==wasOpen) {
            cancelAnimationFrame(frame);
            if(open) frame=requestAnimationFrame(onOpen);
        }
        wasOpen=open;
    };
    const click=event=>{
        if(suppressClick&&event.detail!==0) {suppressClick=false;event.preventDefault();return;}
        section.classList.toggle('mobile-open');
    };
    const pointerDown=event=>{
        if(!event.isPrimary||event.button!==0) return;
        const rect=section.getBoundingClientRect();
        suppressClick=false;
        drag={id:event.pointerId,y:event.clientY,top:rect.top,moved:false};
        toggle.setPointerCapture(event.pointerId);
    };
    const pointerMove=event=>{
        if(!drag||event.pointerId!==drag.id) return;
        const dy=event.clientY-drag.y;
        if(!drag.moved&&Math.abs(dy)<5) return;
        drag.moved=true;suppressClick=true;
        section.classList.add('is-dragging');
        place(drag.top+dy);
    };
    const pointerEnd=event=>{
        if(!drag||event.pointerId!==drag.id) return;
        drag=null;
        section.classList.remove('is-dragging');
        if(toggle.hasPointerCapture(event.pointerId)) toggle.releasePointerCapture(event.pointerId);
    };
    const keyDown=event=>{
        if(event.key==='Escape'&&section.classList.contains('mobile-open')) {
            section.classList.remove('mobile-open');toggle.focus();event.stopPropagation();
        }
    };
    toggle.addEventListener('click',click);
    toggle.addEventListener('pointerdown',pointerDown);
    toggle.addEventListener('pointermove',pointerMove);
    toggle.addEventListener('pointerup',pointerEnd);
    toggle.addEventListener('pointercancel',pointerEnd);
    toggle.addEventListener('lostpointercapture',pointerEnd);
    section.addEventListener('keydown',keyDown);
    window.addEventListener('resize',keepVisible);
    const observer=new MutationObserver(sync);
    observer.observe(section,{attributes:true,attributeFilter:['class']});
    sync();
    return ()=>{
        observer.disconnect();cancelAnimationFrame(frame);
        toggle.removeEventListener('click',click);
        toggle.removeEventListener('pointerdown',pointerDown);
        toggle.removeEventListener('pointermove',pointerMove);
        toggle.removeEventListener('pointerup',pointerEnd);
        toggle.removeEventListener('pointercancel',pointerEnd);
        toggle.removeEventListener('lostpointercapture',pointerEnd);
        section.removeEventListener('keydown',keyDown);
        window.removeEventListener('resize',keepVisible);
    };
}
