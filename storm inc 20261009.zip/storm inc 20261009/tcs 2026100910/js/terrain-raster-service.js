export async function prepareTerrainRaster(world, width, height) {
    if (typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined') return null;
    let worker;
    try {
        return await new Promise((resolve, reject) => {
            worker = new Worker(new URL('./terrain-raster-worker.js', import.meta.url), { type: 'module' });
            worker.onmessage = ({ data }) => data.error ? reject(new Error(data.error)) : resolve(data);
            worker.onerror = reject;
            worker.onmessageerror = reject;
            worker.postMessage({ world, width, height });
        });
    } catch (error) {
        console.warn('[terrain] Original raster initialization fallback:', error);
        return null;
    } finally { worker?.terminate(); }
}
