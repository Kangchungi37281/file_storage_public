import { MONTHLY_HEIGHT_GRID } from './monthly-height-data.js';
// Periodic Catmull-Rom interpolation: continuous first derivatives keep the
// geostrophic wind continuous across grid lines. No independent wind tuning.
const cubic=(a,b,c,d,t)=>b+.5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*(b-c)+d-a)));
export function sampleMonthlyHeight(lon, lat, month, level=500) {
 const grid=MONTHLY_HEIGHT_GRID[level][Math.max(0,Math.min(11,Math.round(month||8)-1))];
 const x=(((lon%360)+360)%360)/5, y=(Math.max(-90,Math.min(90,lat))+90)/2.5;
 const ix=Math.floor(x), iy=Math.floor(y), tx=x-ix, ty=y-iy;
 const row=j=>{
  const r=grid[Math.max(0,Math.min(72,j))];
  return cubic(r[(ix+71)%72],r[ix%72],r[(ix+1)%72],r[(ix+2)%72],tx);
 };
 return cubic(row(iy-1),row(iy),row(iy+1),row(iy+2),ty);
}

// Spatial motion-minus-steering residual, independently calibrated on
// 2000-2011 JMA tracks. This is an empirical closure, not a wind-field edit.
import { WNP_PROPAGATION_GRID } from './propagation-data.js';
export function sampleWnpPropagation(lon,lat,month=8) {
 lon=((lon%360)+360)%360;
 const grid=WNP_PROPAGATION_GRID[Math.max(0,Math.min(5,Math.round(month)-5))];
 const x=Math.max(0,Math.min(32,(lon-100)/2.5));
 const y=Math.max(0,Math.min(18,(lat-5)/2.5));
 const ix=Math.floor(x),iy=Math.floor(y),tx=x-ix,ty=y-iy;
 const component=k=>{
  const row=j=>{
   const r=grid[Math.max(0,Math.min(18,j))];
   const at=i=>r[Math.max(0,Math.min(32,i))][k];
   return cubic(at(ix-1),at(ix),at(ix+1),at(ix+2),tx);
  };
  return cubic(row(iy-1),row(iy),row(iy+1),row(iy+2),ty);
 };
 const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
 const weight=smooth((lon-90)/10)*(1-smooth((lon-180)/15))*(1-smooth((lat-45)/10))*smooth(lat/5);
 return {u:component(0),v:component(1),confidence:Math.max(0,Math.min(1,component(2)))*weight,domainWeight:weight};
}
