/**
 * js/satellite-view.js
 * 负责处理 WebGL 卫星云图渲染
 */

let gl, program;
let startTime;
let canvas;
let uniforms = {};
let isGrayscale = false;
let renderWorker = null;
let workerReady = false;
let workerFramePending = false;
let canvasTransferred = false;
let workerStartTimer;
let snapshotRequestId = 0;
const workerSnapshots = new Map();

function stopRenderWorker(error) {
    if (!renderWorker) return;
    console.warn('Satellite renderer using compatibility fallback:', error);
    renderWorker.terminate();
    renderWorker = null;
    workerReady = workerFramePending = false;
    canvas.dataset.satelliteRenderer = 'fallback';
    clearTimeout(workerStartTimer);
    for (const request of workerSnapshots.values()) {
        clearTimeout(request.timer);
        request.resolve(null);
    }
    workerSnapshots.clear();
    if (canvasTransferred) {
        // A transferred canvas cannot acquire a main-thread context again.
        const replacement = canvas.cloneNode(false);
        canvas.replaceWith(replacement);
        canvas = replacement;
        canvasTransferred = false;
        configureSatelliteCanvasObservers();
    }
    scheduleSatelliteRender();
}

function startRenderWorker() {
    if (typeof Worker !== 'function' || !canvas.transferControlToOffscreen) return;
    try {
        const worker = new Worker(new URL('./satellite-render-worker.js?v=20260914-render2', import.meta.url), {type:'module'});
        renderWorker = worker;
        canvas.dataset.satelliteRenderer = 'starting';
        workerStartTimer = setTimeout(() => stopRenderWorker('Initialization timed out'), 10000);
        worker.onerror = event => stopRenderWorker(event.message || 'Worker failed');
        worker.onmessage = ({data}) => {
            if (worker !== renderWorker) return;
            if (data.type === 'available') {
                canvas.dataset.satelliteRenderer = 'transferring';
                try {
                    const surface = canvas.transferControlToOffscreen();
                    canvasTransferred = true;
                    worker.postMessage({type:'init',canvas:surface}, [surface]);
                } catch (error) { stopRenderWorker(error); }
            } else if (data.type === 'ready') {
                clearTimeout(workerStartTimer);
                workerReady = true;
                canvas.dataset.satelliteRenderer = 'worker';
                for (const request of workerSnapshots.values()) worker.postMessage(request.message);
                scheduleSatelliteRender();
            } else if (data.type === 'frame') {
                workerFramePending = false;
                scheduleSatelliteRender();
            } else if (data.type === 'snapshot') {
                const request = workerSnapshots.get(data.id);
                if (!request) return;
                workerSnapshots.delete(data.id);
                clearTimeout(request.timer);
                request.resolve(data.blob ? URL.createObjectURL(data.blob) : null);
            } else if (data.type === 'error') stopRenderWorker(data.error);
        };
    } catch (error) { stopRenderWorker(error); }
}

// 历史面板使用的是缩略图，不需要把实时 WebGL 画布原尺寸送进编码器。
// JPEG 对这类小尺寸云图的编码成本通常低于 WebP，同时仍能保持面板查看所需的清晰度。
const SATELLITE_SNAPSHOT_MAX_EDGE = 384;
const SATELLITE_SNAPSHOT_FORMAT = 'image/jpeg';
const SATELLITE_SNAPSHOT_QUALITY = 0.74;
let satelliteSnapshotEncodeQueue = Promise.resolve();
let satelliteSnapshotEncoderWorker = null;
let satelliteSnapshotEncoderUrl = null;
let satelliteSnapshotEncodeRequestId = 0;
const satelliteSnapshotEncodeRequests = new Map();

function disableSatelliteSnapshotWorker(error) {
    const worker = satelliteSnapshotEncoderWorker;
    satelliteSnapshotEncoderWorker = null;
    satelliteSnapshotEncodeRequests.forEach(request => request.reject(error));
    satelliteSnapshotEncodeRequests.clear();
    if (worker) worker.terminate();
    if (satelliteSnapshotEncoderUrl
        && typeof URL !== 'undefined'
        && typeof URL.revokeObjectURL === 'function') {
        URL.revokeObjectURL(satelliteSnapshotEncoderUrl);
    }
    satelliteSnapshotEncoderUrl = null;
}

function getSatelliteSnapshotWorker() {
    if (satelliteSnapshotEncoderWorker) return satelliteSnapshotEncoderWorker;
    if (typeof Worker !== 'function'
        || typeof OffscreenCanvas !== 'function'
        || typeof createImageBitmap !== 'function'
        || typeof Blob !== 'function'
        || typeof URL === 'undefined'
        || typeof URL.createObjectURL !== 'function') return null;

    const workerSource = `
        self.onmessage = async event => {
            const { id, bitmap, width, height, type, quality } = event.data;
            try {
                const output = new OffscreenCanvas(width, height);
                const context = output.getContext('2d', { alpha: false });
                if (!context) throw new Error('2D encoder context unavailable');
                context.drawImage(bitmap, 0, 0, width, height);
                if (typeof bitmap.close === 'function') bitmap.close();
                const blob = await output.convertToBlob({ type, quality });
                self.postMessage({ id, blob });
            } catch (error) {
                if (bitmap && typeof bitmap.close === 'function') bitmap.close();
                self.postMessage({ id, error: String(error) });
            }
        };
    `;

    try {
        satelliteSnapshotEncoderUrl = URL.createObjectURL(
            new Blob([workerSource], { type: 'application/javascript' })
        );
        const worker = new Worker(satelliteSnapshotEncoderUrl);
        worker.onmessage = event => {
            const { id, blob, error } = event.data || {};
            const request = satelliteSnapshotEncodeRequests.get(id);
            if (!request) return;
            satelliteSnapshotEncodeRequests.delete(id);
            if (error || !blob) request.reject(new Error(error || 'Snapshot encoding failed'));
            else request.resolve(URL.createObjectURL(blob));
        };
        worker.onerror = event => {
            disableSatelliteSnapshotWorker(
                new Error(event?.message || 'Snapshot encoder worker failed')
            );
        };
        satelliteSnapshotEncoderWorker = worker;
        return worker;
    } catch (error) {
        disableSatelliteSnapshotWorker(error);
        return null;
    }
}

function encodeSatelliteSnapshotOffMainThread(snapshotCanvas) {
    const worker = getSatelliteSnapshotWorker();
    if (!worker) return null;

    return createImageBitmap(snapshotCanvas).then(bitmap => new Promise((resolve, reject) => {
        const id = ++satelliteSnapshotEncodeRequestId;
        satelliteSnapshotEncodeRequests.set(id, { resolve, reject });
        try {
            worker.postMessage({
                id,
                bitmap,
                width: snapshotCanvas.width,
                height: snapshotCanvas.height,
                type: SATELLITE_SNAPSHOT_FORMAT,
                quality: SATELLITE_SNAPSHOT_QUALITY
            }, [bitmap]);
        } catch (error) {
            satelliteSnapshotEncodeRequests.delete(id);
            if (typeof bitmap.close === 'function') bitmap.close();
            reject(error);
        }
    }));
}

function encodeSatelliteSnapshotOnMainThread(snapshotCanvas) {
    return new Promise(encodeResolve => {
        if (typeof snapshotCanvas.toBlob !== 'function') {
            // 仅作为老旧浏览器的兼容回退；此时仍只编码小缩略图。
            try {
                encodeResolve(
                    snapshotCanvas.toDataURL(
                        SATELLITE_SNAPSHOT_FORMAT,
                        SATELLITE_SNAPSHOT_QUALITY
                    ) || null
                );
            } catch (error) {
                console.warn('Satellite snapshot fallback failed:', error);
                encodeResolve(null);
            }
            return;
        }

        snapshotCanvas.toBlob(blob => {
            if (!blob) {
                encodeResolve(null);
                return;
            }
            encodeResolve(URL.createObjectURL(blob));
        }, SATELLITE_SNAPSHOT_FORMAT, SATELLITE_SNAPSHOT_QUALITY);
    });
}

// 顶点着色器
const vertexShaderSource = `
    attribute vec2 a_position;
    void main() {
        gl_Position = vec4(a_position, 0.0, 1.0);
    }
`;

// 片元着色器 (已更新不对称逻辑)
const fragmentShaderSource = `
    precision mediump float;
    uniform vec2 u_resolution;
    uniform float u_time;
    uniform float u_spiral_strength;
    uniform float u_eye_radius;
    uniform float u_eye_clarity;
    uniform float u_shape_distortion;
    uniform float u_storm_radius;
    uniform float u_cloud_low;
    uniform float u_cloud_high;
    uniform float u_central_mass_size;
    uniform float u_wind_shear_strength;
    uniform float u_random_seed;
    uniform float u_hemisphere; 

    uniform float u_grayscale;
    
    // [新增] 不对称参数
    uniform float u_asym_strength;
    uniform float u_asym_dir;

    float random(vec2 st) {
        return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
    }
    float noise(vec2 st) {
        vec2 i = floor(st);
        vec2 f = fract(st);
        float a = random(i);
        float b = random(i + vec2(1.0, 0.0));
        float c = random(i + vec2(0.0, 1.0));
        float d = random(i + vec2(1.0, 1.0));
        vec2 u = f * f * (3.0 - 2.0 * f);
        return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.y * u.x;
    }
    #define FBM_OCTAVES 5
    float fbm(vec2 st) {
        float value = 0.0;
        float amplitude = 0.6;
        float max_amplitude = 0.0;
        for (int i = 0; i < FBM_OCTAVES; i++) {
            value += amplitude * noise(st);
            max_amplitude += amplitude;
            st *= 2.0;
            amplitude *= 0.5;
        }
        return (value / max_amplitude) * 0.9999;
    }
    vec3 nrl_color_ramp(float t) {
        t = clamp(t, 0.0, 1.0);
        vec3 c0 = vec3(0.0, 0.1, 0.2);
        vec3 c1 = vec3(0.7, 1.0, 1.0);
        vec3 c2 = vec3(0.0, 0.0, 1.0);
        vec3 c3 = vec3(0.0, 1.0, 0.0);
        vec3 c4 = vec3(1.0, 0.0, 0.0);
        vec3 c5 = vec3(1.0, 1.0, 0.0);
        vec3 c6 = vec3(1.0, 1.0, 1.0);
        vec3 color = c0;
        color = mix(color, c1, smoothstep(0.0, 0.2, t));
        color = mix(color, c2, smoothstep(0.2, 0.3, t));
        color = mix(color, c3, smoothstep(0.3, 0.5, t));
        color = mix(color, c4, smoothstep(0.5, 0.8, t));
        color = mix(color, c5, smoothstep(0.8, 0.99, t));
        color = mix(color, c6, smoothstep(0.99, 1.0, t));
        return color;
    }

    void main() {
        vec2 uv = 0.7 * (2.0 * gl_FragCoord.xy - u_resolution.xy) / u_resolution.y;
        float dist = length(uv);
        float angle = atan(uv.y, uv.x);
        
        // --- [新增] 不对称几何计算 ---
        // 1. 计算角度差异
        float angle_diff = angle - u_asym_dir;
        // 2. 角度因子
        float asym_factor = cos(angle_diff);
        // 3. 半径拉伸
        float radius_multiplier = 1.0 + asym_factor * u_asym_strength;
        radius_multiplier = max(0.3, radius_multiplier); 
        // 4. 动态风暴半径
        float dynamic_storm_radius = u_storm_radius * radius_multiplier;
        
        float base_distortion_amp = 0.01;
        float shear_distortion_factor = 0.9;
        float total_distortion_amplitude = base_distortion_amp + u_wind_shear_strength * shear_distortion_factor;
        
        float ROTATION_SPEED = 0.3;
        float NOISE_SCALE = 4.0;

        // 1. 螺旋云带
        float spiral_angle = angle + u_spiral_strength * log(dist) * u_hemisphere - u_time * ROTATION_SPEED * u_hemisphere;
        
        vec2 noise_uv = vec2(cos(spiral_angle) * dist, sin(spiral_angle) * dist) * NOISE_SCALE;
        noise_uv.y += u_time * 0.1;
        float noise_val = fbm(noise_uv + u_random_seed);

        // --- 密度不对称增强 (让延伸侧云层稍厚) ---
        float density_boost = smoothstep(-0.5, 1.0, asym_factor) * u_asym_strength * 0.2;
        noise_val += density_boost;

        // 2. 风眼与边缘
        vec2 spiral_boundary_noise_uv = uv * 6.0 + u_time * 0.3;
        float eye_boundary_amplitude = clamp(max(0.0, u_eye_radius) * 0.22, 0.0015, 0.010);
        float spiral_boundary_perturbation = (fbm(spiral_boundary_noise_uv) - 0.5)
            * 2.0 * eye_boundary_amplitude;

        // Eye radius and eye clarity are separate. A developing eyewall can
        // already have a physical radius while its cloud-filled eye is still
        // only intermittently visible; shear further softens and fills it.
        float eye_falloff = 1.0;
        float effective_eye_clarity = 0.0;
        float shear_eye_damage = smoothstep(0.08, 0.34, u_wind_shear_strength);
        float transitional_eyewall = 0.0;
        if (u_eye_radius > 0.0) {
            effective_eye_clarity = clamp(u_eye_clarity, 0.0, 1.0);
            float eye_soft_width = clamp(
                0.006
                    + u_eye_radius * 0.22
                    + (1.0 - effective_eye_clarity) * 0.020
                    + u_wind_shear_strength * 0.045,
                0.006,
                0.045
            );
            float spiral_inner_radius = max(0.0, u_eye_radius + spiral_boundary_perturbation);
            float eye_edge = smoothstep(
                max(0.0, spiral_inner_radius - eye_soft_width * 0.20),
                spiral_inner_radius + eye_soft_width,
                dist
            );
            float intrusion_noise = fbm(
                uv * 13.0
                    + vec2(u_time * 0.07, -u_time * 0.05)
                    + u_random_seed
            );
            float patchy_intrusion = shear_eye_damage
                * smoothstep(0.38, 0.78, intrusion_noise);
            float local_eye_clarity = effective_eye_clarity
                * (1.0 - 0.62 * patchy_intrusion);
            eye_falloff = mix(1.0, eye_edge, local_eye_clarity);

            // A noisy convective ring appears before the eye fully clears.
            // Strong shear opens a sector of the ring instead of merely
            // translating an otherwise perfect circular hole.
            float eyewall_width = clamp(0.008 + u_eye_radius * 0.30, 0.008, 0.025);
            float eyewall_radius = spiral_inner_radius + eyewall_width * 0.75;
            float eyewall_band = 1.0 - smoothstep(
                eyewall_width,
                eyewall_width * 2.4,
                abs(dist - eyewall_radius)
            );
            float eyewall_texture = 0.58 + 0.42 * fbm(
                uv * 18.0 + vec2(-u_time * 0.08, u_time * 0.06) + u_random_seed
            );
            float shear_sector = smoothstep(-0.45, 0.85, cos(angle - u_asym_dir));
            float eyewall_closure = 1.0 - 0.78 * shear_eye_damage * shear_sector;
            float eyewall_maturity = mix(0.42, 1.0, effective_eye_clarity);
            transitional_eyewall = eyewall_band
                * eyewall_texture
                * eyewall_closure
                * eyewall_maturity;
        }
        noise_val *= eye_falloff;
        noise_val = max(noise_val, transitional_eyewall);
        
        float distortion_noise = fbm(uv * 1.5 + u_time * 0.05);
        float distorted_dist = dist - distortion_noise * u_shape_distortion;
        
        // [修改] 使用 dynamic_storm_radius 替代原有的 u_storm_radius
        float storm_falloff = 1.0 - smoothstep(dynamic_storm_radius, dynamic_storm_radius + 0.2, distorted_dist);
        noise_val *= storm_falloff;
        
        // 3. 中心云团 (CDO)
        float central_mass_value = 0.0;
        if (u_central_mass_size > 0.0) {
            // Keep the high cloud eye over the same vortex center as the
            // low-level radar eye. Shear changes morphology, not the center
            // through an unrelated fixed north-east displacement.
            vec2 cdo_uv = uv;
            float cdo_dist = length(cdo_uv);
            float cdo_angle = atan(cdo_uv.y, cdo_uv.x);
            
            float central_mass_outer_radius = u_eye_radius + u_central_mass_size;
            vec2 boundary_noise_uv = cdo_uv * 6.0 + u_time * 0.3;
            float cdo_boundary_amplitude = clamp(0.015 + u_wind_shear_strength * 0.15, 0.015, 0.05);
            float boundary_perturbation = (fbm(boundary_noise_uv) - 0.5)
                * 2.0 * cdo_boundary_amplitude;
            float perturbed_outer_radius = central_mass_outer_radius + boundary_perturbation;
            float central_inner_mask = 1.0;
            if (u_eye_radius > 0.0) {
                float perturbed_inner_radius = max(0.0, u_eye_radius + spiral_boundary_perturbation);
                float cleared_inner_mask = smoothstep(
                    perturbed_inner_radius,
                    perturbed_inner_radius
                        + 0.010
                        + (1.0 - effective_eye_clarity) * 0.020
                        + u_wind_shear_strength * 0.035,
                    cdo_dist
                );
                central_inner_mask = mix(1.0, cleared_inner_mask, effective_eye_clarity);
            }

            float central_mass_shape = central_inner_mask
                                     * (1.0 - smoothstep(perturbed_outer_radius, perturbed_outer_radius + 0.15, cdo_dist));
            
            float central_mass_rotation_speed = ROTATION_SPEED * 1.2;
            
            float central_mass_internal_angle = cdo_angle + u_spiral_strength * log(cdo_dist) * u_hemisphere 
                                              - u_time * central_mass_rotation_speed * u_hemisphere 
                                              - u_wind_shear_strength;
                                  
            vec2 central_mass_internal_noise_coords;
            central_mass_internal_noise_coords.x = cos(central_mass_internal_angle) * cdo_dist - u_wind_shear_strength;
            central_mass_internal_noise_coords.y = sin(central_mass_internal_angle) * cdo_dist - u_wind_shear_strength;
            
            float internal_texture = fbm(central_mass_internal_noise_coords * 6.0);
            central_mass_value = central_mass_shape * (0.85 + internal_texture * 0.15);
        }
        
        noise_val = max(noise_val, central_mass_value);
        float cloud_intensity = smoothstep(u_cloud_low, u_cloud_high, noise_val);
        vec3 color = nrl_color_ramp(cloud_intensity);
        float ir_val = max(0.1, pow(cloud_intensity*1.3, 1.2));
        vec3 grayColor = vec3(ir_val);
        vec3 final_color = mix(color, grayColor, u_grayscale);
        
        gl_FragColor = vec4(final_color, 1.0);
    }
`;

function createShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error('Shader compilation error:', gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }
    return shader;
}

// 参数状态
let currentParams = {
    spiral: 1.0, eye: -0.1, distortion: 0.4, stormRadius: 0.2,
    eyeClarity: 0.0,
    centralMass: 0.0, shear: 0.0, cloudLow: 0.1, cloudHigh: 0.8,
    hemisphere: 1.0, // [新增] 1.0 for NH, -1.0 for SH
    seed: Math.random() * 100,
    asymStrength: 0.0,
    asymDir: 0.0
};

export function resetSatelliteParams() {
    currentParams = {
        spiral: 1.0, 
        eye: -0.1, 
        eyeClarity: 0.0,
        distortion: Math.random() * 0.4, 
        stormRadius: Math.random() * 0.2 + 0.1,
        centralMass: Math.random() * 0.2, 
        shear: Math.random() * 0.1, 
        cloudLow: 0.0, 
        cloudHigh: Math.random() * 0.5 + 0.5,
        hemisphere: 1.0, // 默认为北半球
        seed: Math.random() * 100,
        asymStrength: Math.random() * 0.3, 
        asymDir: Math.random() * 6.28
    };
}

// 插值函数
function lerp(start, end, t) {
    return start * (1 - t) + end * t;
}

// 辅助：生成正弦波动
function oscillate(base, amplitude, speed) {
    return base + Math.sin(Date.now() * 0.001 * speed) * amplitude;
}

export function initSatelliteView(canvasId) {
    canvas = document.getElementById(canvasId);
    if (!canvas) return;
    startTime = Date.now();
    configureSatelliteCanvasObservers();
    startRenderWorker();
}

// Shared, DOM-free renderer: production Worker and compatibility path use
// exactly the same shaders and uniforms, not separate visual approximations.
export function initializeSatelliteRenderer(surface, preserveDrawingBuffer = false) {
    canvas = surface;
    gl = canvas.getContext('webgl', { preserveDrawingBuffer });
    if (!gl) throw new Error('Satellite WebGL unavailable');

    const vShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
    const fShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
    if (!vShader || !fShader) throw new Error('Satellite shader compilation failed');

    program = gl.createProgram();
    gl.attachShader(program, vShader);
    gl.attachShader(program, fShader);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        throw new Error(`Satellite program link failed: ${gl.getProgramInfoLog(program)}`);
    }

    // Cache uniform locations
    const uniformNames = [
        "u_resolution", "u_time", "u_spiral_strength", "u_eye_radius", "u_eye_clarity",
        "u_shape_distortion", "u_storm_radius", "u_central_mass_size", 
        "u_wind_shear_strength", "u_cloud_low", "u_cloud_high", "u_random_seed",
        "u_hemisphere", "u_asym_strength", "u_asym_dir", "u_grayscale" // [新增]
    ];
    uniformNames.forEach(name => {
        uniforms[name] = gl.getUniformLocation(program, name);
    });

    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);

    const positionAttrib = gl.getAttribLocation(program, "a_position");
    gl.enableVertexAttribArray(positionAttrib);
    gl.vertexAttribPointer(positionAttrib, 2, gl.FLOAT, false, 0, 0);

}

export function setSatelliteGrayscale(enable) {
    isGrayscale = enable;
}

// 根据强度更新目标参数
export function updateSatelliteView(
    intensityKnots,
    age,
    latitude,
    isExtratropical,
    isSubtropical,
    isLand = false,
    sst = 29,
    humidity = 75,
    rmwKm = null,
    circulationSizeKm = 300,
    totalShear = 0
) { 
    if (intensityKnots == null || isNaN(intensityKnots)) intensityKnots = 0;
    if (latitude == null || isNaN(latitude)) latitude = 0;
    if (sst == null || isNaN(sst)) sst = 29;
    if (humidity == null || isNaN(humidity)) humidity = 75;
    if (totalShear == null || isNaN(totalShear)) totalShear = 0;

    currentParams.hemisphere = latitude < 0 ? -1.0 : 1.0;

    // 基础目标对象
    let target = { 
        spiral: 1.0, eye: -0.1, distortion: 0.4, stormRadius: 0.2, 
        eyeClarity: 0.0,
        centralMass: 0.0, shear: 0.0, 
        cloudLow: 0.1, 
        cloudHigh: 0.8, // 默认值，会被覆盖
        asymStrength: 0.0, asymDir: 0.0
    };
    let randomFactor = Math.random(); 
    let dynamicAsymStr = oscillate(0.25, 0.55, 0.5);
    let dynamicAsymDir = (Date.now() * 0.0002) % 6.28;
    // ============================================================
    // 1. 结构形态设定 (Spiral, Eye, Distortion) - 保持基于强度的逻辑
    // ============================================================
    if (isExtratropical) {
        target.spiral = 0.8; target.eye = -0.2; target.distortion = 0.6; target.stormRadius = 0.4; target.centralMass = 0.0; target.shear = 0.2; target.asymStrength = 1.5; target.asymDir = 5.5;
    } else if (isSubtropical) {
        target.spiral = 1.0; target.eye = -0.15; target.distortion = 0.5; target.stormRadius = 0.3; target.centralMass = 0.05; target.shear = 0.15; target.asymStrength = 0.5; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 24) { // LO
        target.spiral = 0.5; target.eye = -0.10; target.distortion = Math.random()*0.3+0.1; target.stormRadius = 0.1; target.centralMass = 0.0; target.shear = 0.10; target.asymStrength = dynamicAsymStr * 1.5; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 34) { // TD
        target.spiral = 1.0; target.eye = -0.10; target.distortion = 0.4; target.stormRadius = 0.15; target.centralMass = 0.0; target.shear = 0.10; target.asymStrength = dynamicAsymStr * 1.4; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 64) { // TS
        let dynamicShear = randomFactor * 0.20;
        let dynamicMass = randomFactor * 0.30;
        target.spiral = 1.2; target.eye = -0.06; target.distortion = 0.35; target.stormRadius = 0.25; target.centralMass = dynamicMass; target.shear = dynamicShear; target.asymStrength = dynamicAsymStr * 1.3; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 83) { // Cat 1
        if (currentParams.seed > 50) {
            let dynamicEye = oscillate(0.025, 0.025, 1.0); 
            target.spiral = 1.4; target.eye = dynamicEye; target.distortion = 0.30; target.stormRadius = 0.2; target.centralMass = 0.15; target.shear = 0.08; target.asymStrength = dynamicAsymStr * 1.2; target.asymDir = dynamicAsymDir;
        } else {
            let dynamicEye = oscillate(0.0, 0.025, 1.0); 
            target.spiral = 1.4; target.eye = dynamicEye; target.distortion = 0.30; target.stormRadius = 0.2; target.centralMass = -0.05; target.shear = 0.0; target.asymStrength = dynamicAsymStr * 1.2; target.asymDir = dynamicAsymDir;
        }
    } else if (intensityKnots < 96) { // Cat 2
        let dynamicEye = oscillate(0.025, 0.025, 1.5); 
        target.spiral = 1.6; target.eye = dynamicEye; target.distortion = 0.35; target.stormRadius = 0.22; target.centralMass = 0.12; target.shear = 0.04; target.asymStrength = dynamicAsymStr * 1.1; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 113) { // Cat 3
        let dynamicEye = oscillate(0.025, 0.025, 2.0); 
        target.spiral = 1.9; target.eye = dynamicEye; target.distortion = Math.random()*0.05 + 0.27; target.stormRadius = Math.random()*0.05 + 0.27; target.centralMass = 0.10; target.shear = 0.03; target.asymStrength = dynamicAsymStr * 1.0; target.asymDir = dynamicAsymDir;
    } else if (intensityKnots < 137) { // Cat 4
        let dynamicEye = oscillate(0.0, 0.02, 2.5); 
        target.spiral = 2.0; target.eye = dynamicEye; target.distortion = Math.random()*0.30; target.stormRadius = 0.25; target.centralMass = 0.08; target.shear = 0.02; target.asymStrength = dynamicAsymStr * 1.0; target.asymDir = dynamicAsymDir;
    } else { // Cat 5
        let dynamicEye = oscillate(-0.005, 0.015, 3.0);
        target.spiral = 2.5; target.eye = dynamicEye; target.distortion = Math.random()*0.30; target.stormRadius = 0.20; target.centralMass = Math.random()*0.05 + 0.05; target.shear = 0.00; target.asymStrength = dynamicAsymStr * 1.0; target.asymDir = dynamicAsymDir;
    }

    // Feed the actual diagnosed environmental shear into cloud morphology.
    // The category presets remain a small background irregularity only.
    const physicalShearVisual = Math.max(
        0,
        Math.min(0.42, (totalShear - 4) / 55)
    );
    target.shear = Math.max(target.shear, physicalShearVisual);

    // Eye radius, eyewall maturity and eye clarity evolve independently. This
    // restores the transitional eyewall: a hurricane can organize a ragged
    // ring before the center clears, while shear can refill an established eye.
    const isEyeEligible = !isExtratropical
        && !isSubtropical
        && intensityKnots >= 64
        && Number.isFinite(rmwKm)
        && rmwKm > 0
        && Number.isFinite(circulationSizeKm)
        && circulationSizeKm > 0;
    if (isEyeEligible) {
        const physicalEyeRadius = Math.max(
            0.0015,
            Math.min(0.07, target.stormRadius * 0.32 * rmwKm / circulationSizeKm)
        );
        const eyeOrganizationT = Math.max(0, Math.min(1, (intensityKnots - 64) / 38));
        const eyeOrganization = eyeOrganizationT * eyeOrganizationT * (3 - 2 * eyeOrganizationT);
        const eyePropensity = Math.max(0.55, Math.min(1.0, 0.55 + currentParams.seed / 220));
        const shearDamageT = Math.max(0, Math.min(1, (totalShear - 7) / 22));
        const shearDamage = shearDamageT * shearDamageT * (3 - 2 * shearDamageT);
        target.eye = physicalEyeRadius * (0.55 + 0.45 * eyeOrganization);
        target.eyeClarity = eyeOrganization
            * eyePropensity
            * (1 - 0.92 * shearDamage);
    } else {
        target.eye = -0.08;
        target.eyeClarity = 0.0;
    }

    // ============================================================
    // 2. 云量 (Cloud High) 核心计算逻辑
    // ============================================================
    
    // 判断是否为成熟的热带系统 (TS及以上)
    const isMatureTropical = !isExtratropical && !isSubtropical && intensityKnots >= 34;

    if (!isMatureTropical) {
        // [A] 弱系统/非热带系统：保持原有的“松散/随机”风格
        // 这里的 CloudHigh 仍然主要由预设决定，湿度只做微调
        if (isExtratropical) target.cloudHigh = 2.0;
        else if (isSubtropical) target.cloudHigh = 1.6;
        else if (intensityKnots < 24) target.cloudHigh = 1.3; // LO: 很淡
        else target.cloudHigh = 1.1; // TD: 稍浓
        
        // 弱系统对湿度的敏感度较低，但也稍微受点影响
        // 湿度越低，云越淡 (+0.1)
        if (humidity < 60) target.cloudHigh += 0.2;

    } else {
        // [B] 成熟热带气旋：完全由湿度驱动 (Direct Mapping)
        // ---------------------------------------------------
        // 映射逻辑：
        // 湿度 95% -> CloudHigh 0.45 (极浓密，CDO 亮白)
        // 湿度 75% -> CloudHigh 0.80 (正常，有层次)
        // 湿度 40% -> CloudHigh 1.35 (极稀薄，即将消散)
        // ---------------------------------------------------
        
        // 钳制湿度输入范围，防止数值溢出
        const effectiveHum = Math.max(30, Math.min(98, humidity));
        
        // 线性方程：y = mx + c
        // (95, 0.45), (40, 1.35)
        // m = (1.35 - 0.45) / (40 - 95) = 0.9 / -55 ≈ -0.0163
        // 使用稍微平滑一点的系数 -0.013
        
        target.cloudHigh = 2.1 - (effectiveHum * 0.015);
    }

    // 全局随机性
    let jitter = (Math.random() - 0.5) * 0.02;
    target.stormRadius += jitter;
    target.distortion += jitter * 2.0;

    let sstThreshold = 27.0;
    let sstEffect = Math.max(0, (sstThreshold - sst) * 0.3);
    
    target.cloudHigh += sstEffect;

    const smoothFactor = 0.25;

    // 登陆后逻辑
    if (isLand) {
        currentParams.cloudHigh += 0.15; 
        currentParams.centralMass -= 0.04;
        if (currentParams.cloudHigh > 2.0) currentParams.cloudHigh = 2.0; 
        
        target.eye = -0.15; 
        target.eyeClarity = 0.0;
        target.spiral *= 0.8; 
    } else {
        currentParams.cloudHigh = lerp(currentParams.cloudHigh, target.cloudHigh, smoothFactor);
    }

    currentParams.spiral = lerp(currentParams.spiral, target.spiral, smoothFactor);
    const eyeRadiusSmoothFactor = (!isEyeEligible || isLand) ? 0.10 : smoothFactor;
    currentParams.eye = lerp(currentParams.eye, target.eye, eyeRadiusSmoothFactor);
    currentParams.eyeClarity = lerp(
        currentParams.eyeClarity,
        target.eyeClarity,
        isLand ? 0.55 : 0.32
    );
    currentParams.distortion = lerp(currentParams.distortion, target.distortion, smoothFactor);
    currentParams.stormRadius = lerp(currentParams.stormRadius, target.stormRadius, smoothFactor);
    currentParams.centralMass = lerp(currentParams.centralMass, target.centralMass, smoothFactor);
    currentParams.shear = lerp(currentParams.shear, target.shear, smoothFactor);
    currentParams.cloudLow = lerp(currentParams.cloudLow, target.cloudLow, smoothFactor);
    currentParams.cloudHigh = lerp(currentParams.cloudHigh, target.cloudHigh, smoothFactor);
    currentParams.asymStrength = lerp(currentParams.asymStrength, target.asymStrength, smoothFactor);
    currentParams.asymDir = lerp(currentParams.asymDir, target.asymDir, smoothFactor * 0.5);
}

let canvasIsVisible = false;
let canvasDisplayWidth = 0;
let canvasDisplayHeight = 0;
let renderFramePending = false;
let satelliteVisibilityObserver = null;
let satelliteResizeObserver = null;

function scheduleSatelliteRender() {
    if (!canvas || !canvasIsVisible || document.hidden || renderFramePending) return;
    if (renderWorker && (!workerReady || workerFramePending)) return;
    renderFramePending = true;
    requestAnimationFrame(render);
}

function updateSatelliteVisibility(isVisible) {
    canvasIsVisible = isVisible;
    if (canvasIsVisible) {
        if (!satelliteResizeObserver && canvas) {
            const rect = canvas.getBoundingClientRect();
            canvasDisplayWidth = Math.round(rect.width);
            canvasDisplayHeight = Math.round(rect.height);
        }
        scheduleSatelliteRender();
    }
}

function configureSatelliteCanvasObservers() {
    satelliteVisibilityObserver?.disconnect();
    satelliteResizeObserver?.disconnect();
    renderFramePending = false;
    canvasIsVisible = false;
    canvasDisplayWidth = 0;
    canvasDisplayHeight = 0;

    if (typeof IntersectionObserver === 'function') {
        satelliteVisibilityObserver = new IntersectionObserver(entries => {
            const entry = entries.find(item => item.target === canvas);
            updateSatelliteVisibility(Boolean(
                entry?.isIntersecting
                && entry.intersectionRect.width > 0
                && entry.intersectionRect.height > 0
            ));
        });
        satelliteVisibilityObserver.observe(canvas);
    } else {
        // Compatibility fallback: classList checks do not force layout.
        const satelliteWindow = canvas.closest('#satellite-window');
        updateSatelliteVisibility(Boolean(
            canvas.isConnected
            && !document.hidden
            && satelliteWindow
            && !satelliteWindow.classList.contains('hidden')
        ));
    }

    if (typeof ResizeObserver === 'function') {
        satelliteResizeObserver = new ResizeObserver(entries => {
            const entry = entries.find(item => item.target === canvas);
            if (!entry) return;

            canvasDisplayWidth = Math.round(entry.contentRect.width);
            canvasDisplayHeight = Math.round(entry.contentRect.height);
            scheduleSatelliteRender();
        });
        satelliteResizeObserver.observe(canvas);
    }

    document.removeEventListener('visibilitychange', handleSatelliteDocumentVisibility);
    document.addEventListener('visibilitychange', handleSatelliteDocumentVisibility);
    window.removeEventListener('resize', handleSatelliteWindowResize);
    window.addEventListener('resize', handleSatelliteWindowResize, { passive: true });
}

function handleSatelliteDocumentVisibility() {
    if (document.hidden) return;

    // IntersectionObserver owns visibility in supported browsers. The class
    // check is only a layout-free fallback for older browsers.
    if (!satelliteVisibilityObserver && canvas) {
        const satelliteWindow = canvas.closest('#satellite-window');
        updateSatelliteVisibility(Boolean(
            canvas.isConnected
            && satelliteWindow
            && !satelliteWindow.classList.contains('hidden')
        ));
    } else if (canvasIsVisible) {
        scheduleSatelliteRender();
    }
}

function handleSatelliteWindowResize() {
    if (satelliteResizeObserver || !canvasIsVisible || !canvas) return;
    const rect = canvas.getBoundingClientRect();
    canvasDisplayWidth = Math.round(rect.width);
    canvasDisplayHeight = Math.round(rect.height);
    scheduleSatelliteRender();
}

function render() {
    renderFramePending = false;

    // Visibility and CSS dimensions are cached by observers. Reading
    // offsetParent/clientWidth here forced synchronous style/layout work on
    // every animation frame, including while the satellite panel was hidden.
    if (document.hidden || !canvas.isConnected || !canvasIsVisible) return;
    if (canvasDisplayWidth <= 0 || canvasDisplayHeight <= 0) return;

    const time = (Date.now() - startTime) * 0.001;

    if (renderWorker) {
        if (!workerReady || workerFramePending) return;
        workerFramePending = true;
        try {
            renderWorker.postMessage({type:'frame',width:canvasDisplayWidth,height:canvasDisplayHeight,
                time,params:{...currentParams},grayscale:isGrayscale});
        } catch (error) { stopRenderWorker(error); }
        return; // The acknowledgement schedules the next frame; no backlog.
    }
    if (!gl || !program) {
        // Set the backing size BEFORE acquiring WebGL, avoiding a reset of
        // an existing GPU buffer on the compatibility path's first frame.
        canvas.width = canvasDisplayWidth;
        canvas.height = canvasDisplayHeight;
        try { initializeSatelliteRenderer(canvas, true); }
        catch (error) { console.warn(error); return; }
    }
    drawSatelliteFrame(canvasDisplayWidth, canvasDisplayHeight, time, currentParams, isGrayscale);
    scheduleSatelliteRender();
}

export function drawSatelliteFrame(width, height, time, params, grayscale) {
    if (canvas.width !== width || canvas.height !== height) {
        if (canvas.width !== width) canvas.width = width;
        if (canvas.height !== height) canvas.height = height;
        gl.viewport(0, 0, canvas.width, canvas.height);
    }
    currentParams = params;
    isGrayscale = grayscale;

    gl.useProgram(program);
    
    gl.uniform2f(uniforms.u_resolution, canvas.width, canvas.height);
    gl.uniform1f(uniforms.u_time, time);
    gl.uniform1f(uniforms.u_spiral_strength, currentParams.spiral);
    gl.uniform1f(uniforms.u_eye_radius, currentParams.eye);
    gl.uniform1f(uniforms.u_eye_clarity, currentParams.eyeClarity);
    gl.uniform1f(uniforms.u_shape_distortion, currentParams.distortion);
    gl.uniform1f(uniforms.u_storm_radius, currentParams.stormRadius);
    gl.uniform1f(uniforms.u_central_mass_size, currentParams.centralMass);
    gl.uniform1f(uniforms.u_wind_shear_strength, currentParams.shear);
    gl.uniform1f(uniforms.u_cloud_low, currentParams.cloudLow);
    gl.uniform1f(uniforms.u_cloud_high, currentParams.cloudHigh);
    gl.uniform1f(uniforms.u_random_seed, currentParams.seed);
    gl.uniform1f(uniforms.u_hemisphere, currentParams.hemisphere);
    gl.uniform1f(uniforms.u_asym_strength, currentParams.asymStrength);
    gl.uniform1f(uniforms.u_asym_dir, currentParams.asymDir);
    gl.uniform1f(uniforms.u_grayscale, isGrayscale ? 1.0 : 0.0);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
}

export function getSatelliteSnapshot() {
    if (renderWorker) {
        // Freeze parameters at request time, not when the encoder catches up.
        const id = ++snapshotRequestId;
        return new Promise(resolve => {
            const timer = setTimeout(() => {
                workerSnapshots.delete(id);
                resolve(null);
            }, 10000);
            const message = {type:'snapshot',id,
                width:canvasDisplayWidth || 384,height:canvasDisplayHeight || 384,
                time:(Date.now()-startTime)*.001,params:{...currentParams},grayscale:isGrayscale};
            workerSnapshots.set(id, {resolve,timer,message});
            try {
                if (workerReady) renderWorker.postMessage(message);
            } catch (error) { stopRenderWorker(error); }
        });
    }
    if (!gl || !canvas || !program) return Promise.resolve(null);

    // render() 自身会安排下一帧；截图时再次调用会额外启动一条永久渲染循环。
    // WebGL 上下文启用了 preserveDrawingBuffer，因此只需读取最近完成的画面。
    // 关键性能点：先在请求帧立即生成独立的小缩略图，再把真正的编码排队。
    // 这样既不会因为排队太久而把“旧时间点”编码成“新画面”，也不会让多个
    // toBlob 同时争抢 CPU。实时画布仍保持原尺寸，只有历史快照降采样。
    return new Promise(resolve => {
        const capture = () => {
            if (!canvas || !canvas.width || !canvas.height) {
                resolve(null);
                return;
            }

            let snapshotCanvas;
            try {
                const scale = Math.min(
                    1,
                    SATELLITE_SNAPSHOT_MAX_EDGE / Math.max(canvas.width, canvas.height)
                );
                snapshotCanvas = document.createElement('canvas');
                snapshotCanvas.width = Math.max(1, Math.round(canvas.width * scale));
                snapshotCanvas.height = Math.max(1, Math.round(canvas.height * scale));

                const snapshotContext = snapshotCanvas.getContext('2d', { alpha: false });
                if (!snapshotContext) {
                    resolve(null);
                    return;
                }
                snapshotContext.imageSmoothingEnabled = true;
                snapshotContext.imageSmoothingQuality = 'medium';
                snapshotContext.drawImage(
                    canvas,
                    0,
                    0,
                    snapshotCanvas.width,
                    snapshotCanvas.height
                );
            } catch (error) {
                console.warn('Satellite snapshot copy failed:', error);
                resolve(null);
                return;
            }

            const encode = () => {
                // Chromium 等现代浏览器将 JPEG 编码放进 Worker，避免
                // toBlob 占用模拟、拖拽和面板更新所在的主线程。
                try {
                    const backgroundEncode = encodeSatelliteSnapshotOffMainThread(snapshotCanvas);
                    if (backgroundEncode) {
                        return backgroundEncode.catch(() =>
                            encodeSatelliteSnapshotOnMainThread(snapshotCanvas)
                        );
                    }
                } catch (error) {
                    // 能力探测或 ImageBitmap 创建失败时走兼容路径。
                }
                return encodeSatelliteSnapshotOnMainThread(snapshotCanvas);
            };

            // 错误被吸收后继续队列，避免一次编码失败让后续历史快照永久卡住。
            const queuedEncode = satelliteSnapshotEncodeQueue
                .catch(() => null)
                .then(encode);
            satelliteSnapshotEncodeQueue = queuedEncode.catch(() => null);
            queuedEncode.then(resolve, () => resolve(null));
        };

        // 等待一次绘制机会，确保 updateSatelliteView 写入的 uniforms 已经
        // 反映到画面；不会主动启动第二条渲染循环。
        if (typeof requestAnimationFrame === 'function') requestAnimationFrame(capture);
        else setTimeout(capture, 0);
    });
}

// object URL 不需要转成 Data URL；当快照被淘汰或请求因重启而失效时释放它。
export function releaseSatelliteSnapshot(snapshot) {
    if (typeof snapshot === 'string' && snapshot.startsWith('blob:')) {
        URL.revokeObjectURL(snapshot);
    }
}
