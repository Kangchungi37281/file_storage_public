import { DAILY_WEATHER_DATA } from './daily-weather-data.js';
import { sampleMonthlyHeight } from './circulation-climatology.js';
const decoded = new Map();
const packedDecoded = new Map();
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
const cubic=(a,b,c,d,t)=>b+.5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*(b-c)+d-a)));
const monthStarts=[2,33,63,94,125,155]; // days after April29, May–October
const monthLengths=[31,30,31,31,30,31];
export function initializeWeatherSequence(month,seed) {
 const rng=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 return {version:1,record:Math.floor(rng()*DAILY_WEATHER_DATA.length),startDay:monthStarts[month-5]+Math.floor(rng()*monthLengths[month-5])};
}
function dataFor(record) {
 if(!decoded.has(record)) {
  const text=atob(DAILY_WEATHER_DATA[record].packed),values=new Int16Array(text.length/2);
  for(let i=0;i<values.length;i++)values[i]=text.charCodeAt(2*i)|(text.charCodeAt(2*i+1)<<8);
  decoded.set(record,values);
 }
 return decoded.get(record);
}
// The ICWC 500-hPa chart samples thousands of grid cells from one fixed
// observed-weather record. Keep a signed 16-bit packed view so WebGPU can
// evaluate the same daily sequence without uploading or decoding it per cell.
export function packedWeatherSequenceRecord(record) {
 if(!Number.isInteger(record)||!DAILY_WEATHER_DATA[record])return new Uint32Array(0);
 if(!packedDecoded.has(record)) {
  const values=dataFor(record),packed=new Uint32Array(Math.ceil(values.length/2));
  for(let i=0;i<values.length;i+=2) {
   const high=values[i+1]??0;
   packed[i>>1]=((values[i]&0xffff)|((high&0xffff)<<16))>>>0;
  }
  packedDecoded.set(record,packed);
 }
 return packedDecoded.get(record);
}
// Interpolate the source monthly mean continuously in time before removing
// it. This keeps month-boundary jumps out of the daily anomaly sequence.
function sourceMean(lon,lat,day,level) {
 const dates=[-14,16,47,77,108,139,169,200,230];
 let i=0;while(i<dates.length-2&&day>dates[i+1])i++;
 const f=clamp((day-dates[i])/(dates[i+1]-dates[i]),0,1);
 return (1-f)*sampleMonthlyHeight(lon,lat,i+4,level)+f*sampleMonthlyHeight(lon,lat,i+5,level);
}
export function sampleWeatherHeight(lon,lat,background,level=500) {
 const state=background.weatherSequence;
 if(!state||state.version!==1||!DAILY_WEATHER_DATA[state.record])return 0;
 lon=((lon%360)+360)%360;
 const day=state.startDay+(background.elapsedHours||0)/24;
 const weight=smooth((lon-85)/10)*smooth((200-lon)/10)*smooth(lat/5)*smooth((65-lat)/10)*smooth((215-day)/5);
 if(weight===0)return 0;
 const x=clamp((lon-85)/2.5,0,46),y=clamp(lat/2.5,0,26),ix=Math.floor(x),iy=Math.floor(y);
 const z=level===850?0:level===200?2:1;
 const data=dataFor(state.record),d0=Math.floor(clamp(day,0,215)),t=clamp(day-d0,0,1);
 const spatial=d=>{
  const row=j=>{const offset=((d*3+z)*27+clamp(j,0,26))*47;const at=i=>data[offset+clamp(i,0,46)];return cubic(at(ix-1),at(ix),at(ix+1),at(ix+2),x-ix);};
  return cubic(row(iy-1),row(iy),row(iy+1),row(iy+2),y-iy);
 };
 return weight*((1-t)*spatial(d0)+t*spatial(Math.min(215,d0+1))-sourceMean(lon,lat,day,level));
}
