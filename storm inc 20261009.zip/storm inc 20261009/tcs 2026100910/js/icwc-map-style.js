// Shared base-map palette for ICWC warning and probability products.
export const ICWC_MAP_STYLE = Object.freeze({
    ocean: '#6ea4c7',
    land: '#d3d6cc',
    coast: '#171d21',
    grid: 'rgba(21,50,65,.35)',
    gridStep: 5
});
