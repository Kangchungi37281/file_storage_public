import { buildStaticAtlasGeometry, staticAtlasCamera } from './static-atlas-geometry.js';

const geometryCache = new WeakMap();
const layerCache = new WeakMap();
const pending = new Map();
let worker;
let workerUnavailable = false;
let sequence = 0;

function stopWorker(error) {
    workerUnavailable = true;
    worker?.terminate();
    worker = null;
    for (const request of pending.values()) request.reject(error);
    pending.clear();
}

function buildInWorker(world, highland, scale, precision) {
    return new Promise((resolve, reject) => {
        if (workerUnavailable || typeof Worker === 'undefined') {
            reject(new Error('Static atlas Worker unavailable'));
            return;
        }
        try {
            if (!worker) {
                worker = new Worker(new URL('./static-atlas-worker.js', import.meta.url), { type: 'module' });
                worker.onmessage = ({ data }) => {
                    const request = pending.get(data.id);
                    if (!request) return;
                    pending.delete(data.id);
                    if (data.error) request.reject(new Error(data.error));
                    else request.resolve(data.geometry);
                };
                worker.onerror = error => stopWorker(error);
                worker.onmessageerror = error => stopWorker(error);
            }
            const id = ++sequence;
            pending.set(id, { resolve, reject });
            try { worker.postMessage({ id, world, highland, scale, precision }); }
            catch (error) { pending.delete(id); reject(error); }
        } catch (error) { stopWorker(error); reject(error); }
    });
}

function geometryFor(world, highland, scale, precision) {
    let entry = geometryCache.get(world);
    // Reuse across DOM replacement, restarts, pan, and zoom-out. Only a new
    // source or a tighter angular error budget needs another background build.
    const tolerance = precision / scale;
    if (entry && entry.highland === highland && entry.tolerance <= tolerance) return entry;
    entry = { highland, tolerance, geometry: null };
    entry.ready = buildInWorker(world, highland, scale, precision).catch(error => {
        console.warn('Static atlas using cached main-thread fallback:', error);
        return new Promise((resolve, reject) => setTimeout(() => {
            try { resolve(buildStaticAtlasGeometry(d3, world, highland, scale, precision)); }
            catch (failure) { reject(failure); }
        }, 0));
    }).then(geometry => { entry.geometry = geometry; return geometry; });
    geometryCache.set(world, entry);
    return entry;
}

export function clearStaticAtlas(layer) {
    if (!layerCache.has(layer.node())) return;
    layerCache.delete(layer.node()); // Invalidates any delayed completion.
    layer.selectAll('*').remove();
}

function paintAtlas(layer, record) {
    const geometry = record.entry.geometry;
    if (!geometry) return; // Keep the previous atlas while rebuilding.
    if (record.installed !== geometry || !layer.node().querySelector('.static-atlas-camera')) {
        layer.selectAll('*').remove();
        record.id = `tcs-static-atlas-${++sequence}`;
        const defs = layer.append('defs').append('g').attr('id', record.id);
        for (const spec of geometry.paths) {
            defs.append('path').attr('class', spec.className).attr('d', spec.d)
                .attr('vector-effect', 'non-scaling-stroke')
                .style('stroke', spec.stroke || null).style('fill', spec.fill || null);
        }
        // Keep the same single-world footprint as D3 at wide history zooms.
        // Periodic copies join at Greenwich, but must stop at the current
        // projection's antimeridian and poles, even in a >360-degree viewport.
        record.clip = layer.select('defs').append('clipPath')
            .attr('id', `${record.id}-clip`).attr('clipPathUnits', 'userSpaceOnUse')
            .append('rect');
        record.camera = layer.append('g')
            .attr('clip-path', `url(#${record.id}-clip)`)
            .append('g').attr('class', 'static-atlas-camera');
        record.installed = geometry;
    }
    const { dx, dy, period, copies } = record.view;
    record.clip.attr('x', record.bounds.x).attr('y', record.bounds.y)
        .attr('width', period).attr('height', period / 2);
    record.camera.attr('transform', `translate(${dx},${dy})`)
        .selectAll('use').data(copies, d => d).join('use')
        .attr('href', `#${record.id}`)
        .attr('transform', d => `translate(${d * period},0) scale(${record.scale / geometry.scale})`);
}

export function drawStaticCylindricalAtlas(layer, projection, world, highland, width) {
    const rotation = projection.rotate();
    if (!projection.tcsCylindricalAtlas || rotation[1] || rotation[2]
        || projection.angle() || projection.reflectX() || projection.reflectY()
        || projection.clipAngle() || projection.clipExtent()) return false;
    const node = layer.node();
    const entry = geometryFor(world, highland, projection.scale(), projection.precision());
    let record = layerCache.get(node);
    if (!record) { record = {}; layerCache.set(node, record); }
    record.scale = projection.scale();
    record.view = staticAtlasCamera(rotation[0], projection.center(), projection.translate(), record.scale, width);
    record.bounds = {
        x: projection.translate()[0] - record.scale * (Math.PI + projection.center()[0] * Math.PI / 180),
        y: record.view.dy - record.scale * Math.PI / 2
    };
    if (record.entry !== entry) {
        record.entry = entry;
        entry.ready.then(() => {
            if (layerCache.get(node) === record && record.entry === entry) paintAtlas(layer, record);
        }).catch(error => console.error('Static atlas could not be generated:', error));
    }
    // Even while a sharper atlas is pending, move/scale the old one with the
    // latest camera so terrain never freezes at the previous cyclone position.
    if (!entry.geometry && record.installed) {
        const requested = record.entry;
        record.entry = { geometry: record.installed };
        paintAtlas(layer, record);
        record.entry = requested;
    } else paintAtlas(layer, record);
    return true;
}
