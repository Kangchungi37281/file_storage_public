// Exact D3 contour extraction, independent of field evaluation and drawing.
let worker, unavailable = false, sequence = 0;
const pending = new Map();

function stopWorker(error) {
    unavailable = true;
    worker?.terminate();
    worker = null;
    for (const request of pending.values()) request.reject(error);
    pending.clear();
}

export async function prepareICWCContours(values, nx, ny, thresholds) {
    if (unavailable || typeof Worker === 'undefined') return null;
    try {
        if (!worker) {
            worker = new Worker(new URL('./icwc-contours-worker.js', import.meta.url), { type: 'module' });
            worker.onmessage = ({ data }) => {
                const request = pending.get(data.id);
                if (!request) return;
                pending.delete(data.id);
                if (data.error) request.reject(new Error(data.error));
                else request.resolve(data.contours);
            };
            worker.onerror = error => stopWorker(error);
            worker.onmessageerror = error => stopWorker(error);
        }
        const id = ++sequence;
        // Keep the original render grid intact; transfer only its exact copy.
        const copy = values.slice();
        return await new Promise((resolve, reject) => {
            pending.set(id, { resolve, reject });
            try { worker.postMessage({ id, values: copy, nx, ny, thresholds }, [copy.buffer]); }
            catch (error) { pending.delete(id); reject(error); }
        });
    } catch (error) {
        console.warn('[ICWC contours] Original contour extraction fallback:', error);
        return null;
    }
}
