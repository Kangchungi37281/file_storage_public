import {
    calculateWindRadii,
    updatePressureSystems,
    updateFrontalZone
} from './cyclone-model.js?v=20261008-forecast-categories1';
import { generatePathForecastsAsync } from './forecast-models.js?v=20261008-forecast-categories1';
import { getLandStatus } from './terrain-data.js?v=20260911-worker1-raster1';

let worker = null;
let readyPromise = null;
let readyResolve = null;
let requestSequence = 0;
const requests = new Map();
const profileForecast = Boolean(globalThis.location?.search)
    && new URLSearchParams(globalThis.location.search).has('step-profile');

function rejectPending(error) {
    requests.forEach(request => request.reject(error));
    requests.clear();
}

function disableWorker(error) {
    if (worker) worker.terminate();
    worker = null;
    // A load error can happen before the ready message. Wake callers which
    // are still waiting for initialization so they can use the fallback.
    readyResolve?.(false);
    readyPromise = null;
    readyResolve = null;
    rejectPending(error);
}

// Rendering/history archives grow throughout a run but are never read by
// forecast steering. Do not copy them into the Worker on every advisory.
export function forecastCycloneSnapshot(cyclone) {
    const { track, forecastLogs, pathForecasts, satelliteCache, ...snapshot } = cyclone;
    return snapshot;
}

export async function generateObservationForecastOffMainThread(input) {
    const snapshot = structuredClone({ ...input, cyclone: forecastCycloneSnapshot(input.cyclone) });
    if (worker && readyPromise && await readyPromise) {
        const id = ++requestSequence;
        return new Promise((resolve, reject) => {
            requests.set(id, { resolve, reject });
            try { worker.postMessage({ type: 'observation-forecast', id, input: snapshot }); }
            catch (error) { requests.delete(id); reject(error); }
        });
    }
    if (!snapshot.forecasts.length && !snapshot.cyclone.isExtratropical) {
        snapshot.forecasts = await generatePathForecastsAsync(snapshot.cyclone,
            structuredClone(snapshot.pressureSystems), (lon, lat) => getLandStatus(lon, lat).isLand,
            snapshot.globalTemp, snapshot.globalShear, snapshot.cyclone.age + 1);
    }
    const { buildObservationForecast } = await import('./observation-forecast.js?v=20261008-forecast-categories1');
    return buildObservationForecast(snapshot);
}

export async function generatePathForecastsOffMainThread(cyclone, pressureSystems,
    globalTemp = 289, globalShearSetting = 100, randomSeed = null) {
    if (cyclone.isExtratropical) return [];
    const snapshot = structuredClone(forecastCycloneSnapshot(cyclone));
    // Capture before the first await: the live storm/field can advance while
    // worker initialization or cooperative fallback is in progress.
    const systemsSnapshot = structuredClone(pressureSystems);
    const fallback = () => generatePathForecastsAsync(snapshot, systemsSnapshot,
        (lon, lat) => getLandStatus(lon, lat).isLand,
        globalTemp, globalShearSetting, randomSeed);
    if (!worker || !readyPromise) return fallback();
    try {
        if (!await readyPromise) return fallback();
        const id = ++requestSequence;
        return await new Promise((resolve, reject) => {
            requests.set(id, { resolve, reject });
            try {
                if (profileForecast) {
                    console.info(`[forecast-profile-request] id=${id}`);
                }
                worker.postMessage({ type: 'forecast', id, cyclone: snapshot,
                    pressureSystems: systemsSnapshot, globalTemp, globalShearSetting, randomSeed,
                    profile: profileForecast });
            } catch (error) {
                requests.delete(id);
                reject(error);
            }
        });
    } catch (error) {
        console.warn('[forecast] Worker unavailable; using cooperative fallback:', error);
        return fallback();
    }
}

export function initializeWindRadiiWorker(terrain) {
    if (!terrain || typeof Worker !== 'function') return false;
    try {
        worker = new Worker(new URL('./wind-radii-worker.js?v=20261008-forecast-categories1', import.meta.url), {
            type: 'module'
        });
        readyPromise = new Promise(resolve => { readyResolve = resolve; });
        worker.onmessage = event => {
            const message = event.data || {};
            if (message.type === 'ready') {
                if (message.terrainReady === true) {
                    console.info('[wind-radii] Worker ready.');
                } else {
                    console.warn('[wind-radii] Worker terrain unavailable; using synchronous fallback.');
                }
                readyResolve?.(message.terrainReady === true);
                readyResolve = null;
                return;
            }
            if (message.type === 'forecast-profile') {
                console.info(`[forecast-profile] ${JSON.stringify(message.profile || {})}`);
                return;
            }
            const request = requests.get(message.id);
            if (!request) return;
            requests.delete(message.id);
            if (message.type === 'result') request.resolve(message.result ?? message.radii);
            else request.reject(new Error(message.error || 'Wind-radius Worker failed'));
        };
        worker.onerror = event => {
            console.warn('[wind-radii] Worker disabled:', event?.message || 'unknown error');
            disableWorker(new Error(event?.message || 'Wind-radius Worker failed'));
        };
        const transfer = [terrain.elevationData.buffer, terrain.landMaskData.buffer];
        if (terrain.coastDistanceData) transfer.push(terrain.coastDistanceData.buffer);
        worker.postMessage({ type: 'init', terrain }, transfer);
        return true;
    } catch (error) {
        disableWorker(error);
        return false;
    }
}

export async function advanceAtmosphereOffMainThread(pressureSystems, month) {
    if (!worker || !readyPromise) {
        const systems = updatePressureSystems(pressureSystems, month);
        return {
            pressureSystems: systems,
            frontalZone: updateFrontalZone(systems, month)
        };
    }
    try {
        if (!await readyPromise) {
            const systems = updatePressureSystems(pressureSystems, month);
            return {
                pressureSystems: systems,
                frontalZone: updateFrontalZone(systems, month)
            };
        }
        const id = ++requestSequence;
        return await new Promise((resolve, reject) => {
            requests.set(id, { resolve, reject });
            worker.postMessage({
                type: 'advance-atmosphere',
                id,
                pressureSystems,
                month
            });
        });
    } catch (error) {
        // Keep unsupported/lost Workers behaviourally identical to the
        // original synchronous model path.
        const systems = updatePressureSystems(pressureSystems, month);
        return {
            pressureSystems: systems,
            frontalZone: updateFrontalZone(systems, month)
        };
    }
}

export async function calculateWindRadiiOffMainThread(cyclone, pressureSystems, month) {
    // Wind-radius diagnostics only read the instantaneous vortex and field.
    // Sending the live object copied its complete best track, forecast log,
    // and satellite cache into the Worker every 3 h; those arrays grow for
    // the whole run and were the source of a periodic structured-clone/GC
    // spike. Keep the Worker payload bounded to the same instantaneous
    // snapshot used by the forecast request.
    const snapshot = forecastCycloneSnapshot(cyclone);
    if (!worker || !readyPromise) {
        return calculateWindRadii(cyclone, pressureSystems, month);
    }
    try {
        if (!await readyPromise) {
            return calculateWindRadii(cyclone, pressureSystems, month);
        }
        const id = ++requestSequence;
        return await new Promise((resolve, reject) => {
            requests.set(id, { resolve, reject });
            worker.postMessage({
                type: 'calculate',
                id,
                cyclone: snapshot,
                pressureSystems,
                month
            });
        });
    } catch (error) {
        // Exact synchronous fallback: unsupported Workers or a lost Worker
        // change performance only, never the diagnostic or history schema.
        return calculateWindRadii(cyclone, pressureSystems, month);
    }
}
