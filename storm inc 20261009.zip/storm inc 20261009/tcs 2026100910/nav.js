(() => {
    const homeURL = new URL('index.html', document.currentScript.src).href;

    function mountHomeNav() {
        if (!document.body || document.getElementById('enceladus-home-nav')) return;

        const style = document.createElement('style');
        style.id = 'enceladus-home-nav-style';
        style.textContent = `
            #enceladus-home-nav {
                all: initial;
                position: fixed;
                top: max(8px, env(safe-area-inset-top));
                left: 0;
                z-index: 60;
                font-family: system-ui, -apple-system, "PingFang SC", sans-serif;
            }

            #enceladus-home-nav.enceladus-home-inline {
                position: static;
                flex: 0 0 auto;
                margin-right: auto;
            }

            #enceladus-home-nav.enceladus-home-brand {
                position: static;
                flex: 0 0 auto;
                margin-left: auto;
                margin-right: 0;
            }

            .topbar:has(#enceladus-home-nav.enceladus-home-inline) .menu-btn {
                margin-right: 0;
            }

            #enceladus-home-link {
                all: initial;
                box-sizing: border-box;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 0;
                min-width: 25px;
                min-height: 30px;
                padding: 0 4px;
                border: 1px solid rgba(226, 232, 240, .16);
                border-left: 0;
                border-radius: 0 8px 8px 0;
                background: rgba(12, 20, 31, .62);
                color: #d5dfeb;
                font: 500 12px/1 system-ui, -apple-system, "PingFang SC", sans-serif;
                text-decoration: none;
                cursor: pointer;
                opacity: .65;
                box-shadow: none;
                backdrop-filter: blur(8px);
                -webkit-backdrop-filter: blur(8px);
                transition: opacity .18s ease, background-color .18s ease, border-color .18s ease;
            }

            #enceladus-home-link .enceladus-home-arrow {
                font: 400 17px/1 system-ui, sans-serif;
                transform: translateY(-1px);
            }

            #enceladus-home-nav.enceladus-home-inline #enceladus-home-link {
                border-left: 1px solid rgba(226, 232, 240, .16);
                border-radius: 7px;
            }

            #enceladus-home-nav.enceladus-home-brand #enceladus-home-link {
                min-width: 32px;
                min-height: 32px;
                padding: 0 8px;
                border: 0;
                border-radius: 8px;
                background: transparent;
                color: #c1ccd5;
                opacity: .85;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
            }

            #enceladus-home-nav.enceladus-home-brand #enceladus-home-link:hover,
            #enceladus-home-nav.enceladus-home-brand #enceladus-home-link:focus-visible {
                background: #26313c;
                color: #e6edf3;
                opacity: 1;
            }

            #enceladus-home-link .enceladus-home-label {
                overflow: hidden;
                max-width: 0;
                opacity: 0;
                white-space: nowrap;
                transition: max-width .18s ease, opacity .18s ease;
            }

            #enceladus-home-link:hover,
            #enceladus-home-link:focus-visible {
                gap: 5px;
                opacity: 1;
                border-color: rgba(226, 232, 240, .34);
                background: rgba(12, 20, 31, .9);
            }

            #enceladus-home-link:hover .enceladus-home-label,
            #enceladus-home-link:focus-visible .enceladus-home-label {
                max-width: 4em;
                opacity: 1;
            }

            #enceladus-home-link:focus-visible {
                outline: 2px solid #d5dfeb;
                outline-offset: 3px;
            }

            @media (hover: none) {
                #enceladus-home-link { min-height: 36px; opacity: .85; }
            }

            @media (prefers-reduced-motion: reduce) {
                #enceladus-home-link,
                #enceladus-home-link .enceladus-home-label { transition: none; }
            }
        `;
        document.head.appendChild(style);

        const nav = document.createElement('nav');
        nav.id = 'enceladus-home-nav';
        nav.setAttribute('aria-label', '全站导航');
        const link = document.createElement('a');
        link.id = 'enceladus-home-link';
        link.href = homeURL;
        link.setAttribute('aria-label', '返回 Enceladus 首页');
        link.innerHTML = '<span class="enceladus-home-arrow" aria-hidden="true">←</span><span class="enceladus-home-label" aria-hidden="true">首页</span>';
        nav.appendChild(link);

        const brandHost = document.querySelector('[data-home-nav="brand"]');
        const mapTopbar = document.querySelector('main.main > header.topbar');
        if (brandHost) {
            nav.classList.add('enceladus-home-brand');
            link.title = '返回首页';
            link.innerHTML = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/></svg><span class="enceladus-home-label" aria-hidden="true">首页</span>';
            brandHost.appendChild(nav);
        } else if (mapTopbar && mapTopbar.querySelector('.menu-btn, .tabs')) {
            nav.classList.add('enceladus-home-inline');
            mapTopbar.insertBefore(nav, mapTopbar.querySelector('.tabs'));
        } else {
            document.body.appendChild(nav);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mountHomeNav, { once: true });
    } else {
        mountHomeNav();
    }
})();
