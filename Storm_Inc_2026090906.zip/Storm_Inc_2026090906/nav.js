const NAV_HOME_URL = new URL('index.html', document.currentScript.src).href;

document.addEventListener('DOMContentLoaded', () => {
    // 1. 定义导航按钮的HTML结构
    // 使用 FontAwesome 图标，去掉冗余的文字标签，改为悬停显示
    const navHTML = `
        <nav class="main-nav">
            <a href="${NAV_HOME_URL}" class="nav-link-home" title="Return to Index">
                <div class="nav-icon-container">
                    <i class="fa-solid fa-angles-left"></i>
                </div>
                <span class="nav-text">返回首页</span>
            </a>
        </nav>
    `;

    // 2. 定义导航按钮的CSS样式
    // 采用 "JetBrains Mono" 字体，青色高亮，玻璃拟态背景
    const navCSS = `
        .main-nav {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 9999; /* 确保在最上层 */
            font-family: 'JetBrains Mono', 'Courier New', monospace;
        }

        .nav-link-home {
            display: flex;
            align-items: center;
            height: 32px;
            padding: 0 10px;
            background-color: rgba(5, 5, 5, 0.6);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: #94a3b8; /* Slate-400 */
            text-decoration: none;
            border-radius: 4px; /* 稍微圆角，保持硬朗感 */
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            font-size: 11px;
            letter-spacing: 1px;
            gap: 8px;
        }

        /* 悬停状态：高亮并显示边框发光 */
        .nav-link-home:hover {
            background-color: rgba(34, 211, 238, 0.1); /* Cyan tint */
            border-color: rgba(34, 211, 238, 0.6);
            color: #22d3ee; /* Cyan-400 */
            box-shadow: 0 0 15px rgba(34, 211, 238, 0.2);
            transform: translateX(2px);
        }

        /* 图标样式 */
        .nav-icon-container {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* 文字样式 */
        .nav-text {
            font-weight: 700;
            opacity: 0.8;
            white-space: nowrap;
        }
        
        /* 针对移动端的微调 */
        @media (max-width: 768px) {
            .main-nav {
                top: 15px;
                left: 15px;
            }
            .nav-link-home {
                height: 28px;
                font-size: 10px;
            }
        }
    `;
    
    // 3. 将CSS注入到页面的<head>中
    const styleElement = document.createElement('style');
    styleElement.textContent = navCSS;
    document.head.appendChild(styleElement);
  
    // 4. 将HTML注入到页面的<body>开头
    document.body.insertAdjacentHTML('afterbegin', navHTML);
});
