/**
 * radar-doppler.js
 * 负责处理 WebGL 多普勒雷达（径向速度）渲染
 * 核心原理：计算风场矢量在雷达视线方向上的投影分量，并模拟多普勒速度折叠
 */
import { getWindVectorAt } from './cyclone-model.js';
import { WebGpuWindFieldBackend } from './webgpu-wind-field.js';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

// ============================================================
// GLSL Fragment Shader (多普勒物理核心)
// ============================================================
const fsSource = `
    precision highp float;

    // --- Uniforms ---
    uniform vec2 u_resolution;       // 画布尺寸
    uniform float u_time;            // 时间
    uniform vec2 u_radar_center;     // 雷达中心 (经纬度)
    uniform float u_radar_radius_km; // 雷达半径 (km)
    
    // 气旋参数
    uniform int u_has_cyclone;       
    uniform vec2 u_cyc_pos;          
    uniform float u_cyc_size;        
    uniform float u_cyc_intensity;   
    uniform float u_cyc_age;         
    uniform float u_cyc_rmw;
    uniform int u_erc_active;
    uniform float u_erc_inner_rmw;
    uniform float u_erc_inner_wind;
    uniform float u_erc_outer_rmw;
    uniform float u_erc_outer_width;
    uniform float u_erc_outer_anomaly;
    uniform float u_erc_outer_share;
    uniform float u_erc_outer_organization;
    uniform float u_erc_inner_integrity;

    uniform vec4 u_sys_params[20]; 
    uniform float u_sys_strength[20];
    
    uniform int u_sys_count;
    uniform sampler2D u_terrain_map; // 地形 (用于简单的杂波过滤)
    uniform sampler2D u_wind_field;  // 同源动力风场；不含近地面地形摩擦

    const float PI = 3.14159265359;
    const float DEG_TO_RAD = 0.01745329251;
    const float NYQUIST_VELOCITY = 50.0; // 最大不模糊速度 m/s（约 97 kt）

    // --- 速度折叠逻辑 ---
    float foldVelocity(float v) {
        // 使用 mod 运算模拟相位折叠
        // 将速度映射到 [-Vmax, +Vmax] 区间内
        // 核心公式: mod(v + Vmax, 2 * Vmax) - Vmax
        return mod(v + NYQUIST_VELOCITY, 2.0 * NYQUIST_VELOCITY) - NYQUIST_VELOCITY;
    }

    // --- 颜色映射：Velocity Ramp ---
    // Inbound (负值): Cool colors (Green/Blue) -> 朝向雷达
    // Outbound (正值): Warm colors (Red/Yellow) -> 远离雷达
    // Zero: Grey/White
    vec4 getVelocityColor(float v) {
        // v 单位: m/s
        
        // 阈值过滤：太小的速度显示为灰色/透明，模拟静风或杂波抑制
        if (abs(v) < 1.5) {
            return vec4(0.6, 0.6, 0.6, 0.2); // 灰色弱回波
        }

        vec3 col = vec3(0.0);
        float alpha = 0.9;
        
        if (v < 0.0) {
            // === Inbound (负值) ===
            float av = abs(v);
            
            if (av < 10.0) {
                col = mix(vec3(0.6, 0.8, 0.6), vec3(0.0, 0.8, 0.0), av / 10.0);
            } else if (av < 20.0) {
                col = mix(vec3(0.0, 0.8, 0.0), vec3(0.0, 0.4, 0.0), (av - 10.0) / 10.0);
            } else if (av < 30.0) {
                col = mix(vec3(0.0, 0.4, 0.0), vec3(0.0, 0.6, 1.0), (av - 20.0) / 10.0);
            } else if (av < 40.0) {
                col = mix(vec3(0.0, 0.6, 1.0), vec3(0.0, 0.0, 0.8), (av - 30.0) / 10.0);
            } else {
                col = mix(vec3(0.0, 0.0, 0.8), vec3(0.6, 0.0, 1.0), clamp((av - 40.0) / 10.0, 0.0, 1.0));
            }
        } else {
            // === Outbound (正值) ===
            if (v < 10.0) {
                col = mix(vec3(0.8, 0.8, 0.6), vec3(1.0, 0.8, 0.0), v / 10.0);
            } else if (v < 20.0) {
                col = mix(vec3(1.0, 0.8, 0.0), vec3(1.0, 0.5, 0.0), (v - 10.0) / 10.0);
            } else if (v < 30.0) {
                col = mix(vec3(1.0, 0.5, 0.0), vec3(1.0, 0.0, 0.0), (v - 20.0) / 10.0);
            } else if (v < 40.0) {
                col = mix(vec3(1.0, 0.0, 0.0), vec3(0.5, 0.0, 0.0), (v - 30.0) / 10.0);
            } else {
                col = mix(vec3(0.5, 0.0, 0.0), vec3(1.0, 0.6, 1.0), clamp((v - 40.0) / 10.0, 0.0, 1.0));
            }
        }

        return vec4(col, alpha);
    }
    // ------------------------------------------
    // 物理计算辅助函数 (复用自 radar-system.js)
    // ------------------------------------------
    float getPressure(vec2 pos) {
        float p = 0.0;
        for (int i = 0; i < 20; i++) {
            if (i >= u_sys_count) break;
            vec4 params = u_sys_params[i];
            float strength = u_sys_strength[i];
            vec2 center = params.xy;
            vec2 sigma = params.zw;
            float dx = pos.x - center.x;
            if (abs(dx) > 180.0) dx = dx > 0.0 ? dx - 360.0 : dx + 360.0;
            float dy = pos.y - center.y;
            float val = strength * exp(-0.5 * ( (dx*dx)/(sigma.x*sigma.x) + (dy*dy)/(sigma.y*sigma.y) ));
            p += val;
        }
        return 1012.0 + p;
    }

    float primaryTangentialWind(
        float radius,
        float rmw,
        float peakWind,
        float size,
        float envelopePeakWind,
        float envelopeRmw
    ) {
        if (radius <= 0.0 || rmw <= 0.0 || peakWind <= 0.0) return 0.0;
        if (radius < rmw) return peakWind * radius / rmw;
        float radialOffset = radius - rmw;
        float coreExponent = clamp(1.05 - size * 0.00025, 0.82, 1.00);
        float coreDecayLengthKm = clamp(30.0 + 0.55 * rmw + 0.03 * size, 80.0, 150.0);
        float coreWind = peakWind
            * pow(rmw / radius, coreExponent)
            * exp(-radialOffset / coreDecayLengthKm);
        float sizeSupport = smoothstep(160.0, 680.0, size);
        float equilibriumRmw = 5.0 + size * 0.125;
        float rmwExpansion = smoothstep(
            equilibriumRmw,
            equilibriumRmw + max(24.0, equilibriumRmw * 0.8),
            envelopeRmw
        );
        float envelopeAmplitude = envelopePeakWind
            * (0.18 + 0.16 * sizeSupport + 0.14 * rmwExpansion);
        float bandCenter = max(envelopeRmw + 30.0, 0.65 * envelopeRmw + 0.25 * size);
        float bandWidth = clamp(0.22 * size, 100.0, 220.0);
        float onsetWidth = clamp(0.60 * rmw, 40.0, 100.0);
        float onset = smoothstep(0.0, onsetWidth, radialOffset);
        float bandOffset = (radius - bandCenter) / bandWidth;
        float rainbandWind = envelopeAmplitude * onset * exp(-0.5 * bandOffset * bandOffset);
        return max(coreWind, rainbandWind);
    }

    vec2 getWindVector(vec2 pos) {
        float dDeg = 0.5;
        float p_x_plus = getPressure(pos + vec2(dDeg, 0.0));
        float p_x_minus = getPressure(pos - vec2(dDeg, 0.0));
        float p_y_plus = getPressure(pos + vec2(0.0, dDeg));
        float p_y_minus = getPressure(pos - vec2(0.0, dDeg));
        float gradX = p_x_plus - p_x_minus;
        float gradY = p_y_plus - p_y_minus;
        float f_sign = pos.y >= 0.0 ? 1.0 : -1.0;
        float bgScale = 4.0;
        vec2 wind_bg = vec2(-gradY, gradX) * bgScale * f_sign;

        vec2 wind_cyc = vec2(0.0);
        if (u_has_cyclone > 0) {
            vec2 offset_deg = pos - u_cyc_pos;
            float dx_km = offset_deg.x * 111.0 * cos(radians(u_cyc_pos.y));
            float dy_km = offset_deg.y * 111.0;
            float dist = sqrt(dx_km*dx_km + dy_km*dy_km);
            float rmw = u_erc_active > 0 ? u_erc_inner_rmw : u_cyc_rmw;
            float v_tan = 0.0;
            float intensity = (u_erc_active > 0 ? u_erc_inner_wind : u_cyc_intensity) * 0.514444;
            if (dist < u_cyc_size * 4.0) {
                float envelopeDriver = max(intensity, u_cyc_intensity * 0.514444);
                float envelopeTransition = u_erc_active > 0
                    ? clamp(
                        0.45 * u_erc_outer_organization
                            + 0.35 * min(1.0, u_erc_outer_share * 1.5)
                            + 0.55 * (1.0 - u_erc_inner_integrity),
                        0.0,
                        1.0
                    )
                    : 0.0;
                float envelopeRmw = u_erc_active > 0
                    ? mix(rmw, u_erc_outer_rmw, envelopeTransition)
                    : rmw;
                v_tan = primaryTangentialWind(
                    dist, rmw, intensity, u_cyc_size, envelopeDriver, envelopeRmw
                );
                if (u_erc_active > 0) {
                    float gap = max(8.0, u_erc_outer_rmw - u_erc_inner_rmw);
                    float innerCutoff = smoothstep(
                        u_erc_inner_rmw + 0.12 * gap,
                        u_erc_inner_rmw + 0.42 * gap,
                        dist
                    );
                    float outerBackground = primaryTangentialWind(
                        u_erc_outer_rmw,
                        rmw,
                        intensity,
                        u_cyc_size,
                        envelopeDriver,
                        envelopeRmw
                    );
                    float outerPeak = outerBackground + max(0.0, u_erc_outer_anomaly) * 0.514444;
                    float replacementWind = primaryTangentialWind(
                        dist,
                        u_erc_outer_rmw,
                        outerPeak,
                        u_cyc_size,
                        outerPeak,
                        u_erc_outer_rmw
                    );
                    v_tan += max(0.0, replacementWind - v_tan) * innerCutoff;
                }
                float angle = atan(dy_km, dx_km);
                float rot = u_cyc_pos.y >= 0.0 ? 1.5708 : -1.5708; 
                float wind_angle = angle + rot;
                wind_cyc = vec2(cos(wind_angle), sin(wind_angle)) * v_tan;
            }
        }
        return wind_bg + wind_cyc;
    }

    void main() {
        vec2 st = gl_FragCoord.xy / u_resolution; 
        vec2 center = vec2(0.5);
        vec2 offset = st - center; 
        float dist_ratio = length(offset) * 2.0;
        
        // 简单的圆形遮罩
        if (dist_ratio > 0.98) discard; 

        // 风矢量由 cyclone-model.getWindVectorAt() 在 CPU 端生成；这里
        // 只解码、投影和折叠。雷达保留同源涡旋与背景风，但不套用
        // 100 m 风场的近地面地形摩擦。
        vec2 encodedWind = texture2D(u_wind_field, st).rg;
        vec2 wind = (encodedWind * 2.0 - 1.0) * 128.0;

        // 2. 计算雷达视线方向矢量 (Radar Beam Direction)
        vec2 beam_dir = length(offset) > 0.001 ? normalize(offset) : vec2(0.0);
        
        // 3. 计算真实径向速度 (Radial Velocity)
        // 正值=远离(红), 负值=靠近(绿)
        float radial_v = dot(wind, beam_dir);

        // 4. [新增] 应用速度折叠 (Velocity Aliasing)
        float folded_v = foldVelocity(radial_v);

        gl_FragColor = getVelocityColor(folded_v);
    }
`;

const vsSource = `
    attribute vec2 a_position;
    void main() {
        gl_Position = vec4(a_position, 0.0, 1.0);
    }
`;

// ============================================================
// WebGL 控制器 Class (复用 RadarRenderer 结构)
// ============================================================
export class DopplerRenderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.gl = canvas.getContext('webgl');
        if (!this.gl) {
            console.error("WebGL not supported for Doppler");
            return;
        }
        this.init();
    }

    init() {
        const gl = this.gl;
        const vs = this.createShader(gl.VERTEX_SHADER, vsSource);
        const fs = this.createShader(gl.FRAGMENT_SHADER, fsSource);
        this.program = this.createProgram(vs, fs);

        const posBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);

        this.a_position = gl.getAttribLocation(this.program, "a_position");
        
        this.u_resolution = gl.getUniformLocation(this.program, "u_resolution");
        this.u_time = gl.getUniformLocation(this.program, "u_time");
        this.u_radar_center = gl.getUniformLocation(this.program, "u_radar_center");
        this.u_radar_radius_km = gl.getUniformLocation(this.program, "u_radar_radius_km");
        this.u_noise_seed = gl.getUniformLocation(this.program, "u_noise_seed");
        
        this.u_sys_params = this.gl.getUniformLocation(this.program, "u_sys_params");
        this.u_sys_strength = this.gl.getUniformLocation(this.program, "u_sys_strength");
        this.u_sys_count = this.gl.getUniformLocation(this.program, "u_sys_count");
        this.u_terrain_map = this.gl.getUniformLocation(this.program, "u_terrain_map");
        this.terrainTexture = this.gl.createTexture();
        this.u_wind_field = this.gl.getUniformLocation(this.program, "u_wind_field");
        this.windFieldTexture = this.gl.createTexture();
        this.windFieldCacheKey = null;
        this.windFieldRequestedKey = null;
        this.windFieldPendingKey = null;
        this.gpuWindField = new WebGpuWindFieldBackend();
        gl.bindTexture(gl.TEXTURE_2D, this.windFieldTexture);
        gl.texImage2D(
            gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0,
            gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([128, 128, 0, 255])
        );
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        
        this.u_has_cyclone = gl.getUniformLocation(this.program, "u_has_cyclone");
        this.u_cyc_pos = gl.getUniformLocation(this.program, "u_cyc_pos");
        this.u_cyc_size = gl.getUniformLocation(this.program, "u_cyc_size");
        this.u_cyc_intensity = gl.getUniformLocation(this.program, "u_cyc_intensity");
        this.u_cyc_age = gl.getUniformLocation(this.program, "u_cyc_age");
        this.u_cyc_rmw = gl.getUniformLocation(this.program, "u_cyc_rmw");
        this.u_erc_active = gl.getUniformLocation(this.program, "u_erc_active");
        this.u_erc_inner_rmw = gl.getUniformLocation(this.program, "u_erc_inner_rmw");
        this.u_erc_inner_wind = gl.getUniformLocation(this.program, "u_erc_inner_wind");
        this.u_erc_outer_rmw = gl.getUniformLocation(this.program, "u_erc_outer_rmw");
        this.u_erc_outer_width = gl.getUniformLocation(this.program, "u_erc_outer_width");
        this.u_erc_outer_anomaly = gl.getUniformLocation(this.program, "u_erc_outer_anomaly");
        this.u_erc_outer_share = gl.getUniformLocation(this.program, "u_erc_outer_share");
        this.u_erc_outer_organization = gl.getUniformLocation(this.program, "u_erc_outer_organization");
        this.u_erc_inner_integrity = gl.getUniformLocation(this.program, "u_erc_inner_integrity");
    }

    loadTerrainTexture(imageElement) {
        const gl = this.gl;
        gl.bindTexture(gl.TEXTURE_2D, this.terrainTexture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, imageElement);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); 
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    }

    getWindFieldCacheKey(state, resolution, radiusKm) {
        const cyclone = state.cyclone || {};
        const lowerSystems = state.pressureSystems?.lower || [];
        const pressureSignature = lowerSystems.map(system => [
            Number(system.x || 0).toFixed(2),
            Number(system.y || 0).toFixed(2),
            Number(system.sigmaX || 0).toFixed(2),
            Number(system.sigmaY || 0).toFixed(2),
            Number(system.strength || 0).toFixed(2)
        ].join(',')).join(';');
        return [
            resolution,
            radiusKm,
            Number(state.siteLon || 0).toFixed(4),
            Number(state.siteLat || 0).toFixed(4),
            state.currentMonth || 0,
            cyclone.status || 'none',
            cyclone.age || 0,
            cyclone.lon || 0,
            cyclone.lat || 0,
            cyclone.intensity || 0,
            cyclone.circulationSize || 0,
            cyclone.rmw || 0,
            cyclone.speed || 0,
            cyclone.direction || 0,
            cyclone.isERCActive ? 1 : 0,
            cyclone.ercInnerRmw || 0,
            cyclone.ercInnerWind || 0,
            cyclone.ercOuterRmw || 0,
            cyclone.ercOuterWindAnomaly || 0,
            cyclone.ercOuterShare || 0,
            cyclone.ercOuterOrganization || 0,
            cyclone.ercInnerIntegrity ?? 1,
            pressureSignature
        ].join('|');
    }

    buildWindFieldDataCpu(state, resolution, radiusKm) {
        const data = new Uint8Array(resolution * resolution * 4);
        const centerLat = Number(state.siteLat || 0);
        const centerLon = Number(state.siteLon || 0);
        const lonKm = 111 * Math.max(0.1, Math.cos(centerLat * Math.PI / 180));
        const cyclone = state.cyclone || { status: 'inactive' };
        const pressureSystems = state.pressureSystems || { upper: [], lower: [] };
        const month = state.currentMonth || cyclone.currentMonth || 1;
        const encode = valueMs => Math.round((clamp(valueMs, -128, 128) / 256 + 0.5) * 255);

        for (let y = 0; y < resolution; y++) {
            const dyKm = ((y + 0.5) / resolution * 2 - 1) * radiusKm;
            const lat = centerLat + dyKm / 111;
            for (let x = 0; x < resolution; x++) {
                const dxKm = ((x + 0.5) / resolution * 2 - 1) * radiusKm;
                const lon = centerLon + dxKm / lonKm;
                const vector = getWindVectorAt(
                    lon,
                    lat,
                    month,
                    cyclone,
                    pressureSystems,
                    { applyTerrainFriction: false }
                );
                const offset = (y * resolution + x) * 4;
                data[offset] = encode((vector.u || 0) * 0.514444);
                data[offset + 1] = encode((vector.v || 0) * 0.514444);
                data[offset + 2] = 0;
                data[offset + 3] = 255;
            }
        }

        return data;
    }

    uploadWindFieldTexture(data, resolution, cacheKey) {
        const gl = this.gl;
        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_2D, this.windFieldTexture);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
        gl.texImage2D(
            gl.TEXTURE_2D, 0, gl.RGBA, resolution, resolution, 0,
            gl.RGBA, gl.UNSIGNED_BYTE, data
        );
        this.windFieldCacheKey = cacheKey;
    }

    updateWindFieldTexture(state, resolution = 160, radiusKm = 460) {
        const useGpu = this.gpuWindField.shouldAttempt();
        // The legacy path remains fully functional, but uses a smaller source
        // texture to avoid overwhelming older CPUs. Linear filtering hides the
        // resolution difference in the final 256 px radar image.
        const effectiveResolution = useGpu ? resolution : Math.min(resolution, 112);
        const cacheKey = this.getWindFieldCacheKey(state, effectiveResolution, radiusKm);
        this.windFieldRequestedKey = cacheKey;
        if (cacheKey === this.windFieldCacheKey || cacheKey === this.windFieldPendingKey) return;

        if (useGpu) {
            // Keep displaying the last completed field while WebGPU works. At
            // most one readback is in flight, so fast simulation mode cannot
            // build an unbounded queue of stale GPU jobs.
            if (this.windFieldPendingKey) return;
            this.windFieldPendingKey = cacheKey;
            this.gpuWindField.compute(state, effectiveResolution, radiusKm).then(data => {
                const isLatest = this.windFieldRequestedKey === cacheKey;
                this.windFieldPendingKey = null;
                if (data && isLatest) {
                    this.uploadWindFieldTexture(data, effectiveResolution, cacheKey);
                }
            }).catch(() => {
                this.windFieldPendingKey = null;
                this.gpuWindField.disable();
            });
            return;
        }

        const data = this.buildWindFieldDataCpu(state, effectiveResolution, radiusKm);
        this.uploadWindFieldTexture(data, effectiveResolution, cacheKey);
    }

    render(state, width, height) {
        const gl = this.gl;
        gl.viewport(0, 0, width, height);
        gl.clearColor(0.0, 0.0, 0.0, 0.0);
        gl.clear(gl.COLOR_BUFFER_BIT);

        if (state.cyclone && state.cyclone.status === 'dissipated') return;

        gl.useProgram(this.program);

        this.updateWindFieldTexture(state, 160, 460);
        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_2D, this.windFieldTexture);
        gl.uniform1i(this.u_wind_field, 1);

        if (state.pressureSystems) {
            const paramsArray = new Float32Array(20 * 4);
            const strengthArray = new Float32Array(20);
            const limit = Math.min(state.pressureSystems.length, 20);
            for (let i = 0; i < limit; i++) {
                const p = state.pressureSystems[i];
                paramsArray[i * 4 + 0] = p.x;
                paramsArray[i * 4 + 1] = p.y;
                paramsArray[i * 4 + 2] = p.sigmaX;
                paramsArray[i * 4 + 3] = p.sigmaY;
                strengthArray[i] = p.strength;
            }
            gl.uniform4fv(this.u_sys_params, paramsArray);
            gl.uniform1fv(this.u_sys_strength, strengthArray);
            gl.uniform1i(this.u_sys_count, limit);
        }

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.terrainTexture);
        gl.uniform1i(this.u_terrain_map, 0);

        gl.enableVertexAttribArray(this.a_position);
        gl.vertexAttribPointer(this.a_position, 2, gl.FLOAT, false, 0, 0);

        gl.uniform2f(this.u_resolution, width, height);
        // 多普勒雷达不需要随机种子
        gl.uniform1f(this.u_noise_seed, 0.0);

        let shaderTime = performance.now() / 1000.0;
        if (state.cyclone && state.cyclone.status === 'active') {
            shaderTime = state.cyclone.age;
        }
        if (this.u_time) gl.uniform1f(this.u_time, shaderTime);
        
        gl.uniform2f(this.u_radar_center, state.siteLon, state.siteLat);
        gl.uniform1f(this.u_radar_radius_km, 460.0);

        if (state.cyclone && state.cyclone.status === 'active') {
            gl.uniform1i(this.u_has_cyclone, 1);
            gl.uniform2f(this.u_cyc_pos, state.cyclone.lon, state.cyclone.lat);
            gl.uniform1f(this.u_cyc_size, state.cyclone.circulationSize);
            gl.uniform1f(this.u_cyc_intensity, state.cyclone.intensity);
            gl.uniform1f(this.u_cyc_age, state.cyclone.age);
            const cycloneRmw = Number.isFinite(state.cyclone.rmw)
                ? state.cyclone.rmw
                : 5 + state.cyclone.circulationSize * 0.125;
            gl.uniform1f(this.u_cyc_rmw, cycloneRmw);
            const hasErc = Boolean(
                state.cyclone.isERCActive
                && Number.isFinite(state.cyclone.ercInnerRmw)
                && Number.isFinite(state.cyclone.ercInnerWind)
                && Number.isFinite(state.cyclone.ercOuterRmw)
            );
            gl.uniform1i(this.u_erc_active, hasErc ? 1 : 0);
            gl.uniform1f(this.u_erc_inner_rmw, hasErc ? state.cyclone.ercInnerRmw : cycloneRmw);
            gl.uniform1f(this.u_erc_inner_wind, hasErc ? state.cyclone.ercInnerWind : state.cyclone.intensity);
            gl.uniform1f(this.u_erc_outer_rmw, hasErc ? state.cyclone.ercOuterRmw : cycloneRmw);
            gl.uniform1f(this.u_erc_outer_width, hasErc ? Math.max(8, state.cyclone.ercOuterWidth || 8) : 8);
            gl.uniform1f(this.u_erc_outer_anomaly, hasErc ? Math.max(0, state.cyclone.ercOuterWindAnomaly || 0) : 0);
            gl.uniform1f(this.u_erc_outer_share, hasErc ? Math.max(0, state.cyclone.ercOuterShare || 0) : 0);
            gl.uniform1f(this.u_erc_outer_organization, hasErc
                ? Math.max(0, state.cyclone.ercOuterOrganization || 0)
                : 0);
            gl.uniform1f(this.u_erc_inner_integrity, hasErc
                ? Math.max(0, Math.min(1, state.cyclone.ercInnerIntegrity ?? 1))
                : 1);
        } else {
            gl.uniform1i(this.u_has_cyclone, 0);
            gl.uniform1i(this.u_erc_active, 0);
        }

        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }

    createShader(type, source) {
        const s = this.gl.createShader(type);
        this.gl.shaderSource(s, source);
        this.gl.compileShader(s);
        if (!this.gl.getShaderParameter(s, this.gl.COMPILE_STATUS)) {
            console.error(this.gl.getShaderInfoLog(s));
            this.gl.deleteShader(s);
            return null;
        }
        return s;
    }

    createProgram(vs, fs) {
        const p = this.gl.createProgram();
        this.gl.attachShader(p, vs);
        this.gl.attachShader(p, fs);
        this.gl.linkProgram(p);
        return p;
    }
}
