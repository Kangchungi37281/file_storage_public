/**
 * forecast-models.js
 * 负责生成各种数值模型的预报数据。
 * [修正版] 修复陆地检测逻辑，检测"预报点"而非"初始点"
 */
import { getSST, normalizeLongitude } from './utils.js';
import { calculateSteering, updatePressureSystems, getStormDepthFactor, integrateStormMotion } from './cyclone-model.js';
import { calculateBackgroundHumidity } from './visualization.js';

// [辅助] 坐标清洗
function wrap180(lon) {
    lon = lon % 360;
    return (lon > 180) ? lon - 360 : (lon < -180 ? lon + 360 : lon);
}

export function generatePathForecasts(cyclone, pressureSystems, checkLandFunc = null, globalTemp = 289, globalShearSetting = 100) {
    if (cyclone.isExtratropical) {
        return [];
    }
    const forecasts = [];
    
    // 模型定义
    const models = [
        { name: "ENAI", bias: { u: 0.5, v: 0.6 } },
    ];

    // 参数配置
    const PATH_STEP_HOURS = 3;
    const INTENSITY_STEP_HOURS = 6;
    const TOTAL_HOURS = 72; // 预测时长
    
    const STEPS_PER_INTENSITY_UPDATE = INTENSITY_STEP_HOURS / PATH_STEP_HOURS; 
    const TOTAL_STEPS = TOTAL_HOURS / PATH_STEP_HOURS; 

    for (const model of models) {
        let tempCyclone = JSON.parse(JSON.stringify(cyclone));
        let tempPressureSystems = JSON.parse(JSON.stringify(pressureSystems));
        
        let track = [[tempCyclone.lon, tempCyclone.lat, tempCyclone.intensity, tempCyclone.isTransitioning, tempCyclone.isExtratropical]];

        let lastCalculatedIntensity = tempCyclone.intensity;
        const startAge = tempCyclone.age || 0;
        for(let t = 1; t <= TOTAL_STEPS; t++) { 
            // 1. 路径计算 (3小时/步)
            updatePressureSystems(tempPressureSystems, cyclone.currentMonth);
            const steering = calculateSteering(tempCyclone.lon, tempCyclone.lat,
                tempPressureSystems, model.bias, getStormDepthFactor(tempCyclone), tempCyclone);
            const motion = integrateStormMotion(tempCyclone, tempPressureSystems,
                steering, PATH_STEP_HOURS);
            tempCyclone.lon = motion.lon;
            tempCyclone.lat = motion.lat;
            tempCyclone.direction = (Math.atan2(motion.u, motion.v) * 180 / Math.PI + 360) % 360;
            tempCyclone.speed = Math.hypot(motion.u, motion.v) * 1.94384;
            const { shearU, shearV } = steering;

            // 2. 强度计算 (12小时/步)
            if (t % STEPS_PER_INTENSITY_UPDATE === 0) {
                const queryLon = wrap180(tempCyclone.lon);
                
                // [修正核心] 检测"当前预报点"是否在陆地，而不是检测 cyclone.isLand (初始点)
                const isForecastingLand = typeof checkLandFunc === 'function'
                    ? checkLandFunc(tempCyclone.lon, tempCyclone.lat)
                    : false;
                // 只有在非陆地时才查 SST，节省性能
                let sst = 29.0;
                let hum = 65.0;
                
                if (!isForecastingLand) {
                    const val = getSST(tempCyclone.lat, tempCyclone.lon, cyclone.currentMonth || 8, globalTemp);
                    if (val !== undefined && val !== null && val > -5) sst = val;
                    
                    // [关键修改] 安全调用：如果函数存在且运行正常，才覆盖默认值
                    if (typeof calculateBackgroundHumidity === 'function') {
                        try {
                            const hVal = calculateBackgroundHumidity(tempCyclone.lon, tempCyclone.lat, tempPressureSystems, cyclone.currentMonth, tempCyclone, globalTemp);
                            // 确保返回值是有效数字
                            if (typeof hVal === 'number' && !isNaN(hVal)) {
                                hum = hVal;
                            }
                        } catch (e) {
                            console.warn("Forecast humidity calc failed, using 65", e);
                            hum = 65.0;
                        }
                    }
                }

                let nextIntensity = lastCalculatedIntensity;

                if (isForecastingLand) {
                    // --- 陆地逻辑 (衰减) ---
                    const frictionDecay = Math.max(5, lastCalculatedIntensity * 0.22); 
                    let naturalDecayResult = lastCalculatedIntensity - frictionDecay;

                    // 强制约束：强度上限 = 上次强度 - 10KT
                    const hardCap = lastCalculatedIntensity - 10;
                    
                    nextIntensity = Math.min(naturalDecayResult, hardCap);
                } else {
                    // --- 海洋逻辑 (增强/维持) ---
                    let mpi = 0;
                    const effectiveSst = sst + (tempCyclone.isSubtropical ? 2 : 0);
                    if (effectiveSst >= 24.7) {
                        // MPI is an environmental ceiling, not a latitude
                        // penalty.  The old (1.08 - 1/latitude) factor made
                        // near-equatorial forecasts collapse artificially.
                        const thermodynamicMpi = 230.28
                            * (1 - Math.exp(-0.182 * (effectiveSst - 24.70)));
                        // Keep dry-air suppression modest and separate from
                        // the convergence rate; humidity must not turn a
                        // favourable MPI gap into negative growth.
                        const dryAirPenalty = Math.max(0, 60 - hum) * 0.5;
                        mpi = Math.max(0, thermodynamicMpi - dryAirPenalty);
                        if (tempCyclone.isSubtropical) mpi = Math.min(90, mpi);
                    }
                    const safeShearU = Number.isFinite(shearU) ? shearU : 0;
                    const safeShearV = Number.isFinite(shearV) ? shearV : 0;
                    // Steering shear is in m/s; use the same conversion as
                    // updateCycloneState so the forecast and analysis paths
                    // share one physical unit (knots).
                    const physicalShear = Math.hypot(safeShearU, safeShearV) * 1.94384;
                    const totalShear = physicalShear * (globalShearSetting / 100.0);
                    const gap = mpi - lastCalculatedIntensity;
                    const shearLoss = Math.max(0, totalShear - 8) * 0.10;
                    if (gap > 0) {
                        // Relax toward MPI at a positive rate.  Shear is an
                        // additive loss, never a sign flip on the MPI gap.
                        const growthRate = Math.max(
                            0.02,
                            Math.random() * 0.04 + 0.07
                                - 0.9 / Math.max(25, lastCalculatedIntensity)
                        );
                        nextIntensity += gap * growthRate - shearLoss;
                    } else {
                        const decayRate = 0.11 + totalShear * 0.003;
                        nextIntensity += gap * decayRate - shearLoss;
                    }
                    const currentForecastAge = startAge + (t * PATH_STEP_HOURS);
                    
                    if (tempCyclone.shearEventActive && currentForecastAge < tempCyclone.shearEventEndTime) {
                        const shearPenalty = tempCyclone.shearEventMagnitude * (Math.random() + 0.5);
                        nextIntensity -= shearPenalty;
                    }
                }

                nextIntensity = Math.max(15, nextIntensity);
                tempCyclone.intensity = nextIntensity;
                lastCalculatedIntensity = nextIntensity;
            } 
            
            track.push([
                tempCyclone.lon, 
                tempCyclone.lat, 
                tempCyclone.intensity, 
                tempCyclone.isTransitioning || false, 
                tempCyclone.isExtratropical || false
            ]);
        }
        forecasts.push({ name: model.name, track: track });
    }
    return forecasts;
}
