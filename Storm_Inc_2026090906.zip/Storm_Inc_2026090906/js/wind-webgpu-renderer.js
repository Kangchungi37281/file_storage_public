/**
 * WebGPU renderer for the 10 m surface wind-vector overlay.
 *
 * The wind model remains the source of truth in cyclone-model.js. This module
 * only expands and draws the already-computed arrow instances on the GPU.
 * Canvas 2D remains the caller-side fallback for browsers without WebGPU.
 */

const INSTANCE_STRIDE_FLOATS = 8;
const VERTICES_PER_INSTANCE = 18;

const SHADER = /* wgsl */ `
struct Viewport {
    size: vec2f,
    lineWidth: f32,
    headLength: f32,
};

@group(0) @binding(0) var<uniform> viewport: Viewport;

struct VertexOutput {
    @builtin(position) position: vec4f,
    @location(0) color: vec4f,
};

fn segmentEndpoints(segment: u32, length: f32) -> vec4f {
    let tip = vec2f(length * 0.5, 0.0);
    let tail = vec2f(-length * 0.5, 0.0);
    let backAngle = 0.85 * 3.14159265359;
    let headOne = tip + vec2f(cos(backAngle), sin(backAngle)) * viewport.headLength;
    let headTwo = tip + vec2f(cos(-backAngle), sin(-backAngle)) * viewport.headLength;

    if (segment == 0u) {
        return vec4f(tail, tip);
    }
    if (segment == 1u) {
        return vec4f(headOne, tip);
    }
    return vec4f(tip, headTwo);
}

@vertex
fn vertexMain(
    @location(0) geometry: vec4f,
    @location(1) color: vec4f,
    @builtin(vertex_index) vertexIndex: u32
) -> VertexOutput {
    let segment = vertexIndex / 6u;
    let corner = vertexIndex % 6u;
    let endpoints = segmentEndpoints(segment, geometry.w);
    let a = endpoints.xy;
    let b = endpoints.zw;
    let direction = normalize(b - a);
    let normal = vec2f(-direction.y, direction.x) * (viewport.lineWidth * 0.5);

    var localPoint = a + normal;
    if (corner == 1u) {
        localPoint = b + normal;
    } else if (corner == 2u || corner == 4u) {
        localPoint = b - normal;
    } else if (corner == 3u) {
        localPoint = a + normal;
    } else if (corner == 5u) {
        localPoint = a - normal;
    }

    let angle = geometry.z;
    let c = cos(angle);
    let s = sin(angle);
    let rotated = vec2f(
        localPoint.x * c - localPoint.y * s,
        localPoint.x * s + localPoint.y * c
    );
    let pixel = geometry.xy + rotated;
    let clip = vec2f(
        pixel.x / viewport.size.x * 2.0 - 1.0,
        1.0 - pixel.y / viewport.size.y * 2.0
    );

    var output: VertexOutput;
    output.position = vec4f(clip, 0.0, 1.0);
    output.color = color;
    return output;
}

@fragment
fn fragmentMain(input: VertexOutput) -> @location(0) vec4f {
    return input.color;
}
`;

function isWebGPUSupported() {
    return typeof navigator !== 'undefined'
        && Boolean(navigator.gpu)
        && typeof document !== 'undefined';
}

export class WindWebGPURenderer {
    static async create(canvas) {
        if (!isWebGPUSupported() || !canvas) return null;

        const adapter = await navigator.gpu.requestAdapter({
            powerPreference: 'high-performance'
        });
        if (!adapter) return null;

        const device = await adapter.requestDevice();
        const context = canvas.getContext('webgpu');
        if (!context) return null;

        const renderer = new WindWebGPURenderer(canvas, adapter, device, context);
        renderer.initialize();
        return renderer;
    }

    constructor(canvas, adapter, device, context) {
        this.canvas = canvas;
        this.adapter = adapter;
        this.device = device;
        this.context = context;
        this.format = navigator.gpu.getPreferredCanvasFormat();
        this.pipeline = null;
        this.uniformBuffer = null;
        this.uniformBindGroup = null;
        this.instanceBuffer = null;
        this.instanceCapacity = 0;
        this.width = 0;
        this.height = 0;
        this.dpr = 1;
        this.configured = false;
        this.lost = false;

        device.lost.then(info => {
            this.lost = true;
            console.warn('[wind-webgpu] device lost:', info?.message || 'unknown reason');
        });
    }

    initialize() {
        this.pipeline = this.device.createRenderPipeline({
            layout: 'auto',
            vertex: {
                module: this.device.createShaderModule({ code: SHADER }),
                entryPoint: 'vertexMain',
                buffers: [
                    {
                        arrayStride: INSTANCE_STRIDE_FLOATS * 4,
                        stepMode: 'instance',
                        attributes: [
                            { shaderLocation: 0, offset: 0, format: 'float32x4' },
                            { shaderLocation: 1, offset: 16, format: 'float32x4' }
                        ]
                    }
                ]
            },
            fragment: {
                module: this.device.createShaderModule({ code: SHADER }),
                entryPoint: 'fragmentMain',
                targets: [{
                    format: this.format,
                    blend: {
                        color: {
                            srcFactor: 'src-alpha',
                            dstFactor: 'one-minus-src-alpha',
                            operation: 'add'
                        },
                        alpha: {
                            srcFactor: 'one',
                            dstFactor: 'one-minus-src-alpha',
                            operation: 'add'
                        }
                    }
                }]
            },
            primitive: {
                topology: 'triangle-list'
            }
        });

        this.uniformBuffer = this.device.createBuffer({
            size: 16,
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        });
        this.uniformBindGroup = this.device.createBindGroup({
            layout: this.pipeline.getBindGroupLayout(0),
            entries: [{ binding: 0, resource: { buffer: this.uniformBuffer } }]
        });
    }

    resize(width, height, dpr = 1) {
        const safeWidth = Math.max(1, Math.round(width));
        const safeHeight = Math.max(1, Math.round(height));
        const safeDpr = Math.max(1, Number.isFinite(dpr) ? dpr : 1);
        const physicalWidth = Math.max(1, Math.round(safeWidth * safeDpr));
        const physicalHeight = Math.max(1, Math.round(safeHeight * safeDpr));

        this.canvas.style.width = `${safeWidth}px`;
        this.canvas.style.height = `${safeHeight}px`;
        if (!this.configured
            || this.canvas.width !== physicalWidth
            || this.canvas.height !== physicalHeight) {
            this.canvas.width = physicalWidth;
            this.canvas.height = physicalHeight;
            this.context.configure({
                device: this.device,
                format: this.format,
                alphaMode: 'premultiplied'
            });
            this.configured = true;
        }

        this.width = safeWidth;
        this.height = safeHeight;
        this.dpr = safeDpr;
    }

    ensureInstanceBuffer(instanceCount) {
        const required = Math.max(1, instanceCount);
        if (required <= this.instanceCapacity && this.instanceBuffer) return;

        let nextCapacity = Math.max(256, this.instanceCapacity || 0);
        while (nextCapacity < required) nextCapacity *= 2;

        this.instanceBuffer?.destroy();
        this.instanceBuffer = this.device.createBuffer({
            size: nextCapacity * INSTANCE_STRIDE_FLOATS * 4,
            usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
        });
        this.instanceCapacity = nextCapacity;
    }

    render(instanceData, width, height, dpr = 1) {
        if (this.lost || !this.pipeline || !this.device || !this.context) return false;

        const data = instanceData instanceof Float32Array
            ? instanceData
            : new Float32Array(instanceData || []);
        const instanceCount = Math.floor(data.length / INSTANCE_STRIDE_FLOATS);

        this.resize(width, height, dpr);
        this.ensureInstanceBuffer(instanceCount);
        if (instanceCount > 0) {
            this.device.queue.writeBuffer(this.instanceBuffer, 0, data);
        }

        const viewport = new Float32Array([
            this.width,
            this.height,
            1.5,
            5.0
        ]);
        this.device.queue.writeBuffer(this.uniformBuffer, 0, viewport);

        const encoder = this.device.createCommandEncoder();
        const pass = encoder.beginRenderPass({
            colorAttachments: [{
                view: this.context.getCurrentTexture().createView(),
                clearValue: { r: 0, g: 0, b: 0, a: 0 },
                loadOp: 'clear',
                storeOp: 'store'
            }]
        });
        pass.setPipeline(this.pipeline);
        pass.setBindGroup(0, this.uniformBindGroup);
        if (instanceCount > 0) {
            pass.setVertexBuffer(0, this.instanceBuffer);
            pass.draw(VERTICES_PER_INSTANCE, instanceCount);
        }
        pass.end();
        this.device.queue.submit([encoder.finish()]);
        return true;
    }

    clear(width, height, dpr = 1) {
        return this.render(new Float32Array(0), width, height, dpr);
    }

    destroy() {
        this.instanceBuffer?.destroy();
        this.uniformBuffer?.destroy();
        this.instanceBuffer = null;
        this.uniformBuffer = null;
        this.pipeline = null;
        this.lost = true;
    }
}

export function canUseWindWebGPU() {
    return isWebGPUSupported();
}
