/** Fixed-size Wiki Path Painter export. No DOM capture or live map mutations. */
export const EXPORT_SIZE = Object.freeze({ width: 2244, height: 1182, header: 236 });
const COLORS = { ocean: '#07111f', panel: '#0a1020', land: '#263a36', border: '#263a30', muted: '#718099' };
const TRIANGLES = new Set(['EX', 'LO', 'WV', 'DB', 'MD']);
const NON_ACE = new Set(['SS', 'SD', 'EX', 'DB', 'LO', 'WV', 'MD']);
const COLORED = new Set(['TD', 'TS', 'TY', 'HU', 'ST', 'TC', 'EX', 'SS', 'SD', 'MD']);
const RAD = Math.PI / 180;
let assetsPromise;

export function intensityColor(type, wind) {
    if (!COLORED.has(type)) return '#9ca3af';
    return wind >= 137 ? '#8d75e6' : wind >= 113 ? '#ff738a' : wind >= 96 ? '#ff9e59'
        : wind >= 83 ? '#ffd98c' : wind >= 64 ? '#ffffd9' : wind >= 34 ? '#4dffff' : '#6ec1ea';
}

// Snapshot the saved ATCF, including its basin, number and UTC dates. Do not read selectors.
export function parseExportTrack(raw) {
    const records = new Map();
    let identity;
    for (const line of raw.trim().split(/\r?\n/)) {
        if (!line.trim()) continue;
        const f = line.split(',').map(s => s.trim());
        const lat = /^(-?\d+)([NS])$/.exec(f[6] || '');
        const lon = /^(\d+)([EW])$/.exec(f[7] || '');
        if (f.length < 11 || !/^\d{10}$/.test(f[2]) || !lat || !lon) throw new Error('轨迹记录格式不完整，无法导出。');
        const id = `${f[0]} ${f[1]}`;
        if (identity && identity !== id) throw new Error('请一次导出一条气旋轨迹。');
        identity = id;
        const timestamp = Date.UTC(+f[2].slice(0, 4), +f[2].slice(4, 6) - 1, +f[2].slice(6, 8), +f[2].slice(8, 10));
        const p = { lon: +lon[1] / 10 * (lon[2] === 'W' ? -1 : 1),
            lat: +lat[1] / 10 * (lat[2] === 'S' ? -1 : 1), wind: Number(f[8]), pressure: Number(f[9]), type: f[10], timestamp };
        if (!Number.isFinite(p.wind) || !f[8] || p.wind < 0 || Math.abs(p.lat) > 90 || p.lon < -180 || p.lon > 360
            || !Number.isFinite(timestamp) || new Date(timestamp).toISOString().replace(/[-:T]/g, '').slice(0, 10) !== f[2]) {
            throw new Error('轨迹包含无效的时间、坐标或风速。');
        }
        // Multiple wind-radius records at one time must not multiply the ACE or markers.
        if (!records.has(timestamp)) records.set(timestamp, p);
        if (records.size > 20000) throw new Error('轨迹过长，请分段导出（最多 20,000 个点）。');
    }
    const points = [...records.values()].sort((a, b) => a.timestamp - b.timestamp);
    if (!points.length) throw new Error('没有可导出的轨迹。');
    let peak = points[0], minPressure = Infinity, ace = 0;
    for (const p of points) {
        if (p.wind > peak.wind) peak = p;
        if (Number.isFinite(p.pressure) && p.pressure > 0) minPressure = Math.min(minPressure, p.pressure);
        if (p.wind >= 34 && !NON_ACE.has(p.type) && new Date(p.timestamp).getUTCHours() % 6 === 0) ace += p.wind ** 2 / 10000;
    }
    return { identity, points, peakWind: peak.wind, minPressure, ace, accent: intensityColor(peak.type, peak.wind) };
}

function mercatorY(lat) {
    return -Math.log(Math.tan(Math.PI / 4 + Math.max(-85.05112878, Math.min(85.05112878, lat)) * RAD / 2)) / RAD;
}

export function fitExportTrack(points) {
    let previous;
    const coordinates = points.map(p => {
        let lon = ((p.lon + 180) % 360 + 360) % 360 - 180;
        if (previous !== undefined) lon += 360 * Math.round((previous - lon) / 360);
        previous = lon;
        return [lon, mercatorY(p.lat)];
    });
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const [x, y] of coordinates) {
        minX = Math.min(minX, x); maxX = Math.max(maxX, x);
        minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
    if (maxX - minX > 720) throw new Error('轨迹跨越过多经度，请分段导出。');
    const { width, height, header } = EXPORT_SIZE;
    const padding = 72;
    const scale = Math.min((width - padding * 2) / Math.max(8, maxX - minX),
        (height - header - padding * 2) / Math.max(8, maxY - minY));
    const centerX = (minX + maxX) / 2, centerY = (minY + maxY) / 2;
    const project = (x, y) => [width / 2 + (x - centerX) * scale, (height + header) / 2 + (y - centerY) * scale];
    return { pixels: coordinates.map(([x, y]) => project(x, y)), project, centerX, scale };
}

async function loadAssets() {
    if (!assetsPromise) {
        assetsPromise = (async () => {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 15000);
            try {
                // Fetch font bytes with the same timeout as the map. A failed font never silently falls back.
                const files = ['../../ne_50m_admin_0_countries.geojson',
                    '../../assets/export-fonts/BarlowCondensed-ExtraBold.ttf', '../../assets/export-fonts/BarlowCondensed-Bold.ttf',
                    '../../assets/export-fonts/JetBrainsMono-SemiBold.ttf'];
                const data = await Promise.all(files.map(async (file, i) => {
                    const response = await fetch(new URL(file, import.meta.url), { signal: controller.signal });
                    if (!response.ok) throw new Error(`导出资源加载失败 (${response.status})。`);
                    return i === 0 ? response.json() : response.arrayBuffer();
                }));
                const faces = [new FontFace('TCS Export Display', data[1], { weight: '800' }),
                    new FontFace('TCS Export Display', data[2], { weight: '700' }),
                    new FontFace('TCS Export Mono', data[3], { weight: '600' })];
                await Promise.all(faces.map(face => face.load()));
                faces.forEach(face => document.fonts.add(face));
                return data[0];
            } finally { clearTimeout(timer); }
        })().catch(error => { assetsPromise = null; throw error; });
    }
    return assetsPromise;
}

// Planar Mercator rings match the reference's Leaflet coastlines. Repeat polygons across
// the dateline, using the same unwrapped coordinates as the track; preserve interior holes.
async function drawLand(ctx, world, fit) {
    const { width, height, header } = EXPORT_SIZE;
    ctx.fillStyle = COLORS.land;
    ctx.strokeStyle = COLORS.border;
    ctx.lineWidth = 1;
    let lastYield = performance.now();
    for (const feature of world.features) {
        const geometry = feature.geometry;
        const polygons = geometry?.type === 'Polygon' ? [geometry.coordinates]
            : geometry?.type === 'MultiPolygon' ? geometry.coordinates : [];
        for (const polygon of polygons) {
            const rings = polygon.map(ring => {
                let previous;
                return ring.map(([lon, lat]) => {
                    if (previous !== undefined) lon += 360 * Math.round((previous - lon) / 360);
                    previous = lon;
                    return [lon, mercatorY(lat)];
                });
            });
            if (!rings[0]?.length) continue;
            const base = 360 * Math.round((fit.centerX - rings[0][0][0]) / 360);
            const copies = Math.ceil(width / (360 * fit.scale) / 2) + 1;
            for (let copy = -copies; copy <= copies; copy++) {
                const offset = base + copy * 360;
                const projected = rings.map(ring => ring.map(([x, y]) => fit.project(x + offset, y)));
                let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
                for (const [x, y] of projected[0]) {
                    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
                    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
                }
                if (maxX < 0 || minX > width || maxY < header || minY > height) continue;
                ctx.beginPath();
                for (const ring of projected) {
                    ring.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
                    ctx.closePath();
                }
                ctx.fill('evenodd'); ctx.stroke();
            }
        }
        if (performance.now() - lastYield > 12) {
            await new Promise(resolve => setTimeout(resolve, 0));
            lastYield = performance.now();
        }
    }
}

// Position by ink bounds rather than browser-dependent line boxes.
function text(ctx, value, x, top, size, family, color, maxWidth, spacing = 0, weight = 800) {
    value = String(value);
    ctx.font = `${weight} ${size}px "${family}"`;
    const advance = ctx.measureText(value).width + spacing * Math.max(0, value.length - 1);
    const factor = Math.min(1, maxWidth / Math.max(1, advance));
    const baseline = top + ctx.measureText(value).actualBoundingBoxAscent;
    ctx.save(); ctx.translate(x, baseline); ctx.scale(factor, 1); ctx.fillStyle = color;
    let cursor = 0;
    for (const char of value) {
        ctx.fillText(char, cursor, 0);
        cursor += ctx.measureText(char).width + spacing;
    }
    ctx.restore();
    return advance * factor;
}

function drawHeader(ctx, model) {
    const { width, header } = EXPORT_SIZE;
    const first = 1083, second = 1701;
    ctx.fillStyle = COLORS.panel; ctx.fillRect(0, 0, width, header);
    ctx.strokeStyle = 'rgba(255,255,255,.10)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(first, 0); ctx.lineTo(first, header);
    ctx.moveTo(second, 0); ctx.lineTo(second, header); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.18)';
    ctx.beginPath(); ctx.moveTo(0, header - 1); ctx.lineTo(width, header - 1); ctx.stroke();
    const mono = (v, x, y, size, color, max, spacing = 0) => text(ctx, v, x, y, size, 'TCS Export Mono', color, max, spacing, 600);
    mono('CYCLONE IDENTIFICATION', 40, 30, 18, COLORS.muted, 990, 2.52);
    mono('PEAK SUSTAINED WIND / MINIMUM PRESSURE', first + 40, 30, 18, COLORS.muted, 540, 2.52);
    mono('ACCUMULATED CYCLONE ENERGY', second + 40, 30, 18, COLORS.muted, 463, 2.52);
    text(ctx, model.identity, 40, 76, 62, 'TCS Export Display', '#f5f8fb', 1000, 2.48);
    const date = time => new Date(time).toISOString().slice(0, 10).replaceAll('-', '/');
    mono(`${date(model.points[0].timestamp)} - ${date(model.points.at(-1).timestamp)}`, 40, 154, 22, '#c8d3df', 1000);
    const windWidth = text(ctx, Math.round(model.peakWind), first + 40, 67, 140, 'TCS Export Display', model.accent, 320, -5.6);
    const unitX = first + 40 + windWidth + 18;
    const unitWidth = text(ctx, 'KT', unitX, 148, 26, 'TCS Export Display', '#c1ccda', 40, 2.08, 700);
    mono(`${Number.isFinite(model.minPressure) ? Math.round(model.minPressure) : '--'} HPA`, unitX + unitWidth + 18, 150, 22, COLORS.muted, second - unitX - unitWidth - 40);
    text(ctx, model.ace.toFixed(4), second + 40, 75, 92, 'TCS Export Display', model.accent, 463);
    mono('10⁴ KT² · SYNOPTIC HOURS', second + 245, 194, 16, '#536178', 260, 1.28);
}

export async function renderTrackExport(model) {
    const fit = fitExportTrack(model.points);
    const world = await loadAssets();
    const canvas = document.createElement('canvas');
    const { width, height, header } = EXPORT_SIZE;
    canvas.width = width; canvas.height = height;
    try {
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('浏览器无法创建导出画布，请关闭部分标签页后重试。');
        ctx.fillStyle = COLORS.ocean; ctx.fillRect(0, 0, width, height);
        ctx.save(); ctx.beginPath(); ctx.rect(0, header, width, height - header); ctx.clip();
        await drawLand(ctx, world, fit);
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 3; ctx.lineJoin = 'round';
        ctx.beginPath();
        fit.pixels.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
        ctx.stroke();
        for (let i = 0; i < model.points.length; i++) {
            const p = model.points[i], [x, y] = fit.pixels[i];
            // Mark only 00/06/12/18 UTC; retain the full track in the connecting line.
            if (new Date(p.timestamp).getUTCHours() % 6 !== 0) continue;
            ctx.fillStyle = intensityColor(p.type, p.wind); ctx.strokeStyle = '#000'; ctx.lineWidth = 1.6;
            ctx.beginPath();
            if (TRIANGLES.has(p.type)) {
                ctx.moveTo(x, y - 9); ctx.lineTo(x + 10, y + 9); ctx.lineTo(x - 10, y + 9); ctx.closePath();
            } else if (p.type === 'SS' || p.type === 'SD') ctx.rect(x - 8, y - 8, 16, 16);
            else ctx.arc(x, y, 8, 0, Math.PI * 2);
            ctx.fill(); ctx.stroke();
            if (i > 0 && i % 500 === 0) await new Promise(resolve => setTimeout(resolve, 0));
        }
        ctx.restore();
        drawHeader(ctx, model);
        ctx.font = '600 20px "TCS Export Mono"'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(156,163,175,.30)';
        ctx.fillText('GENERATED BY STORM_INC GAME', width / 2, height - 18);
        return await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('PNG 编码失败，请重试。')), 'image/png'));
    } finally {
        // Release the ~10 MB backing store, including on drawing/encoding failure.
        canvas.width = 1; canvas.height = 1;
    }
}
