/**
 * cyclone-model.js
 * Core logic
 */
import { NAME_LISTS, getSST, getPressureAt, normalizeLongitude, calculateDistance, windToPressure } from './utils.js';
import { getElevationAt, getLandStatus } from './terrain-data.js';
import { calculateBackgroundHumidity } from './visualization.js';

const basinConfig = {
    'WPAC': { lon: { min: 100, max: 180 }, lat: { min: 5, max: 25 } },  // 西北太平洋
    'EPAC': { lon: { min: 180, max: 260 }, lat: { min: 5, max: 20 } },  // 东北太平洋 (140W to 80W)
    'NATL': { lon: { min: 260, max: 350 }, lat: { min: 6, max: 32 } },  // 北大西洋 (75W to 10W)
    'NIO':  { lon: { min: 60,  max: 100 }, lat: { min: 5, max: 25 } },   // 北印度洋
    'SHEM':  { lon: { min: 140,  max: 200 }, lat: { min: -15, max: -5 } },   // 南太平洋
    'SIO':  { lon: { min: 30,  max: 140 }, lat: { min: -15, max: -5 } },
    'SATL':  { lon: { min: -50,  max: 15 }, lat: { min: -25, max: -10 } }
};

const MODEL_STEP_HOURS = 3;
const ERC_MIN_INTENSITY = 85;
const ERC_ABORT_ADVERSE_DECAY_HOURS = 15;
const ERC_ABORT_BENIGN_DECAY_HOURS = 24;
const ERC_MPI_WEAKENING_RESPONSE_HOURS = 18;
const ERC_MPI_RECOVERY_RESPONSE_HOURS = 9;
const MIN_RMW_KM = 8;
const MPI_REFERENCE_CIRCULATION_KM = 300;
const MPI_REFERENCE_RMW_KM = 30;
const EARTH_RADIUS_M = 6371000;
const EARTH_OMEGA = 7.292115e-5;
const GRAVITY = 9.80665;
const MODERN_FIELD_VERSION = 3;
const ZONAL_PROFILE_VERSION = 2;

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const smoothstep = value => {
    const t = clamp(value, 0, 1);
    return t * t * (3 - 2 * t);
};
const vortexGeometryCache = new WeakMap();

function isModernAtmosphericBackground(background) {
    return background?.flowModel === 'qg-barotropic-v1'
        || background?.fieldVersion >= MODERN_FIELD_VERSION;
}

// Monthly Northern Hemisphere western-Pacific circulation climatology.  The
// model used to compress all of this into one cosine-shaped seasonal scalar;
// that made May/October and onset/retreat phases too similar in the steering
// field.  These are broad reduced-order anchors, not reanalysis values: the
// transient Rossby and synoptic modes still supply the event-to-event spread.
const MONTHLY_NH_CIRCULATION = [
    null,
    { summer: .05, monsoonAxis: 8,  ridgeLatitude: 26, jetLatitude: 37, jetStrength: 1.18, tradeStrength: 1.18, monsoonStrength: .50, waveFactor: 1.13, southAsianHighLongitude: 70, southAsianHighStrength: .05 },
    { summer: .10, monsoonAxis: 8,  ridgeLatitude: 26, jetLatitude: 38, jetStrength: 1.16, tradeStrength: 1.15, monsoonStrength: .52, waveFactor: 1.10, southAsianHighLongitude: 71, southAsianHighStrength: .06 },
    { summer: .20, monsoonAxis: 8,  ridgeLatitude: 27, jetLatitude: 39, jetStrength: 1.10, tradeStrength: 1.10, monsoonStrength: .58, waveFactor: 1.08, southAsianHighLongitude: 72, southAsianHighStrength: .10 },
    { summer: .35, monsoonAxis: 9,  ridgeLatitude: 28, jetLatitude: 41, jetStrength: 1.06, tradeStrength: 1.05, monsoonStrength: .68, waveFactor: 1.06, southAsianHighLongitude: 75, southAsianHighStrength: .28 },
    { summer: .50, monsoonAxis: 10, ridgeLatitude: 29, jetLatitude: 43, jetStrength: 1.03, tradeStrength: 1.00, monsoonStrength: .76, waveFactor: 1.02, southAsianHighLongitude: 79, southAsianHighStrength: .55 },
    { summer: .70, monsoonAxis: 13, ridgeLatitude: 30, jetLatitude: 44, jetStrength: .98, tradeStrength: .96, monsoonStrength: .88, waveFactor: 1.00, southAsianHighLongitude: 84, southAsianHighStrength: .82 },
    { summer: .90, monsoonAxis: 16, ridgeLatitude: 31, jetLatitude: 45, jetStrength: .93, tradeStrength: .90, monsoonStrength: .98, waveFactor: .96, southAsianHighLongitude: 90, southAsianHighStrength: 1.00 },
    { summer: 1.00, monsoonAxis: 17, ridgeLatitude: 32, jetLatitude: 46, jetStrength: .90, tradeStrength: .86, monsoonStrength: 1.00, waveFactor: .92, southAsianHighLongitude: 94, southAsianHighStrength: 1.04 },
    { summer: .85, monsoonAxis: 15, ridgeLatitude: 31, jetLatitude: 44, jetStrength: .97, tradeStrength: .94, monsoonStrength: .92, waveFactor: .99, southAsianHighLongitude: 91, southAsianHighStrength: .92 },
    { summer: .60, monsoonAxis: 11, ridgeLatitude: 29, jetLatitude: 42, jetStrength: 1.06, tradeStrength: 1.06, monsoonStrength: .72, waveFactor: 1.08, southAsianHighLongitude: 85, southAsianHighStrength: .65 },
    { summer: .30, monsoonAxis: 9,  ridgeLatitude: 27, jetLatitude: 39, jetStrength: 1.13, tradeStrength: 1.14, monsoonStrength: .58, waveFactor: 1.10, southAsianHighLongitude: 77, southAsianHighStrength: .30 },
    { summer: .10, monsoonAxis: 8,  ridgeLatitude: 26, jetLatitude: 37, jetStrength: 1.18, tradeStrength: 1.18, monsoonStrength: .50, waveFactor: 1.13, southAsianHighLongitude: 72, southAsianHighStrength: .08 }
];

function monthlyCirculation(month, hemisphere = 1, legacySeasonalShift = null) {
    const numericMonth = Number.isFinite(month)
        ? ((Math.round(month) - 1) % 12 + 12) % 12 + 1
        : 8;
    // A six-month phase reversal gives the Southern Hemisphere its own local
    // summer/winter evolution while preserving the same reduced-order shape.
    const northernMonth = hemisphere < 0
        ? (numericMonth + 5) % 12 + 1
        : numericMonth;
    const table = MONTHLY_NH_CIRCULATION[northernMonth];
    if (table) {
        if (hemisphere < 0) {
            // The Southern Hemisphere subtropical ridge and subtropical jet
            // are not a mirror image of the boreal field. The ocean-dominated
            // hemisphere keeps a stronger, more equatorward westerly belt;
            // even in its local summer the belt has a substantial 30S flank.
            // Keep the correction smooth through the seasons so it changes
            // the common height/wind field rather than forcing tracks later.
            const localSummer = table.summer;
            return {
                ...table,
                ridgeLatitude: Math.max(
                    22,
                    table.ridgeLatitude - (1.5 + 2.5 * localSummer)
                ),
                jetLatitude: Math.max(
                    33,
                    table.jetLatitude - (2 + 4 * localSummer)
                ),
                jetStrength: table.jetStrength * (1.12 + 0.08 * localSummer),
                northernMonth
            };
        }
        // In boreal winter the subtropical ridge belt contracts equatorward
        // and the polar-front jet follows it.  Leaving the January ridge at
        // the late-spring latitude made the whole cold-season circulation
        // too far north: cold highs could not build a realistic southward
        // wedge, and tropical systems stayed warm-core too far poleward.
        const winter = Math.pow(1 - table.summer, 1.15);
        return {
            ...table,
            ridgeLatitude: table.ridgeLatitude - 4.5 * winter,
            jetLatitude: table.jetLatitude - 1.8 * winter,
            northernMonth
        };
    }

    const seasonalShift = Number.isFinite(legacySeasonalShift) ? legacySeasonalShift : 0;
    const summer = (1 + seasonalShift / 4 * hemisphere) / 2;
    const circulation = {
        summer,
        monsoonAxis: 8 + 5 * summer,
        ridgeLatitude: 26 + 5 * summer,
        jetLatitude: 39 + 8 * summer,
        jetStrength: 1,
        tradeStrength: 1,
        monsoonStrength: .5 + .5 * summer,
        waveFactor: 1,
        southAsianHighLongitude: 70 + 24 * summer,
        southAsianHighStrength: summer,
        northernMonth
    };
    if (hemisphere < 0) {
        circulation.ridgeLatitude = Math.max(22, circulation.ridgeLatitude - (1.5 + 2.5 * summer));
        circulation.jetLatitude = Math.max(33, circulation.jetLatitude - (2 + 4 * summer));
        circulation.jetStrength *= 1.12 + 0.08 * summer;
    }
    return circulation;
}

// Reduced-order energy proxies, not resolved temperature gradients or PV dynamics.
// ET growth requires both a frontal zone and favourable phasing ahead of an upper low.
function transitionEnvironment(cyclone, pressureSystems, frontalZone, totalShear) {
    const latitude = Math.abs(cyclone.lat);
    const background = pressureSystems?.upper?.find(c => c.role === 'height-background');
    const localCirculation = background
        ? monthlyCirculation(
            background.calendarMonth,
            cyclone.lat < 0 ? -1 : 1,
            background.seasonalShift
        )
        : null;
    const localWinter = localCirculation ? localCirculation.summer < .35 : false;
    const localFront = background && (background.waves || isModernAtmosphericBackground(background))
        ? Math.abs(waveFieldComponents(cyclone.lon, cyclone.lat, background).jetLatitude)
            - (localWinter ? 6 : 4)
        : null;
    const frontLatitude = clamp(localFront ?? Math.abs(frontalZone?.latitude ?? 35), 25, 55);
    const front = Math.exp(-(((latitude - frontLatitude) / 9) ** 2))
        * smoothstep((latitude - 20) / 8);
    let trough = 0;
    for (const cell of pressureSystems?.upper || []) {
        if (!(cell.strength < 0) || !Number.isFinite(cell.x) || !Number.isFinite(cell.y)) continue;
        const dx = normalizeLongitude(cyclone.lon - cell.x);
        const dy = (cell.y - cyclone.lat) * (cyclone.lat < 0 ? -1 : 1);
        const phasing = Math.exp(-(((dx - 6) / 12) ** 2) - ((dy - 4) / 10) ** 2);
        trough = Math.max(trough, phasing * clamp(Math.abs(cell.strength) / 5, 0, 1));
    }
    if (background?.waves) {
        const local = waveFieldComponents(cyclone.lon, cyclone.lat, background);
        const west = getGeopotentialHeight500(cyclone.lon - 5, cyclone.lat, pressureSystems);
        const east = getGeopotentialHeight500(cyclone.lon + 5, cyclone.lat, pressureSystems);
        trough = smoothstep((east - west) / 60)
            * Math.exp(-(((latitude - Math.abs(local.jetLatitude)) / 14) ** 2));
    }
    const shearCoupling = smoothstep((totalShear - 4) / 12)
        * (1 - 0.65 * smoothstep((totalShear - 35) / 25));
    return {
        front,
        trough,
        support: clamp(front * trough * shearCoupling, 0, 1),
        frontLatitude,
        localWinter,
        transitionSummer: localCirculation?.summer ?? null
    };
}

function advanceExtratropicalTransition(cyclone, environment, sst, totalShear) {
    if (cyclone.isExtratropical) { cyclone.isTransitioning = false; return; }
    const latitude = Math.abs(cyclone.lat);
    // Crossing poleward of the front must not switch transformation off as
    // the Gaussian local growth support falls. Transformation and growth differ.
    const winterLike = environment?.localWinter === true
        || (Number.isFinite(environment?.transitionSummer) && environment.transitionSummer < .35);
    // ET is a baroclinic/vertical-structure transition, not a latitude/SST
    // switch. A modest amount of deep-layer shear is therefore required even
    // in the subpolar fallback branch; cold water alone cannot declare ET.
    const shearThreshold = winterLike ? 6 : 8;
    const shearGate = totalShear >= shearThreshold;
    const frontalContact = latitude >= environment.frontLatitude - (winterLike ? 5 : 4)
        && (environment.front > 0.2 || latitude >= environment.frontLatitude)
        && shearGate;
    // The model has no resolved fronts: retain a climatological subpolar
    // exposure beyond 45 degrees, even if the sampled front/trough misses it.
    const subpolarContact = latitude >= 45 && shearGate;
    const transforming = (frontalContact || subpolarContact) && sst < 26 && shearGate;
    const exposure = Math.max(environment.front, smoothstep((latitude - 40) / 10));
    cyclone.transitionHours = clamp((cyclone.transitionHours || 0)
        + (transforming ? MODEL_STEP_HOURS * (0.6 + 0.8 * exposure) : -MODEL_STEP_HOURS * 2), 0, 24);
    cyclone.isTransitioning = cyclone.transitionHours > 0;
    if (cyclone.transitionHours < 24) return;
    cyclone.isExtratropical = true;
    cyclone.isTransitioning = false;
    cyclone.isSubtropical = false;
    cyclone.extratropicalStage = environment.support >= 0.3 ? 'developing' : 'decaying';
    cyclone.extratropicalDevelopmentEndTime = cyclone.age + 24 + 48 * environment.support;
    cyclone.extratropicalMaxIntensity = 45 + 50 * environment.support;
}

function stormThermodynamicMpi(sst, heat, isSubtropical) {
    // The upper cold core supports convection over water ~2 C cooler. Limit the
    // hybrid warm-core wind ceiling; this is not extra energy for mature hurricanes.
    const effectiveSst = sst + (isSubtropical ? 2 : 0);
    const mpi = effectiveSst > 25
        ? 264.28 * (1 - Math.exp((-0.140 - heat * 0.00084) * (effectiveSst - 25))) : 0;
    return isSubtropical ? Math.min(90, mpi) : mpi;
}

function subtropicalIntensityChange(intensity, thermalChange, sst, humidity, totalShear, losses, trough) {
    // An existing upper cold core supplies a hybrid maintenance pathway over
    // mildly cool water. It fades in very cold water, dry air or destructive
    // shear, and targets storm strength rather than preserving arbitrary winds.
    const support = smoothstep((sst - 19) / 4)
        * smoothstep((humidity - 40) / 20)
        * (1 - smoothstep((totalShear - 18) / 20));
    const hybridChange = (55 + 10 * trough - intensity) * 0.08 - losses;
    return thermalChange + support * Math.max(0, hybridChange - thermalChange);
}

function transitionIntensityChange(intensity, thermalChange, support, progress) {
    const weight = Math.min(0.9, support * (0.35 + 0.65 * clamp(progress / 24, 0, 1)));
    const dynamicalChange = clamp((45 + 50 * support - intensity) * 0.08, -4, 1.5);
    return thermalChange * (1 - weight) + dynamicalChange * weight;
}

function rapidIntensificationRate(cyclone, mpi, sst, shear, humidity, normalRate) {
    const favourable = !cyclone.isERCActive && !cyclone.isSubtropical
        && !cyclone.isTransitioning && !cyclone.isExtratropical && !cyclone.isMonsoonDepression
        && sst >= 29 && shear < 10 && humidity >= 65 && cyclone.intensity >= 40;
    if (!favourable) cyclone.riUntil = 0;
    if (favourable && cyclone.age >= (cyclone.riUntil || 0)
        && cyclone.age >= (cyclone.riCooldownUntil || 0) && mpi - cyclone.intensity >= 20) {
        const opportunity = smoothstep((sst - 28.5) / 2)
            * (1 - smoothstep(shear / 12)) * smoothstep((humidity - 55) / 25);
        if (Math.random() < 0.10 * opportunity) {
            cyclone.riUntil = cyclone.age + 12 * Math.random();
            cyclone.riCooldownUntil = cyclone.riUntil + 24;
            cyclone.riRate = 0.16 + 0.06 * Math.random();
        }
    }
    cyclone.isRapidIntensifying = favourable && cyclone.age < (cyclone.riUntil || 0);
    return cyclone.isRapidIntensifying ? Math.max(normalRate, Number.isFinite(cyclone.riRate) ? cyclone.riRate : 0.18) : normalRate;
}

function expandRmwOverLand(cyclone, elevation) {
    const terrain = clamp(Math.max(0, elevation || 0) / 1000, 0, 1);
    const oldRmw = getPrimaryRmw(cyclone);
    // Progressive core disruption, with stronger expansion over rough terrain.
    // Approach a bounded radius rather than compounding the old size multiplier.
    const ceiling = 120 + 40 * terrain;
    const expansion = (0.14 + 0.16 * terrain) * Math.max(0, 1 - oldRmw / ceiling);
    const newRmw = clamp(oldRmw * (1 + expansion), MIN_RMW_KM, 190);
    const ratio = newRmw / Math.max(MIN_RMW_KM, oldRmw);
    cyclone.rmw = newRmw;
    if (cyclone.isERCActive) {
        cyclone.ercInnerRmw = newRmw;
        if (Number.isFinite(cyclone.ercOuterRmw)) {
            cyclone.ercOuterRmw = clamp(cyclone.ercOuterRmw * ratio, newRmw, 190);
        }
    }
    if (Number.isFinite(cyclone.radarRmwScale)) {
        cyclone.radarRmwScale = clamp(cyclone.radarRmwScale * ratio, 0.35, 3.2);
    }
}

function fallbackRmwFromSize(size = 300) {
    return 5 + size * 0.125;
}

function radarBaseRmw(intensity, circulationSize) {
    const organization = clamp((intensity - 25) / 85, 0.01, 0.99);
    return (20 + circulationSize * 0.12) * (1.8 - 0.7 * organization);
}

function getPrimaryRmw(cyclone) {
    if (cyclone.isERCActive && Number.isFinite(cyclone.ercInnerRmw)) return cyclone.ercInnerRmw;
    if (Number.isFinite(cyclone.rmw)) return cyclone.rmw;
    return fallbackRmwFromSize(cyclone.circulationSize);
}

function getOuterDecayEfficiency(circulationSize = 300) {
    // Large vortices retain a broad envelope, but their gale-force tail should
    // not expand in direct proportion to total circulation size. Compact and
    // average systems are essentially unchanged; the largest systems shorten
    // their radial decay scales by at most 28%.
    const largeCirculation = smoothstep((circulationSize - 250) / 450);
    return 1 - 0.28 * largeCirculation;
}

function getMpiEffectiveRmw(cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return innerRmw;

    // As the outer eyewall takes over, its much larger radius increasingly
    // represents the core over which the available heat engine is spread.
    const transition = getEnvelopeTransition(cyclone);
    return innerRmw + (cyclone.ercOuterRmw - innerRmw) * transition;
}

export function adjustMpiForStormStructure(thermodynamicMpi, cyclone) {
    if (!(thermodynamicMpi > 0)) return 0;

    const circulationSize = clamp(
        Number.isFinite(cyclone.circulationSize)
            ? cyclone.circulationSize
            : MPI_REFERENCE_CIRCULATION_KM,
        100,
        800
    );
    const effectiveRmw = clamp(
        getMpiEffectiveRmw(cyclone),
        MIN_RMW_KM,
        190
    );

    // MPI is a peak-wind ceiling, not a total-storm-energy ceiling. Broad
    // circulations and large eyes distribute the same heat-engine output over
    // more air, so their attainable maximum wind should be lower. The smooth
    // thresholds leave ordinary/compact storms unchanged and avoid abrupt MPI
    // jumps while size or an ERC-driven RMW evolves.
    const circulationDispersion = smoothstep(
        (circulationSize - MPI_REFERENCE_CIRCULATION_KM)
            / (800 - MPI_REFERENCE_CIRCULATION_KM)
    );
    const rmwDispersion = smoothstep(
        (effectiveRmw - MPI_REFERENCE_RMW_KM)
            / (190 - MPI_REFERENCE_RMW_KM)
    );
    const dispersionPenalty = 0.18 * circulationDispersion
        + 0.16 * rmwDispersion
        + 0.04 * circulationDispersion * rmwDispersion;
    const structuralEfficiency = clamp(1 - dispersionPenalty, 0.62, 1);

    return thermodynamicMpi * structuralEfficiency;
}

function hollandShapeParameter(cyclone, peakWind = cyclone?.intensity || 0) {
    // Holland (2008) environmental predictors for the surface-profile B
    // parameter. Pressure deficit is retained on the storm after every model
    // step; older saves fall back to a conservative wind-derived estimate.
    const environmentalPressure = Number.isFinite(cyclone?.environmentalPressure)
        ? cyclone.environmentalPressure : 1010;
    const centralPressure = Number.isFinite(cyclone?.centralPressure)
        ? cyclone.centralPressure
        : environmentalPressure - clamp(0.50 * peakWind, 8, 95);
    const pressureDeficit = clamp(environmentalPressure - centralPressure, 5, 120);
    const pressureTendency = clamp(cyclone?.pressureTendency || 0, -5, 5);
    const latitude = Math.abs(Number.isFinite(cyclone?.lat) ? cyclone.lat : 15);
    const translationMs = Math.max(0, cyclone?.speed || 0) * 0.514444;
    const delta = 0.6 * (1 - pressureDeficit / 215);
    const bs = 1
        - 4.4e-5 * pressureDeficit * pressureDeficit
        + 0.01 * pressureDeficit
        + 0.03 * pressureTendency
        - 0.014 * latitude
        + 0.15 * Math.pow(translationMs, delta);
    return clamp(bs, 0.8, 2.5);
}

function holland2010WindAtRadius(
    radius,
    rmw,
    peakWind,
    circulationSize,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    if (!(radius > 0) || !(rmw > 0) || !(peakWind > 0)) return 0;

    const size = clamp(circulationSize || 300, 100, 800);
    const ratio = rmw / radius;
    const radialPower = Math.pow(ratio, hollandB);
    const normalizedGradientTerm = radialPower * Math.exp(1 - radialPower);

    // H10 Eq. (6), Vmax outside the brackets: solve x_n from (r_n, V_n).
    // No observed peripheral winds exist in this simulation. Use 17 m/s
    // (H10's fallback) at a size-derived radius; the radius/broadness mapping
    // and the weak-storm half-peak limit are simulation closure assumptions.
    const broadness = clamp(outerWindBroadness, 0, 1);
    const fitRadius = Math.max(rmw + 120, size * (0.85 + 0.30 * broadness));
    const peripheralWind = Math.min(17 / 0.514444, 0.5 * peakWind);
    const fitPower = Math.pow(rmw / fitRadius, hollandB);
    const fitLog = Math.log(fitPower) + 1 - fitPower;
    // A synthetic constraint requiring x_n < 0.5 would extrapolate toward
    // zero/negative x and eventually turn the tail upward. Reject that
    // broadening request (not an H10 requirement) to retain monotone decay.
    const peripheralX = Math.max(0.5, Math.log(peripheralWind / peakWind) / fitLog);
    // H10's linear x(r) continues beyond r_n; freezing it leaves an
    // artificially long power-law tail and a slope break at the fit radius.
    const outerFraction = Math.max(0, (radius - rmw) / (fitRadius - rmw));
    const x = 0.5 + (peripheralX - 0.5) * outerFraction;
    return peakWind * Math.pow(Math.max(0, normalizedGradientTerm), x);
}

function estimateSymmetricCoreR64(
    rmw,
    peakWind,
    circulationSize,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    if (!(peakWind > 64) || !(rmw > 0)) return rmw;
    const searchLimit = Math.max(220, Math.min(900, (circulationSize || 300) * 2.5));
    let previousRadius = rmw;
    let previousWind = peakWind;
    for (let radius = rmw + 2; radius <= searchLimit; radius += 2) {
        const wind = holland2010WindAtRadius(
            radius, rmw, peakWind, circulationSize, outerWindBroadness, hollandB
        );
        if (wind <= 64) {
            const fraction = (previousWind - 64) / Math.max(1e-6, previousWind - wind);
            return previousRadius + (radius - previousRadius) * clamp(fraction, 0, 1);
        }
        previousRadius = radius;
        previousWind = wind;
    }
    return searchLimit;
}

function primaryWindAtRadius(
    radius,
    rmw,
    peakWind,
    circulationSize,
    envelopePeakWind = peakWind,
    envelopeRmw = rmw,
    energyDispersion = 0,
    outerWindBroadness = 0.6,
    hollandB = 1.4
) {
    return holland2010WindAtRadius(
        radius,
        rmw,
        peakWind,
        circulationSize,
        outerWindBroadness,
        hollandB
    );
}

function getEnvelopeTransition(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    return clamp(
        0.45 * (cyclone.ercOuterOrganization || 0)
            + 0.35 * Math.min(1, (cyclone.ercOuterShare || 0) * 1.5)
            + 0.55 * (1 - (cyclone.ercInnerIntegrity ?? 1)),
        0,
        1
    );
}

function getOuterEyewallDominance(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const organization = smoothstep(((cyclone.ercOuterOrganization || 0) - 0.28) / 0.67);
    const share = smoothstep(((cyclone.ercOuterShare || 0) - 0.20) / 0.52);
    const innerDecay = smoothstep((0.76 - (cyclone.ercInnerIntegrity ?? 1)) / 0.64);
    let dominance = organization * share * innerDecay;
    return clamp(dominance, 0, 1);
}

function getErcEnergyDispersion(cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const outerShare = clamp(cyclone.ercOuterShare || 0, 0, 1);
    const shareBalance = 4 * outerShare * (1 - outerShare);
    const organization = smoothstep(((cyclone.ercOuterOrganization || 0) - 0.08) / 0.82);
    return organization * smoothstep(shareBalance);
}

function baselineWindAtRadius(radius, cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    const innerWind = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
        ? cyclone.ercInnerWind
        : cyclone.intensity;
    const transition = getEnvelopeTransition(cyclone);
    const energyDispersion = getErcEnergyDispersion(cyclone);
    const envelopeRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? innerRmw + (cyclone.ercOuterRmw - innerRmw) * transition
        : innerRmw;
    return primaryWindAtRadius(
        radius,
        innerRmw,
        innerWind,
        cyclone.circulationSize,
        Math.max(innerWind, cyclone.intensity || 0),
        envelopeRmw,
        energyDispersion,
        Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
        hollandShapeParameter(cyclone, innerWind)
    );
}

function outerEyewallAnomalyAtRadius(radius, cyclone) {
    if (!cyclone.isERCActive || !Number.isFinite(cyclone.ercOuterRmw)) return 0;
    const innerRmw = Number.isFinite(cyclone.ercInnerRmw) ? cyclone.ercInnerRmw : getPrimaryRmw(cyclone);
    const gap = Math.max(8, cyclone.ercOuterRmw - innerRmw);
    const innerCutoff = smoothstep((radius - (innerRmw + 0.12 * gap)) / (0.30 * gap));
    const anomalyPeak = Math.max(0, cyclone.ercOuterWindAnomaly || 0);
    if (anomalyPeak <= 0) return 0;

    // RMW2 begins as a local annular maximum embedded in the parent
    // circulation. It only acquires the complete outer decay of the primary
    // vortex after organization, momentum share, and inner-eyewall decay show
    // that replacement is actually occurring.
    const organization = clamp(cyclone.ercOuterOrganization || 0, 0, 1);
    const ringWidth = clamp(cyclone.ercOuterWidth || 18, 8, 60);
    const innerSigma = Math.min(
        gap * (0.38 + 0.10 * (1 - organization)),
        ringWidth * (0.90 + 0.25 * (1 - organization))
    );
    const outerSigma = ringWidth * (1.10 + 0.35 * (1 - organization));
    const offset = radius - cyclone.ercOuterRmw;
    const sigma = Math.max(6, offset < 0 ? innerSigma : outerSigma);
    const coreShape = Math.exp(-0.5 * Math.pow(offset / sigma, 2));
    const baselineWind = baselineWindAtRadius(radius, cyclone);
    const outerBackground = baselineWindAtRadius(cyclone.ercOuterRmw, cyclone);
    const ringPeakWind = outerBackground + anomalyPeak;
    // A secondary wind maximum is a local perturbation, not a prescribed
    // gale-radius shelf. Its transition to a primary H10 envelope follows
    // continuous structural diagnostics (no ERC-state or V1=V2 switch).
    const localizedWind = baselineWind + anomalyPeak * coreShape * innerCutoff;
    const outerDominance = getOuterEyewallDominance(cyclone);
    const replacementWind = primaryWindAtRadius(
        radius,
        cyclone.ercOuterRmw,
        ringPeakWind,
        cyclone.circulationSize,
        ringPeakWind,
        cyclone.ercOuterRmw,
        0,
        Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
        hollandShapeParameter(cyclone, ringPeakWind)
    );
    // As the inner eyewall disappears or the rings merge, remove its residual
    // everywhere, so the limiting profile is the same one used after ERC.
    // These blend widths are closure assumptions, not observed universal rates.
    const remnantGone = smoothstep((0.25 - (cyclone.ercInnerIntegrity ?? 1)) / 0.20);
    const separated = smoothstep(Math.max(0, cyclone.ercOuterRmw - innerRmw) / Math.max(8, ringWidth));
    const replacementMask = 1 - (1 - innerCutoff) * separated * (1 - remnantGone);
    const resolvedWind = localizedWind
        + (replacementWind - localizedWind) * outerDominance * replacementMask;
    // Signed redistribution is needed to retire the inner remnant; clipping
    // this correction to positive values retains a ghost inner wind maximum.
    return resolvedWind - baselineWind;
}

export function getEyewallWindProfile(cyclone, stepKm = 2) {
    const innerRmw = getPrimaryRmw(cyclone);
    const outerRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? cyclone.ercOuterRmw
        : null;
    const outerWidth = Math.max(8, cyclone.ercOuterWidth || 0);
    const maxRadius = outerRmw === null
        ? Math.max(innerRmw * 3, innerRmw + 80)
        : Math.max(innerRmw + 40, outerRmw + 3 * outerWidth);
    const radii = new Set([0, innerRmw]);
    if (outerRmw !== null) radii.add(outerRmw);
    for (let radius = Math.max(1, stepKm); radius <= maxRadius; radius += Math.max(1, stepKm)) {
        radii.add(radius);
    }
    const points = [...radii]
        .sort((a, b) => a - b)
        .map(radius => ({
            radius,
            wind: baselineWindAtRadius(radius, cyclone)
                + outerEyewallAnomalyAtRadius(radius, cyclone)
        }));
    const peaks = [];
    for (let i = 1; i < points.length - 1; i++) {
        if (points[i].wind >= points[i - 1].wind && points[i].wind > points[i + 1].wind) {
            peaks.push(points[i]);
        }
    }
    const maximum = points.reduce((best, point) => point.wind > best.wind ? point : best, points[0]);
    const significantPeaks = peaks.filter(peak => peak.wind >= Math.max(25, maximum.wind * 0.55));
    return {
        points,
        peaks: significantPeaks,
        maximum,
        hasDoublePeak: significantPeaks.length >= 2
            && significantPeaks.at(-1).radius - significantPeaks[0].radius >= 10
    };
}

/**
 * Returns the resolved two-eyewall structure.  The outer contribution is an
 * anomaly above the primary vortex, so ordinary background flow at RMW2 is
 * not mistaken for a second eyewall.
 */
export function getEyewallStructure(cyclone) {
    const innerRmw = getPrimaryRmw(cyclone);
    const innerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
        ? cyclone.ercInnerWind
        : cyclone.intensity;
    const outerRmw = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
        ? cyclone.ercOuterRmw
        : null;
    const outerAnomaly = outerRmw === null ? 0 : Math.max(0, cyclone.ercOuterWindAnomaly || 0);
    const outerBackground = outerRmw === null ? 0 : baselineWindAtRadius(outerRmw, cyclone);
    const outerPeak = outerBackground + outerAnomaly;

    const innerMomentumSq = Math.pow(Math.max(0, innerPeak) * innerRmw, 2);
    const outerMomentumSq = Math.pow(outerAnomaly * (outerRmw || 0), 2);
    const totalMomentumSq = innerMomentumSq + outerMomentumSq;
    const outerShare = totalMomentumSq > 0 ? outerMomentumSq / totalMomentumSq : 0;
    const windProfile = getEyewallWindProfile(cyclone);

    return {
        innerRmw,
        innerPeak,
        outerRmw,
        outerBackground,
        outerAnomaly,
        outerPeak,
        outerShare,
        peakWind: windProfile.maximum.wind,
        dominantRmw: windProfile.maximum.radius,
        windPeaks: windProfile.peaks,
        hasDoubleWindPeak: windProfile.hasDoublePeak
    };
}

function clearEyewallStructure(cyclone, outcome = 'none') {
    cyclone.ercLastMode = cyclone.ercMode || cyclone.ercLastMode || 'none';
    cyclone.isERCActive = false;
    cyclone.ercState = 'none';
    cyclone.ercMode = 'none';
    cyclone.ercPotential = 0;
    cyclone.ercEligibleHours = 0;
    cyclone.ercFormationTargetHours = null;
    cyclone.ercStartTime = 0;
    cyclone.ercAdverseHours = 0;
    cyclone.ercInnerRmw = null;
    cyclone.ercInnerWind = null;
    cyclone.ercOuterRmw = null;
    cyclone.ercOuterWindAnomaly = 0;
    cyclone.ercOuterWidth = 0;
    cyclone.ercOuterRadarWidthKm = 0;
    cyclone.ercOuterShare = 0;
    cyclone.ercOuterOrganization = 0;
    cyclone.ercInnerIntegrity = 1;
    cyclone.ercSettlingUntil = 0;
    cyclone.ercCompletionOutcome = 'none';
    cyclone.ercCooldownHours = 0;
    cyclone.ercPostContractionHours = 0;
    cyclone.ercPace = 1;
    cyclone.ercRapid = false;
    cyclone.ercPeakSizeTarget = null;
    cyclone.ercMpiCeiling = null;
    if (!['completed', 'fused'].includes(outcome)) {
        cyclone.ercPostSizeTarget = null;
        cyclone.ercPostSizeRelaxHours = 0;
        cyclone.ercPostSizeRelaxUntil = 0;
    }
    cyclone.ercLastOutcome = outcome;
}

function startEyewallReplacement(cyclone, support = 0.7) {
    const innerRmw = getPrimaryRmw(cyclone);
    const mode = innerRmw > 95 || Math.random() < 0.15 ? 'fusion' : 'classic';
    const compactness = 1 - smoothstep(((cyclone.circulationSize || 300) - 180) / 300);
    const rapidChance = clamp(0.16 + 0.25 * support + 0.11 * compactness, 0.16, 0.52);
    // Rapid cycles represent a pre-organized secondary eyewall taking over;
    // the separate fusion pathway keeps its own, more gradual geometry.
    const rapid = mode === 'classic' && Math.random() < rapidChance;
    const pace = rapid ? 2.70 + Math.random() * 0.30 : 1.90 + Math.random() * 0.35;
    const outerRatio = mode === 'fusion'
        ? 1.52 + Math.random() * 0.34
        : 2.15 + Math.random() * 0.55;
    const minimumOuterRmw = innerRmw + (mode === 'fusion' ? 12 : 25);
    const sizeSupportedOuterRmw = Math.max(
        minimumOuterRmw,
        cyclone.circulationSize * (mode === 'fusion' ? 0.42 : 0.38)
    );
    const outerRmw = clamp(
        outerRatio * innerRmw,
        minimumOuterRmw,
        Math.min(190, sizeSupportedOuterRmw)
    );
    const initialWidth = mode === 'fusion'
        ? clamp((outerRmw - innerRmw) * 0.82, 14, 34)
        : clamp(outerRmw * 0.30, 20, 55);
    const initialRadarWidth = mode === 'fusion'
        ? clamp(70 + Math.random() * 45, 60, 125)
        : clamp(60 + outerRmw * 0.45 + Math.random() * 25, 55, 120);

    cyclone.isERCActive = true;
    cyclone.ercStartedCount = (cyclone.ercStartedCount || 0) + 1;
    cyclone.ercFormationTargetHours = null;
    cyclone.ercState = 'forming';
    cyclone.ercMode = mode;
    cyclone.ercStartTime = cyclone.age;
    cyclone.ercAdverseHours = 0;
    cyclone.ercInnerRmw = innerRmw;
    cyclone.ercInnerWind = cyclone.intensity;
    cyclone.ercOuterRmw = outerRmw;
    cyclone.ercOuterWidth = initialWidth;
    cyclone.ercOuterRadarWidthKm = initialRadarWidth;
    cyclone.ercOuterWindAnomaly = Math.max(1.5, cyclone.intensity * (rapid ? 0.050 : 0.025));
    cyclone.ercOuterShare = 0;
    cyclone.ercOuterOrganization = rapid ? 0.15 : 0.06;
    cyclone.ercInnerIntegrity = 1;
    cyclone.ercInitialIntensity = cyclone.intensity;
    cyclone.ercEnvironmentalPeak = cyclone.intensity;
    cyclone.ercMpiCeiling = cyclone.intensity;
    cyclone.ercInitialRmw = innerRmw;
    cyclone.ercCompactRecovery = Math.random() < (0.20 + 0.25 * support + (rapid ? 0.10 : 0));
    cyclone.ercInitialSize = cyclone.circulationSize;
    cyclone.ercPace = pace;
    cyclone.ercRapid = rapid;
    const peakExpansion = rapid
        ? 0.07 + Math.random() * 0.07
        : (mode === 'fusion' ? 0.07 + Math.random() * 0.08 : 0.10 + Math.random() * 0.10);
    cyclone.ercPeakSizeTarget = Math.min(
        800,
        Math.max(
            cyclone.ercInitialSize * (1 + peakExpansion),
            outerRmw * (mode === 'fusion' ? 2.55 : 2.75)
        )
    );
    cyclone.ercPostSizeTarget = cyclone.ercInitialSize * (1.03 + Math.random() * 0.05);
    cyclone.ercPostSizeRelaxHours = rapid
        ? 36 + Math.random() * 48
        : 48 + Math.random() * 72;
    cyclone.ercPostSizeRelaxUntil = 0;
    cyclone.ercPotential = 0;
}

function beginEyewallSettlement(cyclone, structure, outcome = 'completed') {
    const completedMode = cyclone.ercMode || 'classic';
    const rapid = Boolean(cyclone.ercRapid);
    const peakSizeTarget = Number.isFinite(cyclone.ercPeakSizeTarget)
        ? cyclone.ercPeakSizeTarget
        : cyclone.ercInitialSize * 1.12;
    const completedSize = Math.max(
        cyclone.circulationSize,
        cyclone.ercInitialSize + (peakSizeTarget - cyclone.ercInitialSize) * 0.68
    );

    // Crossing the takeover threshold is not the same as instantly acquiring
    // a finished single eyewall.  Keep both radar rings alive while the inner
    // remnant fades and the new primary ring closes and narrows.
    cyclone.ercState = 'settling';
    cyclone.ercCompletionOutcome = outcome;
    cyclone.ercSettlingUntil = cyclone.age + (rapid
        ? 3 + Math.random() * 3
        : (completedMode === 'fusion' ? 9 + Math.random() * 6 : 12 + Math.random() * 6));
    cyclone.rmw = structure.outerRmw;
    cyclone.intensity = structure.peakWind;
    cyclone.circulationSize = completedSize;
    cyclone.ercCooldownHours = 24 + Math.random() * 12;
    cyclone.ercPostContractionHours = completedMode === 'fusion'
        ? 18 + Math.random() * 24
        : 24 + Math.random() * 30;
    const initialRmw = cyclone.ercInitialRmw || cyclone.ercInnerRmw || structure.innerRmw;
    // RMW and the broad circulation envelope need not expand together. Some
    // replacement rings contract back to the old core; others stay expanded.
    cyclone.ercPostRmwTarget = cyclone.ercCompactRecovery
        ? initialRmw * (0.92 + Math.random() * 0.16)
        : Math.max(initialRmw * (1.15 + Math.random() * 0.30), structure.outerRmw * (0.65 + Math.random() * 0.15));
    const minimumPostRmw = MIN_RMW_KM;
    cyclone.ercPostRmwTarget = clamp(
        cyclone.ercPostRmwTarget,
        minimumPostRmw,
        Math.max(MIN_RMW_KM, structure.outerRmw * 0.95)
    );
}

function finishEyewallSettlement(cyclone) {
    const outcome = cyclone.ercCompletionOutcome || 'completed';
    const outerRmw = cyclone.ercOuterRmw;
    const outerRadarWidth = Number.isFinite(cyclone.ercOuterRadarWidthKm)
        ? cyclone.ercOuterRadarWidthKm
        : 55;
    cyclone.rmw = outerRmw;
    cyclone.ercCompletedAt = cyclone.age;
    cyclone.ercCycleCount = (cyclone.ercCycleCount || 0) + 1;
    cyclone.ercCooldownUntil = cyclone.age + Math.max(cyclone.ercCooldownHours || 36, cyclone.ercPostContractionHours || 36);
    cyclone.ercPostContractionUntil = cyclone.age + (cyclone.ercPostContractionHours || 60);
    cyclone.ercPostSizeRelaxUntil = cyclone.age + (cyclone.ercPostSizeRelaxHours || 72);
    cyclone.radarRmwScale = clamp(
        outerRmw / Math.max(1, radarBaseRmw(cyclone.intensity, cyclone.circulationSize)),
        0.35,
        3.2
    );
    // Store the convective-ring thickness separately from RMW.  A large eye
    // therefore remains compatible with a comparatively thin eyewall.
    cyclone.radarEyewallWidthKm = clamp(outerRadarWidth, 30, cyclone.ercMode === 'fusion' ? 130 : 120);
    cyclone.radarEyewallMaturity = 0;
    clearEyewallStructure(cyclone, outcome);
}

function evolveEyewallReplacement(cyclone, environment, applyBaseTendency = true) {
    const {
        mpi,
        totalShear,
        effectiveHumidity,
        isOverLand,
        baseIntensityChange
    } = environment;

    // Once a secondary eyewall has formed, the temporary intensity dip is a
    // consequence of the replacement itself and must not be interpreted as
    // loss of structural maturity.
    const maturityIntensity = cyclone.isERCActive
        && Number.isFinite(cyclone.ercInitialIntensity)
        ? Math.max(cyclone.intensity, cyclone.ercInitialIntensity)
        : cyclone.intensity;
    const maturity = smoothstep((maturityIntensity - ERC_MIN_INTENSITY) / 35);
    // Mature storms commonly enter ERC close to their environmental ceiling;
    // only a substantial MPI overshoot should suppress secondary formation.
    const mpiSupport = 1 - smoothstep((cyclone.intensity - mpi + 5) / 20);
    const shearSupport = 1 - smoothstep((totalShear - 8) / 16);
    const moistureSupport = smoothstep((effectiveHumidity - 55) / 22);
    const oceanSupport = isOverLand || cyclone.isTransitioning || cyclone.isExtratropical || cyclone.isSubtropical ? 0 : 1;
    const structureSupport = smoothstep(((cyclone.circulationSize || 300) - 150) / 300);
    // Moderate shear or merely average humidity should slow organization, not
    // collapse the support product to almost zero. Truly hostile values are
    // handled separately by the adverse-environment test below.
    const shearOrganization = 0.35 + 0.65 * shearSupport;
    const moistureOrganization = 0.40 + 0.60 * moistureSupport;
    const support = oceanSupport * maturity * mpiSupport
        * shearOrganization * moistureOrganization
        * (0.78 + 0.22 * structureSupport);

    if (!cyclone.isERCActive) {
        if (cyclone.age < (cyclone.ercCooldownUntil || 0) || cyclone.intensity < ERC_MIN_INTENSITY) {
            // Brief weakening below the nominal threshold should not erase a
            // long period of prior inner-core organization. Cool the memory
            // gradually; a genuinely prolonged weak phase still removes it.
            cyclone.ercPotential = Math.max(0, (cyclone.ercPotential || 0) - 0.04);
            cyclone.ercEligibleHours = Math.max(
                0,
                (cyclone.ercEligibleHours || 0) - MODEL_STEP_HOURS
            );
            return;
        }

        // Treat this as accumulated favourable-structure exposure rather than
        // a brittle consecutive-hours counter. Marginal three-hour humidity
        // or shear samples no longer erase six hours of mature-core history.
        const structurallyEligible = oceanSupport > 0
            && cyclone.intensity >= 95
            && totalShear < 30
            && effectiveHumidity >= 40
            && mpi >= 75
            && cyclone.intensity <= mpi + 20;

        // Mature storms retain a weaker cycle-building signal even when one
        // humidity sample makes the instantaneous support score mediocre.
        // This prevents a long-lived major cyclone from remaining permanently
        // locked in an unrealistically steady, single-eyewall state.
        const sustainedStructureSupport = oceanSupport * maturity * mpiSupport
            * (0.40 + 0.60 * shearSupport)
            * (0.45 + 0.55 * moistureSupport);
        const formationSupport = Math.max(support, 0.72 * sustainedStructureSupport);
        const exposureGain = MODEL_STEP_HOURS * (
            0.75 + 0.25 * clamp(formationSupport, 0, 1)
        );
        cyclone.ercEligibleHours = structurallyEligible
            ? Math.min(144, (cyclone.ercEligibleHours || 0) + exposureGain)
            : Math.max(0, (cyclone.ercEligibleHours || 0) - 0.5 * MODEL_STEP_HOURS);

        const noisySupport = clamp(formationSupport + (Math.random() - 0.5) * 0.08, 0, 1);
        const overdueCyclePressure = 0.065
            * smoothstep(((cyclone.ercEligibleHours || 0) - 12) / 36);
        cyclone.ercPotential = clamp(
            (cyclone.ercPotential || 0)
                + 0.30 * noisySupport * noisySupport
                - 0.012 * (1 - noisySupport)
                + overdueCyclePressure,
            0,
            1.15
        );
        if (structurallyEligible && !Number.isFinite(cyclone.ercFormationTargetHours)) {
            // A persistent mature core should not remain a single eyewall indefinitely.
            // Randomize once per cycle, not every step; exposure survives brief interruptions.
            cyclone.ercFormationTargetHours = 30 + 24 * Math.random();
        }
        const matureCycleDue = structurallyEligible
            && cyclone.ercEligibleHours >= cyclone.ercFormationTargetHours;
        if (oceanSupport && (cyclone.ercPotential >= 1 || matureCycleDue)) startEyewallReplacement(cyclone, support);
        return;
    }

    const elapsed = cyclone.age - cyclone.ercStartTime;
    // Abort only for an actually hostile environment. The old support < 0.28
    // test also included current intensity, so ordinary ERC weakening could
    // incorrectly abort its own cycle.
    const adverse = oceanSupport <= 0
        || totalShear > 32
        || effectiveHumidity < 40
        || mpi < 65
        || isOverLand;
    // Hostile conditions may weaken both rings thermodynamically, but they
    // cannot keep driving an eyewall replacement. The former 0.65 floor in
    // innerLoss let a failed outer ring erode the inner eyewall throughout the
    // full 18-hour abort-confirmation window.
    const replacementSupport = adverse ? 0 : support;
    const replacementViability = adverse ? 0 : 1;
    cyclone.ercOuterOrganization = Number.isFinite(cyclone.ercOuterOrganization)
        ? cyclone.ercOuterOrganization
        : 0.04;
    cyclone.ercOuterRadarWidthKm = Number.isFinite(cyclone.ercOuterRadarWidthKm)
        ? cyclone.ercOuterRadarWidthKm
        : clamp((cyclone.ercOuterWidth || 18) * 3, 30, 120);
    cyclone.ercInnerIntegrity = Number.isFinite(cyclone.ercInnerIntegrity)
        ? cyclone.ercInnerIntegrity
        : 1;
    cyclone.ercMode = cyclone.ercMode === 'fusion' ? 'fusion' : 'classic';
    cyclone.ercPace = Number.isFinite(cyclone.ercPace) ? clamp(cyclone.ercPace, 0.7, 3) : 1;
    cyclone.ercRapid = Boolean(cyclone.ercRapid);
    cyclone.ercInitialSize = Number.isFinite(cyclone.ercInitialSize) && cyclone.ercInitialSize > 0
        ? cyclone.ercInitialSize
        : cyclone.circulationSize;
    cyclone.ercPeakSizeTarget = Number.isFinite(cyclone.ercPeakSizeTarget)
        ? cyclone.ercPeakSizeTarget
        : cyclone.ercInitialSize * 1.12;
    cyclone.ercPostSizeTarget = Number.isFinite(cyclone.ercPostSizeTarget)
        ? cyclone.ercPostSizeTarget
        : cyclone.ercInitialSize * 1.05;
    cyclone.ercPostSizeRelaxHours = Number.isFinite(cyclone.ercPostSizeRelaxHours)
        ? cyclone.ercPostSizeRelaxHours
        : 72;
    cyclone.ercAdverseHours = adverse
        ? cyclone.ercAdverseHours + MODEL_STEP_HOURS
        : Math.max(0, cyclone.ercAdverseHours - MODEL_STEP_HOURS);

    // Structural MPI can fall quickly as the diagnosed core shifts from RMW1
    // to a much larger RMW2. That is a geometric reclassification, not an
    // instantaneous removal of angular momentum. Let the ERC-specific wind
    // ceiling follow a falling MPI over a finite response time; environmental
    // losses still enter every step through baseIntensityChange.
    const previousMpiCeiling = Number.isFinite(cyclone.ercMpiCeiling)
        ? cyclone.ercMpiCeiling
        : Math.max(cyclone.intensity, mpi);
    const mpiResponseHours = mpi < previousMpiCeiling
        ? ERC_MPI_WEAKENING_RESPONSE_HOURS
        : ERC_MPI_RECOVERY_RESPONSE_HOURS;
    const mpiResponse = 1 - Math.exp(-MODEL_STEP_HOURS / mpiResponseHours);
    cyclone.ercMpiCeiling = previousMpiCeiling + (mpi - previousMpiCeiling) * mpiResponse;
    const ercWindCeiling = Math.max(10, cyclone.ercMpiCeiling);

    // During the dual-eyewall display the ordinary radar core represents the
    // inner eyewall.  Bring its rendered radius into physical agreement
    // gradually, so the outer-ring ratio is not magnified by an old scale.
    const innerRadarScaleTarget = clamp(
        cyclone.ercInnerRmw / Math.max(1, radarBaseRmw(cyclone.intensity, cyclone.circulationSize)),
        0.35,
        3.2
    );
    const currentRadarScale = Number.isFinite(cyclone.radarRmwScale) ? cyclone.radarRmwScale : 1;
    const radarAlignmentRate = cyclone.ercState === 'settling' ? 0.32 : 0.14;
    cyclone.radarRmwScale = currentRadarScale
        + (innerRadarScaleTarget - currentRadarScale) * radarAlignmentRate;

    cyclone.ercEnvironmentalPeak = clamp((cyclone.ercEnvironmentalPeak ?? cyclone.ercInitialIntensity)
        + baseIntensityChange, 10, ercWindCeiling);
    let structure = getEyewallStructure(cyclone);

    if (cyclone.ercState === 'settling') {
        const pace = cyclone.ercPace;
        const settlePace = pace * (cyclone.ercMode === 'fusion' ? 1.35 : 1);
        // Settlement changes geometry, but must not pin wind to the pre-cycle peak.
        // Continue the same environmental tendency used outside replacement.
        const replacementPeakTarget = clamp(structure.peakWind + baseIntensityChange, 10, ercWindCeiling);
        const settlingBackground = baselineWindAtRadius(cyclone.ercOuterRmw, cyclone);
        const settlingAnomalyTarget = Math.max(0, replacementPeakTarget - settlingBackground);
        cyclone.ercOuterWindAnomaly += (settlingAnomalyTarget - cyclone.ercOuterWindAnomaly)
            * Math.min(0.50, 0.18 * settlePace);
        const targetWidth = cyclone.ercMode === 'fusion'
            ? clamp(9 + cyclone.intensity * 0.045, 10, 18)
            : clamp(7 + cyclone.intensity * 0.035, 8, 15);
        const targetRadarWidth = cyclone.ercMode === 'fusion'
            ? clamp(48 + cyclone.circulationSize * 0.055, 50, 90)
            : clamp(30 + cyclone.circulationSize * 0.045, 35, 72);
        cyclone.ercOuterOrganization += (1 - cyclone.ercOuterOrganization)
            * Math.min(0.44, 0.16 * settlePace);
        cyclone.ercOuterWidth += (targetWidth - cyclone.ercOuterWidth)
            * Math.min(0.46, 0.18 * settlePace);
        cyclone.ercOuterRadarWidthKm += (targetRadarWidth - cyclone.ercOuterRadarWidthKm)
            * Math.min(0.40, 0.14 * settlePace);
        const integrityRetention = cyclone.ercMode === 'fusion' ? 0.76 : 0.70;
        // Express the former per-step retention as a continuous decay time.
        // At the current 3 h model step this is numerically identical, while
        // remaining stable if the integration interval changes later.
        const integrityDecayHours = -MODEL_STEP_HOURS / Math.log(integrityRetention);
        cyclone.ercInnerIntegrity *= Math.exp(
            -MODEL_STEP_HOURS * settlePace / integrityDecayHours
        );
        cyclone.ercInnerWind = Math.max(20, cyclone.ercInnerWind
            + Math.min(0, baseIntensityChange)
            - (1.4 + 1.8 * support) * settlePace);

        const contractionFloor = cyclone.ercCompactRecovery && cyclone.ercInnerIntegrity < 0.20
            ? cyclone.ercPostRmwTarget : cyclone.ercMode === 'fusion'
            ? cyclone.ercInnerRmw * 1.10
            : Math.max(cyclone.ercInnerRmw + 12, cyclone.ercPostRmwTarget);
        const settleContraction = (cyclone.ercCompactRecovery ? 0.07 : cyclone.ercMode === 'fusion' ? 0.010 : 0.005) * settlePace;
        cyclone.ercOuterRmw = Math.max(contractionFloor, cyclone.ercOuterRmw * (1 - settleContraction));
        cyclone.circulationSize += (cyclone.ercPeakSizeTarget - cyclone.circulationSize)
            * Math.min(0.34, 0.14 * settlePace);

        structure = getEyewallStructure(cyclone);
        // The resolved outer-wind blend consumes ercOuterShare. Refresh it
        // after the current geometry update before diagnosing the final peak;
        // otherwise settlement uses yesterday's weaker takeover state.
        cyclone.ercOuterShare = structure.outerShare;
        structure = getEyewallStructure(cyclone);
        // During settlement the inner remnant is removed from the blended
        // profile. Transfer that changing contribution to the already-dominant
        // replacement ring so the bookkeeping transition follows the existing
        // environmental target instead of creating a cliff or spike.
        for (let correctionStep = 0; correctionStep < 4; correctionStep++) {
            const peakError = replacementPeakTarget - structure.peakWind;
            if (Math.abs(peakError) < 0.1) break;
            cyclone.ercOuterWindAnomaly = Math.max(0, cyclone.ercOuterWindAnomaly + peakError);
            structure = getEyewallStructure(cyclone);
            cyclone.ercOuterShare = structure.outerShare;
            structure = getEyewallStructure(cyclone);
        }
        cyclone.ercOuterShare = structure.outerShare;
        cyclone.intensity = structure.peakWind;

        const visuallySettled = cyclone.ercInnerIntegrity <= (cyclone.ercRapid ? 0.14 : 0.06)
            && cyclone.ercOuterOrganization >= (cyclone.ercRapid ? 0.90 : 0.93)
            && Math.abs(cyclone.ercOuterWidth - targetWidth) <= (cyclone.ercRapid ? 2.5 : 1.5);
        const coreSettled = !cyclone.ercCompactRecovery || cyclone.ercOuterRmw <= cyclone.ercPostRmwTarget * 1.10;
        if ((cyclone.age >= cyclone.ercSettlingUntil && visuallySettled && coreSettled)
            || cyclone.age >= cyclone.ercSettlingUntil + 48 || (adverse && cyclone.ercAdverseHours >= 12)) {
            finishEyewallSettlement(cyclone);
        }
        return;
    }

    // An organized outer ring intercepts inflow even when the compact inner
    // eyewall still owns the maximum wind (especially in a merging cycle).
    const ringInterception = adverse ? 0
        : smoothstep((cyclone.ercOuterOrganization - 0.30) / 0.40)
            * smoothstep((elapsed - 12) / 36)
            * smoothstep((structure.outerPeak / Math.max(1, structure.innerPeak) - 0.65) / 0.25);
    const competition = Math.max(smoothstep((structure.outerShare - 0.08) / 0.48), ringInterception);
    if (applyBaseTendency) {
        cyclone.ercInnerWind += baseIntensityChange * (1 - 0.72 * competition);
    }

    if (cyclone.ercState === 'aborting') {
        const peakBeforeAbortStep = cyclone.intensity;
        // Dissolve a failed outer eyewall over a physical time scale. Multiplying
        // its anomaly by 0.52 every three hours removed nearly all of a dominant
        // ring in one or two samples, then exposed the already weakened inner
        // eyewall when the diagnosed profile was written back to total intensity.
        const anomalyDecayHours = adverse
            ? ERC_ABORT_ADVERSE_DECAY_HOURS
            : ERC_ABORT_BENIGN_DECAY_HOURS;
        const organizationDecayHours = adverse ? 12 : 18;
        cyclone.ercOuterWindAnomaly *= Math.exp(-MODEL_STEP_HOURS / anomalyDecayHours);
        cyclone.ercOuterOrganization *= Math.exp(-MODEL_STEP_HOURS / organizationDecayHours);
        cyclone.ercOuterWidth = Math.min(60, cyclone.ercOuterWidth * 1.04);
        cyclone.ercOuterRadarWidthKm = Math.min(130, cyclone.ercOuterRadarWidthKm * 1.025);
        cyclone.ercInnerIntegrity += (1 - cyclone.ercInnerIntegrity) * 0.24;
        structure = getEyewallStructure(cyclone);

        // Environmental weakening still applies, but structural bookkeeping may
        // only add a limited loss in one model step. If the decaying outer ring
        // remains the wind maximum, retain enough of its anomaly to keep the
        // resolved profile continuous rather than assigning an unsupported
        // scalar intensity above the profile.
        const environmentalLossAllowance = clamp(-Math.min(0, baseIntensityChange), 0, 8);
        const structuralLossAllowance = adverse
            ? clamp(4 + 0.15 * Math.max(0, totalShear - 32), 4, 8)
            : 3;
        const continuityFloor = Math.max(
            10,
            peakBeforeAbortStep - environmentalLossAllowance - structuralLossAllowance
        );
        if (structure.peakWind < continuityFloor) {
            cyclone.ercOuterWindAnomaly += continuityFloor - structure.peakWind;
            structure = getEyewallStructure(cyclone);
        }
        if (structure.peakWind < continuityFloor) {
            cyclone.ercInnerWind = Math.max(cyclone.ercInnerWind, continuityFloor);
            structure = getEyewallStructure(cyclone);
        }
        cyclone.intensity = structure.peakWind;
        cyclone.ercOuterShare = structure.outerShare;
        if (cyclone.ercOuterWindAnomaly < 0.8) {
            cyclone.rmw = cyclone.ercInnerRmw;
            cyclone.ercCooldownUntil = cyclone.age + 12 + Math.random() * 12;
            clearEyewallStructure(cyclone, 'aborted');
        }
        return;
    }

    const outerTargetPeak = Math.min(
        ercWindCeiling,
        Math.max(
            35,
            cyclone.ercInnerWind * (0.86 + 0.10 * replacementSupport),
            cyclone.ercEnvironmentalPeak * (0.60 + 0.24 * cyclone.ercOuterOrganization + 0.10 * replacementSupport)
        )
    );
    const anomalyTarget = Math.max(0, outerTargetPeak - structure.outerBackground);
    const pace = cyclone.ercPace;
    const growthRate = Math.min(
        0.42,
        (0.018 + 0.10 * replacementSupport + 0.025 * cyclone.ercOuterOrganization) * pace
    );
    cyclone.ercOuterWindAnomaly += (anomalyTarget - cyclone.ercOuterWindAnomaly) * growthRate;

    structure = getEyewallStructure(cyclone);
    const timeOrganization = smoothstep(elapsed / (48 / pace));
    const organizationTarget = clamp(
        Math.max(
            replacementSupport * (0.10 + 1.55 * structure.outerShare + 0.30 * timeOrganization),
            // Once seeded, a surviving ring axisymmetrizes over time. Multiplying
            // every stage by marginal support formerly trapped it in 'forming'.
            adverse ? 0 : timeOrganization * (0.55 + 0.30 * replacementSupport)
        ),
        0,
        1
    );
    cyclone.ercOuterOrganization += (organizationTarget - cyclone.ercOuterOrganization)
        * Math.min(0.42, (0.08 + 0.14 * replacementSupport) * pace);

    const organizedWidth = cyclone.ercMode === 'fusion'
        ? clamp(cyclone.ercOuterRmw * 0.16, 10, 26)
        : clamp(cyclone.ercOuterRmw * 0.105, 8, 22);
    const looseWidth = cyclone.ercMode === 'fusion'
        ? clamp((cyclone.ercOuterRmw - cyclone.ercInnerRmw) * 0.82, 14, 36)
        : clamp(cyclone.ercOuterRmw * 0.30, 20, 55);
    const widthTarget = looseWidth + (organizedWidth - looseWidth) * cyclone.ercOuterOrganization;
    cyclone.ercOuterWidth += (widthTarget - cyclone.ercOuterWidth)
        * Math.min(0.44, (0.10 + 0.12 * support) * pace);
    const looseRadarWidth = cyclone.ercMode === 'fusion'
        ? 115
        : clamp(75 + cyclone.ercOuterRmw * 0.30, 75, 120);
    const organizedRadarWidth = cyclone.ercMode === 'fusion'
        ? clamp(55 + cyclone.circulationSize * 0.055, 55, 95)
        : clamp(32 + cyclone.circulationSize * 0.05, 38, 78);
    const radarWidthTarget = looseRadarWidth
        + (organizedRadarWidth - looseRadarWidth) * cyclone.ercOuterOrganization;
    cyclone.ercOuterRadarWidthKm += (radarWidthTarget - cyclone.ercOuterRadarWidthKm)
        * Math.min(0.40, (0.08 + 0.10 * support) * pace);
    cyclone.ercOuterRadarWidthKm = clamp(cyclone.ercOuterRadarWidthKm, 30, 130);

    if (cyclone.ercMode === 'fusion') {
        const fusionFloor = cyclone.ercInnerRmw * 1.18;
        const contractionRate = (0.006 + 0.020 * cyclone.ercOuterOrganization * replacementSupport) * pace;
        cyclone.ercOuterRmw = Math.max(fusionFloor, cyclone.ercOuterRmw * (1 - contractionRate));
    } else if (cyclone.ercOuterOrganization < 0.16) {
        // A loose secondary rainband can drift outward before it axisymmetrizes.
        cyclone.ercOuterRmw = Math.min(190, cyclone.ercOuterRmw * 1.0015);
    } else {
        const classicFloor = Math.min(190, cyclone.ercInnerRmw * 1.52);
        const contractionRate = (0.0015 + 0.0085 * cyclone.ercOuterOrganization * replacementSupport) * pace;
        cyclone.ercOuterRmw = Math.max(classicFloor, cyclone.ercOuterRmw * (1 - contractionRate));
    }

    structure = getEyewallStructure(cyclone);
    const takeover = Math.max(smoothstep((structure.outerShare - 0.12) / 0.42), 0.8 * ringInterception);
    const dualCompetition = smoothstep((cyclone.ercOuterOrganization - 0.18) / 0.55)
        * smoothstep(elapsed / (24 / pace));
    const innerLoss = dualCompetition * (0.30 + 2.35 * takeover)
        * (0.65 + 0.85 * replacementSupport) * pace
        * replacementViability;
    cyclone.ercInnerWind = Math.max(20, cyclone.ercInnerWind - innerLoss);
    const integrityLoss = Math.min(
        0.38,
        (0.008 + 0.12 * takeover) * cyclone.ercOuterOrganization
            * replacementSupport * pace * replacementViability
    );
    cyclone.ercInnerIntegrity = clamp(cyclone.ercInnerIntegrity * (1 - integrityLoss), 0, 1);
    if (adverse) {
        // Once replacement support is gone, release the inner core from ring
        // competition. Environmental intensity losses were already applied.
        cyclone.ercInnerIntegrity += (1 - cyclone.ercInnerIntegrity) * 0.10;
    }
    const windIntegrity = clamp(
        (cyclone.ercInnerWind - 20) / Math.max(20, cyclone.ercInitialIntensity - 20),
        0,
        1
    );
    cyclone.ercInnerIntegrity = Math.min(cyclone.ercInnerIntegrity, windIntegrity + 0.08);

    structure = getEyewallStructure(cyclone);
    cyclone.ercOuterShare = structure.outerShare;
    cyclone.intensity = structure.peakWind;
    const sizeProgress = Math.max(
        smoothstep(elapsed / (cyclone.ercRapid ? 15 : 36)),
        smoothstep((cyclone.ercOuterOrganization - 0.08) / 0.82),
        smoothstep((structure.outerShare - 0.04) / 0.64)
    );
    const activeSizeTarget = cyclone.ercInitialSize
        + (cyclone.ercPeakSizeTarget - cyclone.ercInitialSize) * sizeProgress;
    cyclone.circulationSize += (activeSizeTarget - cyclone.circulationSize)
        * Math.min(0.36, 0.13 * pace);

    if (cyclone.ercOuterOrganization < 0.32) cyclone.ercState = 'forming';
    else if (structure.outerPeak < structure.innerPeak * 0.94 && cyclone.ercInnerIntegrity > 0.52) cyclone.ercState = 'concentric';
    else cyclone.ercState = 'takeover';

    const separationRatio = structure.outerRmw / Math.max(1, structure.innerRmw);
    const persistentLateTakeover = !adverse
        && elapsed >= 45
        && cyclone.ercOuterOrganization >= 0.42
        && structure.outerShare >= 0.12
        && structure.outerPeak >= Math.max(
            structure.innerPeak * 0.86,
            cyclone.ercInitialIntensity * 0.60
        );
    const persistentFusion = !adverse
        && elapsed >= 36
        && cyclone.ercOuterOrganization >= 0.34
        && structure.outerShare >= 0.008
        && structure.outerPeak >= Math.max(
            structure.innerPeak * 0.80,
            cyclone.ercInitialIntensity * 0.55
        );
    if (!adverse && cyclone.ercMode === 'fusion'
        && ((elapsed >= (cyclone.ercRapid ? 6 : 12)
            && cyclone.ercOuterOrganization >= 0.34
            && separationRatio <= 1.50
            && structure.outerShare >= 0.008)
            || persistentFusion)) {
        const fusionWeight = 0.48 + 0.30 * smoothstep((structure.outerShare - 0.12) / 0.38);
        const fusedRmw = structure.innerRmw + (structure.outerRmw - structure.innerRmw) * fusionWeight;
        cyclone.ercOuterRmw = fusedRmw;
        beginEyewallSettlement(cyclone, { ...structure, outerRmw: fusedRmw }, 'fused');
    } else if (!adverse && cyclone.ercMode === 'classic'
        && ((elapsed >= (cyclone.ercRapid ? 6 : 18)
        // A replacement can pass its strongest outer-ring stage between
        // three-hour samples. Relax the simultaneous completion thresholds
        // gradually after 24 h, so a persistent near-takeover settles instead
        // of timing out solely because share and integrity peaked one step apart.
        && cyclone.ercOuterOrganization >= (cyclone.ercRapid
            ? 0.52
            : 0.62 - 0.12 * smoothstep((elapsed - 24) / 36))
        && cyclone.ercInnerIntegrity <= (cyclone.ercRapid
            ? 0.78
            : 0.63 + 0.16 * smoothstep((elapsed - 24) / 36))
        && structure.outerPeak >= Math.max(
            structure.innerPeak * (cyclone.ercRapid
                ? 0.90
                : 0.95 - 0.05 * smoothstep((elapsed - 24) / 36)),
            cyclone.ercInitialIntensity * (cyclone.ercRapid
                ? 0.68
                : 0.74 - 0.07 * smoothstep((elapsed - 24) / 36))
        )
        && structure.outerShare >= (cyclone.ercRapid
            ? 0.15
            : 0.24 - 0.07 * smoothstep((elapsed - 24) / 36)))
            || persistentLateTakeover)) {
        beginEyewallSettlement(cyclone, structure, 'completed');
    } else if (cyclone.ercAdverseHours >= 18 || elapsed >= 120 || cyclone.ercOuterWindAnomaly < 0.5) {
        cyclone.ercState = 'aborting';
    }
}

// The first native field was a useful visual prototype, but its ridge axis and
// height anomalies were generated by unrelated functions. Keep its evaluator
// for archived snapshots while new snapshots use the QG-inspired field below.
function legacyWaveFieldComponents(lon, lat, background, level = 500) {
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    const summer = (1 + background.seasonalShift / 4 * Math.tanh(lat / 5)) / 2;
    const waves = background.waves.filter(w => w.hemisphere === hemisphere);
    let meander = 0, disturbance = 0, shortWave = 0;
    for (const wave of waves) {
        const phase = wave.k * lon * radians + wave.phase;
        if (wave.k <= 4) meander += wave.amplitude * Math.sin(phase) / 28;
    }
    // Long-wave displacement smoothly tapers towards the equator and poles.
    const displacement = meander * smoothstep(latitude / 12) * Math.exp(-(((latitude - 39) / 28) ** 2));
    const ridgeLatitude = 25 + 5 * summer + displacement;
    const jetLatitude = 41 + 5 * summer + displacement;
    for (const wave of waves) {
        const tiltPhase = level === 200 ? 0.10 : level === 850 ? -0.10 : 0; // 弧度，不再乘k
        const phase = wave.k * lon * radians + wave.phase + tiltPhase
            + wave.tilt * (latitude - jetLatitude) * radians;
        const envelope = Math.exp(-0.5 * ((latitude - wave.latitude - displacement) / wave.width) ** 2);
        const value = wave.amplitude * Math.cos(phase) * envelope
            * (wave.k >= 5 ? smoothstep((latitude - 22) / 16) : 1);
        disturbance += value;
        if (wave.k >= 5) shortWave += value;
    }
    const tropicalTaper = smoothstep((latitude - 10) / 18);
    const poleTaper = Math.cos(latitude * radians) ** 2;
    disturbance *= tropicalTaper * poleTaper;
    // Finite-amplitude wave adjustment: constructive interference must not
    // create arbitrarily high crests. Applied to the shared model field (and
    // hence its winds), never to contour labels or only to the exported image.
    disturbance = 90 * Math.tanh(disturbance / 90);
    const t = smoothstep((latitude - 32 - 4 * summer - displacement * .35) / 50);
    const polarDrop = 740 * t;
    const ridge = 16 * Math.exp(-0.5 * ((latitude - ridgeLatitude) / 10) ** 2);
    const tradeWindRamp = 5 * smoothstep((latitude - 3) / 22);
    // The barotropic wave component is shared; only thickness gradients and
    // modest vertical tilt create shear. Never multiply the entire field by 2.15.
    const polarFactor = level === 850 ? .55 : level === 200 ? 1.18 + .4 * (1 - summer) : 1;
    const ridgeFactor = level === 850 ? .85 : level === 200 ? 1.08 : 1;
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5790;
    return { height: datum - polarDrop * polarFactor + (ridge + tradeWindRamp) * ridgeFactor + disturbance, ridgeLatitude, jetLatitude, shortWave, displacement };
}

function interpolateProfile(profile, latitude) {
    if (!Array.isArray(profile) || profile.length === 0) return 0;
    const position = clamp(latitude / .25, 0, profile.length - 1);
    const lower = Math.floor(position);
    const upper = Math.min(profile.length - 1, lower + 1);
    const fraction = position - lower;
    return profile[lower] + (profile[upper] - profile[lower]) * fraction;
}

function zonalWindProfile(latitude, summer, level, circulation = null) {
    const radians = Math.PI / 180;
    // The subtropical jet sits poleward of the ridge core.  Placing this axis
    // three degrees too far equatorward makes the 20–25N steering vector flip
    // eastward almost simultaneously for every storm.  Its meridional width
    // must also remain close to a jet-scale feature: a broad Gaussian tail
    // otherwise fills the 25–35N ridge belt with spurious zonal flow.
    const jetLatitude = circulation?.jetLatitude ?? (39 + 8 * summer);
    const jetWidth = 9 + 1.5 * summer;
    const jetMaximum = (17 - 3 * summer) * (circulation?.jetStrength ?? 1);
    // The tropical easterly basic state extends well poleward of the
    // equatorial belt.  Letting it vanish by 20N makes the first few degrees
    // of every track depend on whichever random wave happens to be nearby.
    // The subtropical westerlies then take over gradually, rather than at a
    // sharp synthetic boundary.
    const tradeEasterly = -8.0 * (circulation?.tradeStrength ?? 1)
        * (1 - smoothstep((latitude - 4) / 42));
    // The first term is only the weak flow around the ridge belt.  The
    // stronger westerly acceleration belongs closer to the jet entrance and
    // should not turn every 25–30N disturbance into a flat eastward runner.
    const subtropicalWesterly = 0.45 * smoothstep((latitude - 27) / 12)
        + 1.8 * smoothstep((latitude - 38) / 15);
    const jet = jetMaximum * Math.exp(-0.5 * ((latitude - jetLatitude) / jetWidth) ** 2);
    const polarTail = (5 - 1.5 * summer)
        * smoothstep((latitude - 45) / 14)
        * (1 - smoothstep((latitude - 76) / 11));
    const scale = level === 850 ? .58 : level === 200 ? 1.12 : 1;
    // A small minimum westerly component poleward of the jet represents the
    // climatological polar-front flow without making the whole hemisphere a
    // uniform conveyor belt.
    const polarMinimum = 2.5 * smoothstep((latitude - 50) / 18);
    return (tradeEasterly + subtropicalWesterly + jet + polarTail + polarMinimum) * scale
        * Math.max(.12, Math.cos(latitude * radians));
}

function buildZonalHeightProfiles(background) {
    const profiles = { 850: { 1: [], '-1': [] }, 500: { 1: [], '-1': [] }, 200: { 1: [], '-1': [] } };
    const stepRadians = .25 * Math.PI / 180;
    const radians = Math.PI / 180;
    const datums = { 850: 1490, 500: 5790, 200: 12320 };
    for (const hemisphere of [1, -1]) {
        const seasonalShift = Number.isFinite(background.seasonalShift)
            ? background.seasonalShift : 0;
        const circulation = monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            seasonalShift
        );
        const summer = circulation.summer;
        for (const level of [850, 500, 200]) {
            const profile = [datums[level]];
            for (let index = 1; index <= 340; index++) {
                const latitude = index * .25;
                const priorLatitude = latitude - .25;
                const f0 = 2 * EARTH_OMEGA * Math.sin(priorLatitude * radians);
                const f1 = 2 * EARTH_OMEGA * Math.sin(latitude * radians);
                const u0 = zonalWindProfile(priorLatitude, summer, level, circulation);
                const u1 = zonalWindProfile(latitude, summer, level, circulation);
                const dz = -EARTH_RADIUS_M * stepRadians * (f0 * u0 + f1 * u1) / (2 * GRAVITY);
                profile.push(profile.at(-1) + dz);
            }
            profiles[level][hemisphere] = profile;
        }
    }
    return profiles;
}

function ensureModernAtmosphericState(background) {
    if (!isModernAtmosphericBackground(background)) return false;
    if (!background.zonalProfiles
        || background.zonalProfileVersion !== ZONAL_PROFILE_VERSION) {
        background.zonalProfiles = buildZonalHeightProfiles(background);
        background.zonalProfileVersion = ZONAL_PROFILE_VERSION;
    }
    // Some early v3 snapshots may have been serialized before the wave array
    // was added. Treat them as a quiet modern atmosphere, not as a legacy one.
    if (!Array.isArray(background.waves)) background.waves = [];
    if (!Array.isArray(background.tropicalWaves)) background.tropicalWaves = [];
    return true;
}

function rossbyPhaseSpeedMS(wave) {
    const radians = Math.PI / 180;
    const latitude = clamp(Math.abs(wave.latitude), 12, 70);
    const cosLatitude = Math.max(.25, Math.cos(latitude * radians));
    const kx = wave.k / (EARTH_RADIUS_M * cosLatitude);
    const meridionalWavelength = Math.max(2500000, wave.meridionalWavelengthKm * 1000);
    const ky = Math.PI / meridionalWavelength;
    // beta is df/dy with y positive northward.  It is positive in both
    // hemispheres; changing its sign for the Southern Hemisphere would make
    // otherwise identical Rossby modes propagate eastward relative to the
    // mean flow there.
    const beta = 2 * EARTH_OMEGA * cosLatitude / EARTH_RADIUS_M;
    const dispersion = beta / Math.max(1e-14, kx * kx + ky * ky);
    return wave.meanFlowMS - dispersion;
}

function rossbyFrequencyFromSpeed(wave) {
    const radians = Math.PI / 180;
    const latitude = clamp(Math.abs(wave.latitude), 12, 70);
    const cosLatitude = Math.max(.25, Math.cos(latitude * radians));
    const degreesPerHour = wave.phaseSpeedMS * 3600 / (EARTH_RADIUS_M * cosLatitude) * 180 / Math.PI;
    // phase = k*lambda + phaseOffset; a positive phase speed therefore means
    // a decreasing phase offset, i.e. eastward propagation.
    return -wave.k * degreesPerHour * radians;
}

function modernWaveFieldComponents(lon, lat, background, level = 500, skipEquatorialBlend = false) {
    // The two hemispheric wave banks should join through an equatorial
    // transition zone. Selecting one bank with `lat < 0 ? -1 : 1` creates a
    // visible north/south seam in both contours and wind vectors.
    const equatorialWidth = 8;
    if (!skipEquatorialBlend && Math.abs(lat) < equatorialWidth) {
        const north = modernWaveFieldComponents(
            lon, equatorialWidth, background, level, true
        );
        const south = modernWaveFieldComponents(
            lon, -equatorialWidth, background, level, true
        );
        const northWeight = smoothstep((lat + equatorialWidth) / (2 * equatorialWidth));
        const blend = (southValue, northValue) =>
            southValue + (northValue - southValue) * northWeight;
        return {
            height: blend(south.height, north.height),
            ridgeLatitude: blend(south.ridgeLatitude, north.ridgeLatitude),
            jetLatitude: blend(south.jetLatitude, north.jetLatitude),
            shortWave: blend(south.shortWave, north.shortWave),
            displacement: blend(south.displacement, north.displacement),
            tropicalWave: blend(south.tropicalWave, north.tropicalWave)
        };
    }
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    const seasonalShift = Number.isFinite(background.seasonalShift)
        ? background.seasonalShift : 0;
    const circulation = monthlyCirculation(
        background.calendarMonth,
        hemisphere,
        seasonalShift
    );
    const summer = circulation.summer;
    const waves = (background.waves || []).filter(w => w.hemisphere === hemisphere);
    const baseJetLatitude = circulation.jetLatitude;
    let jetDisplacement = 0;
    let ridgeDisplacement = 0;
    for (const wave of waves) {
        if (wave.k <= 3) {
            const phase = wave.k * lon * radians + wave.phase;
            const envelope = Math.exp(-0.5 * ((latitude - wave.latitude) / Math.max(8, wave.width)) ** 2);
            jetDisplacement += (wave.axisScaleDeg || 0) * Math.cos(phase) * envelope;
            const ridgeLatitude = circulation.ridgeLatitude;
            const ridgeEnvelope = Math.exp(-0.5 * ((latitude - ridgeLatitude) / 10) ** 2);
            ridgeDisplacement += 0.45 * (wave.axisScaleDeg || 0) * Math.cos(phase) * ridgeEnvelope;
        }
    }
    jetDisplacement *= smoothstep((latitude - 18) / 20)
        * (1 - smoothstep((latitude - 76) / 11));
    // Three independent planetary modes can otherwise align into an
    // implausibly large jet excursion. Limit only the geometric displacement;
    // the underlying height field and Rossby phase evolution remain intact.
    jetDisplacement = clamp(jetDisplacement, -15, 15);
    ridgeDisplacement *= smoothstep((latitude - 10) / 12)
        * (1 - smoothstep((latitude - 42) / 12));
    ridgeDisplacement = clamp(ridgeDisplacement, -7, 7);
    const totalDisplacement = jetDisplacement + ridgeDisplacement;
    // A displaced midlatitude jet cannot translate the entire tropical
    // height profile with it.  Applying the full axis displacement at 25–30N
    // samples the jet's steep gradient where no jet exists and produces
    // unrealistically strong, nearly zonal steering there.  Couple the
    // displacement into the barotropic profile only as the storm approaches
    // the jet latitude.
    const profileDisplacementTaper = smoothstep((latitude - 28) / 12);
    const effectiveProfileDisplacement = totalDisplacement * profileDisplacementTaper;
    const profileLatitude = clamp(latitude - effectiveProfileDisplacement, 0, 85);
    const profile = background.zonalProfiles?.[level]?.[hemisphere]
        || background.zonalProfiles?.[level]?.[String(hemisphere)];
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5790;
    let height = profile ? interpolateProfile(profile, profileLatitude) : datum;
    let shortWave = 0;
    let disturbance = 0;
    for (const wave of waves) {
        const verticalPhase = level === 200
            ? wave.verticalTiltRad
            : level === 850 ? -wave.verticalTiltRad : 0;
        const phase = wave.k * lon * radians + wave.phase + verticalPhase;
        const waveLatitude = wave.latitude + .28 * effectiveProfileDisplacement;
        const envelope = Math.exp(-0.5 * ((latitude - waveLatitude) / Math.max(7, wave.width)) ** 2);
        // Midlatitude Rossby waves should not erase the tropical trade-wind
        // corridor. Their longitude gradients are the main source of
        // spurious eastward motion in synthetic tracks, so let planetary
        // waves enter only gradually through the subtropics and keep the
        // shorter baroclinic waves confined closer to the frontal zone. A
        // single taper for every wavenumber leaks too much random phase into
        // 25–35N and creates a false flat-eastward steering corridor.
        const longWaveTaper = smoothstep((latitude - 26) / 16);
        const shortWaveTaper = smoothstep((latitude - 33) / 10);
        const latitudeTaper = (wave.k <= 3 ? longWaveTaper : shortWaveTaper)
            * (1 - smoothstep((latitude - 78) / 9));
        // Keep the wave nearly barotropic.  The zonal profile supplies the
        // climatological thermal-wind shear; making the wave itself much
        // larger aloft than below creates an artificial 30N shear wall.
        const levelFactor = level === 850 ? .84 : level === 200 ? 1.08 : 1;
        const baroclinicFactor = level === 850 ? -.12 : level === 200 ? .16 : 0;
        const value = (wave.amplitude * levelFactor
            + (wave.baroclinicAmplitude || 0) * baroclinicFactor)
            * Math.cos(phase) * envelope * latitudeTaper;
        disturbance += value;
        if (wave.k >= 4) shortWave += value;
    }
    let tropicalDisturbance = 0;
    for (const wave of (background.tropicalWaves || []).filter(w => w.hemisphere === hemisphere)) {
        const phase = wave.k * lon * radians + wave.phase
            + (level === 200 ? .06 : level === 850 ? -.04 : 0);
        const envelope = Math.exp(-0.5 * ((latitude - wave.latitude)
            / Math.max(4.5, wave.width)) ** 2);
        const levelFactor = level === 850 ? .78 : level === 200 ? 1.08 : 1;
        tropicalDisturbance += wave.amplitude * levelFactor
            * Math.cos(phase) * envelope;
    }
    // Independent random modes can otherwise constructively interfere into a
    // height gradient much stronger than a planetary wave.  Bound the total
    // finite-amplitude anomaly in the field itself; this is a reduced-order
    // QG closure, not a cosmetic clamp applied only to the plotted contours.
    height += 72 * Math.tanh(disturbance / 72);
    height += 48 * Math.tanh(tropicalDisturbance / 48);
    return {
        height,
        ridgeLatitude: hemisphere * (circulation.ridgeLatitude + .35 * totalDisplacement),
        jetLatitude: hemisphere * (baseJetLatitude + jetDisplacement),
        shortWave,
        displacement: totalDisplacement,
        tropicalWave: tropicalDisturbance
    };
}

// A reduced-order quasi-geostrophic field. The prognostic state consists of
// zonal height profiles, dispersive Rossby-wave modes and a weak transient
// synoptic component. All three native levels are derived from that same
// state, rather than being independent pressure ellipses.
function waveFieldComponents(lon, lat, background, level = 500) {
    if (isModernAtmosphericBackground(background)) {
        return modernWaveFieldComponents(lon, lat, background, level);
    }
    return legacyWaveFieldComponents(lon, lat, background, level);
}

// Per-atmosphere RNG: rendering is pure and forecast clones cannot consume the
// live atmosphere's random sequence. Its state is included in every snapshot.
function synopticRandom(state) {
    state.rng = (Math.imul(state.rng,1664525)+1013904223) >>> 0;
    return state.rng / 4294967296;
}
function synopticNormal(state) {
    return Math.sqrt(-2*Math.log(Math.max(1e-9,synopticRandom(state))))
        * Math.cos(2*Math.PI*synopticRandom(state));
}
function createColdLow(state, background, hemisphere, initial = false) {
    const summer=monthlyCirculation(
        background.calendarMonth,
        hemisphere,
        background.seasonalShift
    ).summer;
    const sector=synopticRandom(state)<.65 ? state.sector : (synopticRandom(state)<.5?170:310);
    // These are weak synoptic/short-wave height lows, not a second set of
    // major pressure centers.  A 24–96 h lifetime and 24–38 m 500-hPa
    // amplitude is enough for a small closed contour or trough kink without
    // making the background field as busy as a chart analysis.
    const life=24+72*synopticRandom(state);
    return { lon:normalizeLongitude(sector+(synopticRandom(state)-.5)*55),
        lat:hemisphere*(18+20*synopticRandom(state)), radius:4+2*synopticRandom(state),
        amplitude:24+14*synopticRandom(state), age:initial?life*.25:0, life,
        driftU:-.7-1.1*synopticRandom(state), driftV:(synopticRandom(state)-.5)*.5,
        summer };
}
function createTropicalDisturbance(state, background, hemisphere, initial = false) {
    const summer = monthlyCirculation(
        background.calendarMonth,
        hemisphere,
        background.seasonalShift
    ).summer;
    const sector = state.sector + (synopticRandom(state) - .5) * 90;
    // These represent easterly-wave troughs, monsoon gyres and weak tropical
    // depressions that are too small/short-lived to be explicit pressure
    // centres.  Most are troughs; a minority are weak ridging pulses.  The
    // finite lifetime is important: the low-shear corridor must migrate and
    // decay instead of becoming a permanent basin-wide template.
    const life = 66 + 126 * synopticRandom(state);
    const amplitude = 10 + 13 * synopticRandom(state)
        + 4 * summer * synopticRandom(state);
    const isRidgePulse = synopticRandom(state) < .18;
    return {
        lon: normalizeLongitude(sector),
        lat: hemisphere * (8 + 12 * summer + (synopticRandom(state) - .5) * 7),
        radiusLon: 8 + 6 * synopticRandom(state),
        radiusLat: 4.5 + 3 * synopticRandom(state),
        amplitude: isRidgePulse ? -amplitude * (.45 + .25 * synopticRandom(state)) : amplitude,
        age: initial ? life * (.12 + .24 * synopticRandom(state)) : 0,
        life,
        driftU: -.12 - .20 * synopticRandom(state),
        driftV: (synopticRandom(state) - .5) * .06,
        tilt: (synopticRandom(state) - .5) * 10,
        summer
    };
}
function frontalGenesisLongitude(state, background, hemisphere) {
    const waves = (background.waves || [])
        .filter(wave => wave.hemisphere === hemisphere && wave.k <= 3);
    const waveSignal = waves.reduce((sum, wave) => sum
        + .22 * Math.sin(wave.phase + wave.k * state.sector * Math.PI / 180), 0);
    // Genesis is tied to the slowly varying jet-wave phase, but remains a
    // precursor in the same broad basin rather than appearing at an arbitrary
    // longitude every time a previous low expires.
    return normalizeLongitude(
        state.sector + 32 * Math.sin((background.elapsedHours || 0) / 84 + (state.frontalGenesisPhase ?? 0))
            + 22 * waveSignal
    );
}

function createFrontalLow(state, background, hemisphere, initial = false) {
    const circulation = monthlyCirculation(
        background.calendarMonth,
        hemisphere,
        background.seasonalShift
    );
    const summer = circulation.summer;
    // The subtropical/front-zone track migrates poleward in the local winter
    // and equatorward in the local summer. It is deliberately distinct from
    // the polar jet latitude used by the steering profile: these are weak
    // baroclinic lows embedded in the subtropical jet entrance/exit region.
    const frontLatitude = 35 + 8 * (1 - summer);
    const life = 126 + 126 * synopticRandom(state);
    const peakAmplitude = 30 + 24 * synopticRandom(state);
    const growthHours = 30 + 24 * synopticRandom(state);
    const decayHours = 42 + 30 * synopticRandom(state);
    const age = initial ? life * (.08 + .20 * synopticRandom(state)) : 0;
    const baseDriftU = 3.5 + 5.5 * synopticRandom(state);
    const baseDriftV = (synopticRandom(state) - .5) * .10;
    const baseTilt = (2 * synopticRandom(state) - 1) * 9;
    return {
        lon: normalizeLongitude(frontalGenesisLongitude(state, background, hemisphere)
            + (initial ? (synopticRandom(state) - .5) * 28 : (synopticRandom(state) - .5) * 10)),
        lat: hemisphere * clamp(
            frontLatitude + (synopticRandom(state) - .5) * 8,
            25,
            55
        ),
        radiusLon: 6 + 5 * synopticRandom(state),
        radiusLat: 4 + 3 * synopticRandom(state),
        amplitude: peakAmplitude,
        peakAmplitude,
        age,
        life,
        growthHours,
        decayHours,
        baseDriftU,
        baseDriftV,
        driftU: baseDriftU,
        driftV: baseDriftV,
        baseTilt,
        tilt: baseTilt,
        development: initial ? .28 + .20 * synopticRandom(state) : .01,
        // A newly spawned low is a weak precursor. It is present in the
        // prognostic state immediately, but has no chart-scale closed low
        // yet; the field signal grows continuously from this value.
        fieldEnvelope: initial ? .12 + .25 * synopticRandom(state) : .008,
        fadeHours: 0,
        cutoff: 0,
        phase: 'incipient',
        summer
    };
}
function initializeSynopticField(background, cells, cyclone) {
    const state={rng:(Math.floor(background.waves[0].phase/Math.PI/2*4294967296)>>>0)||1,
        sector:({WPAC:160,EPAC:240,NATL:310,NIO:85,SIO:85,SHEM:170,SATL:340})[cyclone.basin]||160,
        modes:[],baroclinicModes:[],coldLows:[],tropicalDisturbances:[],frontalLows:[],
        frontalGenesisPhase:0,births:0,expired:0};
    state.frontalGenesisPhase = 2 * Math.PI * synopticRandom(state);
    // A few metres of coherent height texture represent unresolved short
    // waves/fronts.  Keep the perturbation bounded so it adds structure to
    // the contours without competing with the planetary field.
    for(let i=0;i<8;i++) state.modes.push({kx:8+Math.floor(14*synopticRandom(state)),
        ky:6+Math.floor(12*synopticRandom(state)),phaseX:2*Math.PI*synopticRandom(state),
        phaseY:2*Math.PI*synopticRandom(state),amplitude:clamp(4.5*synopticNormal(state),-9,9),
        phaseSpeed:(synopticRandom(state)-.5)*.045});
    for(const hemisphere of [1,-1]) {
        const summer=monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        if(synopticRandom(state)<.55+.30*summer){state.coldLows.push(createColdLow(state,background,hemisphere,true));state.births++;}
        // Keep one or two weak, finite-lived tropical disturbances active in
        // each hemisphere.  Their vertically tilted height signal supplies
        // realistic low-shear windows and faint low/trough contours without
        // turning the whole field into a collection of named systems.
        const disturbanceCount = summer > .55 ? 2 : 1;
        for (let i = 0; i < disturbanceCount; i++) {
            state.tropicalDisturbances.push(
                createTropicalDisturbance(state, background, hemisphere, true)
            );
            state.births++;
        }
        // Keep a small number of baroclinic lows near the subtropical jet
        // zone. They are not additional TCs: they are finite-lived trough
        // disturbances that make the MSLP field and the jet corridor evolve
        // together, especially poleward of the tropical genesis belt.
        // The winter westerly belt contains several weak baroclinic waves at
        // once; keep fewer in summer so the tropical field does not become a
        // catalogue of unrelated midlatitude lows.
        const frontalCount = summer < .30 ? 3 : summer < .65 ? 2 : 1;
        for (let i = 0; i < frontalCount; i++) {
            state.frontalLows.push(createFrontalLow(state, background, hemisphere, true));
            state.births++;
        }
        // Low-latitude monsoon outflow and nearby troughs are not captured by
        // a purely barotropic perturbation.  These broad, slowly propagating
        // modes are oppositely signed at 200 and 850 hPa, with little signal
        // at 500 hPa, so they create moving high- and low-shear corridors
        // instead of making one longitude permanently hostile.
        // A single pair of broad modes mostly changes the magnitude of the
        // background shear, and its vector magnitude is biased upward after
        // footprint averaging. Use several weaker, phase-independent tropical
        // disturbances so a real low-shear corridor can form when their
        // vertical tilt temporarily offsets the climatological shear.
        for (let i = 0; i < 5; i++) {
            const amplitude = 18 + 10 * synopticRandom(state);
            state.baroclinicModes.push({
                hemisphere,
                k: 1 + Math.floor(3 * synopticRandom(state)),
                phase: 2 * Math.PI * synopticRandom(state),
                phaseSpeed: (synopticRandom(state) - .5) * .018,
                latitude: hemisphere * (10 + 15 * synopticRandom(state)),
                width: 7 + 5 * synopticRandom(state),
                amplitude,
                baseAmplitude: amplitude
            });
        }
    }
    for(const cell of cells.filter(c=>c.role==='ridge')) {
        cell.synopticAnchor={x:cell.x,y:cell.y,dx:0,dy:0,amplitude:0};
    }
    background.synoptic=state;
}
function transientHeight(lon,lat,background,level) {
    const state=background.synoptic;
    if(!state)return 0;
    const radians=Math.PI/180;
    let height=0;
    // Spatially coherent, temporally correlated weather noise, shared by all
    // levels so restoring track variability does not inflate deep-layer shear.
    const taper=Math.exp(-Math.pow(lat/55,4));
    for(const mode of state.modes) height+=mode.amplitude
        * Math.cos(mode.kx*lon*radians+mode.phaseX)
        * Math.cos(mode.ky*lat*radians+mode.phaseY)*taper;
    for(const low of state.coldLows) {
        const envelope=Math.sin(Math.PI*clamp(low.age/low.life,0,1))**2;
        const tilt=level===200?1:level===850?-.5:0;
        const dx=normalizeLongitude(lon-low.lon+tilt)*Math.cos(low.lat*radians);
        const dy=lat-low.lat;
        const vertical=level===200?1.05:level===850?.28:1;
        height-=low.amplitude*vertical*envelope*Math.exp(-.5*((dx/low.radius)**2+(dy/low.radius)**2));
    }
    return height;
}

function transientBaroclinicHeight(lon, lat, background, level) {
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.baroclinicModes) || level === 500) return 0;
    const radians = Math.PI / 180;
    const hemisphere = lat < 0 ? -1 : 1;
    const latitude = Math.abs(lat);
    const tropicalEnvelope = smoothstep((latitude - 5) / 7)
        * (1 - smoothstep((latitude - 34) / 10));
    if (tropicalEnvelope <= 0) return 0;
    const verticalSign = level === 200 ? 1 : level === 850 ? -0.72 : 0;
    const height = state.baroclinicModes
        .filter(mode => mode.hemisphere === hemisphere)
        .reduce((sum, mode) => {
            const phase = mode.k * lon * radians + mode.phase;
            const envelope = Math.exp(-0.5 * ((latitude - Math.abs(mode.latitude)) / mode.width) ** 2);
            return sum + mode.amplitude * verticalSign * Math.cos(phase) * envelope * tropicalEnvelope;
        }, 0);
    // Several independent modes can otherwise construct an unrealistically
    // deep composite anomaly when they align. Preserve their gradients and
    // phase relationships, but keep the finite-amplitude QG closure bounded.
    return 70 * Math.tanh(height / 70);
}

function transientTropicalDisturbanceHeight(lon, lat, background, level) {
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.tropicalDisturbances)) return 0;
    const radians = Math.PI / 180;
    let height = 0;
    for (const disturbance of state.tropicalDisturbances) {
        const envelope = Math.sin(
            Math.PI * clamp(disturbance.age / Math.max(1, disturbance.life), 0, 1)
        ) ** 2;
        if (envelope <= 0) continue;
        const vertical = level === 850 ? .92 : level === 200 ? -.56 : .48;
        // A tropical disturbance is normally a lower/mid-tropospheric trough
        // with weak upper divergence/outflow.  The sign reversal aloft is
        // intentionally modest: it varies shear direction without creating a
        // synthetic hurricane anticyclone around every weak wave.
        const centerLon = normalizeLongitude(
            disturbance.lon + (level === 200 ? disturbance.tilt : 0)
        );
        const dx = normalizeLongitude(lon - centerLon)
            * Math.cos(disturbance.lat * radians);
        const dy = lat - disturbance.lat;
        const gaussian = Math.exp(-.5 * (
            (dx / disturbance.radiusLon) ** 2
            + (dy / disturbance.radiusLat) ** 2
        ));
        height -= disturbance.amplitude * vertical * envelope * gaussian;
    }
    return 42 * Math.tanh(height / 42);
}

function frontalLifecycleEnvelope(low) {
    if (Number.isFinite(low.fieldEnvelope)) return clamp(low.fieldEnvelope, 0, 1);
    // Compatibility path for saved/hand-authored fields created before the
    // stateful frontal lifecycle existed.
    const age = Math.max(0, low.age || 0);
    const life = Math.max(1, low.life || 1);
    return Math.sin(Math.PI * clamp(age / life, 0, 1)) ** 2;
}

function frontalBaroclinicSupport(low, background) {
    const local = waveFieldComponents(low.lon, low.lat, background);
    const latitude = Math.abs(low.lat);
    const jetDistance = Math.abs(latitude - Math.abs(local.jetLatitude));
    const jetEnvelope = Math.exp(-.5 * (jetDistance / 8) ** 2);
    const shortWaveSupport = .55 + .45 * smoothstep((Math.abs(local.shortWave) - 6) / 22);
    return clamp(jetEnvelope * shortWaveSupport, 0, 1);
}

function frontalColdSurgeInteraction(low, systems, summer) {
    if (low.lat <= 0 || summer > .55) {
        return { upstream: 0, blocking: 0 };
    }
    let upstream = 0;
    let blocking = 0;
    for (const surge of systems?.lower || []) {
        if (!surge.isColdSurge || !Number.isFinite(surge.x) || !Number.isFinite(surge.y)) continue;
        const downstreamDistance = normalizeLongitude(low.lon - surge.x);
        const crossFront = Math.exp(-.5 * ((low.lat - surge.y) / 10) ** 2);
        const strength = clamp((surge.strength || 0) / 24, 0, 1);
        // A cold high arriving upstream initially sharpens the baroclinic
        // zone. Once its wedge reaches the low, the same ridge turns the
        // trough more meridionally and cuts off development.
        const developmentOverlap = Math.exp(-.5 * ((downstreamDistance - 34) / 24) ** 2);
        const blockingOverlap = Math.exp(-.5 * ((downstreamDistance - 9) / 15) ** 2);
        upstream = Math.max(upstream, crossFront * strength * developmentOverlap);
        blocking = Math.max(blocking, crossFront * strength * blockingOverlap);
    }
    return { upstream, blocking };
}

function transientFrontalLowHeight(lon, lat, background, level) {
    const state = background?.synoptic;
    if (!state || !Array.isArray(state.frontalLows)) return 0;
    const radians = Math.PI / 180;
    let height = 0;
    for (const low of state.frontalLows) {
        const envelope = frontalLifecycleEnvelope(low);
        if (envelope <= 0) continue;
        // A frontal cyclone is cyclonic through the middle troposphere and
        // usually tilts downstream with height. Its 200-hPa signature is
        // weaker than the 500-hPa trough, unlike a mature tropical warm core.
        const vertical = level === 850 ? .50 : level === 200 ? .68 : 1;
        const centerLon = normalizeLongitude(
            low.lon + (level === 200 ? low.tilt : 0)
        );
        const dx = normalizeLongitude(lon - centerLon)
            * Math.cos(low.lat * radians);
        const dy = lat - low.lat;
        const gaussian = Math.exp(-.5 * (
            (dx / low.radiusLon) ** 2 + (dy / low.radiusLat) ** 2
        ));
        height -= low.amplitude * vertical * envelope * gaussian;
    }
    return 52 * Math.tanh(height / 52);
}

function transientSurfacePressureAnomaly(lon, lat, background) {
    const state = background?.synoptic;
    if (!state) return 0;
    const radians = Math.PI / 180;
    let pressure = 0;
    const gaussianAt = feature => {
        const dx = normalizeLongitude(lon - feature.lon)
            * Math.cos(feature.lat * radians);
        const dy = lat - feature.lat;
        return Math.exp(-.5 * (
            (dx / (feature.radiusLon || feature.radius || 8)) ** 2
            + (dy / (feature.radiusLat || feature.radius || 6)) ** 2
        ));
    };
    for (const low of state.frontalLows || []) {
        const envelope = frontalLifecycleEnvelope(low);
        pressure -= .075 * low.amplitude * envelope * gaussianAt(low);
    }
    for (const disturbance of state.tropicalDisturbances || []) {
        const envelope = Math.sin(Math.PI * clamp(
            disturbance.age / Math.max(1, disturbance.life), 0, 1
        )) ** 2;
        // Ridge pulses have negative amplitude and therefore add pressure.
        pressure -= .065 * disturbance.amplitude * envelope * gaussianAt(disturbance);
    }
    for (const low of state.coldLows || []) {
        const envelope = Math.sin(Math.PI * clamp(low.age / Math.max(1, low.life), 0, 1)) ** 2;
        pressure -= .035 * low.amplitude * envelope * gaussianAt(low);
    }
    return clamp(pressure, -7, 4);
}

function advanceSynopticField(systems,background) {
    const state=background.synoptic;
    const rho=Math.exp(-MODEL_STEP_HOURS/18);
    for(const mode of state.modes) {
        mode.amplitude=clamp(rho*mode.amplitude+4.5*Math.sqrt(1-rho*rho)*synopticNormal(state),-9,9);
        mode.phaseX+=mode.phaseSpeed*MODEL_STEP_HOURS;
    }
    for (const mode of state.baroclinicModes || []) {
        const modeRho = Math.exp(-MODEL_STEP_HOURS / 36);
        mode.amplitude = clamp(
            modeRho * mode.amplitude
                + 8 * Math.sqrt(1 - modeRho * modeRho) * synopticNormal(state),
            -32,
            32
        );
        mode.phase += mode.phaseSpeed * MODEL_STEP_HOURS;
        mode.latitude += mode.hemisphere * .015 * Math.sin(
            background.elapsedHours / 60 + mode.phase
        );
    }
    for(const cell of systems.upper.filter(c=>c.synopticAnchor)) {
        const anchor=cell.synopticAnchor;
        const oldX=cell.x,oldY=cell.y;
        const retention=Math.exp(-MODEL_STEP_HOURS/48),innovation=Math.sqrt(1-retention*retention);
        anchor.dx=clamp(retention*anchor.dx+3*innovation*synopticNormal(state),-7,7);
        anchor.dy=clamp(retention*anchor.dy+1.4*innovation*synopticNormal(state),-3.5,3.5);
        anchor.amplitude=clamp(retention*anchor.amplitude+innovation*synopticNormal(state),-2,2);
        const targetX=anchor.x+(cell.velocityX||0)*background.elapsedHours/MODEL_STEP_HOURS+anchor.dx;
        cell.x=normalizeLongitude(cell.x+.22*normalizeLongitude(targetX-cell.x));
        cell.y+=.22*(anchor.y+anchor.dy-cell.y);
        const priorStrength=cell.strength;
        cell.strength+=.15*(cell.baseStrength*(1+.18*anchor.amplitude)-cell.strength);
        const lower=systems.lower?.find(c=>c.fieldId===cell.fieldId);
        if(lower){lower.x+=normalizeLongitude(cell.x-oldX);lower.y+=cell.y-oldY;
            lower.strength*=cell.strength/Math.max(.1,priorStrength);}
    }
    for(const low of state.coldLows) {
        const wind=gradientWind(low.lon,low.lat,(x,y)=>waveFieldComponents(x,y,background).height,9.80665);
        const u=.3*wind.u+low.driftU,v=.3*wind.v+low.driftV;
        low.lon=normalizeLongitude(low.lon+u*MODEL_STEP_HOURS*3600/(111320*Math.max(.3,Math.cos(low.lat*Math.PI/180))));
        low.lat=clamp(low.lat+v*MODEL_STEP_HOURS*3600/111320,-65,65);
        low.age+=MODEL_STEP_HOURS;
    }
    const before=state.coldLows.length;
    state.coldLows=state.coldLows.filter(low=>low.age<low.life);
    state.expired+=before-state.coldLows.length;
    for (const disturbance of state.tropicalDisturbances || []) {
        const radians = Math.PI / 180;
        disturbance.lon = normalizeLongitude(
            disturbance.lon + disturbance.driftU * MODEL_STEP_HOURS * 3600
                / (111320 * Math.max(.3, Math.cos(disturbance.lat * radians)))
        );
        disturbance.lat = clamp(
            disturbance.lat + disturbance.driftV * MODEL_STEP_HOURS * 3600 / 111320,
            -35,
            35
        );
        disturbance.age += MODEL_STEP_HOURS;
    }
    const disturbanceBefore = (state.tropicalDisturbances || []).length;
    state.tropicalDisturbances = (state.tropicalDisturbances || [])
        .filter(disturbance => disturbance.age < disturbance.life);
    state.expired += disturbanceBefore - state.tropicalDisturbances.length;
    for (const low of state.frontalLows || []) {
        const hemisphere = low.lat < 0 ? -1 : 1;
        low.summer = monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        const interaction = frontalColdSurgeInteraction(low, systems, low.summer);
        const jetSupport = frontalBaroclinicSupport(low, background);
        const age = Math.max(0, low.age || 0);
        const life = Math.max(1, low.life || 1);
        const growthHours = Math.max(18, low.growthHours || 42);
        const decayHours = Math.max(24, low.decayHours || 54);
        const decayStart = Math.max(growthHours + 18, life - decayHours);
        const growth = smoothstep(age / growthHours);
        const decay = 1 - smoothstep((age - decayStart) / decayHours);
        const nominalEnvelope = growth * decay;
        const targetEnvelope = clamp(
            nominalEnvelope
                * (.72 + .34 * jetSupport + .18 * interaction.upstream)
                * (1 - .78 * interaction.blocking),
            0,
            1
        );
        const envelopeResponse = 1 - Math.exp(-MODEL_STEP_HOURS / 18);
        low.fieldEnvelope = clamp(
            (Number.isFinite(low.fieldEnvelope) ? low.fieldEnvelope : nominalEnvelope)
                + (targetEnvelope - (Number.isFinite(low.fieldEnvelope) ? low.fieldEnvelope : nominalEnvelope))
                    * envelopeResponse,
            0,
            1
        );
        const developmentTarget = clamp(
            .45 * jetSupport + .32 * interaction.upstream
                + .35 * nominalEnvelope - .68 * interaction.blocking,
            0,
            1
        );
        low.development = clamp(
            (Number.isFinite(low.development) ? low.development : nominalEnvelope)
                + (developmentTarget - (Number.isFinite(low.development) ? low.development : nominalEnvelope))
                    * (1 - Math.exp(-MODEL_STEP_HOURS / 24)),
            0,
            1
        );
        low.cutoff = clamp(
            (low.cutoff || 0)
                + (interaction.blocking - (low.cutoff || 0))
                    * (1 - Math.exp(-MODEL_STEP_HOURS / 12)),
            0,
            1
        );
        low.phase = low.cutoff > .52
            ? 'cutoff'
            : low.fieldEnvelope < .10 && age >= growthHours
                ? 'decaying'
                : low.fieldEnvelope < .10
                    ? 'precursor'
                : age < growthHours
                    ? 'incipient'
                    : 'developing';
        low.tilt = (low.baseTilt || 0) + (low.lat < 0 ? -1 : 1) * 8 * low.cutoff;
        low.driftU = (low.baseDriftU || low.driftU || 0) * (1 - .34 * low.cutoff);
        low.driftV = (low.baseDriftV || low.driftV || 0)
            + (low.lat < 0 ? -1 : 1) * .38 * low.cutoff;
        low.fadeHours = low.fieldEnvelope < .025 ? (low.fadeHours || 0) + MODEL_STEP_HOURS : 0;
        const wind = gradientWind(
            low.lon,
            low.lat,
            (x, y) => waveFieldComponents(x, y, background).height,
            9.80665
        );
        const u = .25 * wind.u + low.driftU;
        const v = .25 * wind.v + low.driftV;
        low.lon = normalizeLongitude(
            low.lon + u * MODEL_STEP_HOURS * 3600
                / (111320 * Math.max(.3, Math.cos(low.lat * Math.PI / 180)))
        );
        low.lat = clamp(
            low.lat + v * MODEL_STEP_HOURS * 3600 / 111320,
            -65,
            65
        );
        low.age += MODEL_STEP_HOURS;
    }
    const frontalBefore = (state.frontalLows || []).length;
    state.frontalLows = (state.frontalLows || [])
        .filter(low => !(low.age >= low.life
            && (low.fadeHours || 0) >= 12
            && frontalLifecycleEnvelope(low) < .025));
    state.expired += frontalBefore - state.frontalLows.length;
    for(const hemisphere of [1,-1]) {
        const summer=monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift
        ).summer;
        const count=state.coldLows.filter(low=>Math.sign(low.lat)===hemisphere).length;
        if(state.coldLows.length<4&&count<2&&synopticRandom(state)<1-Math.exp(-MODEL_STEP_HOURS/(180-60*summer))){
            state.coldLows.push(createColdLow(state,background,hemisphere));state.births++;
        }
        const disturbanceCount = state.tropicalDisturbances
            .filter(disturbance => Math.sign(disturbance.lat) === hemisphere).length;
        const targetCount = summer > .55 ? 2 : 1;
        if (disturbanceCount < targetCount
            && synopticRandom(state) < 1 - Math.exp(-MODEL_STEP_HOURS / (42 - 12 * summer))) {
            state.tropicalDisturbances.push(
                createTropicalDisturbance(state, background, hemisphere)
            );
            state.births++;
        }
        const frontalCount = state.frontalLows
            .filter(low => Math.sign(low.lat) === hemisphere).length;
        const activeFrontalCount = state.frontalLows
            .filter(low => Math.sign(low.lat) === hemisphere
                && low.age < low.life
                && low.phase !== 'decaying'
                && frontalLifecycleEnvelope(low) >= .06).length;
        const frontalTarget = summer < .30 ? 3 : summer < .65 ? 2 : 1;
        // Start a weak precursor before the previous low is removed. This
        // keeps the jet corridor populated during decay and prevents the next
        // cyclone from popping into existence at the exact deletion step.
        if (activeFrontalCount < frontalTarget
            && frontalCount < frontalTarget + 1
            && synopticRandom(state) < 1 - Math.exp(-MODEL_STEP_HOURS / (54 - 15 * summer))) {
            state.frontalLows.push(createFrontalLow(state, background, hemisphere));
            state.births++;
        }
    }
}

function normalizedCellDistance(lon, lat, cell) {
    const radians = Math.PI / 180;
    const meanLatitude = (lat + cell.y) * .5;
    const dxKm = normalizeLongitude(lon - cell.x) * 111.32 * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - cell.y) * 111.32;
    const sxKm = Math.max(90, (cell.sigmaX || cell.baseSigmaX || 20) * 111.32
        * Math.max(.20, Math.cos(cell.y * radians)));
    const syKm = Math.max(90, (cell.sigmaY || 12) * 111.32);
    return Math.hypot(dxKm / sxKm, dyKm / syKm);
}

function coldSurgeFieldEnvelope(cell) {
    if (!cell?.isColdSurge) return 0;
    if (Number.isFinite(cell.fieldEnvelope)) return clamp(cell.fieldEnvelope, 0, 1);
    const peak = Math.max(1, cell.peakStrength || cell.baseStrength || 20);
    return clamp(Math.max(0, cell.strength || 0) / peak, 0, 1);
}

// A Siberian cold high is a continental air-mass source.  Once its centre
// has travelled east over the marginal seas, the shallow ridge should lose
// amplitude through marine mixing; the detached upper trough can outlive it,
// but the 850-hPa pressure gradient must not remain a continent-sized wall.
// Track this from the source longitude rather than from a TC position so the
// decay is an atmospheric property and does not alter cyclone attributes.
function coldSurgeMarineFactor(cell) {
    if (!cell?.isColdSurge) return 1;
    const sourceX = Number.isFinite(cell.sourceX) ? cell.sourceX : cell.x;
    const eastwardTravel = Math.max(0, normalizeLongitude(cell.x - sourceX));
    const marineTransition = smoothstep((eastwardTravel - 7) / 13);
    const residence = smoothstep(((cell.ageHours || 0) - 48) / 96);
    return clamp(
        1 - marineTransition * (.50 + .20 * residence),
        .35,
        1
    );
}

function coldSurgeWedgeGaussian(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const hemisphere = cell.y < 0 ? -1 : 1;
    // The cold air does not remain a circular blob over Mongolia. Its
    // equatorward/eastward wedge reaches the downstream coast and ocean,
    // where it modifies the low-level ridge, SST and TC structure.
    const centerLon = normalizeLongitude(cell.x + 9);
    // The equatorward plume digs farther south as the continental high
    // matures; keeping it fixed near the source latitude leaves the SCS on
    // its weak-gradient fringe instead of in the cold-surge flow.
    const centerLat = cell.y - hemisphere * (7 + 4 * coldSurgeFieldEnvelope(cell));
    const radians = Math.PI / 180;
    const meanLatitude = (lat + centerLat) * .5;
    const dxKm = normalizeLongitude(lon - centerLon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - centerLat) * 111.32;
    // The low-level ridge plume must carry equatorward flow on its coastal
    // flank.  The former southeast-tilted ellipse put the SCS on the wrong
    // pressure-gradient side and often produced a northward low-level wind.
    // Mirror the ridge/trough tilt by hemisphere, with modest event-to-event
    // spread supplied when the surge is created.
    const tiltDegrees = Number.isFinite(cell.wedgeTiltDeg)
        ? cell.wedgeTiltDeg
        : 18;
    const tilt = hemisphere * tiltDegrees * radians;
    const alongKm = dxKm * Math.cos(tilt) + dyKm * Math.sin(tilt);
    const crossKm = -dxKm * Math.sin(tilt) + dyKm * Math.cos(tilt);
    // The 850-hPa cold-air tongue is broad across the front.  A narrow
    // ellipse creates a very steep height gradient at its southern edge and
    // can produce an impossible 50--60 kt reversal far from the front.
    const distance = Math.hypot(alongKm / 2100, crossKm / 1250);
    const cutoff = 1 - smoothstep((distance - 2.6) / 1.0);
    return cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
}

// A mature cold surge commonly has a weak frontal trough/low on the
// equatorward edge of the continental ridge.  It is deliberately broad and
// shallow: its purpose is to close the pressure-gradient saddle over the
// coastal seas, not to create a second TC-like vortex.
function coldSurgeFrontalLowGaussian(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const envelope = coldSurgeFieldEnvelope(cell);
    const frontalEnvelope = smoothstep((envelope - .08) / .30);
    if (frontalEnvelope <= 0) return 0;
    const hemisphere = cell.y < 0 ? -1 : 1;
    const centerLon = normalizeLongitude(cell.x + 12);
    const centerLat = cell.y - hemisphere * (17 + 3 * envelope);
    const radians = Math.PI / 180;
    const meanLatitude = (lat + centerLat) * .5;
    const dxKm = normalizeLongitude(lon - centerLon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - centerLat) * 111.32;
    // A cold-surge frontal trough is elongated along the subtropical jet and
    // narrow across it.  Keep the along-front tail finite: an infinitely
    // generous tail lets a storm outside the cold-air/front interaction zone
    // feel the same meridional pressure gradient as a directly affected TC.
    const distance = Math.hypot(dxKm / 3600, dyKm / 700);
    // The taper begins before the far-field Gaussian tail becomes dynamically
    // important.  It is C1-smooth, so the trough still grows/decays normally
    // while its remote ends no longer bend unrelated tracks southward.
    const cutoff = 1 - smoothstep((distance - 1.72) / .70);
    // The frontal low is coupled to the same cold-air reach as the surface
    // ridge.  Without this second, local gate, its free-tropospheric-looking
    // tail can steer a TC that is still outside the cold-surge corridor,
    // which is precisely the failure mode this feature is meant to avoid.
    const broadSurface = {
        ...cell,
        sigmaX: Math.max(24, (cell.sigmaX || cell.baseSigmaX || 16) * 1.65),
        sigmaY: Math.max(14, (cell.sigmaY || cell.baseSigmaY || 11) * 1.35)
    };
    const directCore = Math.exp(-0.5 * normalizedCellDistance(
        lon, lat, broadSurface
    ) ** 2);
    const directWedge = coldSurgeWedgeGaussian(lon, lat, cell);
    const directCoupling = clamp(
        Math.max(.55 * directCore, directWedge),
        0,
        1
    );
    const couplingGate = smoothstep((directCoupling - .035) / .10);
    return cutoff <= 0
        ? 0
        : Math.exp(-0.5 * distance * distance)
            * cutoff * frontalEnvelope * couplingGate;
}

// The free-tropospheric response of a continental cold surge is not locked
// above the surface high. As the cold dome reaches the coast and begins to
// decay, its upper PV anomaly can amplify downstream and cut off on the
// equatorward side. Keep that displacement as state derived from the same
// cold-surge lifecycle, rather than as a TC-specific steering correction.
function coldSurgeUpperTroughState(cell) {
    if (!cell?.isColdSurge) return null;
    const age = Math.max(0, Number.isFinite(cell.ageHours) ? cell.ageHours : 0);
    const growthHours = Math.max(24, cell.growthHours || 48);
    const decayStartHours = Math.max(
        growthHours + 24,
        cell.decayStartHours || Math.max(growthHours + 24, (cell.lifeHours || 384) - (cell.decayHours || 96))
    );
    const decayHours = Math.max(48, cell.decayHours || 96);
    const upperGrowth = smoothstep(age / Math.max(24, growthHours * .82));
    // The trough outlives the surface pressure maximum. This is the
    // decaying/cut-off stage in which a Central-Asian trough can still dig
    // southward after the cold high has already weakened at the ground.
    const upperDecay = 1 - smoothstep(
        (age - (decayStartHours + 18)) / (decayHours + 54)
    );
    const envelope = clamp(upperGrowth * upperDecay, 0, 1);
    const denominator = Math.max(72, decayStartHours - growthHours * .25);
    const progress = smoothstep((age - growthHours * .35) / denominator);
    const digging = clamp(
        Number.isFinite(cell.upperTroughDigging) ? cell.upperTroughDigging : .72,
        .35,
        1.15
    );
    const hemisphere = cell.y < 0 ? -1 : 1;
    const phase = Number.isFinite(cell.upperTroughPhase) ? cell.upperTroughPhase : 0;
    const meander = Math.sin(phase + age / 54);
    const longitude = normalizeLongitude(
        // Downstream displacement is intentionally large enough for the
        // mature/decaying trough core to reach the ocean east of Japan. A
        // trough core that remains over the source high cannot steer a TC on
        // the high's downstream/equatorward side.
        // Keep the upper trough downstream of the continental high, but not
        // so far east that the SCS sits outside its southern/western flank.
        // The old displacement detached the trough from the surface surge
        // and left the coastal low-level turn without a coherent mid-level
        // counterpart.
        cell.x + 7 + (4 + 4 * digging) * progress + 2.5 * meander
    );
    const latitude = cell.y - hemisphere * (
        2.5 + (8 + 18 * digging) * progress
            + 1.8 * Math.cos(phase + age / 72)
    );
    return {
        lon: longitude,
        lat: clamp(latitude, -65, 65),
        envelope,
        progress,
        digging,
        // The East-Asian trough is a tilted baroclinic feature, not an
        // axis-aligned oval.  Its long axis slopes southwest to northeast
        // in the NH (reversed in the SH), and broadens as the cold dome
        // reaches the coast and begins to cut off.
        tiltRad: hemisphere * (12 + 10 * progress) * Math.PI / 180,
        sigmaAlongKm: 1650 + 650 * progress,
        sigmaCrossKm: 720 + 180 * progress,
        // A weakening surge leaves a narrower, more cut-off trough core.
        coreScale: .72 + .48 * progress
    };
}

function coldSurgeUpperTroughGaussian(lon, lat, trough) {
    if (!trough) return 0;
    const radians = Math.PI / 180;
    const meanLatitude = (lat + trough.lat) * .5;
    const dxKm = normalizeLongitude(lon - trough.lon) * 111.32
        * Math.max(.20, Math.cos(meanLatitude * radians));
    const dyKm = (lat - trough.lat) * 111.32;
    const tilt = Number.isFinite(trough.tiltRad) ? trough.tiltRad : 0;
    const alongKm = dxKm * Math.cos(tilt) + dyKm * Math.sin(tilt);
    const crossKm = -dxKm * Math.sin(tilt) + dyKm * Math.cos(tilt);
    const distance = Math.hypot(
        alongKm / Math.max(400, trough.sigmaAlongKm || 1800),
        crossKm / Math.max(250, trough.sigmaCrossKm || 800)
    );
    const cutoff = 1 - smoothstep((distance - 2.1) / 1.25);
    return cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
}

export function getColdSurgeImpact(cyclone, pressureSystems) {
    const result = { influence: 0, sstCooling: 0, shearBoost: 0 };
    if (!cyclone || !Array.isArray(pressureSystems?.lower)) return result;
    for (const surge of pressureSystems.lower) {
        if (!surge?.isColdSurge) continue;
        const envelope = coldSurgeFieldEnvelope(surge);
        if (envelope <= 0) continue;
        const broadSurface = {
            ...surge,
            sigmaX: Math.max(24, (surge.sigmaX || surge.baseSigmaX || 16) * 1.65),
            sigmaY: Math.max(14, (surge.sigmaY || surge.baseSigmaY || 11) * 1.35)
        };
        const core = Math.exp(-0.5 * normalizedCellDistance(
            cyclone.lon, cyclone.lat, broadSurface
        ) ** 2);
        const wedge = coldSurgeWedgeGaussian(cyclone.lon, cyclone.lat, surge);
        const exposure = clamp(Math.max(.55 * core, wedge) * envelope, 0, 1);
        const sizeFactor = clamp(.85 + .15 * ((cyclone.circulationSize || 300) / 350), .75, 1.10);
        result.influence = Math.max(result.influence, exposure);
        // A cold surge cools the ocean gradually; this is an air-sea
        // response, not an arbitrary one-step SST replacement.
        result.sstCooling = Math.max(result.sstCooling, 1.8 * exposure * sizeFactor);
        // Do not add a synthetic shear term here. The 850/500/200-hPa fields
        // now share the same cold-dome/trough structure, so the shear used by
        // the cyclone model is diagnosed from those three resolved winds.
        // Keep the legacy diagnostic at zero to make accidental double
        // counting of the cold surge impossible in older callers.
        result.shearBoost = 0;
    }
    return result;
}

function modernCellHeightAnomaly(lon, lat, cell, level) {
    if (!cell || cell.role === 'height-background' || cell.role === 'wave-handle') return 0;
    const distance = normalizedCellDistance(lon, lat, cell);
    // A synoptic anomaly is not allowed to exert a mathematically infinite
    // Gaussian tail across the hemisphere. The cosine taper is C1-smooth and
    // leaves the core unchanged through 2.25 normalized radii.
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    if (cutoff <= 0) return 0;
    const gaussian = Math.exp(-.5 * distance * distance) * cutoff;
    // The South Asian High is much more vertically top-heavy than an ordinary
    // 500-hPa ridge.  Keep the existing 500-hPa amplitude for steering, while
    // allowing the calibrated summer 200-hPa core to reach observed strong
    // cases without lifting the whole upper-air background.
    const roleScale = cell.role === 'south-asian-high'
        && level === 200
        && Number.isFinite(cell.level200AnomalyScale)
        ? cell.level200AnomalyScale
        : Number.isFinite(cell.anomalyScale)
            ? cell.anomalyScale
            : cell.role === 'ridge' && !cell.isManual ? .35 : 1;
    // The South Asian High is an upper-tropospheric anticyclone: it should
    // strongly affect deep-layer steering at 200/500 hPa, while contributing
    // little to the boundary-layer monsoon flow.  Keeping this vertical
    // structure explicit is what makes its southern flank turn a storm west
    // near 20N without creating a spurious low-level wall everywhere.
    const levelScale = cell.role === 'south-asian-high'
        ? (level === 200 ? 1.35 : level === 500 ? .55 : .15)
        : level === 850 ? .72 : level === 200 ? 1.08 : 1;
    const verticalFactor = cell.role === 'monsoon'
        ? (level === 850 ? (cell.strength < 0 ? .65 : -.65) : level === 200 ? .40 : .35)
        : 1;
    return 12 * cell.strength * roleScale * levelScale * verticalFactor * gaussian;
}

function coldSurgeUpperHeightAnomaly(lon, lat, cell, level) {
    if (!cell?.isColdSurge || level === 850) return 0;
    // A continental cold high is shallow at the surface but cold-core in the
    // free troposphere: its pressure maximum projects upward as a broad
    // trough/low-height anomaly, not as another anticyclone.  The broader
    // footprint aloft represents the cold dome spreading beyond the surface
    // centre while keeping the anomaly finite and lifecycle-continuous.
    const broadening = level === 200 ? 1.55 : 1.35;
    const footprint = {
        ...cell,
        sigmaX: (cell.sigmaX || cell.baseSigmaX || 16) * broadening,
        sigmaY: (cell.sigmaY || cell.baseSigmaY || 11) * (level === 200 ? 1.22 : 1.10)
    };
    const distance = normalizedCellDistance(lon, lat, footprint);
    const cutoff = 1 - smoothstep((distance - 2.25) / 1.25);
    // This cutoff belongs only to the broad surface-cold-dome projection. It
    // must not short-circuit the delayed upper trough, whose core is allowed
    // to detach and dig southward while the surface high is already fading.
    const gaussian = cutoff <= 0 ? 0 : Math.exp(-0.5 * distance * distance) * cutoff;
    const wedge = coldSurgeWedgeGaussian(lon, lat, cell);
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const marineFactor = coldSurgeMarineFactor(cell);
    // 500 hPa retains the main trough signal, but not the exaggerated 4.5x
    // amplification that made a mature cold high dominate a TC thousands of
    // kilometres away.  The detached upper trough is allowed to persist, but
    // its remote surface-linked part weakens as the cold high moves offshore.
    const levelScale = level === 200 ? 1.4 : 3.0;
    const upperTrough = coldSurgeUpperTroughState(cell);
    let diggingCore = 0;
    if (upperTrough?.envelope > 0) {
        diggingCore = coldSurgeUpperTroughGaussian(lon, lat, upperTrough)
            * upperTrough.envelope * upperTrough.coreScale;
    }
    const peakStrength = Math.max(
        strength,
        Number.isFinite(cell.peakStrength) ? cell.peakStrength : strength
    );
    // The surface cold dome, its downstream/equatorward streamer and the
    // delayed cut-off core are one vertical structure. The latter persists
    // after the surface high weakens, which allows late-life troughs to dig
    // from Central Asia into the mid/low latitudes without inventing an
    // unrelated pressure centre.
    const upperCore = 1.55 * peakStrength
        * (upperTrough?.envelope || 0) * diggingCore
        * (.75 + .25 * marineFactor);
    return -levelScale * (
        marineFactor * strength * (.58 * gaussian + .55 * wedge)
        + upperCore
    );
}

function coldSurgeLowerWedgeHeightAnomaly(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    // The coastal cold-surge ridge must be dynamically visible at 850 hPa;
    // otherwise the model can diagnose cooling and shear while leaving the
    // weakened vortex advected by the old tropical flow.
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const envelope = coldSurgeFieldEnvelope(cell);
    const marineFactor = coldSurgeMarineFactor(cell);
    // The wedge is a shallow 850-hPa extension, not a second synoptic-scale
    // high.  Its former amplitude generated 20--30 m/s reverse flow at the
    // far southern edge of the ellipse.  Keep the same geometry and lifecycle
    // while calibrating the pressure gradient to a realistic cold surge.
    const ridge = 12 * marineFactor * strength * envelope
        * coldSurgeWedgeGaussian(lon, lat, cell);
    const frontalLow = 10 * marineFactor * strength * envelope
        * coldSurgeFrontalLowGaussian(lon, lat, cell);
    return ridge - frontalLow;
}

function coldSurgeSurfacePressureAnomaly(lon, lat, cell) {
    if (!cell?.isColdSurge) return 0;
    const strength = Math.max(0, Number.isFinite(cell.strength) ? cell.strength : 0);
    const envelope = coldSurgeFieldEnvelope(cell);
    const marineFactor = coldSurgeMarineFactor(cell);
    return marineFactor * (
        .35 * strength * envelope * coldSurgeWedgeGaussian(lon, lat, cell)
        - .08 * strength * envelope * coldSurgeFrontalLowGaussian(lon, lat, cell)
    );
}

function createColdSurge(initial = false, random = Math.random) {
    const peakStrength = 16 + 10 * random();
    const lifeHours = 180 + 96 * random();
    const growthHours = 30 + 18 * random();
    const decayHours = 48 + 24 * random();
    const baseSigmaX = 13 + 7 * random();
    const baseSigmaY = 9 + 5 * random();
    const sourceX = 100 + 25 * random();
    return {
        type: 'high',
        role: 'cold-surge-high',
        isColdSurge: true,
        // A Siberian cold high is a broad, elongated mass anomaly, not a
        // compact 6-degree pressure dot. The initial precursor is weak and
        // broad; the ridge grows continuously into its mature footprint.
        x: sourceX,
        sourceX,
        y: 43 + 8 * random(),
        baseSigmaX,
        sigmaX: baseSigmaX,
        baseSigmaY,
        sigmaY: baseSigmaY,
        peakStrength,
        baseStrength: peakStrength,
        strength: peakStrength * (initial ? .14 + .12 * random() : .01),
        fieldEnvelope: initial ? .14 + .12 * random() : .01,
        ageHours: initial ? 18 + 48 * random() : 0,
        growthHours,
        decayStartHours: lifeHours - decayHours,
        decayHours,
        lifeHours,
        phase: initial ? 'developing' : 'precursor',
        // Degrees per three-hour model step. The low-level cold surge moves
        // east/southeast on a multi-day time scale, with a weak meander rather
        // than a fixed diagonal or an instantaneous relocation.
        velocityX: .18 + .10 * random(),
        velocityY: -.050 - .060 * random(),
        flowAdvectionWeight: .10 + .05 * random(),
        meanderPhase: 2 * Math.PI * random(),
        meanderRate: .015 + .012 * random(),
        // The upper trough digs independently of the shallow surface-high
        // centre. This is sampled once per surge, then evolves smoothly with
        // age; it is not selected from the TC track.
        upperTroughDigging: .45 + .65 * random(),
        upperTroughPhase: 2 * Math.PI * random(),
        wedgeTiltDeg: 12 + 14 * random(),
        noiseLayers: []
    };
}

export function getGeopotentialHeight500(lon, lat, systems, level = 500) {
    const upperCells = systems?.upper || [];
    const background = upperCells.find(c => c.role === 'height-background');
    const modernField = ensureModernAtmosphericState(background);
    // The native waves provide the broad 850-hPa background, while explicit
    // lower-layer cells provide trades, monsoon troughs and low-level highs.
    // Previously a native background made every 850-hPa sample iterate only
    // upperCells, silently bypassing pressureSystems.lower.
    const useExplicitLowerLayer = level === 850
        && Array.isArray(systems?.lower)
        && systems.lower.length > 0;
    const cells = useExplicitLowerLayer ? systems.lower : upperCells;
    if (background?.waves || modernField) {
        const components = waveFieldComponents(lon, lat, background, level);
        let height = components.height
            + transientHeight(lon,lat,background,level)
            + transientBaroclinicHeight(lon,lat,background,level)
            + transientTropicalDisturbanceHeight(lon,lat,background,level)
            + transientFrontalLowHeight(lon,lat,background,level);
        for (const cell of cells) {
            if (cell.role === 'height-background' || cell.role === 'wave-handle') continue;
            if (modernField) {
                height += modernCellHeightAnomaly(lon, lat, cell, level);
                continue;
            }
            const dx = normalizeLongitude(lon - cell.x);
            const hemisphere = cell.y < 0 ? -1 : 1;
            // A curved monsoon axis and a ridge extension embedded in the waves.
            const axis = cell.y + hemisphere * ((cell.role === "ridge" ? components.displacement * .65 : 0)
                + 2 * Math.sin(dx * Math.PI / 35 + (background.elapsedHours || 0) / 100));
            const dy = lat - axis;
            const sx = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20);
            const sy = Math.max(1, cell.sigmaY || 12);
            // Lower monsoon cells already carry the negative anomaly sign.
            const verticalFactor = useExplicitLowerLayer
                ? (cell.role === 'monsoon' ? 0.65 : 1)
                : cell.role === 'monsoon'
                    ? (level === 850 ? -0.65 : level === 200 ? .40 : .35)
                    : 1;
            height += 12 * cell.strength * verticalFactor
                * Math.exp(-.5 * ((dx / sx) ** 2 + (dy / sy) ** 2));
        }
        if (modernField && level !== 850) {
            for (const surge of systems?.lower || []) {
                height += coldSurgeUpperHeightAnomaly(lon, lat, surge, level);
            }
        }
        if (modernField && level === 850) {
            for (const surge of systems?.lower || []) {
                height += coldSurgeLowerWedgeHeightAnomaly(lon, lat, surge);
            }
        }
        return height;
    }
    // Retain the prior field evaluator for archived runs, without rewriting history.
    if (!background) return (level === 200 ? 12400 : 5800) + (level === 200 ? 18 : 12) * (getPressureAt(lon, lat, cells, false) - 1010);
    const t = clamp((Math.abs(lat) - 24 - (background.seasonalShift || 0) * Math.sign(lat)) / 55, 0, 1);
    let height = (level === 200 ? 12400 : 5800) - 650 * t*t*(3-2*t) * (level === 200 ? 2.15 : 1);
    for (const cell of cells) {
        if (cell.role === 'height-background') continue;
        const dx = normalizeLongitude(lon - cell.x), dy = lat - cell.y;
        const sx = Math.max(1, cell.sigmaX || cell.baseSigmaX || 20), sy = Math.max(1, cell.sigmaY || 12);
        const factor = level === 200 ? (cell.role === 'monsoon' ? .55 : cell.strength < 0 ? 1.65 : 1.15) : 1;
        height += 12 * cell.strength * factor * Math.exp(-.5*((dx/sx)**2+(dy/sy)**2));
    }
    return height;
}

function modernZonalHeightAt(background, latitude, level = 500) {
    const profileFor = hemisphere => background?.zonalProfiles?.[level]?.[hemisphere]
        || background?.zonalProfiles?.[level]?.[String(hemisphere)];
    const datum = level === 850 ? 1490 : level === 200 ? 12320 : 5790;
    const absoluteLatitude = Math.abs(latitude);
    if (absoluteLatitude < 8) {
        const south = profileFor(-1);
        const north = profileFor(1);
        const southValue = south ? interpolateProfile(south, absoluteLatitude) : datum;
        const northValue = north ? interpolateProfile(north, absoluteLatitude) : datum;
        return southValue + (northValue - southValue)
            * smoothstep((latitude + 8) / 16);
    }
    const hemisphere = latitude < 0 ? -1 : 1;
    const profile = profileFor(hemisphere);
    return profile ? interpolateProfile(profile, absoluteLatitude) : datum;
}

// Reduced-order sea-level pressure closure.  The surface field must not be a
// collection of isolated Gaussian symbols: the real MSLP pattern is a broad
// mass field shaped by the equatorial trough, subtropical ridges, subpolar
// lows, and the same synoptic height anomalies that steer the storm aloft.
// This maps the native 500-hPa height anomaly to MSLP while retaining the
// explicit lower-layer cells for monsoon troughs, ridges and cold surges.
export function getSurfacePressureAt(lon, lat, systems, options = {}) {
    const systemsObj = Array.isArray(systems) ? null : systems;
    const lower = Array.isArray(systems) ? systems : systemsObj?.lower || [];
    const background = systemsObj?.upper?.find(c => c.role === 'height-background');

    if (!background || !ensureModernAtmosphericState(background)) {
        return getPressureAt(lon, lat, lower, false);
    }

    const latitude = Math.abs(lat);
    const northernCirculation = monthlyCirculation(
        background.calendarMonth, 1, background.seasonalShift
    );
    const southernCirculation = monthlyCirculation(
        background.calendarMonth, -1, background.seasonalShift
    );
    const circulationWeight = smoothstep((lat + 8) / 16);
    const summer = southernCirculation.summer
        + (northernCirculation.summer - southernCirculation.summer) * circulationWeight;
    const ridgeLatitude = southernCirculation.ridgeLatitude
        + (northernCirculation.ridgeLatitude - southernCirculation.ridgeLatitude)
            * circulationWeight;

    // Broad climatological mass distribution.  These are deliberately modest
    // pressure anomalies; the transient field and explicit cells provide the
    // event-scale structure on top of them.
    const equatorialTrough = -2.8 * Math.exp(-0.5 * (latitude / 13) ** 2);
    const subtropicalRidge = (4.0 + 0.8 * summer)
        * Math.exp(-0.5 * ((latitude - ridgeLatitude) / 14) ** 2);
    const subpolarLow = -(3.4 - 0.7 * summer)
        * Math.exp(-0.5 * ((latitude - (58 - 2 * summer)) / 14) ** 2);
    const polarHigh = 1.4 * (1 - summer)
        * Math.exp(-0.5 * ((latitude - 76) / 11) ** 2);

    // A 500-hPa height anomaly is a compact proxy for column mass.  Removing
    // the zonal profile prevents the normal pole-to-equator height gradient
    // from becoming a fake MSLP gradient; only the synoptic/planetary anomaly
    // is mapped to the surface.
    const height = getGeopotentialHeight500(lon, lat, systems, 500);
    const zonalHeight = modernZonalHeightAt(background, lat, 500);
    const heightAnomaly = clamp(height - zonalHeight, -220, 220);
    // The sea-level reduction must not inherit the full amplitude of every
    // upper-air contour.  A 500-hPa ridge is a mass signal, but mapping
    // 100 m directly to 5 hPa made ordinary summer ridges look like winter
    // anticyclones.  Keep the coupling weaker and let the explicit surface
    // systems carry the local pressure extrema.
    const upperMassAnomaly = 0.035 * heightAnomaly;

    // The lower field is already expressed as hPa around its 1010-hPa datum.
    // Add it after the broad closure so monsoon lows, subtropical highs and
    // winter cold surges remain visible without replacing the continuous mass
    // field with isolated symbols.
    const lowerAnomaly = getPressureAt(lon, lat, lower, false) - 1010
        + lower
            .filter(cell => cell.isColdSurge)
            .reduce((sum, cell) => sum + coldSurgeSurfacePressureAnomaly(lon, lat, cell), 0);
    const landStatus = options.includeTerrain === false ? { isLand: false } : getLandStatus(lon, lat, 0.5);
    const elevation = options.includeTerrain === false ? 0 : getElevationAt(lon, lat);
    // MSLP is reduced to sea level, so terrain must remain a weak correction,
    // not a raw station-pressure lapse rate.  The small relief term keeps
    // continental contours from being perfectly smooth while avoiding a
    // mountain-shaped false synoptic low.
    const terrainFraction = clamp(elevation / 680, 0, 1);
    const terrainWeight = landStatus.isLand ? 1 : landStatus.isNearLand ? 0.35 : 0;
    const terrainAnomaly = -0.85 * terrainFraction * terrainWeight;
    // The tropical marine background is close to 1010–1012 hPa.  Use a small
    // seasonal offset rather than a permanently high 1012.5-hPa datum; the
    // winter cold-surge and subtropical-high cells still provide genuine
    // high-pressure events when they are present.
    const surfaceDatum = 1011.0 + 1.0 * (1 - summer);
    const summerAwareCeiling = 1038 + 8 * (1 - summer);
    return clamp(
        surfaceDatum + equatorialTrough + subtropicalRidge + subpolarLow
            + polarHigh + upperMassAnomaly + lowerAnomaly + terrainAnomaly
            + transientSurfacePressureAnomaly(lon, lat, background),
        982,
        summerAwareCeiling
    );
}

// The environmental height field deliberately excludes the storm vortex so
// steering does not count the cyclone twice.  A product chart, however,
// should show the cyclone's own 500-hPa closed circulation.  This evaluator
// supplies that diagnostic warm-core (or post-transition cold-core) anomaly
// only when a chart explicitly asks for it.
export function getCycloneHeightAnomalyAt(lon, lat, cyclone, level = 500) {
    if (![500, 200].includes(level) || !cyclone
        || !Number.isFinite(cyclone.lon) || !Number.isFinite(cyclone.lat)
        || !Number.isFinite(cyclone.intensity)) return 0;

    const intensity = clamp(cyclone.intensity, 15, 160);
    const circulationSize = clamp(cyclone.circulationSize || 300, 120, 700);
    const distance = calculateDistance(lat, lon, cyclone.lat, cyclone.lon);
    // The vertical structure is deliberately split at 500 hPa.  A tropical
    // cyclone remains a cyclonic vortex through the lower/middle troposphere;
    // its anticyclonic outflow is an upper-tropospheric feature.  The 200-hPa
    // warm-core height anomaly therefore grows with maturity, while the
    // 500-hPa chart keeps a closed low-height/cyclonic signature.  The smooth
    // 30–105 kt transition represents the gradual development of a deep warm
    // core rather than applying one sign to every pressure level.
    const warmCoreMaturity = smoothstep((intensity - 30) / 75);
    const levelFactor = level === 200
        ? 0.28 + 0.82 * warmCoreMaturity
        : -(0.35 + 0.45 * warmCoreMaturity);
    const radius = Math.max(
        level === 200 ? 180 : 140,
        circulationSize * (level === 200 ? 0.72 + 0.0035 * intensity : 0.55 + 0.003 * intensity)
    );
    const core = Math.exp(-0.5 * (distance / radius) ** 2);
    const outerCompensation = Math.exp(-0.5 * (distance / (radius * (level === 200 ? 2.4 : 2.2))) ** 2);

    const phase = cyclone.isExtratropical
        ? (level === 200 ? -0.75 : 1)
        : cyclone.isTransitioning
            ? (level === 200 ? 0.45 : 1)
            : 1;
    const amplitude = levelFactor * phase * (15 + 0.62 * intensity + 0.03 * circulationSize);
    return amplitude * (core - 0.18 * outerCompensation);
}

// Public diagnostics for the map, forecast and future data-assimilation
// layers. Keeping these quantities next to the field evaluator prevents UI
// code from reverse-engineering the synthetic atmosphere from its contours.
export function getAtmosphericDiagnostics(lon, lat, systems) {
    const background = systems?.upper?.find(c => c.role === 'height-background');
    if (!background) return { fieldVersion: 0, flowModel: 'legacy', levels: {} };
    ensureModernAtmosphericState(background);
    const components = waveFieldComponents(lon, lat, background, 500);
    const levels = {};
    for (const level of [850, 500, 200]) {
        const wind = gradientWind(lon, lat,
            (x, y) => getGeopotentialHeight500(x, y, systems, level), GRAVITY);
        const derivatives = flowDerivatives(lon, lat, systems, level);
        levels[level] = {
            height: getGeopotentialHeight500(lon, lat, systems, level),
            u: wind.u,
            v: wind.v,
            speed: Math.hypot(wind.u, wind.v),
            ...derivatives
        };
    }
    const west = getGeopotentialHeight500(lon - 3, lat, systems, 500);
    const east = getGeopotentialHeight500(lon + 3, lat, systems, 500);
    const north = getGeopotentialHeight500(lon, lat + 3, systems, 500);
    const south = getGeopotentialHeight500(lon, lat - 3, systems, 500);
    return {
        fieldVersion: background.fieldVersion || 2,
        flowModel: background.flowModel || 'legacy',
        ridgeLatitude: components.ridgeLatitude,
        jetLatitude: components.jetLatitude,
        displacement: components.displacement,
        shortWave: components.shortWave,
        zonalGradient: (east - west) / 6,
        meridionalGradient: (north - south) / 6,
        levels
    };
}

function advanceWaveField(background) {
    const prior = background.waves.map(w => ({...w}));
    background.elapsedHours = (background.elapsedHours || 0) + MODEL_STEP_HOURS;
    background.waves.forEach((wave, index) => {
        const neighbours = prior.filter(w => w.hemisphere === wave.hemisphere && Math.abs(w.k-wave.k) === 1);
        const coupling = neighbours.reduce((sum,w) => sum + Math.sin(w.phase-prior[index].phase), 0);
        if (isModernAtmosphericBackground(background)) {
            // Linearized barotropic Rossby-wave evolution: phase propagation
            // follows the initialized U-beta/K² dispersion relation. Coupling
            // is deliberately weak and bounded so it cannot reverse the
            // background wave propagation or create an arbitrary attractor.
            const frequency = Number.isFinite(wave.frequency)
                ? wave.frequency
                : rossbyFrequencyFromSpeed(wave);
            wave.phase = (wave.phase + frequency * MODEL_STEP_HOURS
                + .0015 * clamp(coupling, -2, 2)) % (2 * Math.PI);
            const envelope = 1 + .15 * Math.sin(
                background.elapsedHours / wave.envelopeHours + wave.envelopePhase
            );
            wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .035;
            wave.verticalTiltRad = wave.baseVerticalTiltRad
                + .04 * Math.sin(background.elapsedHours / 120 + wave.envelopePhase);
        } else {
            wave.phase = (wave.phase + wave.frequency * MODEL_STEP_HOURS + .006 * coupling) % (2*Math.PI);
            const envelope = 1 + .22 * Math.sin(background.elapsedHours / wave.envelopeHours + wave.envelopePhase);
            wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .045;
            wave.tilt = wave.baseTilt + .8 * Math.sin(background.elapsedHours / 90 + wave.envelopePhase);
        }
    });
    for (const wave of (background.tropicalWaves || [])) {
        const envelope = 1 + .18 * Math.sin(
            background.elapsedHours / wave.envelopeHours + wave.envelopePhase
        );
        wave.phase = (wave.phase + wave.frequency * MODEL_STEP_HOURS) % (2 * Math.PI);
        wave.amplitude += (wave.baseAmplitude * envelope - wave.amplitude) * .055;
        wave.latitude += .025 * Math.sin(
            background.elapsedHours / 72 + wave.phaseOffset
        );
    }
}

function gradientWind(lon, lat, sample, factor) {
    const delta = 0.25;
    const radians = Math.PI / 180;
    const f = 2 * 7.292115e-5 * Math.sin(lat * radians);
    // Smooth equatorial regularization; no singular wind or discontinuity at 0°.
    const inverseF = f / (f * f + (2.0e-5) ** 2);
    const dy = 2 * delta * 6371000 * radians;
    const dx = dy * Math.max(0.087, Math.cos(lat * radians));
    return {
        u: -factor * inverseF * (sample(lon, lat + delta) - sample(lon, lat - delta)) / dy,
        v: factor * inverseF * (sample(lon + delta, lat) - sample(lon - delta, lat)) / dx
    };
}

function flowDerivatives(lon, lat, systems, level = 500) {
    const delta = 1;
    const radians = Math.PI / 180;
    const dy = delta * EARTH_RADIUS_M * radians;
    const dx = dy * Math.max(.087, Math.cos(lat * radians));
    const wind = (x, y) => gradientWind(x, y,
        (sampleLon, sampleLat) => getGeopotentialHeight500(
            sampleLon, sampleLat, systems, level), GRAVITY);
    const west = wind(lon - delta, lat), east = wind(lon + delta, lat);
    const south = wind(lon, lat - delta), north = wind(lon, lat + delta);
    const dudx = (east.u - west.u) / (2 * dx);
    const dudy = (north.u - south.u) / (2 * dy);
    const dvdx = (east.v - west.v) / (2 * dx);
    const dvdy = (north.v - south.v) / (2 * dy);
    const relativeVorticity = dvdx - dudy;
    return {
        relativeVorticity,
        divergence: dudx + dvdy,
        deformation: Math.hypot(dudx - dvdy, dvdx + dudy),
        absoluteVorticity: relativeVorticity
            + 2 * EARTH_OMEGA * Math.sin(lat * radians)
    };
}

function calculateLayerWind(lon, lat, systems) {
    return gradientWind(lon, lat, (x, y) => getPressureAt(x, y, systems, false), 100 / 1.15);
}

export function getSurfaceEnvironmentalWind(lon, lat, systems, applyTerrainFriction = true) {
    // Local steady bulk momentum balance:
    // (Cd |U| / h) U + f k×U = -grad(p)/rho.
    // It includes friction at the equator without an artificial inverse-f cap.
    // h=500 m, Cd and the 0.8 slab-to-10m factor are explicit diagnostic
    // assumptions, not a resolved/stability-dependent boundary-layer model.
    const delta = 0.25;
    const radians = Math.PI / 180;
    const dy = 2 * delta * EARTH_RADIUS_M * radians;
    const dx = dy * Math.max(0.087, Math.cos(lat * radians));
    const sample = (x, y) => getSurfacePressureAt(x, y, systems, { includeTerrain: false });
    const forceX = -(sample(lon + delta, lat) - sample(lon - delta, lat)) * 100 / (1.15 * dx);
    const forceY = -(sample(lon, lat + delta) - sample(lon, lat - delta)) * 100 / (1.15 * dy);
    const forceSq = forceX * forceX + forceY * forceY;
    if (!(forceSq > 0)) return { u: 0, v: 0 };
    const f = 2 * EARTH_OMEGA * Math.sin(lat * radians);
    const land = applyTerrainFriction && getLandStatus(lon, lat)?.isLand;
    const dragPerDepth = (land ? 0.003 : 0.0015) / 500;
    const speedSq = 2 * forceSq / (f * f
        + Math.sqrt(f ** 4 + 4 * dragPerDepth * dragPerDepth * forceSq));
    const damping = dragPerDepth * Math.sqrt(speedSq);
    const denominator = f * f + damping * damping;
    return {
        u: 0.8 * (damping * forceX + f * forceY) / denominator,
        v: 0.8 * (damping * forceY - f * forceX) / denominator
    };
}

export function getWindVectorAt(lon, lat, month, cyclone, pressureSystems, options = {}) {
    const applyTerrainFriction = typeof options === 'object'
        ? options.applyTerrainFriction !== false
        : true;
    // Environmental flow is optional because the wind-radii solver samples
    // both the earth-relative wind and the cyclone-only contribution.  The
    // former supplies physically real quadrant enhancement/cancellation; the
    // latter prevents a detached monsoon or westerly current being mistaken
    // for part of the storm's gale envelope.
    const includeEnvironmentalFlow = typeof options === 'object'
        ? options.includeEnvironmentalFlow !== false
        : true;
    const includeComponents = typeof options === 'object'
        ? options.includeComponents === true
        : false;
    let k = 1.0;
    let alphaDeg = 15;
    if (applyTerrainFriction) {
        const landInfo = getLandStatus(lon, lat);
        const isLand = landInfo ? landInfo.isLand : false;
        if (isLand) {
            const elevation = getElevationAt(lon, lat) || 0;
            k = Math.max(0.4, 0.8 - (elevation / 1700));
            alphaDeg = Math.min(55, 15 + (elevation / 17));
        }
    }

    const inflowAngle = alphaDeg * (Math.PI / 180);

    // Surface winds respond to surface pressure and drag, not the free
    // 850-hPa jet used for steering and shear.
    const envFlow = includeEnvironmentalFlow
        ? getSurfaceEnvironmentalWind(lon, lat, pressureSystems, applyTerrainFriction)
        : { u: 0, v: 0 };
    const envWind = { u: envFlow.u * 1.94384, v: envFlow.v * 1.94384 };
    
    // 2. Vortex Flow
    let u_vortex = 0;
    let v_vortex = 0;
    let u_trans = 0;
    let v_trans = 0;

    if (cyclone.status === 'active') {
        const dist = calculateDistance(lat, lon, cyclone.lat, cyclone.lon);
        // Avoid rebuilding the full diagnostic radial profile for every wind
        // grid sample. Only the dominant RMW is needed for translation decay.
        const geometrySignature = [
            cyclone.intensity,
            cyclone.rmw,
            cyclone.circulationSize,
            cyclone.outerWindBroadness,
            cyclone.isERCActive ? 1 : 0,
            cyclone.ercInnerRmw,
            cyclone.ercInnerWind,
            cyclone.ercOuterRmw,
            cyclone.ercOuterWindAnomaly,
            cyclone.ercOuterOrganization,
            cyclone.ercOuterShare,
            cyclone.ercInnerIntegrity,
            cyclone.ercOuterWidth,
            cyclone.centralPressure,
            cyclone.environmentalPressure,
            cyclone.pressureTendency,
            cyclone.speed,
            cyclone.lat
        ].join('|');
        let geometry = vortexGeometryCache.get(cyclone);
        if (!geometry || geometry.signature !== geometrySignature) {
            const innerRmw = getPrimaryRmw(cyclone);
            const innerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercInnerWind)
                ? cyclone.ercInnerWind
                : cyclone.intensity;
            const outerPeak = cyclone.isERCActive && Number.isFinite(cyclone.ercOuterRmw)
                ? baselineWindAtRadius(cyclone.ercOuterRmw, cyclone)
                    + Math.max(0, cyclone.ercOuterWindAnomaly || 0)
                : -Infinity;
            const takeover = getOuterEyewallDominance(cyclone);
            const RMW = innerRmw + ((cyclone.ercOuterRmw || innerRmw) - innerRmw) * takeover;
            const dominantPeak = Number.isFinite(outerPeak)
                ? innerPeak + (outerPeak - innerPeak) * takeover : innerPeak;
            let symmetricCoreR64 = estimateSymmetricCoreR64(
                RMW,
                dominantPeak,
                cyclone.circulationSize,
                Number.isFinite(cyclone.outerWindBroadness) ? cyclone.outerWindBroadness : 0.6,
                hollandShapeParameter(cyclone, dominantPeak)
            );
            if (cyclone.isERCActive
                && Number.isFinite(cyclone.ercOuterRmw)
                && outerPeak > 54) {
                const outerOrganization = clamp(cyclone.ercOuterOrganization || 0, 0, 1);
                const outerRingWidth = clamp(cyclone.ercOuterWidth || 18, 8, 60);
                const outerCoreSigma = outerRingWidth
                    * (1.10 + 0.35 * (1 - outerOrganization));
                symmetricCoreR64 = Math.max(
                    symmetricCoreR64,
                    RMW + (cyclone.ercOuterRmw + 2.40 * outerCoreSigma - RMW)
                        * takeover * smoothstep((outerPeak - 54) / 20)
                );
            }
            geometry = { signature: geometrySignature, RMW, symmetricCoreR64 };
            vortexGeometryCache.set(cyclone, geometry);
        }
        const { RMW, symmetricCoreR64 } = geometry;
        // Do not let the finite-domain taper erase the broad gale tail before
        // it can separate R34 from R64. The taper begins outside the expected
        // gale contour and remains tied to both circulation size and core size.
        const fadeStart = Math.max(
            cyclone.circulationSize * 1.4,
            symmetricCoreR64 * 2.65
        );
        const outerRadius = Math.max(
            cyclone.circulationSize * 4.0,
            fadeStart + Math.max(180, symmetricCoreR64)
        );

        if (dist < outerRadius) {
            let vortexSpeed = baselineWindAtRadius(dist, cyclone)
                + outerEyewallAnomalyAtRadius(dist, cyclone);
            // Surface roughness removes more of the outer wind envelope than
            // the core. Offshore sectors retain their unmodified local friction.
            if (k < 1) k *= 1 - 0.25 * smoothstep((dist / Math.max(1, RMW) - 1) / 4);

            // Keep the existing finite circulation envelope outside the core.
            if (dist > fadeStart) {
                const t = (dist - fadeStart) / (outerRadius - fadeStart);
                const fade = (Math.exp(-2 * t) - Math.exp(-2)) / (1 - Math.exp(-2));
                vortexSpeed *= clamp(fade, 0, 1);
            }

            const dx = lon - cyclone.lon;
            const dy = lat - cyclone.lat;
            const angleToCenter = Math.atan2(dy, dx);
            
            // Inflow Angle
            const rotationOffset = (cyclone.lat >= 0) ? (Math.PI / 2 + inflowAngle) : (-Math.PI / 2 - inflowAngle);
            const windAngle = angleToCenter + rotationOffset;

            const speedMs = vortexSpeed; 

            u_vortex = Math.cos(windAngle) * speedMs;
            v_vortex = Math.sin(windAngle) * speedMs;
            const moveSpeed = cyclone.speed;
            const moveAngleMath = (450 - cyclone.direction) % 360 * (Math.PI / 180);
            // Storm motion is not just a track displacement: it is added to
            // the near-core circulation and therefore enlarges the forward
            // side while partially cancelling the rear side.  A fixed 0.6
            // factor made a 15 kt translating storm look almost symmetric.
            // Keep the effect bounded so fast-moving systems do not acquire
            // an implausibly elongated wind field.
            const asymmetryFactor = clamp(0.45 + 0.018 * moveSpeed, 0.45, 0.75);
            u_trans = Math.cos(moveAngleMath) * moveSpeed * asymmetryFactor;
            v_trans = Math.sin(moveAngleMath) * moveSpeed * asymmetryFactor;
            // Translation is a storm-scale flow, not an eyewall-only
            // correction.  The old 45 km e-folding scale removed almost all
            // of it before the 34 kt contour, making moving storms look too
            // symmetric.  Let it persist through the inner circulation and
            // fade on a scale tied to the diagnosed storm size.
            const translationFadeStart = 1.1 * RMW;
            const translationDecayScale = Math.max(
                90,
                0.35 * cyclone.circulationSize,
                1.75 * RMW
            );
            let transDecay = 1.0;
            if (dist > translationFadeStart) {
                transDecay = Math.exp(-(dist - translationFadeStart) / translationDecayScale);
            }
            
            u_trans *= transDecay;
            v_trans *= transDecay;
        }
    }

    const cycloneU = (u_vortex + u_trans) * k;
    const cycloneV = (v_vortex + v_trans) * k;
    const totalU = envWind.u + cycloneU;
    const totalV = envWind.v + cycloneV;
    const result = {
        u: totalU,
        v: totalV,
        magnitude: Math.hypot(totalU, totalV)
    };
    if (includeComponents) {
        result.cycloneU = cycloneU;
        result.cycloneV = cycloneV;
        result.cycloneMagnitude = Math.hypot(cycloneU, cycloneV);
    }
    return result;
}

/**
 * Resolve the cyclone-associated 34/50/64 kt contour in each operational
 * quadrant.  Wind radii are earth-relative (vortex + translation + local
 * environment), but a small cyclone-only contribution is required so a
 * detached monsoon surge or westerly belt cannot become part of the ring.
 * Searching outward from the dynamically relevant eyewall and stopping at
 * its first outer crossing also rejects a remote re-entry into an unrelated
 * wind maximum.  During an eyewall replacement cycle, the diagnosed outer
 * eyewall is a valid anchor even when the moat between the two eyewalls is
 * below the requested wind threshold.
 */
export function calculateWindRadii(cyclone, pressureSystems, month, maxSearchKm = 900) {
    const structure = getEyewallStructure(cyclone);
    const thresholds = [34, 50, 64].filter(threshold => cyclone.intensity >= threshold);
    const result = { 34: [0, 0, 0, 0], 50: [0, 0, 0, 0], 64: [0, 0, 0, 0] };
    const angularBinCount = 16;
    const angularResult = {
        34: Array(angularBinCount).fill(0),
        50: Array(angularBinCount).fill(0),
        64: Array(angularBinCount).fill(0)
    };
    result.angular = angularResult;
    if (thresholds.length === 0) return result;

    const distances = new Set([0, structure.innerRmw]);
    for (let radius = 5; radius <= maxSearchKm; radius += 10) distances.add(radius);

    const addPeakMesh = (peakRadius, halfWidth) => {
        if (!Number.isFinite(peakRadius)) return;
        for (let radius = Math.max(1, peakRadius - halfWidth); radius <= peakRadius + halfWidth; radius += 2) {
            distances.add(radius);
        }
        distances.add(peakRadius);
    };
    addPeakMesh(structure.innerRmw, Math.max(20, structure.innerRmw * 0.45));
    if (Number.isFinite(structure.outerRmw)) {
        addPeakMesh(structure.outerRmw, Math.max(25, 1.5 * (cyclone.ercOuterWidth || 15)));
    }

    const radialDistances = [...distances]
        .filter(radius => radius >= 0 && radius <= maxSearchKm)
        .sort((a, b) => a - b);
    const cosLat = Math.max(0.1, Math.cos(cyclone.lat * Math.PI / 180));
    const pointAt = (angleRad, distanceKm) => {
        const distanceDeg = distanceKm / 111.32;
        return [
            cyclone.lon + distanceDeg * Math.cos(angleRad) / cosLat,
            cyclone.lat + distanceDeg * Math.sin(angleRad)
        ];
    };

    const directionalCache = new Map();
    const resolveDirectionalRadii = angle => {
        const normalizedAngle = ((angle % 360) + 360) % 360;
        if (directionalCache.has(normalizedAngle)) {
            return directionalCache.get(normalizedAngle);
        }
        const angleRad = normalizedAngle * Math.PI / 180;
        // Evaluate only mesh points consumed by an eyewall search or a
        // connected threshold crossing. Preserve the exact mesh and order;
        // all three thresholds share the same per-direction sample cache.
        const profile = new Array(radialDistances.length);
        const sampleAt = index => {
            if (profile[index]) return profile[index];
            const distance = radialDistances[index];
            const [lon, lat] = pointAt(angleRad, distance);
            const wind = getWindVectorAt(
                lon, lat, month, cyclone, pressureSystems,
                { includeEnvironmentalFlow: true, includeComponents: true }
            );
            return profile[index] = {
                distance,
                totalWind: wind.magnitude,
                cycloneWind: wind.cycloneMagnitude
            };
        };
        const outermost = { 34: 0, 50: 0, 64: 0 };

        thresholds.forEach(threshold => {
            const associationFloor = Math.min(12, threshold * 0.20);
            const marginAt = sample => Math.min(
                sample.totalWind - threshold,
                sample.cycloneWind - associationFloor
            );

            const findEyewallPeak = (center, halfWidth) => {
                let peakIndex = -1;
                let peakMargin = -Infinity;
                for (let i = 0; i < radialDistances.length; i++) {
                    if (Math.abs(radialDistances[i] - center) > halfWidth) continue;
                    const margin = marginAt(sampleAt(i));
                    if (margin >= 0 && margin > peakMargin) {
                        peakMargin = margin;
                        peakIndex = i;
                    }
                }
                return peakIndex;
            };

            // An ERC moat may be below the threshold while the outer eyewall
            // is fully valid.  Treat the resolved outer ring as the anchor,
            // rather than demanding a geometrically unbroken threshold band
            // all the way from the inner eyewall.
            let connectedIndex = -1;
            const outerEyewallIsRelevant = Number.isFinite(structure.outerRmw)
                && structure.outerPeak >= threshold;
            if (outerEyewallIsRelevant) {
                const outerHalfWidth = Math.max(
                    12,
                    2.5 * (cyclone.ercOuterWidth || 15)
                );
                connectedIndex = findEyewallPeak(structure.outerRmw, outerHalfWidth);
            }
            if (connectedIndex < 0) {
                connectedIndex = findEyewallPeak(
                    structure.innerRmw,
                    Math.max(10, structure.innerRmw * 0.65)
                );
            }
            if (connectedIndex < 0) return;

            outermost[threshold] = radialDistances[connectedIndex];
            for (let i = connectedIndex + 1; i < radialDistances.length; i++) {
                const previous = sampleAt(i - 1);
                const current = sampleAt(i);
                const previousMargin = marginAt(previous);
                const currentMargin = marginAt(current);
                if (currentMargin >= 0) {
                    outermost[threshold] = current.distance;
                    continue;
                }

                const fraction = previousMargin / Math.max(1e-6, previousMargin - currentMargin);
                outermost[threshold] = previous.distance
                    + (current.distance - previous.distance) * clamp(fraction, 0, 1);
                break;
            }
        });
        directionalCache.set(normalizedAngle, outermost);
        return outermost;
    };

    // Resolve a finer angular field as well as the four operational
    // quadrants.  The latter remain the public/advisory representation;
    // the former prevents the map from drawing an artificial four-sided
    // polygon and preserves translational asymmetry around the storm.
    for (let bin = 0; bin < angularBinCount; bin++) {
        const directional = resolveDirectionalRadii(bin * 360 / angularBinCount);
        thresholds.forEach(threshold => {
            angularResult[threshold][bin] = directional[threshold];
        });
    }

    // Standard advisory order: NE, SE, SW, NW. Angles here are mathematical
    // angles measured counter-clockwise from east.
    const quadrantRanges = [
        { start: 0, end: 90 },
        { start: 270, end: 360 },
        { start: 180, end: 270 },
        { start: 90, end: 180 }
    ];

    for (let quadrantIndex = 0; quadrantIndex < quadrantRanges.length; quadrantIndex++) {
        const range = quadrantRanges[quadrantIndex];
        const quadrantMax = { 34: 0, 50: 0, 64: 0 };
        for (let angle = range.start; angle <= range.end; angle += 10) {
            const outermost = resolveDirectionalRadii(angle);

            thresholds.forEach(threshold => {
                quadrantMax[threshold] = Math.max(quadrantMax[threshold], outermost[threshold]);
            });
        }

        thresholds.forEach(threshold => {
            result[threshold][quadrantIndex] = quadrantMax[threshold];
        });
    }

    return result;
}

function applyCalculatedWindRadii(cyclone, rawRadiiKm) {
    const previousRadii = cyclone.radiiState || {};
    const previousAngularRadii = cyclone.radiiAngularState || {};
    const eyewallStructure = getEyewallStructure(cyclone);
    const radiiState = {};
    const radiiAngularState = {};
    [34, 50, 64].forEach(threshold => {
        const raw = rawRadiiKm[threshold];
        const previous = Array.isArray(previousRadii[threshold]) ? previousRadii[threshold] : null;
        const rawAngular = Array.isArray(rawRadiiKm.angular?.[threshold])
            ? rawRadiiKm.angular[threshold]
            : [];
        const previousAngular = Array.isArray(previousAngularRadii[threshold])
            && previousAngularRadii[threshold].length === rawAngular.length
            ? previousAngularRadii[threshold]
            : null;
        let rmwFloor = 0;
        if (eyewallStructure.innerPeak >= threshold) rmwFloor = eyewallStructure.innerRmw;
        if (Number.isFinite(eyewallStructure.outerRmw) && eyewallStructure.outerPeak >= threshold) {
            rmwFloor = Math.max(rmwFloor, eyewallStructure.outerRmw);
        }

        radiiState[threshold] = raw.map((rawRadius, quadrant) => {
            if (rawRadius <= 0 || cyclone.intensity < threshold) return 0;
            if (!previous || !Number.isFinite(previous[quadrant]) || previous[quadrant] <= 0) {
                return Math.max(rawRadius, rmwFloor);
            }
            const response = rawRadius >= previous[quadrant] ? 0.65 : 0.50;
            const smoothed = previous[quadrant] + (rawRadius - previous[quadrant]) * response;
            return Math.max(smoothed, rmwFloor);
        });

        radiiAngularState[threshold] = rawAngular.map((rawRadius, index) => {
            if (rawRadius <= 0 || cyclone.intensity < threshold) return 0;
            if (!previousAngular || !Number.isFinite(previousAngular[index]) || previousAngular[index] <= 0) {
                return Math.max(rawRadius, rmwFloor);
            }
            const response = rawRadius >= previousAngular[index] ? 0.65 : 0.50;
            const smoothed = previousAngular[index] + (rawRadius - previousAngular[index]) * response;
            return Math.max(smoothed, rmwFloor);
        });
    });

    for (let quadrant = 0; quadrant < 4; quadrant++) {
        radiiState[50][quadrant] = Math.min(radiiState[50][quadrant], radiiState[34][quadrant]);
        radiiState[64][quadrant] = Math.min(radiiState[64][quadrant], radiiState[50][quadrant]);
    }
    for (let index = 0; index < radiiAngularState[34].length; index++) {
        radiiAngularState[50][index] = Math.min(radiiAngularState[50][index], radiiAngularState[34][index]);
        radiiAngularState[64][index] = Math.min(radiiAngularState[64][index], radiiAngularState[50][index]);
    }
    cyclone.radiiState = radiiState;
    cyclone.radiiAngularState = radiiAngularState;

    const toDegrees = radiiKm => radiiKm.map(radius => radius / 111.32);
    cyclone.r34 = toDegrees(radiiState[34]);
    cyclone.r50 = toDegrees(radiiState[50]);
    cyclone.r64 = toDegrees(radiiState[64]);
    return cyclone;
}

export function initializeCyclone(world, month, basin = 'WPAC', globalTemp, globalShear, customLon = null, customLat = null) {
    let lat, lon, isOverLand;

    let useCustomCoords = (customLon !== null && customLat !== null);
    
    if (useCustomCoords) {
        isOverLand = world.features.some(feature => d3.geoContains(feature, [customLon, customLat]));
        if (isOverLand) {
            console.warn(`Custom coordinates (${customLon}, ${customLat}) are on land. Falling back to random generation.`);
            useCustomCoords = false;
        } else {
            lon = customLon;
            lat = customLat;
            // console.log(`Using custom generation point: ${lon}, ${lat}`);
        }
    }
    
    if (!useCustomCoords) {
        const selectedBasin = basinConfig[basin] || basinConfig['WPAC']; // WPAC default
        const lonRange = selectedBasin.lon;
        const latBaseRange = selectedBasin.lat;
        const latRangeSpan = latBaseRange.max - latBaseRange.min;
        const hem = latBaseRange.max > 0 ? 1 : -1;
        const seasonalFactor = basin === 'WPAC'
            ? monthlyCirculation(month, hem).summer
            : (Math.cos((month - 8) * (Math.PI / 6)) + 1) / 2;
        const seasonalShift = latBaseRange.max > 0 ? (latRangeSpan / 4) * (seasonalFactor - 0.5) :
        (latRangeSpan / 4) * (seasonalFactor - 0.5);
        const currentMinLat = latBaseRange.min + seasonalShift + hem*Math.max(0,(globalTemp / 2.89 - 100));
        const currentMaxLat = latBaseRange.max + (basin === 'WPAC' ? 2 : 4) * seasonalShift + hem*(globalTemp / 2.89 - 100);
        const latSpan = currentMaxLat - currentMinLat;

        // 4. Don't spawn on land
        let sst;
        do {
            // WPAC genesis has a low-latitude mode and a thinner poleward tail, not a uniform summer box.
            const genesisDraw = Math.random();
            lat = currentMinLat + Math.pow(genesisDraw, basin === 'WPAC' ? 1.6 : 1) * latSpan;
            if (basin === 'WPAC') {
                // Western North Pacific genesis is concentrated in the
                // Philippine Sea / Mariana corridor.  A uniform 100–180E
                // draw overpopulates the dateline and creates an artificial
                // eastern fast-track plume before steering is even applied.
                const sectorDraw = Math.random();
                const positionDraw = Math.random();
                if (sectorDraw < 0.03) lon = 100 + 10 * positionDraw;
                else if (sectorDraw < 0.33) lon = 110 + 20 * positionDraw;
                else if (sectorDraw < 0.79) lon = 130 + 20 * positionDraw;
                else if (sectorDraw < 0.99) lon = 150 + 20 * positionDraw;
                else lon = 170 + 10 * positionDraw;
            } else {
                lon = lonRange.min + Math.random() * (lonRange.max - lonRange.min);
            }
            const status = getLandStatus(lon, lat);
            isOverLand = status.isLand;

            sst = getSST(lat, lon, month, globalTemp);

        } while (isOverLand || sst < 25.4); // 如果在陆地上或者海温过低，重试
    }

    // --- Subtropical ---
    const initialSST = getSST(lat, lon, month, globalTemp);
    let isSubtropical = false;
    let subtropicalTransitionTime = 0;
    if (initialSST < 27.5 && Math.random() < 0.75 && (lon > 122 || lon < 40)) {
        isSubtropical = true;
        const durationSteps = 12 + Math.floor(Math.random() * 21);
        subtropicalTransitionTime = durationSteps * 3;
    }

    let isMonsoonDepression = false;
    let monsoonDepressionEndTime = 0;
    if (Math.random() < (0.2 + globalTemp / 72.25 - 4) && (lat > 0)) {
        isMonsoonDepression = true;
        const durationSteps = Math.floor(Math.random() * 50);
        monsoonDepressionEndTime = durationSteps * 3;
    }

    const initialCirculationSize = 150 + Math.random() * 350;

    return {
        lat: lat,
        lon: lon,
        intensity: 23 + Math.random() * 2,
        direction: Math.random() * 360,
        speed: 10 + Math.random() * 5,
        // The dynamical center is kept separate from the operational center
        // fix.  This lets weak/transitioning systems wander without turning
        // the environmental steering field into white-noise motion.
        centerFixOffsetEastKm: 0,
        centerFixOffsetNorthKm: 0,
        basin: basin,
        age: 0,
        shearEventActive: false,
        shearEventEndTime: 0,
        shearEventMagnitude: 0,
        totalShear: 0,
        steeringU: 0,
        steeringV: 0,
        lowLevelU: 0,
        lowLevelV: 0,
        track: [],
        status: 'active',
        isTransitioning: false,
        isLand: isOverLand || false,
        isExtratropical: false,
        isSubtropical: isSubtropical,
        subtropicalTransitionTime: subtropicalTransitionTime,
        subtropicalWarmHours: 0,
        transitionHours: 0,
        baroclinicSupport: 0,
        isMonsoonDepression: isMonsoonDepression,
        monsoonDepressionEndTime: monsoonDepressionEndTime,
        extratropicalStage: 'none',
        extratropicalDevelopmentEndTime: 0,
        extratropicalMaxIntensity: 0,
        upwellingCoolingEffect: 0,
        coldSurgeCoolingEffect: 0,
        coldSurgeInfluence: 0,
        coldSurgeShearBoost: 0,
        isERCActive: false,
        ercState: 'none',
        ercMode: 'none',
        ercLastMode: 'none',
        ercPotential: 0,
        ercEligibleHours: 0,
        ercCycleCount: 0,
        ercStartedCount: 0,
        ercFormationTargetHours: null,
        ercCooldownUntil: 0,
        ercStartTime: 0,
        ercAdverseHours: 0,
        ercInnerRmw: null,
        ercInnerWind: null,
        ercOuterRmw: null,
        ercOuterWindAnomaly: 0,
        ercOuterWidth: 0,
        ercOuterRadarWidthKm: 0,
        ercOuterShare: 0,
        ercOuterOrganization: 0,
        ercInnerIntegrity: 1,
        ercSettlingUntil: 0,
        ercCompletionOutcome: 'none',
        ercCooldownHours: 0,
        ercPostContractionHours: 0,
        ercPace: 1,
        ercRapid: false,
        ercInitialIntensity: 0,
        ercMpiCeiling: null,
        ercInitialRmw: null,
        ercCompactRecovery: false,
        riUntil: 0,
        riCooldownUntil: 0,
        riRate: 0,
        isRapidIntensifying: false,
        ercInitialSize: 0,
        ercPeakSizeTarget: null,
        ercPostSizeTarget: null,
        ercPostSizeRelaxHours: 0,
        ercPostSizeRelaxUntil: 0,
        ercLastOutcome: 'none',
        ercCompletedAt: 0,
        ercPostContractionUntil: 0,
        ercPostRmwTarget: null,
        circulationSize: initialCirculationSize,
        outerWindBroadness: 0.08 + 0.92 * Math.pow(Math.random(), 0.65),
        rmw: fallbackRmwFromSize(initialCirculationSize),
        radarRmwScale: 1,
        radarEyewallWidthKm: null,
        radarEyewallMaturity: 1,
        r34: 0, r50: 0, r64: 0,
        forecastLogs: {},
        ace: 0
    };

}

export function initializePressureSystems(cyclone, month) {
    if (!Number.isFinite(month)) month = 8;
    const season = Math.cos((month - 8) * Math.PI / 6);
    const cell = (x,y,sx,sy,strength,role) => ({type:strength<0?'low':'high', x,y,
        sigmaX:sx,baseSigmaX:sx,sigmaY:sy,strength,baseStrength:strength,role,
        velocityX:.03,velocityY:0,oscillationPhase:0,oscillationSpeed:0,noiseLayers:[]});
    const background = {...cell(0,0,360,90,0,'height-background'), seasonalShift:season*4,
        fieldVersion:MODERN_FIELD_VERSION, flowModel:'qg-barotropic-v1',
        zonalProfileVersion: ZONAL_PROFILE_VERSION,
        calendarMonth: Math.round(month), elapsedHours:0, waves:[], tropicalWaves:[]};
    background.zonalProfiles = buildZonalHeightProfiles(background);
    const upper=[background],lower=[],upperOnly=[];
    for (const hemisphere of [1,-1]) {
        const circulation = monthlyCirculation(month, hemisphere, season * 4);
        const summer = circulation.summer;
        const jetLatitude = circulation.jetLatitude;
        const meanFlowMS = 13 + 5 * (1 - summer);
        for(let k=1;k<=8;k++) {
            const longWave = k <= 3;
            // Geopotential-height amplitudes are metres at 500 hPa.  The old
            // 34/12 m values were visually useful but dynamically too weak to
            // bend the jet or produce a meaningful trough passage.
            // Keep the planetary modes in the observed order of magnitude
            // without allowing eight unrelated harmonics to create a
            // 50-kt meridional jet at one longitude.  The jet profile carries
            // the climatological wind; these amplitudes only bend it.
            const amplitude = (longWave ? 96 : 32)
                * (.82 + Math.random()*.36) * circulation.waveFactor;
            const width = longWave ? 15 + Math.random() * 4 : 8 + Math.random() * 4;
            const latitude = (longWave ? jetLatitude - 1 : jetLatitude - 6)
                + (Math.random() - .5) * (longWave ? 7 : 6);
            const wave = {hemisphere,k,amplitude,baseAmplitude:amplitude,
                phase:Math.random()*Math.PI*2,
                // Mean-flow-dependent Rossby dispersion: long waves can be
                // stationary or westward, while shorter waves generally move
                // eastward with the jet.
                meanFlowMS,
                latitude,
                width,
                meridionalWavelengthKm: longWave ? 3600 : 2200,
                // This is the meridional displacement of the jet axis, in
                // degrees latitude. Long-wave troughs/ridges should move the
                // jet by several degrees; short waves remain embedded in it.
                axisScaleDeg: longWave ? 4.5 + Math.random() * 3.0 : 0,
                baroclinicAmplitude: amplitude * (.04 + Math.random() * .06),
                verticalTiltRad: (Math.random() - .5) * .10,
                baseVerticalTiltRad: (Math.random() - .5) * .10,
                envelopeHours: longWave ? 168 + Math.random() * 180 : 72 + Math.random() * 120,
                envelopePhase:Math.random()*Math.PI*2};
            wave.phaseSpeedMS = rossbyPhaseSpeedMS(wave);
            wave.frequency = rossbyFrequencyFromSpeed(wave);
            background.waves.push(wave);
        }
        // Tropical easterly/monsoon waves supply the missing low-latitude
        // degrees of freedom.  They are weaker and shorter-lived than the
        // planetary modes, but their phase and sign differ by case, so the
        // trade-wind background does not collapse every storm into a parallel
        // track.  A minority of eastward-propagating modes represents Kelvin
        // or convectively coupled disturbances without making them dominant.
        for (let i = 0; i < 3; i++) {
            const amplitude = 22 + 16 * circulation.monsoonStrength + Math.random() * 8;
            const sign = Math.random() < .76 ? 1 : -1;
            const tropicalWave = {
                hemisphere,
                k: 1 + Math.floor(Math.random() * 3),
                amplitude: (Math.random() < .58 ? 1 : -1) * amplitude,
                baseAmplitude: 0,
                phase: Math.random() * Math.PI * 2,
                frequency: sign * (.012 + .016 * Math.random()),
                latitude: 7 + 10 * summer + (Math.random() - .5) * 3,
                width: 5.5 + Math.random() * 2.5,
                envelopeHours: 96 + Math.random() * 120,
                envelopePhase: Math.random() * Math.PI * 2,
                phaseOffset: Math.random() * Math.PI * 2
            };
            tropicalWave.baseAmplitude = tropicalWave.amplitude;
            background.tropicalWaves.push(tropicalWave);
        }
        // Basin-scale ridge extensions are small perturbations to the continuous ridge.
        for(const longitude of [175,240,325,65]) {
            const x=longitude+(Math.random()-.5)*36,
                y=hemisphere*(circulation.ridgeLatitude+(Math.random()-.5)*5);
            const ridgeCell = cell(x,y,22+Math.random()*8,11+Math.random()*2,4+Math.random()*2,'ridge');
            ridgeCell.anomalyScale = .35;
            ridgeCell.oscillationSpeed=.018; ridgeCell.oscillationAmount=.20; ridgeCell.oscillationPhase=Math.random()*Math.PI*2;
            upper.push(ridgeCell);
            const lowerRidge = cell(x+3,y,30,13,3+Math.random()*2,'ridge');
            lowerRidge.anomalyScale = .65;
            lower.push(lowerRidge);
        }
        for(const longitude of (hemisphere>0?[90,140]:[85,155])) {
            const y=hemisphere*circulation.monsoonAxis;
            upper.push(cell(longitude,y,23,6,1.2+1.1*circulation.monsoonStrength,'monsoon'));
            lower.push(cell(longitude,y,28,8,
                -(2+2*summer) * (.90 + .10*circulation.monsoonStrength), 'monsoon'));
        }
        // Boreal-summer upper anticyclone over South Asia.  This is kept as
        // an upper-only cell so it can steer a deep tropical vortex from its
        // southern flank without turning the low-level monsoon trough into a
        // continent-wide westward conveyor.  The seasonal longitude follows
        // the observed west/east migration of the monsoon anticyclone.
        if (hemisphere > 0 && circulation.southAsianHighStrength > .12) {
            const sah = cell(
                circulation.southAsianHighLongitude,
                24 + 3 * circulation.summer,
                23 + 4 * circulation.summer,
                6 + .7 * circulation.summer,
                3.8 + 2.8 * circulation.southAsianHighStrength,
                'south-asian-high'
            );
            sah.anomalyScale = .78;
            // In July–August the South Asian High's 200-hPa geopotential
            // height should commonly approach 12,560 m, with stronger and
            // weaker realizations still represented by the stochastic cell
            // amplitude and planetary-wave background.  This is deliberately
            // a 200-hPa-only calibration; the 500-hPa steering field keeps its
            // previous amplitude.
            sah.level200AnomalyScale = .78 + .84 * circulation.southAsianHighStrength;
            sah.velocityX = 0;
            sah.velocityY = 0;
            // The climatological cell is only the mean state.  Give each
            // synthetic case its own displaced/elongated version, then let
            // the cell breathe and wobble on synoptic (multi-day) time
            // scales instead of stamping the same westward corridor onto
            // every storm.
            sah.baseX = sah.x;
            sah.baseY = sah.y;
            sah.baseStrength = sah.strength;
            sah.baseSigmaX = sah.sigmaX;
            sah.baseSigmaY = sah.sigmaY;
            sah.x = normalizeLongitude(sah.x + (Math.random() - .5) * 8);
            sah.y += (Math.random() - .5) * 2;
            sah.strength *= .84 + .32 * Math.random();
            sah.sigmaX *= .90 + .20 * Math.random();
            sah.sigmaY *= .90 + .20 * Math.random();
            sah.baseX = sah.x;
            sah.baseY = sah.y;
            sah.baseStrength = sah.strength;
            sah.baseSigmaX = sah.sigmaX;
            sah.baseSigmaY = sah.sigmaY;
            sah.variabilityPhase = Math.random() * Math.PI * 2;
            sah.wavePhaseOffset = Math.random() * Math.PI * 2;
            sah.oscillationSpeed = .08 + .05 * Math.random();
            sah.oscillationAmount = 0;
            upperOnly.push(sah);
        }
    }
    // Append upper-only cells after the paired upper/lower cells so the
    // diagnostic fieldId correspondence below remains intact.
    upper.push(...upperOnly);
    lower.forEach((entry,index)=>{entry.fieldId=`environment-${index}`;upper[index+1].fieldId=entry.fieldId;});
    // Keep a weak winter precursor in the Siberian source region from the
    // start of a run. This represents the slowly varying continental high;
    // individual cold surges then grow out of it instead of appearing as a
    // fully formed pressure centre on an arbitrary update step.
    if (month >= 10 || month <= 4) lower.push(createColdSurge(true));
    for (const wave of background.waves.filter(w => w.k === 3 || w.k === 6)) {
        const handle = cell(140,wave.hemisphere*wave.latitude,12,10,-8,'wave-handle');
        handle.waveKey = `${wave.hemisphere}:${wave.k}`;
        handle.velocityX=0;
        upper.push(handle);
    }
    initializeSynopticField(background,upper,cyclone);
    synchronizeWaveHandles(upper,background);
    return {upper,lower};
}

function synchronizeWaveHandles(cells,background) {
    for (const handle of cells.filter(c => c.role === 'wave-handle')) {
        const wave=background.waves.find(w => `${w.hemisphere}:${w.k}` === handle.waveKey);
        if (!wave) continue;
        const period=360/wave.k;
        const base=(Math.PI-wave.phase)/wave.k*180/Math.PI;
        handle.x=base+Math.round((handle.x-base)/period)*period;
        handle.y=wave.hemisphere*wave.latitude;
    }
}

export function updatePressureSystems(systemsObj, month) {
    const background = systemsObj.upper?.find(c => c.role === "height-background");
    ensureModernAtmosphericState(background);
    if (background && Number.isFinite(month)) {
        const calendarMonth = ((Math.round(month) - 1) % 12 + 12) % 12 + 1;
        if (background.calendarMonth !== calendarMonth) {
            background.calendarMonth = calendarMonth;
            background.zonalProfiles = buildZonalHeightProfiles(background);
            background.zonalProfileVersion = ZONAL_PROFILE_VERSION;
        }
    }
    if (background?.waves) { advanceWaveField(background); synchronizeWaveHandles(systemsObj.upper,background); }
    const updateList = (list) => {
        for (let i = list.length - 1; i >= 0; i--) {
            const cell = list[i];

            // Cold-surge highs need their own slow mass-field lifecycle. The
            // previous generic cell update moved a compact high diagonally and
            // then multiplied its pressure by a hard latitude cutoff, which
            // made the high appear, jump and vanish as a single symbol.
            if (cell.isColdSurge) {
                const ageHours = Math.max(0, cell.ageHours || 0);
                const growthHours = Math.max(24, cell.growthHours || 48);
                const decayHours = Math.max(48, cell.decayHours || 96);
                const lifeHours = Math.max(
                    growthHours + decayHours + 24,
                    cell.lifeHours || 384
                );
                const decayStartHours = Math.max(
                    growthHours + 24,
                    cell.decayStartHours || lifeHours - decayHours
                );
                const growth = smoothstep(ageHours / growthHours);
                const decay = 1 - smoothstep(
                    (ageHours - decayStartHours) / decayHours
                );
                const targetEnvelope = clamp(growth * decay, 0, 1);
                const currentEnvelope = Number.isFinite(cell.fieldEnvelope)
                    ? cell.fieldEnvelope
                    : clamp((cell.strength || 0) / Math.max(1, cell.baseStrength || 1), 0, 1);
                const response = 1 - Math.exp(-MODEL_STEP_HOURS / 24);
                cell.fieldEnvelope = clamp(
                    currentEnvelope + (targetEnvelope - currentEnvelope) * response,
                    0,
                    1
                );
                const peakStrength = Number.isFinite(cell.peakStrength)
                    ? cell.peakStrength
                    : Math.max(1, cell.baseStrength || cell.strength || 20);
                cell.peakStrength = peakStrength;
                cell.baseStrength = peakStrength;
                cell.strength = peakStrength * cell.fieldEnvelope;
                cell.sigmaX = (cell.baseSigmaX || cell.sigmaX || 16)
                    * (.92 + .30 * cell.fieldEnvelope);
                cell.sigmaY = (cell.baseSigmaY || cell.sigmaY || 11)
                    * (.94 + .18 * cell.fieldEnvelope);
                cell.meanderPhase = (cell.meanderPhase || 0)
                    + (cell.meanderRate || .02);
                const meander = Math.sin(cell.meanderPhase);
                const lowLevelFlow = gradientWind(
                    cell.x,
                    cell.y,
                    (x, y) => waveFieldComponents(x, y, background, 850).height,
                    9.80665
                );
                const flowLon = lowLevelFlow.u * MODEL_STEP_HOURS * 3600
                    / (111320 * Math.max(.3, Math.cos(cell.y * Math.PI / 180)));
                const flowLat = lowLevelFlow.v * MODEL_STEP_HOURS * 3600 / 111320;
                const transportFactor = .72 + .68 * cell.fieldEnvelope;
                cell.x = normalizeLongitude(
                    cell.x + (cell.velocityX || .18) * transportFactor
                        + (cell.flowAdvectionWeight || .14) * flowLon
                        + .018 * meander
                );
                cell.y = clamp(
                    cell.y + (cell.velocityY || -.06) * transportFactor
                        + (cell.flowAdvectionWeight || .14) * .55 * flowLat
                        + .010 * Math.cos(cell.meanderPhase * .73),
                    15,
                    60
                );
                cell.ageHours = ageHours + MODEL_STEP_HOURS;
                cell.phase = cell.fieldEnvelope < .04
                    ? 'precursor'
                    : cell.fieldEnvelope > .72
                        ? 'mature'
                        : cell.ageHours >= decayStartHours
                            ? 'decaying'
                            : 'developing';
                cell.fadeHours = cell.fieldEnvelope < .02
                    ? (cell.fadeHours || 0) + MODEL_STEP_HOURS
                    : 0;
                const upperTrough = coldSurgeUpperTroughState(cell);
                if (cell.ageHours >= lifeHours + 48
                    && cell.fadeHours >= 12
                    && cell.fieldEnvelope < .02
                    && (upperTrough?.envelope || 0) < .02) {
                    list.splice(i, 1);
                    continue;
                }
            } else {
                cell.x += cell.velocityX;
                cell.y += cell.velocityY;
                if (cell.x > 360) cell.x -= 360;
                if (cell.x < 0) cell.x += 360;
            }

            if (cell.oscillationSpeed) {
                cell.oscillationPhase = (cell.oscillationPhase || 0) + cell.oscillationSpeed;
                const stretch = Math.sin(cell.oscillationPhase) * cell.oscillationAmount;
                if (cell.baseSigmaX) {
                    cell.sigmaX = cell.baseSigmaX * (1 + stretch);
                }
            }

            if (cell.role === 'south-asian-high' && Number.isFinite(cell.baseX)) {
                const phase = cell.oscillationPhase || 0;
                const longWaveSignal = (background?.waves || [])
                    .filter(wave => wave.hemisphere > 0 && wave.k <= 3)
                    .reduce((sum, wave) => sum
                        + .24 * Math.sin(wave.phase + (cell.wavePhaseOffset || 0) + wave.k * .35), 0);
                // A monsoon anticyclone is a slowly varying upper ridge, not
                // a fixed Gaussian.  Let Rossby-wave phase modulate its
                // centroid and amplitude, while keeping the perturbation
                // bounded enough that the monthly climatology remains the
                // dominant signal.
                cell.x = normalizeLongitude(cell.baseX
                    + 4.2 * Math.sin(phase)
                    + 1.6 * Math.sin(.43 * phase + (cell.variabilityPhase || 0))
                    + 3.0 * longWaveSignal);
                cell.y = cell.baseY
                    + 1.1 * Math.sin(.71 * phase + (cell.variabilityPhase || 0) * .7)
                    + .8 * longWaveSignal;
                cell.strength = cell.baseStrength * clamp(
                    1 + .13 * Math.sin(.63 * phase + (cell.variabilityPhase || 0))
                        + .07 * longWaveSignal,
                    .72,
                    1.30
                );
                cell.sigmaX = cell.baseSigmaX * (1
                    + .08 * Math.sin(.52 * phase + (cell.wavePhaseOffset || 0)));
                cell.sigmaY = cell.baseSigmaY * (1
                    + .10 * Math.sin(.47 * phase + (cell.variabilityPhase || 0)));
            }
        }
    };

    if (systemsObj.upper) updateList(systemsObj.upper);
    
    if (systemsObj.lower) {
        updateList(systemsObj.lower);
        
        // --- Generation ---
        const isWinter = (month >= 10 || month <= 4);
        
        const activeSurges = systemsObj.lower.filter(s => s.isColdSurge).length;
        const atmosphericRandom = background?.synoptic
            ? () => synopticRandom(background.synoptic)
            : Math.random;

        if (isWinter && activeSurges < 1
            && atmosphericRandom() < 1 - Math.exp(-MODEL_STEP_HOURS / 120)) {
            systemsObj.lower.push(createColdSurge(false, atmosphericRandom));
        }
    }
    
    if(background?.synoptic) advanceSynopticField(systemsObj,background);
    return systemsObj;
}

export function updateFrontalZone(pressureSystemsObj, month) {
    const list = Array.isArray(pressureSystemsObj) ? pressureSystemsObj : pressureSystemsObj.upper;
    
    // The public frontal-zone latitude is unsigned so the same transition
    // code works for north and south storms. Do not discard Southern
    // Hemisphere highs by filtering on raw (negative) latitude.
    const highs = list.filter(p => p.strength > 8 && Math.abs(p.y) > 10);
    if (highs.length === 0) return { latitude: 35 };
    
    const avgLat = highs.reduce((sum, p) => sum + Math.abs(p.y), 0) / highs.length;
    return { latitude: clamp(avgLat + 8, 32, 52) };
}

// A newly formed depression is a shallow, low-topped vortex advected mostly
// by the low-level flow; as convection organizes and the warm core builds,
// its circulation extends into the mid/upper troposphere and the deep-layer
// mean increasingly dominates its motion. Baroclinically supported stages
// (subtropical, transitioning, extratropical) are treated as already deep
// regardless of surface wind, since their steering is tied to the jet/trough
// pattern rather than to how strong the surface winds happen to be.
// Returns a 0 (shallow) .. 1 (deep, mature) factor.
export function getStormDepthFactor(cyclone) {
    if (!cyclone) return 0.65;
    if (cyclone.isExtratropical || cyclone.isTransitioning) return 0.9;
    const intensityDepth = smoothstep((cyclone.intensity - 25) / 55);
    const sizeDepth = smoothstep(((cyclone.circulationSize || 300) - 150) / 350);
    const subtropicalBoost = cyclone.isSubtropical ? 0.15 : 0;
    return clamp(0.30 + 0.45 * intensityDepth + 0.10 * sizeDepth + subtropicalBoost, 0.25, 0.95);
}

// Nine-point disk quadrature. The outer eight equal-area sectors are sampled
// at their area-centroid radius; Gaussian weights retain the inner circulation.
function steeringFootprint(lon, lat, size) {
    const radius = clamp(0.6 * (size || 300), 150, 500);
    const points = [{ lon, lat, weight: 1 / 9 }];
    for (let i = 0; i < 8; i++) {
        const angle = i * Math.PI / 4;
        const point = advectPosition(lon, lat, Math.sin(angle), Math.cos(angle), radius * 0.72 / 3.6);
        points.push({ ...point, weight: Math.exp(-(0.72 ** 2)) / 9 });
    }
    return points;
}

// Great-circle displacement; hours and m/s, safe at the dateline and poles.
function advectPosition(lon, lat, u, v, hours) {
    const distance = Math.hypot(u, v) * hours * 3600 / 6371000;
    const bearing = Math.atan2(u, v), phi = lat * Math.PI / 180;
    const nextPhi = Math.asin(clamp(Math.sin(phi) * Math.cos(distance)
        + Math.cos(phi) * Math.sin(distance) * Math.cos(bearing), -1, 1));
    const delta = Math.atan2(Math.sin(bearing) * Math.sin(distance) * Math.cos(phi),
        Math.cos(distance) - Math.sin(phi) * Math.sin(nextPhi));
    return { lon: normalizeLongitude(lon + delta * 180 / Math.PI), lat: nextPhi * 180 / Math.PI };
}

// Rotate a propagation vector toward the poleward side without changing its
// magnitude.  This is used for the broad recurvature belt where a TC begins
// to couple to the trough circulation before it is fully extratropical.
function rotateTowardPoleward(u, v, latitude, angleDegrees) {
    const polewardSign = Math.sign(latitude) || 1;
    const polewardV = v * polewardSign;
    const angle = angleDegrees * Math.PI / 180;
    const cosAngle = Math.cos(angle), sinAngle = Math.sin(angle);
    return {
        u: u * cosAngle - polewardV * sinAngle,
        v: (u * sinAngle + polewardV * cosAngle) * polewardSign
    };
}

export function calculateSteering(lon, lat, pressureSystemsObj, bias = { u: 0, v: 0 }, stormDepth = 0.65, cyclone = null) {
    const nativeField = pressureSystemsObj.upper?.some(c => c.role === 'height-background'
        && (Array.isArray(c.waves) || isModernAtmosphericBackground(c)));
    const layers = [{u:0,v:0}, {u:0,v:0}, {u:0,v:0}];
    let total = 0;
    for (const point of steeringFootprint(lon, lat, cyclone?.circulationSize)) {
        [850,500,200].forEach((level, index) => {
            const wind = level === 850 && !nativeField
                ? calculateLayerWind(point.lon, point.lat, pressureSystemsObj.lower)
                : gradientWind(point.lon, point.lat, (x,y) => getGeopotentialHeight500(x,y,pressureSystemsObj,level), 9.80665);
            layers[index].u += wind.u * point.weight;
            layers[index].v += wind.v * point.weight;
        });
        total += point.weight;
    }
    for (const layer of layers) { layer.u /= total; layer.v /= total; }
    // Intermediate levels are log-pressure interpolations, not independent
    // prognostic fields. This preserves the existing atmosphere and vertical tilt.
    const interpolate = (a,b,f) => ({u:a.u+(b.u-a.u)*f,v:a.v+(b.v-a.v)*f});
    const [low,mid,high] = layers;
    const winds = [low, interpolate(low,mid,Math.log(850/700)/Math.log(850/500)),
        mid, interpolate(mid,high,Math.log(500/300)/Math.log(500/200)), high];
    const weak = [.40,.30,.20,.08,.02], mature = [.15,.20,.30,.22,.13], extratropical = [.10,.15,.30,.25,.20];
    const depth = smoothstep((clamp(stormDepth,0,1)-.30)/.55);
    const transition = cyclone?.isExtratropical ? 1 : cyclone?.isTransitioning ? .5 : 0;
    let steerU = bias.u, steerV = bias.v;
    winds.forEach((wind,i) => {
        const weight = (weak[i]+depth*(mature[i]-weak[i]))*(1-transition)+extratropical[i]*transition;
        steerU += weight*wind.u; steerV += weight*wind.v;
    });
    // The resolved wave field is allowed to perturb tropical systems, but it
    // must not replace the basin-scale trade flow before the storm reaches
    // the subtropical baroclinic zone.  Blend toward the same zonal basic
    // state used to construct the QG height field; the taper is broad enough
    // to avoid an artificial 25N steering wall.
    const background = nativeField
        ? pressureSystemsObj.upper.find(c => c.role === 'height-background')
        : null;
    if (background && isModernAtmosphericBackground(background)
        && !cyclone?.isTransitioning && !cyclone?.isExtratropical) {
        const latitude = Math.abs(lat);
        const hemisphere = lat < 0 ? -1 : 1;
        const circulation = monthlyCirculation(
            background.calendarMonth,
            hemisphere,
            background.seasonalShift || 0
        );
        const tradeAnchor = zonalWindProfile(latitude, circulation.summer, 500, circulation);
        // Keep the tropical basic state present through the ridge belt.  A
        // short taper ending near 24N makes the mean track direction flip
        // abruptly at the same latitude for every storm; the real subtropical
        // transition is broad and individual systems still retain a poleward
        // beta component while crossing it.
        const tradeBlend = 0.52 * (1 - smoothstep((latitude - 8) / 30));
        steerU = steerU * (1 - tradeBlend) + tradeAnchor * tradeBlend;
        steerV *= 1 - 0.55 * tradeBlend;
    }
    const betaFactor = Math.sin(Math.min(Math.PI/2,1.2*Math.abs(lat*Math.PI/180)+Math.PI/12));
    // Keep beta propagation separate from the environmental field. Its
    // magnitude is intentionally independent of the footprint used to sample
    // that field, preserving a clean distinction between steering and vortex
    // propagation in diagnostics and forecast experiments.
    // Calibrated vortex beta drift.  It is deliberately modest compared with
    // the environmental flow, but it supplies the persistent poleward bias
    // that keeps tropical vortices from orbiting indefinitely in weak-flow
    // pockets and from forming an artificial low-latitude track reservoir.
    const sizeFactor = 0.75 + 0.45 * smoothstep(((cyclone?.circulationSize || 300) - 150) / 350);
    const persistentTropical = cyclone
        ? smoothstep(((cyclone.age || 0) - 72) / 120)
            * (1 - smoothstep((Math.abs(lat) - 8) / 14))
            * smoothstep((cyclone.intensity - 32) / 35)
        : 0;
    // Beta drift is a tropical-vortex propagation term, not an additional
    // midlatitude jet. Let it fade as the storm approaches the baroclinic
    // zone; otherwise its westward component needlessly cancels the resolved
    // westerlies just where a transitioning system should accelerate east.
    const betaEnvelope = 1 - smoothstep((Math.abs(lat) - 28) / 18);
    const tropicalBetaBoost = 0.70 * (1 - smoothstep((Math.abs(lat) - 18) / 18));
    const betaU = -1.05 * betaFactor * sizeFactor * betaEnvelope;
    const betaV = Math.sign(lat) * (2.55 * betaFactor * sizeFactor * (1 + tropicalBetaBoost)
        + 0.75 * persistentTropical) * betaEnvelope;
    // The ridge-edge meridional component is already present in the
    // gradient-wind field. Do not add a climatological poleward vector here:
    // doing so made a TC on the cold-surge trough's western flank turn north
    // even when all three resolved levels were carrying a southward flow.
    const ridgePolewardV = 0;
    // Recurvature is a vector rotation, not an instantaneous hand-off to the
    // full jet.  In the 22–38N transition belt, a tropical vortex is still
    // partly coupled to the ridge and its poleward motion. Rotate the
    // positive-U part of the environmental vector toward the poleward side
    // of the flow while preserving its magnitude; this changes direction,
    // not translation speed, and avoids a synthetic flat-east corridor.
    const turnBelt = smoothstep((Math.abs(lat) - 22) / 6)
        * (1 - smoothstep((Math.abs(lat) - 38) / 7));
    const tropicalTurnWeight = !cyclone
        ? 0
        : cyclone.isExtratropical
            ? 0
            : cyclone.isTransitioning ? .45 : 1;
    if (cyclone && steerU > 0 && tropicalTurnWeight > 0 && turnBelt > 0) {
        const rotated = rotateTowardPoleward(
            steerU,
            steerV,
            lat,
            25 * turnBelt * tropicalTurnWeight
        );
        steerU = rotated.u;
        steerV = rotated.v;
    }
    // No storm-specific cold-surge steering correction belongs here. The
    // same 850/500/200 geopotential field above is now the sole source of
    // environmental steering; any southwest motion must therefore come from
    // the diagnosed pressure gradients and the ordinary vortex terms.
    const coldSurgeImpact = getColdSurgeImpact(cyclone, pressureSystemsObj);
    return {steerU:steerU + betaU,
        steerV:steerV + betaV,
        environmentU:steerU, environmentV:steerV,
        lowU: low.u, lowV: low.v,
        midU: mid.u, midV: mid.v,
        highU: high.u, highV: high.v,
        shearU:high.u-low.u, shearV:high.v-low.v, betaU, betaV, ridgePolewardV,
        coldSurgeInfluence: coldSurgeImpact.influence,
        coldSurgeBlend: 0};
}

function motionResponseHours(cyclone, steering) {
    const size = smoothstep(((cyclone.circulationSize || 300)-100)/600);
    const strength = smoothstep((cyclone.intensity-25)/100);
    let hours = 1.5 + 5*size + 3*strength;
    // Compare environmental steering, not the lagging translation vector.
    // Ignore directions in near-calm flow where bearing is undefined.
    const history = cyclone.steeringHistory || [];
    let turn = 0;
    for (const old of history.slice(-2)) {
        const product = Math.hypot(old.u,old.v)*Math.hypot(steering.steerU,steering.steerV);
        if (Math.hypot(old.u,old.v)>1.5 && Math.hypot(steering.steerU,steering.steerV)>1.5) {
            turn = Math.max(turn, Math.acos(clamp((old.u*steering.steerU+old.v*steering.steerV)/product,-1,1))*180/Math.PI);
        }
    }
    hours += (3.5-hours)*smoothstep((turn-15)/20);
    return hours;
}

// A TC does not translate at the full instantaneous wind speed of a single
// pressure level.  The mismatch is small in the trades, but becomes severe
// when a synthetic wave produces a 40–60 kt jet vector.  Use a smooth,
// latitude- and stage-dependent response ceiling for the environmental target.
// The actual translation is still allowed to relax toward that target at its
// own response time; do not cap it a second time after inertia is applied.
function translationCeiling(cyclone, latitude) {
    const absLat = Math.abs(latitude);
    let maximum = 10
        + 5 * smoothstep((absLat - 22) / 12)
        + 4 * smoothstep((absLat - 35) / 15);
    if (cyclone?.isTransitioning) {
        maximum += 3.5;
    }
    if (cyclone?.isExtratropical) {
        maximum += 6;
    }
    return maximum;
}

function translationTarget(steering, cyclone, latitude) {
    const maximum = translationCeiling(cyclone, latitude);
    const speed = Math.hypot(steering.steerU, steering.steerV);
    if (speed <= maximum || speed < 1e-6) return steering;
    const scale = maximum * Math.tanh(speed / maximum) / speed;
    return {
        ...steering,
        steerU: steering.steerU * scale,
        steerV: steering.steerV * scale
    };
}

// Spatial midpoint integration with exact velocity relaxation at each stage.
// Weather is held at the supplied snapshot: sampling never advances its RNG.
export function integrateStormMotion(cyclone, systems, first, hours = MODEL_STEP_HOURS) {
    const tau = motionResponseHours(cyclone, first);
    const direction = cyclone.direction*Math.PI/180, speed = cyclone.speed/1.94384;
    const u0 = speed*Math.sin(direction), v0 = speed*Math.cos(direction);
    const relax = (u,v,targetU,targetV,t) => {
        const fraction = 1-Math.exp(-t/tau);
        return {u:u+(targetU-u)*fraction,v:v+(targetV-v)*fraction};
    };
    // Integrate the predictor velocity, avoiding an Euler displacement with the
    // already-relaxed end velocity when accelerating out of weak steering.
    const half = hours/2, average = tau/half*(1-Math.exp(-half/tau));
    const firstTarget = translationTarget(first, cyclone, cyclone.lat);
    const midpoint = advectPosition(cyclone.lon,cyclone.lat,
        firstTarget.steerU+(u0-firstTarget.steerU)*average,
        firstTarget.steerV+(v0-firstTarget.steerV)*average,half);
    const second = calculateSteering(midpoint.lon,midpoint.lat,systems,{u:0,v:0},getStormDepthFactor(cyclone),cyclone);
    const secondTarget = translationTarget(second, cyclone, midpoint.lat);
    // Keep the response-time lag in the realized motion.  In particular, do
    // not cap this relaxed velocity a second time: the target limiter belongs
    // to the environmental steering vector, while the inertia is what gives
    // recurvature its physically plausible speed evolution.
    const middleVelocity = relax(u0,v0,secondTarget.steerU,secondTarget.steerV,half);
    const position = advectPosition(cyclone.lon,cyclone.lat,middleVelocity.u,middleVelocity.v,hours);
    const velocity = relax(u0,v0,secondTarget.steerU,secondTarget.steerV,hours);
    return {...position,...velocity,tau};
}

function randomNormal() {
    return Math.sqrt(-2 * Math.log(Math.max(1e-9, Math.random())))
        * Math.cos(2 * Math.PI * Math.random());
}

// Operational center fixes are not the same thing as bulk vortex motion.
// Weak storms, subtropical/transitioning systems, and ERC phases can have an
// ambiguous or precessing LLCC, so successive fixes wander around a smoother
// dynamical center.  Model that as a bounded, autocorrelated position offset
// in local east/north kilometres.  The environmental trajectory remains the
// deterministic component passed through integrateStormMotion().
function evolveCenterFixOffset(cyclone) {
    const intensity = clamp(Number.isFinite(cyclone?.intensity) ? cyclone.intensity : 25, 10, 160);
    const size = clamp(cyclone?.circulationSize || 300, 100, 800);
    const weak = 1 - smoothstep((intensity - 25) / 55);
    const broad = 1 - smoothstep((size - 160) / 360);
    const structuralAmbiguity = cyclone?.isTransitioning || cyclone?.isExtratropical
        ? 1
        : cyclone?.isSubtropical
            ? 0.65
            : cyclone?.isERCActive || ['takeover', 'settling', 'aborting'].includes(cyclone?.ercState)
                ? 0.75
                : 0;

    // Stationary 1-sigma center-fix uncertainty.  These are deliberately
    // kilometre-scale offsets, not a random heading impulse: a mature,
    // compact TC stays coherent while a weak/ambiguous center visibly wobbles.
    const rawSigmaKm = 7
        + 22 * weak
        + 8 * broad
        + 18 * structuralAmbiguity;
    // A weak LLCC is still less certain than a mature vortex, but the prior
    // uncertainty was large enough to look like random track noise.  Reduce
    // the low-intensity component to 30% of its former amplitude and restore
    // the mature value smoothly as the circulation consolidates.
    const lowIntensityScale = .30 + .70 * smoothstep((intensity - 25) / 55);
    const sigmaKm = rawSigmaKm * lowIntensityScale;
    const retention = Math.exp(-MODEL_STEP_HOURS / 18);
    const innovation = Math.sqrt(1 - retention * retention) * sigmaKm;
    let east = retention * (cyclone?.centerFixOffsetEastKm || 0) + innovation * randomNormal();
    let north = retention * (cyclone?.centerFixOffsetNorthKm || 0) + innovation * randomNormal();

    // Bound the tails so center ambiguity cannot move a storm across a whole
    // synoptic feature or create an accidental landfall by itself.
    const maximum = 16 + 1.45 * sigmaKm;
    const magnitude = Math.hypot(east, north);
    if (magnitude > maximum) {
        const scale = maximum / magnitude;
        east *= scale;
        north *= scale;
    }
    return { east, north };
}

// Exact coastline checks are retained, but a conservative geographic index
// prevents every ocean sample from traversing the complete FeatureCollection.
// Buckets only reject features whose spherical d3.geoBounds cannot contain
// the query point; the final land/sea decision remains d3.geoContains.
const landFeatureIndexCache = new WeakMap();
const LAND_INDEX_CELL_DEGREES = 5;

function getLandFeatureIndex(world) {
    if (!world || !Array.isArray(world.features) || !globalThis.d3?.geoBounds) return null;
    const cached = landFeatureIndexCache.get(world);
    if (cached) return cached;

    const lonCells = Math.ceil(360 / LAND_INDEX_CELL_DEGREES);
    const latCells = Math.ceil(180 / LAND_INDEX_CELL_DEGREES);
    const buckets = new Map();
    const clampCell = (value, count) => clamp(value, 0, count - 1);
    const lonCell = lon => clampCell(
        Math.floor((clamp(lon, -180, 180) + 180) / LAND_INDEX_CELL_DEGREES),
        lonCells
    );
    const latCell = lat => clampCell(
        Math.floor((clamp(lat, -90, 90) + 90) / LAND_INDEX_CELL_DEGREES),
        latCells
    );
    const addRange = (feature, west, east, south, north) => {
        const x0 = lonCell(west), x1 = lonCell(east);
        const y0 = latCell(south), y1 = latCell(north);
        for (let y = y0; y <= y1; y++) {
            for (let x = x0; x <= x1; x++) {
                const key = y * lonCells + x;
                let bucket = buckets.get(key);
                if (!bucket) {
                    bucket = [];
                    buckets.set(key, bucket);
                }
                if (bucket[bucket.length - 1] !== feature && !bucket.includes(feature)) {
                    bucket.push(feature);
                }
            }
        }
    };
    const splitFeature = feature => {
        const geometry = feature?.geometry;
        if (!geometry) return [];
        if (geometry.type === 'MultiPolygon') {
            return geometry.coordinates.map(coordinates => ({
                type: 'Feature',
                properties: feature.properties || {},
                geometry: { type: 'Polygon', coordinates }
            }));
        }
        if (geometry.type === 'GeometryCollection') {
            return geometry.geometries.flatMap(child => splitFeature({
                type: 'Feature',
                properties: feature.properties || {},
                geometry: child
            }));
        }
        return [feature];
    };

    try {
        world.features.flatMap(splitFeature).forEach(feature => {
            const bounds = globalThis.d3.geoBounds(feature);
            if (!bounds || bounds.length !== 2) return;
            const west = bounds[0][0], south = bounds[0][1];
            const east = bounds[1][0], north = bounds[1][1];
            if (![west, south, east, north].every(Number.isFinite)) return;
            if (west <= east) {
                addRange(feature, west, east, south, north);
            } else {
                // d3 represents antimeridian-crossing bounds with west > east.
                addRange(feature, west, 180, south, north);
                addRange(feature, -180, east, south, north);
            }
        });
    } catch (error) {
        console.warn('Land feature index unavailable; using exact world scan.', error);
        return null;
    }

    const index = { buckets, lonCells, latCells };
    landFeatureIndexCache.set(world, index);
    return index;
}

function indexedGeoContains(world, lon, lat) {
    const exactContains = globalThis.d3?.geoContains;
    if (!exactContains || !world) return false;
    const index = getLandFeatureIndex(world);
    if (!index) return exactContains(world, [lon, lat]);

    const normalizedLon = normalizeLongitude(lon);
    const x = clamp(
        Math.floor((normalizedLon + 180) / LAND_INDEX_CELL_DEGREES),
        0,
        index.lonCells - 1
    );
    const y = clamp(
        Math.floor((clamp(lat, -90, 90) + 90) / LAND_INDEX_CELL_DEGREES),
        0,
        index.latCells - 1
    );
    const candidates = index.buckets.get(y * index.lonCells + x) || [];
    return candidates.some(feature => exactContains(feature, [normalizedLon, lat]));
}

function sampleTrackLandInteraction(startLon, startLat, endLon, endLat, world) {
    let lonDelta = endLon - startLon;
    if (lonDelta > 180) lonDelta -= 360;
    if (lonDelta < -180) lonDelta += 360;
    const pathLengthKm = calculateDistance(startLat, startLon, endLat, startLon + lonDelta);
    // Six-kilometre sampling resolves most islands represented by the map
    // data and is independent of the visible wind/map resolution.
    const segments = clamp(Math.ceil(pathLengthKm / 6), 2, 72);
    const samples = [];
    let firstLandfall = null;
    let previousLand = false;
    let landWeight = 0;
    let maxElevation = 0;
    let endpointStatus = { isLand: false, isNearLand: false };

    for (let index = 0; index <= segments; index++) {
        const fraction = index / segments;
        const lon = normalizeLongitude(startLon + lonDelta * fraction);
        const lat = startLat + (endLat - startLat) * fraction;
        const rasterStatus = getLandStatus(lon, lat, 0.08) || { isLand: false, isNearLand: false };
        let isLand = Boolean(rasterStatus.isLand);
        // The terrain raster is intentionally coarse. Use the already-loaded
        // coastline geometry as a second test so a fast three-hour step cannot
        // tunnel through a small island between two ocean endpoints.
        if (!isLand && world && globalThis.d3?.geoContains) {
            isLand = indexedGeoContains(world, lon, lat);
        }
        const elevation = isLand ? Math.max(0, getElevationAt(lon, lat) || 0) : 0;
        if (isLand && !previousLand && index > 0 && !firstLandfall) {
            firstLandfall = { lon, lat };
        }
        const trapezoidWeight = index === 0 || index === segments ? 0.5 : 1;
        if (isLand) landWeight += trapezoidWeight;
        maxElevation = Math.max(maxElevation, elevation);
        previousLand = isLand;
        endpointStatus = {
            isLand,
            isNearLand: Boolean(rasterStatus.isNearLand)
        };
        samples.push(isLand);
    }

    return {
        landFraction: clamp(landWeight / segments, 0, 1),
        maxElevation,
        endpointIsLand: endpointStatus.isLand,
        endpointIsNearLand: endpointStatus.isNearLand,
        crossedLand: samples.some(Boolean),
        firstLandfall
    };
}

export function updateCycloneState(cyclone, pressureSystems, frontalZone, world, month, globalTemp, globalShearSetting, heatDistribution = 50, nameIndex) {
    let updatedCyclone = { ...cyclone };
    updatedCyclone.isRapidIntensifying = false;
    updatedCyclone.age += 3;
    updatedCyclone.rmw = Number.isFinite(updatedCyclone.rmw)
        ? updatedCyclone.rmw
        : fallbackRmwFromSize(updatedCyclone.circulationSize);
    updatedCyclone.outerWindBroadness = Number.isFinite(updatedCyclone.outerWindBroadness)
        ? clamp(updatedCyclone.outerWindBroadness, 0, 1)
        : 0.08 + 0.92 * Math.pow(Math.random(), 0.65);
    updatedCyclone.ercPotential = Number.isFinite(updatedCyclone.ercPotential) ? updatedCyclone.ercPotential : 0;
    updatedCyclone.ercEligibleHours = Number.isFinite(updatedCyclone.ercEligibleHours)
        ? updatedCyclone.ercEligibleHours
        : 0;
    updatedCyclone.ercCycleCount = Number.isFinite(updatedCyclone.ercCycleCount)
        ? updatedCyclone.ercCycleCount
        : 0;
    updatedCyclone.ercCooldownUntil = Number.isFinite(updatedCyclone.ercCooldownUntil) ? updatedCyclone.ercCooldownUntil : 0;
    // Migrate saves made by the former timer-only weakening/recovery model.
    if (!updatedCyclone.isERCActive && ['weakening', 'recovering'].includes(updatedCyclone.ercState)) {
        updatedCyclone.ercState = 'none';
    }
    const hasValidEyewallState = Number.isFinite(updatedCyclone.ercInnerRmw)
        && Number.isFinite(updatedCyclone.ercInnerWind)
        && Number.isFinite(updatedCyclone.ercOuterRmw)
        && Number.isFinite(updatedCyclone.ercOuterWindAnomaly);
    if (updatedCyclone.isERCActive && !hasValidEyewallState) {
        clearEyewallStructure(updatedCyclone, 'interrupted');
    }

    // --- ACE Calculation ---
    if (updatedCyclone.age % 6 === 0 && updatedCyclone.intensity >= 34 && !updatedCyclone.isExtratropical) {
        const ace_contribution = (updatedCyclone.intensity ** 2) / 10000;
        updatedCyclone.ace += ace_contribution;
    }

    if (updatedCyclone.isMonsoonDepression && updatedCyclone.age >= updatedCyclone.monsoonDepressionEndTime) {
        updatedCyclone.isMonsoonDepression = false;
    }

    // --- Steering ---
    // Remove the previous operational-fix offset before advancing the smooth
    // dynamical center.  Otherwise a center-fix error would accumulate as a
    // false environmental displacement over the storm's whole lifetime.
    const previousFixOffset = {
        east: cyclone.centerFixOffsetEastKm || 0,
        north: cyclone.centerFixOffsetNorthKm || 0
    };
    const dynamicalStart = advectPosition(
        cyclone.lon,
        cyclone.lat,
        -previousFixOffset.east * 1000,
        -previousFixOffset.north * 1000,
        1 / 3600
    );
    const dynamicalCyclone = { ...cyclone, lon: dynamicalStart.lon, lat: dynamicalStart.lat };
    const steering = calculateSteering(
        dynamicalStart.lon,
        dynamicalStart.lat,
        pressureSystems,
        { u: 0, v: 0 },
        getStormDepthFactor(cyclone),
        dynamicalCyclone
    );
    const { shearU, shearV } = steering;
    updatedCyclone.steeringU = steering.steerU;
    updatedCyclone.steeringV = steering.steerV;
    updatedCyclone.lowLevelU = steering.lowU;
    updatedCyclone.lowLevelV = steering.lowV;
    let motion = integrateStormMotion(dynamicalCyclone, pressureSystems, steering);
    const nextFixOffset = evolveCenterFixOffset(cyclone);
    const fixedPosition = advectPosition(
        motion.lon,
        motion.lat,
        nextFixOffset.east * 1000,
        nextFixOffset.north * 1000,
        1 / 3600
    );
    motion = { ...motion, lon: fixedPosition.lon, lat: fixedPosition.lat };
    updatedCyclone.centerFixOffsetEastKm = nextFixOffset.east;
    updatedCyclone.centerFixOffsetNorthKm = nextFixOffset.north;
    const trackLand = sampleTrackLandInteraction(
        cyclone.lon,
        cyclone.lat,
        motion.lon,
        motion.lat,
        world
    );
    // Every environmental diagnostic below belongs to the new valid time.
    // Previously lon/lat were updated only after intensity, producing a
    // systematic one-step landfall lag.
    updatedCyclone.lon = motion.lon;
    updatedCyclone.lat = motion.lat;
    updatedCyclone.landExposure = trackLand.landFraction;
    if (trackLand.firstLandfall) {
        updatedCyclone.landfallEvent = {
            age: updatedCyclone.age,
            lon: trackLand.firstLandfall.lon,
            lat: trackLand.firstLandfall.lat
        };
    }
    const physicalShear = Math.hypot(shearU, shearV) * 1.94384;
    const coldSurgeImpact = getColdSurgeImpact(updatedCyclone, pressureSystems);

    // Wind shear is diagnosed only from the resolved 850/200-hPa winds.
    // Cold-surge influence changes those winds through the shared height
    // field; it is not added again as a separate intensity penalty.
    let totalShear = physicalShear * (globalShearSetting / 100.0);
    const isWinterHalf = (month >= 11 || month <= 4);
    const shearEventProb = (isWinterHalf && updatedCyclone.lon > 100 && updatedCyclone.lon < 121 && updatedCyclone.lat > 16) ? 0.55 : (isWinterHalf ? 0.045 * (globalShearSetting ** 2 / 10000) : 0.03 * (globalShearSetting ** 2 / 10000));
    // Random shear event
    if (updatedCyclone.shearEventActive) {
        if (updatedCyclone.age >= updatedCyclone.shearEventEndTime) {
            updatedCyclone.shearEventActive = false;
            updatedCyclone.shearEventMagnitude = 0;
        } else {
            totalShear += Math.max(0, updatedCyclone.shearEventMagnitude);
        }
    } else if (Math.random() < shearEventProb && !updatedCyclone.isTransitioning) {
        updatedCyclone.shearEventActive = true;
        updatedCyclone.shearEventEndTime = updatedCyclone.age + (1 + Math.random()*48);
        updatedCyclone.shearEventMagnitude = -3 + Math.random() * 6 + 1.8 * Math.abs(month - 8) ** 0.5 + Math.max(0,(globalShearSetting / 10 - 10));
    }
    updatedCyclone.totalShear = totalShear;
    const shearResponseHours = 15;
    const shearRelax = 1 - Math.exp(-MODEL_STEP_HOURS / shearResponseHours);
    updatedCyclone.effectiveShear = Number.isFinite(updatedCyclone.effectiveShear)
    ? updatedCyclone.effectiveShear + (totalShear - updatedCyclone.effectiveShear) * shearRelax
    : totalShear;

    updatedCyclone.direction = (Math.atan2(motion.u,motion.v)*180/Math.PI+360)%360;
    updatedCyclone.speed = Math.hypot(motion.u,motion.v)*1.94384;
    updatedCyclone.motionResponseHours = motion.tau;
    updatedCyclone.steeringHistory = [...(cyclone.steeringHistory || []).slice(-1),
        {u:steering.steerU,v:steering.steerV}];

    // Cold welling
    if (updatedCyclone.speed < 7) {
        const coolingRate = (7 - updatedCyclone.speed) / 7 * 0.25; 
        updatedCyclone.upwellingCoolingEffect = Math.min(updatedCyclone.upwellingCoolingEffect + coolingRate, 5.0); 
    } else {
        updatedCyclone.upwellingCoolingEffect = Math.max(updatedCyclone.upwellingCoolingEffect - 0.2, 0); 
    }

    let sst = getSST(updatedCyclone.lat, updatedCyclone.lon, month, globalTemp);
    const surgeCoolingResponse = 1 - Math.exp(-MODEL_STEP_HOURS / 18);
    const previousSurgeCooling = Number.isFinite(updatedCyclone.coldSurgeCoolingEffect)
        ? updatedCyclone.coldSurgeCoolingEffect : 0;
    updatedCyclone.coldSurgeCoolingEffect = previousSurgeCooling
        + (coldSurgeImpact.sstCooling - previousSurgeCooling) * surgeCoolingResponse;
    updatedCyclone.coldSurgeInfluence = coldSurgeImpact.influence;
    updatedCyclone.coldSurgeShearBoost = 0;
    sst -= updatedCyclone.upwellingCoolingEffect + updatedCyclone.coldSurgeCoolingEffect;
    
    const etEnvironment = transitionEnvironment(updatedCyclone, pressureSystems, frontalZone, totalShear);
    updatedCyclone.baroclinicSupport = etEnvironment.support;
    advanceExtratropicalTransition(updatedCyclone, etEnvironment, sst, totalShear);

    const oldIntensity = updatedCyclone.intensity;
    const ercStateBeforeIntensity = updatedCyclone.ercState || 'none';
    let intensityPath = 'tropical';
    let thermodynamicMpiDiagnostic = null;
    let structuralMpiDiagnostic = null;
    let baseIntensityChangeDiagnostic = null;
    let sizeShearResistance = 1;
    const terrainElevation = Math.max(
        trackLand.maxElevation,
        getElevationAt(updatedCyclone.lon, updatedCyclone.lat) || 0
    );
    const landStatus = getLandStatus(updatedCyclone.lon, updatedCyclone.lat, 0.2);
    const isOverLand = trackLand.endpointIsLand || landStatus.isLand;
    const isNearLand = landStatus.isNearLand;
    const landInteraction = trackLand.landFraction > 0;

    updatedCyclone.isLand = isOverLand;
    if (landInteraction || isOverLand || isNearLand) updatedCyclone.riUntil = 0;

    // --- Intensity Change ---
    
    // 1. Land decay. Apply a continuous time tendency proportional to the
    // fraction of this three-hour trajectory spent over land. This resolves
    // islands without turning one terrain sample into a 50–70 kt cliff.
    if (landInteraction || isOverLand) {
        intensityPath = terrainElevation > 80 ? 'terrain' : 'land';
        const sizeResistance = 0.80
            + 0.45 * smoothstep(((updatedCyclone.circulationSize || 300) - 150) / 500);
        const terrainSeverity = smoothstep(terrainElevation / 900);
        const japanRetention = updatedCyclone.lat >= 30 && updatedCyclone.lat <= 40
            && updatedCyclone.lon >= 129 && updatedCyclone.lon <= 140 ? 1.18 : 1;
        const decayTimeHours = clamp(
            (23 - 7 * terrainSeverity) * sizeResistance * japanRetention,
            8,
            28
        );
        const effectiveExposure = Math.max(trackLand.landFraction, isOverLand ? 0.35 : 0);
        const retention = Math.exp(-MODEL_STEP_HOURS * effectiveExposure / decayTimeHours);
        updatedCyclone.intensity *= retention;
        updatedCyclone.speed *= 1 - 0.01 * effectiveExposure;

    } else if (updatedCyclone.isExtratropical) {
        intensityPath = 'extratropical';
        updatedCyclone.speed += 1.5; 
        if (updatedCyclone.extratropicalStage === 'developing') {
            if (updatedCyclone.age >= updatedCyclone.extratropicalDevelopmentEndTime || etEnvironment.support < 0.15) {
                updatedCyclone.extratropicalStage = 'decaying';
                const decayRate = -6 + Math.random() * 6; 
                updatedCyclone.intensity += decayRate;
            } else {
                const divisor = 9 + Math.random() * 5; 
                const target = Math.min(updatedCyclone.extratropicalMaxIntensity, 45 + 50 * etEnvironment.support);
                const intensification = clamp((target - updatedCyclone.intensity) / divisor, -4, 1.5);
                updatedCyclone.intensity += intensification;
            }
        } else { 
            const decayRate = -1 - Math.random() * 2; 
            updatedCyclone.intensity += decayRate;
        }

    } else {
        // MPI Logic
        const heat = Math.max(0, Math.min(100, heatDistribution));
        const thermodynamicMpi = stormThermodynamicMpi(sst, heat, updatedCyclone.isSubtropical);
        const mpi = adjustMpiForStormStructure(thermodynamicMpi, updatedCyclone);
        thermodynamicMpiDiagnostic = thermodynamicMpi;
        structuralMpiDiagnostic = mpi;

        // Growth Rate Logic
        let latF = (0.4 / Math.max(5, Math.abs(updatedCyclone.lat)) ** 2) * (updatedCyclone.intensity / 50);
        let intensificationRate = Math.max(0, Math.random() * 0.14 * Math.min(1, ((updatedCyclone.intensity - 13) / 65)) - latF);


        if (updatedCyclone.isMonsoonDepression) {
            intensificationRate *= (Math.random() + 0.10) * 0.70; 
        }
        
        let potentialChange = (mpi - updatedCyclone.intensity) * intensificationRate;
        
        let shear = Math.max(0, updatedCyclone.effectiveShear - 8) / 10.0; 
        
        // Latitude and season already enter the three-dimensional environmental field.
        // Do not add a second, hidden climatological shear penalty here.

        // Dry Air Logic
        const samplingRadiusDeg = cyclone.circulationSize * 0.005;
        let envHumiditySum = 0;
        let minEnvHumidity = 60;
        const samplePoints = 12; 
        for (let i = 0; i < samplePoints; i++) {
            const angleRad = (i / samplePoints) * 2 * Math.PI;
            const sampleLon = cyclone.lon + samplingRadiusDeg * Math.cos(angleRad) / Math.cos(cyclone.lat * Math.PI / 180);
            const sampleLat = cyclone.lat + samplingRadiusDeg * Math.sin(angleRad);
            const val = calculateBackgroundHumidity(sampleLon, sampleLat, pressureSystems, month, cyclone, globalTemp);
            envHumiditySum += val;
            if (val < minEnvHumidity) minEnvHumidity = val;
        }
        const avgEnvHumidity = envHumiditySum / samplePoints;
        const effectiveHumidity = (minEnvHumidity * 0.4) + (avgEnvHumidity * 0.6);
        intensificationRate = rapidIntensificationRate(updatedCyclone, mpi, sst, totalShear, effectiveHumidity, intensificationRate);
        potentialChange = (mpi - updatedCyclone.intensity) * intensificationRate;
        if (updatedCyclone.isRapidIntensifying) potentialChange = Math.min(12, potentialChange);
        let dryAirFactor = 0;
        if (effectiveHumidity < 60) {
            const sizeSensitivity = Math.max(0, 600 - cyclone.circulationSize); 
            dryAirFactor = (60 - effectiveHumidity) * 0.0002 * sizeSensitivity;
        }
        const currentSize = updatedCyclone.circulationSize || 300;
        const clampedSize = Math.max(150, Math.min(500, currentSize));
        // Shear resistance is not identical across all tropical vortices.
        // Broad, vertically coherent circulations retain convection and
        // recover their alignment more effectively than small, shallow
        // disturbances.  Use a smooth scale response rather than a hard
        // category switch: the penalty is about 1.20x for a 150-km system,
        // about 0.95x near 300 km, and bottoms near 0.55x by 500 km.  This
        // reduces vulnerability without pretending that a large storm is
        // immune to a persistent hostile shear vector.
        const sizeMaturity = smoothstep((clampedSize - 150) / (500 - 150));
        sizeShearResistance = 1.20 - 0.65 * sizeMaturity;
        const shearSensitivity = updatedCyclone.isSubtropical ? 0.75 : 1;
        const environmentalLosses = sizeShearResistance * shear * shearSensitivity + dryAirFactor;
        const tropicalChange = potentialChange - environmentalLosses;
        const thermalChange = updatedCyclone.isSubtropical
            ? subtropicalIntensityChange(updatedCyclone.intensity, tropicalChange, sst,
                effectiveHumidity, totalShear, environmentalLosses, etEnvironment.trough)
            : tropicalChange;
        const baseIntensityChange = updatedCyclone.isTransitioning
            ? transitionIntensityChange(updatedCyclone.intensity, thermalChange, etEnvironment.support, updatedCyclone.transitionHours)
            : thermalChange;
        baseIntensityChangeDiagnostic = baseIntensityChange;
        if (updatedCyclone.isTransitioning) intensityPath = 'transitioning';
        else if (updatedCyclone.isERCActive) intensityPath = `erc-${updatedCyclone.ercState || 'active'}`;
        const ercEnvironment = {
            mpi,
            totalShear,
            effectiveHumidity,
            isOverLand,
            baseIntensityChange
        };

        if (updatedCyclone.isERCActive) {
            evolveEyewallReplacement(updatedCyclone, ercEnvironment);
        } else {
            updatedCyclone.intensity += baseIntensityChange;
            // This call accumulates structural favourability and may seed an
            // outer eyewall; its intensity evolution begins on the next step.
            evolveEyewallReplacement(updatedCyclone, ercEnvironment, false);
        }
    }

    // Tropical conversion needs sustained warm-water convection, not simply an age timer.
    if (updatedCyclone.isSubtropical) {
        updatedCyclone.subtropicalWarmHours = Math.max(0, (updatedCyclone.subtropicalWarmHours || 0)
            + (!isOverLand && !updatedCyclone.isTransitioning && sst >= 26 && totalShear < 20 ? MODEL_STEP_HOURS : -MODEL_STEP_HOURS));
        const requiredWarmHours = Math.max(24, updatedCyclone.subtropicalTransitionTime || 48);
        if (updatedCyclone.subtropicalWarmHours >= requiredWarmHours || updatedCyclone.isExtratropical) {
            updatedCyclone.isSubtropical = false;
        }
    }

    // Land interaction and structural transition disrupt both eyewalls.  Keep
    // a short-lived decaying outer ring over land, but remove the tropical
    // double-eyewall structure immediately after extratropical transition.
    if (updatedCyclone.isERCActive && updatedCyclone.isExtratropical) {
        updatedCyclone.rmw = updatedCyclone.ercInnerRmw;
        clearEyewallStructure(updatedCyclone, 'interrupted');
    } else if (updatedCyclone.isERCActive && (landInteraction || isOverLand || updatedCyclone.isTransitioning)) {
        updatedCyclone.ercState = 'aborting';
        updatedCyclone.ercAdverseHours = Math.max(18, updatedCyclone.ercAdverseHours || 0);
        updatedCyclone.ercInnerWind = Math.min(updatedCyclone.ercInnerWind, updatedCyclone.intensity);
        const structuralExposure = Math.max(trackLand.landFraction, isOverLand ? 0.35 : 0);
        updatedCyclone.ercOuterWindAnomaly *= Math.exp(
            -MODEL_STEP_HOURS * structuralExposure / ERC_ABORT_ADVERSE_DECAY_HOURS
        );
        const disruptedStructure = getEyewallStructure(updatedCyclone);
        // Land can only weaken the scalar maximum on this step. Synchronize
        // both rings to it so the old outer-eyewall state cannot restore a
        // 120 kt maximum immediately after a 64 kt terrain sample.
        updatedCyclone.intensity = Math.min(updatedCyclone.intensity, disruptedStructure.peakWind);
        updatedCyclone.ercInnerWind = Math.min(updatedCyclone.ercInnerWind, updatedCyclone.intensity);
        if (disruptedStructure.outerPeak > updatedCyclone.intensity) {
            updatedCyclone.ercOuterWindAnomaly = Math.max(
                0,
                updatedCyclone.ercOuterWindAnomaly
                    - (disruptedStructure.outerPeak - updatedCyclone.intensity)
            );
        }
        updatedCyclone.ercOuterShare = disruptedStructure.outerShare;
        if (updatedCyclone.ercOuterWindAnomaly < 0.8) {
            updatedCyclone.rmw = updatedCyclone.ercInnerRmw;
            updatedCyclone.ercCooldownUntil = updatedCyclone.age + 12 + Math.random() * 12;
            clearEyewallStructure(updatedCyclone, 'aborted');
        }
    }

    const intensityDiagnostic = {
        age: updatedCyclone.age,
        before: oldIntensity,
        after: updatedCyclone.intensity,
        change: updatedCyclone.intensity - oldIntensity,
        path: intensityPath,
        totalShear,
        effectiveShear: updatedCyclone.effectiveShear,
        coldSurgeInfluence: updatedCyclone.coldSurgeInfluence,
        coldSurgeCooling: updatedCyclone.coldSurgeCoolingEffect,
        coldSurgeShearBoost: updatedCyclone.coldSurgeShearBoost,
        sst,
        thermodynamicMpi: thermodynamicMpiDiagnostic,
        structuralMpi: structuralMpiDiagnostic,
        sizeShearResistance,
        baseIntensityChange: baseIntensityChangeDiagnostic,
        ercStateBefore: ercStateBeforeIntensity,
        ercStateAfter: updatedCyclone.ercState || 'none',
        ercMpiCeiling: Number.isFinite(updatedCyclone.ercMpiCeiling) ? updatedCyclone.ercMpiCeiling : null
    };
    updatedCyclone.lastIntensityDiagnostic = intensityDiagnostic;
    if (intensityDiagnostic.change <= -12) {
        updatedCyclone.intensityEvents = [
            ...(Array.isArray(updatedCyclone.intensityEvents) ? updatedCyclone.intensityEvents.slice(-19) : []),
            intensityDiagnostic
        ];
    }

    const intensityChange = updatedCyclone.intensity - oldIntensity;
    const canPostRelaxSize = !updatedCyclone.isERCActive
        && updatedCyclone.age > (updatedCyclone.ercCompletedAt || 0)
        && updatedCyclone.age <= (updatedCyclone.ercPostSizeRelaxUntil || 0)
        && Number.isFinite(updatedCyclone.ercPostSizeTarget)
        && !isOverLand
        && !updatedCyclone.isTransitioning
        && !updatedCyclone.isExtratropical;
    if (landInteraction || isOverLand) {
        expandRmwOverLand(updatedCyclone, terrainElevation);
        // Decay the broad envelope over hours, preserving residual winds and
        // avoiding both mountain-driven inflation and an instantaneous cutoff.
        const envelopeExposure = Math.max(trackLand.landFraction, isOverLand ? 0.35 : 0);
        updatedCyclone.circulationSize *= Math.exp(
            -MODEL_STEP_HOURS * envelopeExposure / (updatedCyclone.isExtratropical ? 96 : 48)
        );
    } else if (updatedCyclone.isExtratropical || updatedCyclone.isTransitioning) {
        updatedCyclone.circulationSize *= 1.04;
        updatedCyclone.rmw *= 1.03;
    } else if (updatedCyclone.isERCActive || updatedCyclone.ercCompletedAt === updatedCyclone.age) {
        // ERC structure already controls size and RMW for this step.
    } else if (canPostRelaxSize) {
        // The newly dominant outer eyewall contracts faster than the broader
        // wind envelope.  Leave both dimensions to their explicit post-ERC
        // relaxation paths rather than the generic intensity-size tendency.
    } else if (intensityChange > 0.5) {
        updatedCyclone.circulationSize *= 0.99;
        updatedCyclone.rmw *= (Math.random()*0.03 + 0.97);
    } else {
        updatedCyclone.circulationSize *= 1.002;
        updatedCyclone.rmw *= 1.001;
    }

    if (canPostRelaxSize) {
        const relaxationHours = Math.max(24, updatedCyclone.ercPostSizeRelaxHours || 72);
        const relaxationRate = clamp(MODEL_STEP_HOURS / relaxationHours * 3.2, 0.055, 0.14);
        updatedCyclone.circulationSize += (
            updatedCyclone.ercPostSizeTarget - updatedCyclone.circulationSize
        ) * relaxationRate;
    } else if (updatedCyclone.age > (updatedCyclone.ercPostSizeRelaxUntil || 0)) {
        updatedCyclone.ercPostSizeTarget = null;
    }

    const canPostContract = !updatedCyclone.isERCActive
        && updatedCyclone.age > (updatedCyclone.ercCompletedAt || 0)
        && updatedCyclone.age <= (updatedCyclone.ercPostContractionUntil || 0)
        && Number.isFinite(updatedCyclone.ercPostRmwTarget)
        && !isOverLand
        && !updatedCyclone.isTransitioning
        && !updatedCyclone.isExtratropical;
    if (canPostContract && updatedCyclone.rmw > updatedCyclone.ercPostRmwTarget + 0.5) {
        const priorRmw = updatedCyclone.rmw;
        const contractionRate = 0.12 + 0.10 * smoothstep((updatedCyclone.intensity - 70) / 70);
        updatedCyclone.rmw += (updatedCyclone.ercPostRmwTarget - updatedCyclone.rmw) * contractionRate;
        const priorRadarScale = Number.isFinite(updatedCyclone.radarRmwScale)
            ? updatedCyclone.radarRmwScale
            : 1;
        updatedCyclone.radarRmwScale = clamp(
            priorRadarScale * updatedCyclone.rmw / Math.max(1, priorRmw),
            0.35,
            3.2
        );
    } else if (updatedCyclone.age > (updatedCyclone.ercPostContractionUntil || 0)) {
        updatedCyclone.ercPostRmwTarget = null;
    }
    if (!updatedCyclone.isERCActive
        && Number.isFinite(updatedCyclone.radarEyewallMaturity)
        && updatedCyclone.radarEyewallMaturity < 1) {
        updatedCyclone.radarEyewallMaturity = Math.min(1, updatedCyclone.radarEyewallMaturity + 0.08);
    }
    updatedCyclone.circulationSize = Math.max(100, Math.min(updatedCyclone.circulationSize, 800));
    updatedCyclone.rmw = clamp(updatedCyclone.rmw, MIN_RMW_KM, 190);
    updatedCyclone.intensity = Math.max(10, updatedCyclone.intensity);
    
    const currentEnvPressure = getPressureAt(updatedCyclone.lon, updatedCyclone.lat, pressureSystems);
    const previousCentralPressure = Number.isFinite(cyclone.centralPressure)
        ? cyclone.centralPressure : null;
    const currentCentralPressure = windToPressure(
        updatedCyclone.intensity, 
        updatedCyclone.circulationSize, 
        updatedCyclone.basin, 
        currentEnvPressure
    );
    updatedCyclone.environmentalPressure = currentEnvPressure;
    updatedCyclone.centralPressure = currentCentralPressure;
    updatedCyclone.pressureTendency = previousCentralPressure === null
        ? 0
        : (currentCentralPressure - previousCentralPressure) / MODEL_STEP_HOURS;

    applyCalculatedWindRadii(
        updatedCyclone,
        calculateWindRadii(updatedCyclone, pressureSystems, month)
    );
    const normalizeRadii = radii => Array.isArray(radii) && radii.length === 4
        ? radii
        : [0, 0, 0, 0];
    const radii34 = normalizeRadii(updatedCyclone.r34);
    const radii50 = normalizeRadii(updatedCyclone.r50);
    const radii64 = normalizeRadii(updatedCyclone.r64);
    updatedCyclone.track.push([updatedCyclone.lon, updatedCyclone.lat, updatedCyclone.intensity, updatedCyclone.isTransitioning, updatedCyclone.isExtratropical, updatedCyclone.circulationSize, updatedCyclone.isSubtropical, radii34, radii50, radii64, Math.round(currentCentralPressure)]);

    if (updatedCyclone.intensity < 17 || (updatedCyclone.isExtratropical && updatedCyclone.intensity < 24) || updatedCyclone.lat > 70 || updatedCyclone.lat < -70) {
        updatedCyclone.status = 'dissipated';
    }
    
    if (!updatedCyclone.named && updatedCyclone.intensity >= 34 && !updatedCyclone.isExtratropical) {
        updatedCyclone.named = true;
        const basinKey = updatedCyclone.basin || 'WPAC';
        const list = NAME_LISTS[basinKey] || NAME_LISTS['WPAC'];
        const safeIndex = nameIndex % list.length;
        updatedCyclone.name = list[safeIndex];
        console.log(`System upgraded to Tropical Storm ${updatedCyclone.name} (${basinKey})`);
    }
    
    return updatedCyclone;
}
